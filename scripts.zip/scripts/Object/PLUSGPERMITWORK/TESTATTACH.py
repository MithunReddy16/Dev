#------------------------------------------------------------------------
#STPSCRIPT
#Script Name :DM_EMAILPTW_ACTION
#Description :script to generate PTW report and send it to the ptw requestor
#Comment     :Used in STP Work Order 
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          20-May-2025         Initiate version.
#---------------------------------------------------------------------------------------------

from psdi.server import MXServer
from psdi.util import MXApplicationException
from java.util import HashMap
from java.io import File
from java.io import FileOutputStream
from com.ibm.tivoli.maximo.report.birt.runtime import ReportParameterData
from com.ibm.tivoli.maximo.report.birt.admin import ReportAdminService


def generatePTWReport(ptwNo,thirdParty,userInfo):
        
    
    reportName = "DM_PTW.rptdesign"#"DM_PTW_InHouse.rptdesign"   # Your BIRT report name
    if  thirdParty:
        reportName = "DM_PTW.rptdesign"#"DM_PTW_Contractors.rptdesign"
    appName = "DM_PLUSGPTW"                # Application
    outputFormat = "pdf"               # pdf / xls / doc
    emailTo = userInfo.getEmail()
    subject = "Permit to Work#"+" "+ptwNo
    message = "Please find the attached report."
    #ccEmail =  getEmailCC(ptwNo,userInfo)
    whereClause ="PERMITWORKNUM ='"+ptwNo+"'"
    
    mxServer = MXServer.getMXServer()
    reportService = mxServer.lookup("BIRTREPORT")
   
    # Parameters map
    params = ReportParameterData()
    params.addParameter("where", whereClause)
    additionMap = HashMap<>()
    
    # Generate report file
    print("Generating report...")
    
    reportBytes = reportService.runReport(
        userInfo,
        reportName,
        appName,
        params,
        "Permit to Work#"+" "+ptwNo+".pdf",
        outputFormat
    )
    
    if reportBytes is None:
        raise MXApplicationException("report", "Report generation failed")
    
    docTypeSet = mxServer.getMboSet("DOCTYPES", userInfo)
    docTypeSet.setWhere("doctype = 'Attachments'")
    docTypeSet.reset()
    docTypeMbo = docTypeSet.getMbo(0)
    basePath = docTypeMbo.getString("DEFAULTFILEPATH")
    # ==== SAVE FILE ====
    outputFile = basePath+"/Permit to Work#"+ptwNo+".pdf"
    fileObj = File(outputFile)
    
    fos = FileOutputStream(fileObj)
    fos.write(reportBytes)
    fos.close()
    attachPTW(outputFile,userInfo)
    
    print("Report saved to: " + outputFile)
    
    # ==== SEND EMAIL ====

    # Send email with attachment
    '''mxServer.sendEMail(
        emailTo,
        None,              # CC
        None,              # BCC
        "maxadmin@dm.ae", # from
        subject,
        message,
        None,
        [fileObj.getAbsolutePath()],
        None               # Reply-to
    )'''
    
    #if fileObj.exists():
    #    fileObj.delete()

def getEmailCC(ptwNo,userInfo):
    ccEmailAddress =""
    mxServer = MXServer.getMXServer()
    ptwSet = mxServer.getMboSet("PLUSGPERMITWORK",userInfo)
    ptwSet.setWhere("PERMITWORKNUM='"+ptwNo+"' and siteid='DM'")
    ptwSet.reset()
    ptwMbo = ptwSet.getMbo(0)
    if ptwMbo is not None:
        emailSet = ptwMbo.getMboSet("DM_EMAILS&&","EMAIL","(personid in ( select personid from PLUSGPERWORKREV where plusgpermitworkid = :plusgpermitworkid)) or (personid in ( select personid from PLUSGPERWORKISS where plusgpermitworkid = :plusgpermitworkid))")
        emailSet.reset()
        ccEmailAddress =""
        emailMbo =emailSet.moveFirst()
        f = False
        while emailMbo:
            if not f:
                ccEmailAddress = emailMbo.getString("EMAILADDRESS")
                f = True
            else:
                ccEmailAddress = ccEmailAddress+","+ emailMbo.getString("EMAILADDRESS") 
            emailMbo =emailSet.moveNext()
    
    return ccEmailAddress
    
    
def getPTWMbo(ptwNo):
    mxServer = MXServer.getMXServer()
    ptwSet = mxServer.getMboSet("Script to run report and save as attachment",userInfo)
    ptwSet.setWhere("PERMITWORKNUM='"+ptwNo+"' and siteid='DM'")
    ptwSet.reset()
    return ptwSet.getMbo(0)
    

def attachPTW(fullFilePath,userInfo):
    #woMboSet = mbo.getMboSet("PLUSGWORKORDER")
    #woMbo = woMboSet.getMbo(0)
    doclinksMboSet = mbo.getMboSet("DOCLINKS")

    doclinksMbo = doclinksMboSet.add()
    
    doclinksMbo.setValue("URLTYPE", "FILE")
    doclinksMbo.setValue("URLNAME", fullFilePath)
    doclinksMbo.setValue("NEWURLNAME", fullFilePath)
    doclinksMbo.setValue("DOCTYPE", "Attachments"  )
    doclinksMbo.setValue("ADDINFO", True)
    doclinksMbo.setValue("DESCRIPTION", "PTW "+mbo.getString("PERMITWORKNUM"))


generatePTWReport(mbo.getString("PERMITWORKNUM"),mbo.getBoolean("THIRDPARTY"),mbo.getUserInfo())