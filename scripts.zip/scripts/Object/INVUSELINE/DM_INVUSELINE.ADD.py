#-----------------------------------------------------------------------------------------
# Name:        DM_INVUSELINE.ADD
# Description: whilw adding invuseline set frombin is mandatory
# Author: Mithun Reddy
# Version: 1.0 - 23-Jun-2025
#-----------------------------------------------------------------------------------------
def setError(Msg):
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)


frombin=mbo.getString("FROMBIN")
if frombin is None or frombin=='' :
    setError('Frombin should not be blank while adding the inventory usuage lines.')