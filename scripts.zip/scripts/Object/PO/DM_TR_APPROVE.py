from psdi.server import MXServer
if app == "DM_PLUSGPOTR":
    if(mbo.isModified("STATUS") and mbo.getString("STATUS") == 'APPR'):
        ctSet = mbo.getMboSet("$CT", "COMMTEMPLATE", "templateid='DM_TR_APPROVAL'")
        ct = ctSet.getMbo(0)
    
        if ct:
            ct.sendMessage(mbo, mbo)
        else:
            service.log("DM_MR_EMAIL: Template DM_TR_APPROVAL not found")