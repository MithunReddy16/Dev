#Modified by Mithun 
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
if app == "DM_PLUSGPOTR":
    wfAssignmentSet = mbo.getMboSet("WFASSIGNMENT")
    assigned = False
    currentuser = mbo.getUserInfo().getPersonId()
    for i in range(wfAssignmentSet.count()):
    	wfMbo = wfAssignmentSet.getMbo(i)
    	assign_user = wfMbo.getString("ASSIGNCODE")
    	assign_status = wfMbo.getString("ASSIGNSTATUS")
    	if assign_user == currentuser and assign_status in ("ACTIVE"):
    		assigned = True
    		break  
    #if not assigned and mbo.getString("status") not in ('WAPPR'):	
    if mbo.getString("status") not in ('WAPPR'):	
    	logger.debug("****** in if  ***")
    	mbo.setFieldFlag("DESCRIPTION",7L,True)
    	mbo.setFieldFlag("STORELOC",7L,True)
    	mbo.setFlag(7L,True)
    #elif mbo.getString("STATUS") not in ("WAPPR","RETURNED"):
        #service.error("A","B")
    	#mbo.setFieldFlag(["DESCRIPTION","ORDEDATE","STORELOC","REQUIREDDATE"],7L,True)
    Creator = mbo.getMboSet("DM_POSTATUS").moveFirst()
    if Creator:
        if currentuser != Creator.getString("CHANGEBY"): 
            POLineSet = mbo.getMboSet("POLINE")
            POLineSet.setFlag(7L,True)