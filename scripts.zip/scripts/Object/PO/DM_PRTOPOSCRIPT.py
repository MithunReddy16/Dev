from psdi.mbo import MboConstants

from psdi.util.logging import MXLoggerFactory

logger=MXLoggerFactory.getLogger('maximo.script')
PRLine_mboset=mbo.getMboSet("PRLine")
if PRLine_mboset.isEmpty()==False and PRLine_mboset is not None:
    logger.info("fwawsas")
    prline_mbo=PRLine_mboset.moveFirst();
    PR_mboset=prline_mbo.getMboSet("PR")
    if PR_mboset.isEmpty()==False and PR_mboset is not None:
      
        pr_mbo=PR_mboset.moveFirst();
        mbo.setValue("DM_PRPROCESSTYPE",pr_mbo.getString("DM_PRPROCESSTYPE"), MboConstants.NOACCESSCHECK|MboConstants.NOVALIDATION);
        mbo.setValue("DM_PRITEMTYPE",pr_mbo.getString("DM_PRITEMTYPE"), MboConstants.NOACCESSCHECK|MboConstants.NOVALIDATION);
        if mbo.getString("DM_PRPROCESSTYPE") is not None:
             mbo.setFieldFlag(["DM_PRITEMTYPE","DM_PRPROCESSTYPE"],MboConstants.READONLY, True)
         
 
    prline_mbo=PRLine_mboset.moveNext();