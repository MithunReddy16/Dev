/*
#-----------------------------------------------------------------------------------------
# Script Name : DM_FIELDS_MAPPING
# Description : This script is used to copy WS_ID from parent.
#
# Event              : Object Launchpoint Script object name:DM_EXT_API_FIELDS_MAPPING
# Author             : Pramod Kumar
# Version            : 1.0
# Date               : 10-Oct-2024
#-----------------------------------------------------------------------------------------
*/
load("nashorn:mozilla_compat.js");
importPackage(Packages.psdi.server);
importPackage(Packages.psdi.mbo);
importPackage(Packages.psdi.mbo.MboConstants);

mbo.setFieldFlag("VALUE", MboConstants.READONLY, true);
mbo.setFieldFlag("DESCRIPTION", MboConstants.READONLY, true);
mbo.setFieldFlag("FIELD_NAME", MboConstants.READONLY, true);
mbo.setFieldFlag("DATATYPE", MboConstants.READONLY, true);

if(mbo.getOwner() && mbo.isNew()){
   mbo.setValue("WS_ID",mbo.getOwner().getInt("DM_EXT_API_DETAILID")) 
}