#------------------------------------------------------------------------
# Script Name :DM_DATACHANGE_SAVE
#Description :Asset Data Change Request Save Script.
#Comment     :Used in Asset Data Change Request Application. 
#
#Author/Modifiedby    Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
# Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-Aug-2025         Initiate version.
#
#----------------------------------------------------------------------

from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.util import MXApplicationException



#Function to update asset location and create asset trans
def updateAssetLoc(requestLineMbo):
    assetSet = MXServer.getMXServer().getMboSet("ASSET", mbo.getUserInfo())
    assetSet.setWhere("assetnum ='"+requestLineMbo.getString("assetnum")+"' and siteid='DM'"  )
    assetSet.reset()
    assetMbo = assetSet.getMbo(0)
    toLoc= requestLineMbo.getString("tolocation")
    assetMbo.setValue('NEWSITE','DM')
    assetMbo.setValue('NEWLOCATION',toLoc)
    assetSet.moveAsset()
    #assetLoc = assetMbo.getString("location")
    #toLoc= requestLineMbo.getString("tolocation")
    #assetMbo.setValue("location",toLoc,MboConstants.NOACCESSCHECK)
    #assetTransSet = assetMbo.getMboSet("assettrans")
    #assetTrans = assetTransSet.add()
    #assetTrans.setValue("tositeid","DM")
    #assetTrans.setValue("toloc",toLoc)
    #assetTrans.setValue("fromloc",assetLoc)
    #assetTrans.setValue("transtype","MOVED")
    assetSet.save()
    assetSet.clearWarnings()

 
    
service.log_debug("######################################## Start:" + scriptName+" ######################")

requestLineMboSet = mbo.getMboSet("DM_DATACHANGELINE")
count = requestLineMboSet.count()
requestLineMbo = requestLineMboSet.moveFirst()
i = 0
param =""
noChange = False
while requestLineMbo is not None:
    service.log_debug("######################################## requestLineMbo ####################")

    mboStatus = mbo.getString("status")
    
    if mboStatus in ["DRAFT","RETURNED"]:
        # copy the cost center, floc, maintsec, location values to from the header to line 
        # if the flags are checked.    
        if mbo.isModified("APPLYTOCC"):
            if mbo.getBoolean("APPLYTOCC"):
                requestLineMbo.setValue("TOCOSTCENTER",mbo.getString("TOCOSTCENTER"))
            else:    
                requestLineMbo.setValueNull("TOCOSTCENTER")
                mbo.setValueNull("TOCOSTCENTER")
                
    
        if mbo.isModified("APPLYTOLOC"):
            if mbo.getBoolean("APPLYTOLOC"):
                requestLineMbo.setValue("TOLOCATION",mbo.getString("TOLOCATION"))
            else:    
                requestLineMbo.setValueNull("TOLOCATION")
                mbo.setValueNull("TOLOCATION")
                
    
        if mbo.isModified("APPLYTOMAINTSEC"):
            if mbo.getBoolean("APPLYTOMAINTSEC"):
                requestLineMbo.setValue("TOMAINTSEC",mbo.getString("TOMAINTSEC"))
                requestLineMbo.setValue("TOMAINTCC",mbo.getString("TOMAINTCC"))
            else:    
                requestLineMbo.setValueNull("TOMAINTSEC")
                mbo.setValueNull("TOMAINTSEC")
                mbo.setValueNull("TOMAINTCC")
                
        
        if mbo.isModified("APPLYTOFLOC"):
            if mbo.getBoolean("APPLYTOFLOC"):
                requestLineMbo.setValue("TOFLOC",mbo.getString("TOFLOC"))
            else:    
                requestLineMbo.setValueNull("TOFLOC")
                mbo.setValueNull("TOFLOC")
                
     
    if mbo.isModified("status"):
        if "APPRSUP" == mboStatus:
            #update asset location once the supervisor approved the request
            if not requestLineMbo.isNull("tolocation"):
                updateAssetLoc(requestLineMbo)
            #complete the requestline if the location is the only change in the line. 
            if requestLineMbo.isNull("TOCLASSSTRUCTUREID") and requestLineMbo.isNull("TOCOSTCENTER") and requestLineMbo.isNull("TOFLOC") and requestLineMbo.isNull("TOMAINTSEC"):
                requestLineMbo.setValue("STATUS","COMPLETED")
                            
        if "APPRMSM" == mboStatus or "WAMD" == mboStatus:
            #update asset maintenance section once the target maintenance section manager approved the request
            assetMboSet = requestLineMbo.getMboSet("asset")
            assetMbo = assetMboSet.getMbo(0)
            if not requestLineMbo.isNull("TOMAINTSEC"):
                if assetMbo is not None:
                    assetMbo.setValue("dm_maintsec",requestLineMbo.getString("TOMAINTSEC"))
                #complete the requestline if the maintenance section is the only change in the line.     
                if requestLineMbo.isNull("TOCLASSSTRUCTUREID") and requestLineMbo.isNull("TOCOSTCENTER") and requestLineMbo.isNull("TOFLOC"):
                    requestLineMbo.setValue("STATUS","COMPLETED") 
                    assetMboSet.save()
        if "SUBMITTED" == mboStatus:
            if requestLineMbo.isNull("TOMAINTSEC") and requestLineMbo.isNull("TOFLOC") and requestLineMbo.isNull("TOLOCATION") and requestLineMbo.isNull("CLASSSTRUCTUREID") and requestLineMbo.isNull("TOCOSTCENTER"):
                param = param + requestLineMbo.getString("assetnum") +","
                noChange = True
              
                        
    if i > count:
        break;
    else:
        i=1+i
    requestLineMbo = requestLineMboSet.moveNext()

if noChange:
    service.error("dmdatachange", "nolinechange",[param])

#updatee changedate/status date
currentDate = MXServer.getMXServer().getDate()
mbo.setValue("CHANGEDDATE", currentDate)
if mbo.isModified("status"):
    mbo.setValue("statusdate", currentDate)
    
    

service.log_debug("######################################## End:" + scriptName+" ######################")