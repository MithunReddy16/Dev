/*
Script: DM_RESETPOLINE
Created By: ram
Date: 11-May-2025
Req: reset the filter in polines dialog after close the dialog


*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(java.time)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)

var logger = MXLoggerFactory.getLogger("maximo.dm")
logger.debug("***RA*** Script POLINE ** START ***")

session = service.webclientsession()
databean = session.getDataBean("copypolinebean")

 //service.error("debug3456", "FromDate: ");
if (databean != null) {
    var polineSet = databean.getMboSet();
    if (polineSet != null) {
        // Clear previous filter (in case dialog was opened again)
        polineSet.setWhere("1=1");
        polineSet.reset();  // This forces re-fetch from DB
        logger.debug("***RA*** POLINE table reset");
    }
}