/*
Script: DM_PLDIAGNP.INIT
Created By: Ashok
Date: 18-Dec-2024
Req: Set intial values

*/

load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_PICKLIST.STATUSCHANGE**START***")
ownerMbo=mbo.getOwner();
if(ownerMbo!=null)
{
	mbo.setValue("DM_PICKLISTNUM",ownerMbo.getString("DM_PICKLISTNUM"),2);
	mbo.setValue("siteid",ownerMbo.getString("siteid"),2);
	mbo.setValue("DM_STOREROOM",ownerMbo.getString("DM_STOREROOM"),2);
	
}