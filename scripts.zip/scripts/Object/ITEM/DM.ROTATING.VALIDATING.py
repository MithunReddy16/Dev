#-----------------------------------------------------------------------------------------
# Name:		DM.ROTATING.VALIDATING
# Description: Rotating Item Validation
# Author: @Amir A
# Version: 1.0 - 23-NOV-2025
#-----------------------------------------------------------------------------------------


from psdi.mbo import SqlFormat
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from java.util import Calendar

mlog = MXLoggerFactory.getLogger("maximo.custom")

def setError(Msg):
	params=[Msg]
	service.error('scriptval','scriptvalidationerror',params)

if launchPoint == "FLD.ITEM.ROTATING":
    if mbovalue.getBoolean():
        if mbo.isNull('COMMODITY') or mbo.getString('COMMODITY')[0:1] !='9' or  mbo.getString('COMMODITY')=="99999-000":
            setError('Invalid Commdity')
elif launchPoint == "FLD.ITEM.COMMODITY":
        Commodity = mbovalue.getString()
        if mbo.getBoolean("ROTATING") and( Commodity == "" or Commodity[0:1] !="9" or Commodity=="99999-000"):
            setError( "Invalid Rotating/ Sub Category Combination.")
        elif not mbo.getBoolean("ROTATING") and Commodity[0:1] =="9" or Commodity!="99999-000":
            if interactive:
                if interactive:
                    session = service.webclientsession();
                    session.showMessageBox("scriptval", "scriptinfo", ["This category used for roating items, this item will  be converted to rotating item."]);
            mbo.setValue("ROTATING",True,2L)
elif launchPoint == "OBJ.ITEM.SAVE" and (app=="" or app=="DM_PLUSTITM"):
    
    RotMboValue = mbo.getMboValue("ROTATING")
    CommMboValue = mbo.getMboValue("COMMODITY")
    
    if CommMboValue.isModified() or RotMboValue.isModified():
        Commodity = CommMboValue.getString()
        if RotMboValue.getBoolean() and( Commodity == "" or Commodity[0:1] !="9" or Commodity=="99999-000"):
            setError( "Invalid Rotating/ Sub Category Combination.")
        elif not RotMboValue.getBoolean() and Commodity[0:1] =="9" and Commodity!="99999-000":
            setError( "Invalid Rotating/ Sub Category Combination.")