from com.ibm.tivoli.maximo.oslc.provider import LocalURIGenerator, OslcResourceCache
from psdi.mbo import SqlFormat
from psdi.server import MXServer

resourceID =mbo.getString("GRP_RESOURCEID")
prnum = mbo.getString("PRNUM")
siteid = mbo.getString("SITEID")
userInfo=mbo.getUserInfo()
oslcResourceInfo = OslcResourceCache.getInstance().getOslcResourceInfo("MXPR")
if oslcResourceInfo:
    resourceID= LocalURIGenerator().getEncodedMboID(mbo, oslcResourceInfo)
    if resourceID:
        mbo.setValue("GRP_RESOURCEID", resourceID, 2L)
'''
if (resourceID is None or resourceID==''):
    prSet = MXServer.getMXServer().getMboSet("PR", userInfo)
    try:
        sqlFormat = SqlFormat("prnum = :1 and siteid =:2 ")
        sqlFormat.setObject(1, "PR", "prnum", prnum)
        sqlFormat.setObject(2, "PR", "siteid", siteid)
        
        prSet.setWhere(sqlFormat.format())

        prMbo = prSet.moveFirst()

        if prMbo is not None:
            oslcResourceInfo = OslcResourceCache.getInstance().getOslcResourceInfo("GRP_PRDOC")
            if oslcResourceInfo:
                resourceID= LocalURIGenerator().getEncodedMboID(mbo, oslcResourceInfo)
            
            
        #else:
        #    resourceID= "PR not found."
        if resourceID:
            mbo.setValue("GRP_RESOURCEID", resourceID, 2L)
    finally:
        if prSet is not None:
            prSet.close()
            prSet.cleanup()
'''