#author :Mithun
from psdi.server import MXServer

if(mbo.isModified("STATUS") and mbo.getString("STATUS") == 'CAN'):
    ctSet = mbo.getMboSet("$CT", "COMMTEMPLATE", "templateid='DM_PR_CAN'")
    ct = ctSet.getMbo(0)

    if ct:
        ct.sendMessage(mbo, mbo)
    else:
        service.log("DM_MR_EMAIL: Template DM_PR_CAN not found")