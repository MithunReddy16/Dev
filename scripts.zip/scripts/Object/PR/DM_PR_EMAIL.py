#Author Mithun 
from psdi.server import MXServer

if(mbo.isModified("STATUS") and mbo.getString("STATUS") == 'APPR'):
    ctSet = mbo.getMboSet("$CT", "COMMTEMPLATE", "templateid='DM_PR_APPROVE'")
    ct = ctSet.getMbo(0)

    if ct:
        ct.sendMessage(mbo, mbo)
    else:
        service.log("DM_PR_APPROVE: Template DM_PR_APPROVE not found")