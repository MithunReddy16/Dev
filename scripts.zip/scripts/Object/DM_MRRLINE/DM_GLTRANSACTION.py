#-----------------------------------------------------------------------------------------
# Name:		DM_GLTRANSACTION
# Description: to form the GL credit and debit information
# Author: @Amir A
#Modified :Mithun
# Version: 1.0 - 23-NOV-2025
#-----------------------------------------------------------------------------------------


from psdi.mbo import SqlFormat
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from java.util import Calendar

mlog = MXLoggerFactory.getLogger("maximo.custom")
mlog.debug("***  DM_GLTRANSCATIONS has started *******")

def setError(Msg,Type):
	if Type == "ERROR":
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)
	else:
		mlog.debug(Msg)

def getStoreAccount(Store):
	locationSet = MXServer.getMXServer().getMboSet("LOCATIONS", MXServer.getMXServer().getSystemUserInfo())
	locationSet.setWhere("type='STOREROOM' and location='"+Store+"'")
	if (not locationSet.isEmpty()):
		locationMbo=locationSet.moveFirst()
		glControlAcct = locationMbo.getString("CONTROLACC")
		if glControlAcct is None:
			#setError("Store Control Account is not defined.",'ERROR')  
			return "??-???-????-?????-??-?????-?????-?????"
		else:
			return glControlAcct
#NewGLFormat(NewGL)   
def glForMatRequisition(storeloc,type):
	item = mbo.getString("itemnum")
	mrnum=mbo.getString("mrnum")
	siteid=mbo.getString("siteid")
	glAccount='??-???-????-?????-??-?????-?????-?????'
	NewGL = getNewGLList()
	if (not mbo.isNull("itemnum") ):
		mrSet = mbo.getMboSet("MR")
		if (not mrSet.isEmpty()):
				mrMbo = mrSet.moveFirst()
				personSet = mrMbo.getMboSet("DM_PERSON")
				if (not personSet.isEmpty()):
					mlog.debug("**** mr person is ***")
					personMbo = personSet.moveFirst()
					mlog.debug("**** mr person is ***"+personMbo.getString("PERSONID"))
					orgHierSet = personMbo.getMboSet("DM_SECTION")
					if (not orgHierSet.isEmpty()):
						orgHierMbo = orgHierSet.moveFirst()
						costcenter = orgHierMbo.getString("COSTCENTER")
						location = personMbo.getString("DM_GLLOCATION")
						entity = orgHierMbo.getString("ENTITY")
						'''
						if (entity is None or entity==''):
							setError('Requestor entity not defined in Organization Hierarchy  profile for the GL formation.','WARN')  
						if (location is None or location==''):
							setError('Requestor Location not defined in Employee profile.','WARN')  
						if (costcenter is None or costcenter==''):
							setError('Requestor costcenter not defined in Organization Hierarchy  profile for the GL formation.','WARN')  
						'''
						if entity:
							NewGL[0]=entity
						if location:
							NewGL[1]=location
						if costcenter:
							NewGL[2]=costcenter
							
						itemSet = mbo.getMboSet("ITEM")
						if (not itemSet.isEmpty()):
							item = itemSet.moveFirst()
							commodityMbo = item.getMboSet("COMMODITIES").moveFirst()
							if commodityMbo :
								account = commodityMbo.getString("DM_ACCOUNT")
								subaccount = commodityMbo.getString("DM_SUBACCOUNT")
								'''
								if (account is None or account==''):
									#account="?????"
									setError('Item does not have sub-account at commodity level for the GL formation.','WARN')  
								if (subaccount is None or subaccount==''):
									setError('Item does not have sub-account at commodity level for the GL formation.','WARN')  
									#subaccount='??'
								else:
								'''
								if account:
									NewGL[3]=account
								if subaccount:
									NewGL[4]=subaccount

								glAccount = entity +'-'+location+'-'+costcenter+'-'+account+'-'+subaccount+'-'+'00000'+'-'+'00000'+'-'+'00000'
								mlog.debug("**** mr alaccount is ***"+glAccount)

	return NewGLFormat(NewGL)
								
def glForWorkorder (storeloc,type):	
	#wonum = mbo.getString("wonum")
	item = mbo.getString("itemnum")
	glAccount='??-???-????-?????-??-?????-?????-?????'
	mlog.debug("**** type is ***"+type)
	NewGL = getNewGLList()
	#if not mbo.isNull("itemnum") and storeloc  and storeloc!="":
	if not mbo.isNull("itemnum") :
		asset = mbo.getString("assetnum")		
		if asset  and asset!='':			
			assetSet = mbo.getMboSet("ASSET")
		elif (asset is None or asset==''):			
			assetSet = mbo.getMboSet("WORKORDER").getMbo(0).getMboSet("ASSET")			
		if (not assetSet.isEmpty()):			
			assetMbo = assetSet.moveFirst()
			assetGL = assetMbo.getString ("GLACCOUNT")			
			if assetGL  and assetGL !='':
				glsegments = assetGL.split("-")
				if len(glsegments) >= 3:
					glcomp01=glsegments[0]
					glcomp02=glsegments[1]
					NewGL[0] =glsegments[0]
					NewGL[1] =glsegments[1]

		itemSet = mbo.getMboSet("ITEM")
		if (not itemSet.isEmpty()):
			item = itemSet.moveFirst()
			commoditySet = item.getMboSet("COMMODITIES")						 
			if (not commoditySet.isEmpty()):
				commodityMbo = commoditySet.moveFirst()
				if commodityMbo :
					account = commodityMbo.getString("DM_ACCOUNT")
					if account:
						NewGL[3] =account
					subaccount = commodityMbo.getString("DM_SUBACCOUNT")
					if (subaccount):
						NewGL[4] =subaccount
					if type in ["WO"] :
						#orghiSet=mbo.getOwner().getMboSet("DM_MAINTSEC")
						orghiSet=mbo.getMboSet("WORKORDER.DM_MAINTSEC")
					if type in ["MRR","MR"] :
						orghiSet=mbo.getMboSet("WORKORDER").getMbo(0).getMboSet("DM_MAINTSEC")
					if(not orghiSet.isEmpty()):
						org=orghiSet.moveFirst()
						costcenter=org.getString("costcenter")
						if costcenter is None :
							parentorgMboSet=org.getMboSet("SECTIONPARENT1")
							if not parentorgMboSet.isEmpty():
								parentorgMbo=parentorgMboSet.moveFirst()
								costcenter=parentorgMbo.getString("costcenter")
					if(costcenter):
						NewGL[2]=costcenter

		
	return NewGLFormat(NewGL) 

def getNewGLList():
	GLArray=[]
	GLArray.append('??')
	GLArray.append('???')
	GLArray.append('????')
	GLArray.append('?????')
	GLArray.append('??')
	GLArray.append('00000')
	GLArray.append('00000')
	GLArray.append('00000')
	return GLArray

def NewGLFormat(GLArray):
	GL =""
	for i in range (len(GLArray)):
		GL = GL+ str(GLArray[i])+"-"
	return GL[:-1]

def glForWorkorderInvuseline (storeloc,type):	
	#wonum = mbo.getString("wonum")
	item = mbo.getString("itemnum")
	
	glAccount='??-???-????-?????-??-?????-?????-?????'
	mlog.debug("**** type is ***"+type)
	NewGL = getNewGLList()
	
	
	if not mbo.isNull("itemnum") and storeloc  and storeloc!="":
		asset = mbo.getString("assetnum")		
		if asset  and asset!='':			
			assetSet = mbo.getMboSet("ASSET")
		elif (asset is None or asset==''):			
			assetSet = mbo.getMboSet("WORKORDER").getMbo(0).getMboSet("ASSET")			
		
		if (not assetSet.isEmpty()):			
			assetMbo = assetSet.moveFirst()
			assetGL = assetMbo.getString ("GLACCOUNT")			
			if assetGL  and assetGL !='':
				glsegments = assetGL.split("-")
				
				NewGL[0]=glsegments[0]
				NewGL[1]=glsegments[1]
				#glcomp03=glsegments[2]

		if type in ["WO"] :
			#orghiSet=mbo.getOwner().getMboSet("DM_MAINTSEC")
			orghiSet=mbo.getMboSet("WORKORDER.DM_MAINTSEC")
		if type in ["MRR","MR"] :
			orghiSet=mbo.getMboSet("WORKORDER").getMbo(0).getMboSet("DM_MAINTSEC")
		if(not orghiSet.isEmpty()):
			org=orghiSet.moveFirst()
			costcenter=org.getString("costcenter")
			if org.isNull("costcenter") :
				parentorgMboSet=org.getMboSet("SECTIONPARENT1")
				if not parentorgMboSet.isEmpty():
					parentorgMbo=parentorgMboSet.moveFirst()
					costcenter=parentorgMbo.getString("costcenter")
			if(costcenter and costcenter!=""):
				NewGL[2] = costcenter
		
		
		itemSet = mbo.getMboSet("ITEM")
		if (not itemSet.isEmpty()):
			item = itemSet.moveFirst()
			commoditySet = item.getMboSet("COMMODITIES")						 
			if (not commoditySet.isEmpty()):
				commodityMbo = commoditySet.moveFirst()
				if commodityMbo:
					account = commodityMbo.getString("DM_ACCOUNT")
					if not commodityMbo.isNull("DM_ACCOUNT"):
						NewGL[3] = account
					
					#if (account is None or account==''):
						#setError('Item does not have account code at commodity level for the GL formation.','ERROR')  
						#account='?????'
					subaccount = commodityMbo.getString("DM_SUBACCOUNT")
					if not commodityMbo.isNull("DM_SUBACCOUNT"):
						NewGL[4] = subaccount
					#if (subaccount is None or subaccount==''):
						#subaccount='??'
						#setError('Item does not have sub-account at commodity level for the GL formation.','ERROR')

			

		
	
	return NewGLFormat(NewGL)



def glForMRRMatusetrans(storeloc,type):
	itemnum = mbo.getString("ITEMNUM")
	mrnum = mbo.getString("MRNUM")
	wonum=mbo.getString("WONUM")
	NewGL = getNewGLList()
	gldebit=""
	glcredit=""
	if type=="WO":
		MatUseTransSet = mbo.getMboSet("$matrectrans","MATUSETRANS","issuetype='ISSUE' and storeloc='"+storeloc+"' and itemnum='"+itemnum+"' and refwo='"+wonum+"'")	
	elif type == "MR":
		MatUseTransSet = mbo.getMboSet("$matrectrans","MATUSETRANS","issuetype='ISSUE' and storeloc='"+storeloc+"' and itemnum='"+itemnum+"' and mrnum='"+mrnum+"'")	
	else:
		return NewGLFormat(NewGL), NewGLFormat(NewGL) ,"0.00"
	
	MatUseTransSet.reset()
	#service.error("A","issuetype='ISSUE' and storeloc='"+storeloc+"' and itemnum='"+itemnum+"' and refwo='"+wonum+"'")
	matrecMbo = MatUseTransSet.moveFirst()
	if matrecMbo:
		#service.error(matrecMbo.getString("glcreditacct"),matrecMbo.getString("gldebitacct"))
		gldebit = matrecMbo.getString("gldebitacct")
		glcredit = matrecMbo.getString("glcreditacct")
		unitcost = matrecMbo.getFloat("UNITCOST")
		

		IssueActualDate = matrecMbo.getDate("actualdate")
		cal = Calendar.getInstance()
		cal.setTime(IssueActualDate)
		IssueYear = cal.get(Calendar.YEAR)
		ReturnActualDate = mbo.getDate('DM_ACTUALDATE')

		if not ReturnActualDate:
			ReturnActualDate = MXServer.getMXServer().getDate()

		cal.setTime(ReturnActualDate)
		ReturnYear =  cal.get(Calendar.YEAR)
		NewGL = gldebit.split("-")

		if not ReturnYear == IssueYear:

			acctcode = MXServer.getMXServer().getProperty('dm.issueclosedperiod.account')
			subacctcode = MXServer.getMXServer().getProperty('dm.issueclosedperiod.subaccount')
			glsegments =gldebit.split("-")

			if len(glsegments) >= 3:
				NewGL[0]=glsegments[0]
				NewGL[1]=glsegments[1]
				NewGL[2]=glsegments[2]
				NewGL[3]=acctcode
				NewGL[4]=subacctcode
				NewGL[5]="00000"
				NewGL[6]="00000"
				NewGL[7]="00000"
				'''
				glcomp01=glsegments[0]
				glcomp02=glsegments[1]
				glcomp03=glsegments[2]
				glcomp06="00000"
				glcomp07="00000"
				glcomp08="00000"
				gldebit = glcomp01+"-"+glcomp02+"-"+glcomp03+"-"+acctcode+"-"+subacctcode+"-"+glcomp06+"-"+glcomp07+"-"+glcomp08
				'''


		    
		MatUseTransSet.cleanup()
		MatUseTransSet.close()
		
		return NewGLFormat(NewGL), glcredit,unitcost
	else:
		MatUseTransSet.cleanup()
		MatUseTransSet.close()
		
		return NewGLFormat(NewGL), NewGLFormat(NewGL) ,"0.00"
		
		
def validateGLAccount(glcode):
	if glcode is None or glcode.strip() == "":
		#service.setWarning("GLWARN", "invalidgl",None)
		return False

	if   '?' in glcode:
		return False
	'''
	# Check if GL account exists and is active
	coaSet = mbo.getMboSet("$coa", "CHARTOFACCOUNTS", "glaccount='" + glcode + "' AND active=1")
	if coaSet.isEmpty():
		# GL exists but inactive or not found with active=1
		#service.setWarning("GLWARN", "notactivegl",None)
		coaSet.close()
		return False
	coaSet.close()
	'''

	return True

def validateGLAccountError(glcode):
	'''
	coaSet = mbo.getMboSet("$coa", "CHARTOFACCOUNTS", "glaccount='" + glcode + "' AND active=1")
	if coaSet.isEmpty():
		coaSet.close()
		setError('GL Account is not valid','ERROR')
	'''
	
	if glcode == None or glcode ==""  or  '?' in glcode:
		setError('GL Account is not valid','ERROR')
		
	return True
  
	

## Issuance against MR
app = mbo.getThisMboSet().getParentApp()

if launchPoint == "OBJ.MATUSETRANS.SAVE":
	owner = mbo.getOwner()
	if owner and owner.getName() in ( "WOACTIVITY" , "WORKORDER"):
		validateGLAccountError(mbo.getString("GLCREDITACCT"))
		validateGLAccountError(mbo.getString("GLDEBITACCT"))

#if launchPoint =="INVUSELINE.SAVE" or ((launchPoint=="FLD.INVUSELINE.WONUM" or launchPoint=="FLD.INVUSELINE.MRNUM" or launchPoint=="FLD.INVUSELINE.ASSETNUM" or launchPoint=="FLD.INVUSELINE.TOSTORE	or launchPoint=="FLD.INVUSELINE.ITEMNUM" ) AND not mbo.toBeAdded() ):
if  launchPoint=="INVUSELINE.SAVE" or (launchPoint=="FLD.INVUSELINE.ITEMNUM"  and not mbo.toBeAdded() and not mbo.isNull("ITEMNUM")) :
	glCreditacct=''
	transtype=mbo.getString("usetype")
	mrnum=mbo.getString("mrnum")
	wonum=mbo.getString("refwo")
	storeloc=mbo.getString("fromstoreloc")
	issueid=mbo.getInt("issueid")
	mlog.debug("*** application is*******"+str(app))
	if app not in ["DM_MRR"] :
		#service.error("A",app)
		if (not mbo.isNull("mrnum") and transtype=='ISSUE'  and (wonum is None or wonum=='')):
			if mbo.isNull("GLDEBITACCT"):
				glDebitacct = glForMatRequisition(storeloc,"MR")
				if (glDebitacct  and glDebitacct!=''):
					mbo.setValue("GLDEBITACCT",glDebitacct,11L )
			glCreditacct = getStoreAccount(storeloc)
			if (glCreditacct  and glCreditacct!=''):
				mbo.setValue("GLCREDITACCT",glCreditacct,11L )
		if (not mbo.isNull("mrnum")  and transtype=='RETURN'  and (wonum is None or wonum=='')):
			if  mbo.isNull("GLCREDITACCT"):
				glCreditacct = glForMatRequisition(storeloc,"MR")
				if (glCreditacct  and glCreditacct!=''):
					mbo.setValue("GLCREDITACCT",glCreditacct,11L )
			glDebitacct = getStoreAccount(storeloc)
			if (glDebitacct  and glDebitacct!=''):
				mbo.setValue("GLDEBITACCT",glDebitacct,11L )
		if (transtype=='ISSUE'  and (wonum and wonum !='')):
			glDebitacct = glForWorkorderInvuseline(storeloc,"WO")
			if (glDebitacct  and glDebitacct!=''):
				mbo.setValue("GLDEBITACCT",glDebitacct,11L )
			glCreditacct = getStoreAccount(storeloc)
			if (glCreditacct  and glCreditacct!=''):
				mbo.setValue("GLCREDITACCT",glCreditacct,11L )
		if (transtype=='RETURN'  and (wonum  and wonum !='')):		
			glCreditacct = glForWorkorderInvuseline(storeloc,"WO")
			glDebitacct = getStoreAccount(storeloc)
			if (glCreditacct and glCreditacct!="" ):
				mbo.setValue("GLCREDITACCT",glCreditacct,11L)
			if (glDebitacct and glDebitacct!=""):
				mbo.setValue("GLDEBITACCT",glDebitacct,11L )
		if (transtype=='TRANSFER' ):
			transferglAccount = MXServer.getMXServer().getProperty('dm.transfer.glaccount')
			mbo.setValue("GLDEBITACCT",transferglAccount,11L )		
			fromStoreSet = mbo.getMboSet("FROMLOCATION")
			if (not fromStoreSet.isEmpty()):
				fromStoreMbo = fromStoreSet.moveFirst()
				glCreditacct = fromStoreMbo.getString("CONTROLACC")			
				mbo.setValue("GLCREDITACCT",glCreditacct,11L )
		if (transtype=='RETURN' and issueid and issueid!=0):		
			#financialPeriodSet = mbo.getMboSet("DM_FINANCIALPERIODS")
			issueSet = mbo.getMboSet("DM_MATUSETRANSISSUE")

			issueMbo = issueSet.moveFirst()
			if (issueMbo):

				glDebitacct = issueMbo.getString("GLDEBITACCT")
				glCreditacct = issueMbo.getString("GLCREDITACCT")

				mbo.setValue("GLDEBITACCT",glCreditacct,11L )
				IssueActualDate = issueMbo.getString("actualdate")
				cal = Calendar.getInstance()
				cal.setTime(IssueActualDate)
				IssueYear = cal.get(Calendar.YEAR)
				ReturnActualDate = mbo.getDate('DM_ACTUALDATE')

				if not ReturnActualDate:
					ReturnActualDate = MXServer.getMXServer().getDate()

				cal.setTime(ReturnActualDate)
				ReturnYear =  cal.get(Calendar.YEAR)


				if not ReturnYear == IssueYear:

					acctcode = MXServer.getMXServer().getProperty('dm.issueclosedperiod.account')
					subacctcode = MXServer.getMXServer().getProperty('dm.issueclosedperiod.subaccount')
					glsegments = glDebitacct.split("-")

					if len(glsegments) >= 3:
						glcomp01=glsegments[0]
						glcomp02=glsegments[1]
						glcomp03=glsegments[2]
						glcomp06="00000"
						glcomp07="00000"
						glcomp08="00000"
						glaccount = glcomp01+"-"+glcomp02+"-"+glcomp03+"-"+acctcode+"-"+subacctcode+"-"+glcomp06+"-"+glcomp07+"-"+glcomp08
						mbo.setValue("GLCREDITACCT",glaccount,11L )
				else:
					
					glDebitacct = issueMbo.getString("GLDEBITACCT")
					glCreditacct = issueMbo.getString("GLCREDITACCT")
					mbo.setValue("GLDEBITACCT",glCreditacct,11L )
					mbo.setValue("GLCREDITACCT",glDebitacct,11L )
			
## Issuance against Workorder App
if launchPoint=="MATUSETRANS.STORELOC":
	parentMbo=mbo.getOwner().getName()
	transtype = mbo.getString("issuetype")
	if parentMbo=='WORKORDER':
		storeAccount = getStoreAccount(storeloc)			
		if transtype=='ISSUE':
			mbo.setValue("GLCREDITACCT",storeAccount,11L)
		elif transtype=='RETURN':
			mbo.setValue("GLDEBITACCT",storeAccount,11L)

def getGLForReturnWO():
	parentMbo=mbo.getOwner()
	parentMboName = parentMbo.getName()
	if parentMbo and parentMboName == "WORKORDER":
		if not mbo.isNull("STORELOC") and not mbo.isNull("ITEMNUM") and not mbo.isNull("actualdate") and mbo.getString("ISSUETYPE") == "RETURN":
			WhereC="issuetype='ISSUE' and storeloc='{}' and itemnum='{}' and refwo='{}'".format(mbo.getString("STORELOC"),mbo.getString("ITEMNUM"),parentMbo.getString("WONUM"))
			MatUseTransSet = mbo.getMboSet("$matrectrans","MATUSETRANS",WhereC)
			MatUseTransSet.reset()
			matUseMbo = MatUseTransSet.moveFirst()
			gldebit = None
			if matUseMbo:	
				#service.error("Trans Found","A")
				gldebit = matUseMbo.getString("gldebitacct")#Trans
				glcredit = matUseMbo.getString("GLCREDITACCT")#Store
				IssueActualDate = matUseMbo.getDate("actualdate")
				cal = Calendar.getInstance()
				cal.setTime(IssueActualDate)
				IssueYear = cal.get(Calendar.YEAR)
				ReturnActualDate = mbo.getDate('actualdate')

				if not ReturnActualDate:
					ReturnActualDate = MXServer.getMXServer().getDate()

				cal.setTime(ReturnActualDate)
				ReturnYear =  cal.get(Calendar.YEAR)
				

				if not ReturnYear == IssueYear:
					glsegments = gldebit.split("-")
					acctcode = MXServer.getMXServer().getProperty('dm.issueclosedperiod.account')
					subacctcode = MXServer.getMXServer().getProperty('dm.issueclosedperiod.subaccount')
					glcomp01=glsegments[0]
					glcomp02=glsegments[1]
					glcomp03=glsegments[2]
					glcomp06="00000"
					glcomp07="00000"
					glcomp08="00000"
					gldebit = glcomp01+"-"+glcomp02+"-"+glcomp03+"-"+acctcode+"-"+subacctcode+"-"+glcomp06+"-"+glcomp07+"-"+glcomp08
						

			MatUseTransSet.cleanup()
			MatUseTransSet.close()
			if gldebit:
				return gldebit
			else:
				#service.error("Trans Not Found",WhereC)
				return glForWorkorder(storeloc,"WO")
				
			
		
		#service.error("Did meet conditrion","A")
		return glForWorkorder(storeloc,"WO")
			
			
			

if launchPoint=="MATUSETRANS.ACTUALDATExx":
	mbo.setValue("GLCREDITACCT",gldebit)


if (launchPoint =="MATUSETRANS.ITEMNUM" or launchPoint=="MATUSETRANS.ISSUETYPE" or launchPoint =="MATUSETRANS.ACTUALDATE") :
	wonum = mbo.getString("wonum")
	mrnum = mbo.getString("mrnum")
	transtype = mbo.getString("issuetype")
	storeloc=mbo.getString("storeloc")
	item =  mbo.getString("itemnum")
	parentMbo=mbo.getOwner().getName() 
	if item and item!="" and wonum and wonum!="" and parentMbo=='WORKORDER':
		if transtype=='ISSUE':
			glDebitacct = glForWorkorder(storeloc,"WO")
			if (glDebitacct and glDebitacct!=''):
				mbo.setValue("GLDEBITACCT",glDebitacct,11L )

		if  transtype=='RETURN':
			#glCreditacct = glForWorkorder(storeloc,"WO")
			glCreditacct = getGLForReturnWO()
			if (glCreditacct and glCreditacct!=''):
				mbo.setValue("GLCREDITACCT",glCreditacct,11L)

## Return against MRR
#and not mbo.isNew() removed from conditon
if (launchPoint =="DM_MRRLINE.MRNUM" or launchPoint=="DM_MRRLINE.WONUM"  or  (launchPoint=="DM_MRRLINE.GLDATE")  ):

	
	wonum = mbo.getString("wonum")
	mrnum = mbo.getString("mrnum")
	storeloc=mbo.getString("storeloc")
	item =  mbo.getString("itemnum")
	mlog.debug("***  DM_GLTRANSCATIONS LunchPoint started *******" + launchPoint)
	#if (app=='DM_MRR'):
	if (wonum  and wonum!=""):
		mlog.debug("***  DM_GLTRANSCATIONS LunchPoint inside Wo *******" + launchPoint)
		
		gldebit,glcredit,unitcost = glForMRRMatusetrans(storeloc,"WO")
		#service.error(gldebit,glcredit)
		validDebit  = validateGLAccount(gldebit)
		#validCredit = validateGLAccount(glcredit)
		if not validDebit:
			service.setWarning("GLWARN", "invalidgl",None)
		mbo.setValue("GLDEBITACCT",glcredit,11L )
		mbo.setValue("GLCREDITACCT",gldebit,11L )
		mbo.setValue("UNITCOST",unitcost,11L )
	elif ( mrnum and mrnum!="" and (wonum is None or wonum =='')):
		mlog.debug("***  DM_GLTRANSCATIONS LunchPoint inside MR *******" + launchPoint)
		gldebit,glcredit,unitcost  = glForMRRMatusetrans(storeloc,"MR")
		validDebit  = validateGLAccount(gldebit)
		#validCredit = validateGLAccount(glcredit)
		if not validDebit :
			service.setWarning("GLWARN", "invalidgl",None)
		mlog.debug("** validCredit"+glcredit)
		mlog.debug("** validDebit"+gldebit)
		mbo.setValue("GLDEBITACCT",glcredit,11L )
		mbo.setValue("GLCREDITACCT",gldebit,11L )
		mbo.setValue("UNITCOST",unitcost,11L )
	else:
		mbo.setValueNull("GLCREDITACCT")
	mlog.debug("***  DM_GLTRANSCATIONS LunchPoint Ended *******" + launchPoint)


## Transfer In - Shipment receiving
#if ((launchPoint =="MATRECTRANS.TOSTORELOC" or launchPoint =="MATRECTRANS.SAVE") and (app=="SHIPREC" or app=="PLUSTISS")):
if (launchPoint =="MATRECTRANS.TOSTORELOC" or launchPoint =="MATRECTRANS.SAVE"):
	itemnum = mbo.getString("itemnum")
	transtype = mbo.getString("issuetype")
	fromstoreloc=mbo.getString("fromstoreloc")
	tostoreloc=mbo.getString("tostoreloc")
	if (transtype=="SHIPRECEIPT" or transtype=="TRANSFER"):
		transferglAccount = MXServer.getMXServer().getProperty('dm.transfer.glaccount')
		mbo.setValue("GLCREDITACCT",transferglAccount,11L )
		ToStoreSet = mbo.getMboSet("LOCATIONS")
		if (not ToStoreSet.isEmpty()):
			ToStoreMbo = ToStoreSet.moveFirst()
			glDebitacct = ToStoreMbo.getString("CONTROLACC")
			mbo.setValue("GLDEBITACCT",glDebitacct,11L )
	if (transtype=="SHIPTRANSFER" ):
		transferglAccount = MXServer.getMXServer().getProperty('dm.transfer.glaccount')
		mbo.setValue("GLDEBITACCT",transferglAccount,11L )
		'''
		ToStoreSet = mbo.getMboSet("LOCATIONS")
		if (not ToStoreSet.isEmpty()):
			ToStoreMbo = ToStoreSet.moveFirst()
			glDebitacct = ToStoreMbo.getString("CONTROLACC")
			mbo.setValue("GLCREDITACCT",glDebitacct,11L )
		'''


if  launchPoint == "OBJ.INVBALANCE.NEWBAL" or launchPoint == "FLD.INVBALANCES.NEWBAL" :
	
	wcs = service.webclientsession()
	pageId= None
	if wcs:
		pageId=wcs.getCurrentPageId()
	#service.error('a',str(),None)
	
	if pageId and pageId == "CURBALADJ":
		
		Adjustment = MXServer.getMXServer().getProperty('dm.adjustment.glcreditaccount')
		StorAccount = mbo.getString("INVENTORY.LOCATIONS.CONTROLACC")
		#Control -> Debit, Shrink -> Credit
		#in Maximo Debit should be always store account since transaction is in minus 
		mbo.setValue('SHRINKAGEACC',Adjustment)
		mbo.setValue('CONTROLACC',StorAccount)
		'''
		if not mbo.isNull("NEWCURBAL"):
			Issue = True if mbo.getFloat("NEWCURBAL") < mbo.getFloat("curbal") else False
		
			if Issue:
				#Debit Adjustment Account ( Controll Account)
				#Credit Store Account( Shrink)
				mbo.setValue('SHRINKAGEACC',StorAccount)
				mbo.setValue('CONTROLACC',Adjustment)
			if not Issue:
				#Debit Store Account ( Controll Account)
				#Credit Adjustment Account( Shrink)
				mbo.setValue('SHRINKAGEACC',Adjustment)
				mbo.setValue('CONTROLACC',StorAccount)
		'''


## Inventory Adjustment
if (launchPoint =="INVTRANS.SAVE"):
	transtype = mbo.getString("transtype")
	if (transtype=="PCOUNTADJ" ):
		glDebitacct = MXServer.getMXServer().getProperty('dm.adjustment.gldebitaccount')
		glCreditacct = MXServer.getMXServer().getProperty('dm.adjustment.glcreditaccount')
		StorAccount = mbo.getString("INVENTORY.LOCATIONS.CONTROLACC")
		mbo.setValue("GLDEBITACCT",StorAccount,11L )
		mbo.setValue("GLCREDITACCT",glCreditacct,11L )


if launchPoint == "OBJ.MRRLINE.INIT.GL":	
	if mbo.isNew():
		owner = mbo.getOwner()
		if owner and owner.getString("RETURNTYPE").upper() in ("PROJECT","ONSITE"):
			mbo.setValue('GLDEBITACCT',mbo.getString('STORELOC.CONTROLACC'))
			#Credit should be selected by end user
			


if (launchPoint =="FLD.MRLINE.ITEMNUM"):
	owner=mbo.getOwner()

	requestedby = owner.getString("REQUESTEDBY")

	approved_lines_count = 0
	NewGL = getNewGLList()

	SEGMENT1=""
	SEGMENT2=""
	SEGMENT3=""
	SEGMENT4=""
	SEGMENT5=""
	SEGMENT6=""
	SEGMENT7=""
	SEGMENT8=""
	
	AppName=mbo.getThisMboSet().getParentApp()
	#service.error("","AppName:"+AppName)
	if itemnum and AppName in ('DM_CREATEDR','DM_VIEWIDR') :
		
		if mbo.isNew()!=0:
			personMboSet=owner.getMboSet("DM_PERSON")
			if not personMboSet.isEmpty():
				person = personMboSet.getMbo(0)
				SEGMENT2=person.getString("DM_GLLOCATION")
				NewGL[1] =person.getString("DM_GLLOCATION")
				orgHierarchySet=person.getMboSet("DM_SECTION")
				if not orgHierarchySet.isEmpty():
					orgHierarchy = orgHierarchySet.getMbo(0)
					#SEGMENT1=orgHierarchy.getString("ENTITY")
					#SEGMENT3=orgHierarchy.getString("COSTCENTER")
					NewGL[0]=orgHierarchy.getString("ENTITY")
					NewGL[2]=orgHierarchy.getString("COSTCENTER")
				
			itemSet=mbo.getMboSet("ITEM")
			if not itemSet.isEmpty():
				item = itemSet.getMbo(0)
				commoditiesSet=item.getMboSet("COMMODITIES")
				if not commoditiesSet.isEmpty():
					commodities = commoditiesSet.getMbo(0)
					#SEGMENT4=commodities.getString("DM_ACCOUNT")
					#SEGMENT5=commodities.getString("DM_SUBACCOUNT")
					NewGL[3]=commodities.getString("DM_ACCOUNT")
					NewGL[4]=commodities.getString("DM_SUBACCOUNT")
					SEGMENT6="00000"
					SEGMENT7="00000"
					SEGMENT8="00000"
					
			glDebitAcct=SEGMENT1 + "-" + SEGMENT2 + "-" + SEGMENT3+ "-" + SEGMENT4+ "-" + SEGMENT5+ "-" + SEGMENT6+ "-" + SEGMENT7+ "-" + SEGMENT8
			mbo.setValue("GLDEBITACCT",NewGLFormat(NewGL))