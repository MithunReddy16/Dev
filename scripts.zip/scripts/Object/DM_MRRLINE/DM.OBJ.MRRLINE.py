def setError(Msg):
		#global errorkey,errorgroup,params
		#errorkey='scriptvalidationerror'
		#errorgroup='scriptval'
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)
		
if launchPoint=='MRRLINE.INIT':
	App= mbo.getThisMboSet().getParentApp()
	MrrMbo= mbo.getOwner()
	if App =='DM_MRR':
		if  MrrMbo and not MrrMbo.getString('STATUS') in ('DRAFT','RETURN'):
			mbo.setFieldFlag(['ITEMNUM','CONDITION','QUANTITY','UNITCOST','MRNUM','WONUM','ASSETNUM','LOCATION','RETURNREASON','REMARKS'],7L,True)
		if  MrrMbo and not MrrMbo.getString('STATUS') in ('ASSIGNED'):
			mbo.setFieldFlag(['BINNUM'],7L,True)
			# below line modified by Mithun 
		if App =='DM_MRR' and MrrMbo and MrrMbo.getString('STATUS') in ('CLOSE'):
			mbo.setFieldFlag(['GLCREDITACCT','GLDEBITACCT'],7L,True)
			mbo.setFieldFlag(['DM_ACTUALDATE','GLDEBITACCT'],7L,True)
	
		
		if mbo.isNew():
			mbo.setValue('STORELOC',MrrMbo.getString('STORELOC'))
		  #  mbo.setValue('GLCREDITACCT',MrrMbo.getString('GLACCOUNT'))
		if  MrrMbo and MrrMbo.getString('RETURNTYPE') == 'WO':
			mbo.setFieldFlag(['MRNUM'],7L,True)
			mbo.setFieldFlag(['WONUM'],128L,True)
		elif   MrrMbo and MrrMbo.getString('RETURNTYPE') == 'MR':
			mbo.setFieldFlag(['WONUM'],7L,True)
			mbo.setFieldFlag(['MRNUM'],128L,True)
		else:
			mbo.setFieldFlag(['WONUM'],7L,True)
			mbo.setFieldFlag(['MRNUM'],7L,True)
		if  mbo.getFloat("QRETURN") +  mbo.getFloat("QREJECT")  == mbo.getFloat('QUANTITY'):
			mbo.setFlag(7L,True)
if launchPoint=='MRRLINE.CC':
	MrrMbo = mboset.getOwner()
	if MrrMbo.isNull('STORELOC'):
		setError('Please select storeroom.')
	elif MrrMbo.isNull('RETURNTYPE'):
		setError('Please select Return Type.')
		
	elif MrrMbo.getString('STATUS') not in ('DRAFT','RETURN'):
		setError('Lines can only be added on DRAFT and RETURN status.')