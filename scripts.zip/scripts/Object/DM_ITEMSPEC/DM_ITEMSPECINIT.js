load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")

//logger.error("Entering SR_INIT script for ticket " + mbo.getString("TICKETID"))
logger.error("***ASH***Sript DM_ITEMSPECINIT**START***")

if(mbo.toBeAdded() && mbo.getString("ASSETATTRID")!=null)
{
    assetattrDataType=mbo.getString("ASSETATTRIBUTE.DATATYPE")+"";
    //errorGroup=assetattrDataType+"grp"
    //errorKey=assetattrDataType+"key"
    //mbo.setValue("ALNVALUE",assetattrDataType);
    //mbo.setFieldFlag("DATEVALUE",MboConstants.READONLY,true)
    if(assetattrDataType.equalsIgnoreCase("NUMERIC"))
    {
        mbo.setFieldFlag("DATEVALUE",MboConstants.READONLY,true)
        mbo.setFieldFlag("ALNVALUE",MboConstants.READONLY,true)
        //mbo.setFieldFlag("TABLEVALUE",MboConstants.READONLY,true)
    }
    else if(assetattrDataType.equalsIgnoreCase("ALN"))
    {
         mbo.setFieldFlag("DATEVALUE",MboConstants.READONLY,true)
        mbo.setFieldFlag("NUMVALUE",MboConstants.READONLY,true)
    }
    else if(assetattrDataType.equalsIgnoreCase("DATE"))
    {
         mbo.setFieldFlag("NUMVALUE",MboConstants.READONLY,true)
        mbo.setFieldFlag("ALNVALUE",MboConstants.READONLY,true)
    }
}