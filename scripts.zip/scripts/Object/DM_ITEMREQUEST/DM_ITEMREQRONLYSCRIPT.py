# Modified by Mithun 
from psdi.mbo import Mbo
from psdi.mbo import MboConstants
from psdi.mbo import MboSet
from psdi.util import MXApplicationException


def setError(Msg):
		#global errorkey,errorgroup,params
		#errorkey='scriptvalidationerror'
		#errorgroup='scriptval'
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)
		
if launchPoint == "DM_ITEMREQRONLY":
    if(mbo.isNew()==0):
      status=mbo.getString("status")
      if status not in ("D-APPR","CLOSED","CAN"):
       if  mbo.isNull("ITRDESCRIPTION"):
                            mbo.setFieldFlag("ITRDescription", MboConstants.READONLY,False )
                            mbo.setFieldFlag("ITRDescription", MboConstants.REQUIRED, True)
      
      if status  in ('D-APPR'):
           mbo.setFieldFlag("ITRDescription", MboConstants.READONLY,True )
           mbo.setFieldFlag("ITRDescription", MboConstants.REQUIRED, False)
      if  status  in ('CLOSED','CAN'): 
          mbo.setFieldFlag("Status", MboConstants.READONLY,True )
      if  status  in ('WITEMUPD'):
          mbo.setFieldFlag("ITRDESCRIPTION", MboConstants.READONLY,True )
      line= mbo.getMboSet("DM_ITEMREQUESTLINE").getMbo(0)
      if line is not None:
                if status  in ("D-APPR"):
                   line.setFieldFlag(["DESCRIPTION", "Reason","DESCRIPTION_LONGDESCRIPTION"], MboConstants.READONLY, True)       
                if  status  in ('CLOSED','CAN'):   
                        line.setFieldFlag(["DESCRIPTION", "Reason","DESCRIPTION_LONGDESCRIPTION","itemnum"], MboConstants.READONLY, True)    
      

if launchPoint == "DM_ITEMREQDEL":
    
      delrequest = mbo.getOwner()
      
      status=delrequest.getString("status")
      
      if status in ("D-APPR","CLOSED","CAN"):
              		setError('Can not delete the line')
              		
if launchPoint == "DM_ITEMREQADD":
    
      addrequest = mboset.getOwner()
      
      status=addrequest.getString("status")
   
      
      if status in ("D-APPR","CLOSED","CAN"):
              		setError('Can not Add the line')