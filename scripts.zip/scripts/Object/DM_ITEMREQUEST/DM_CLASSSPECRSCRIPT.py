from psdi.mbo import MboConstants

def setError(msg):
    params = [msg]
    service.error('scriptval', 'scriptvalidationerror', params)

itemspecset = mbo.getMboSet("DM_ITEMSPEC")
itemspecmbo = itemspecset.moveFirst()

while itemspecmbo:
    if not itemspecmbo.toBeDeleted() and itemspecmbo.getInt("mandatory") == 1:
        
        attribute = itemspecmbo.getString("ASSETATTRID")
        
        assetattrset = itemspecmbo.getMboSet("ASSETATTRIBUTE")
        #assetattrset.setWhere("ASSETATTRID = '{}'".format(attribute))
        assetattrset.reset()
        assetattrmbo = assetattrset.moveFirst()
        
        if assetattrmbo:
            datatype = assetattrmbo.getString("DATATYPE").upper()
            
            alnvalue = itemspecmbo.getString("ALNVALUE")
            tablevalue = itemspecmbo.getString("TABLEVALUE")
            datevalue = itemspecmbo.getDate("DATEVALUE")
            numericvalue = itemspecmbo.getDouble("NUMVALUE")

            if datatype == "ALN" and not alnvalue:
                setError("ALN value is required for attribute {}".format(attribute))
            elif datatype == "TABLE" and not tablevalue:
                setError("Table value is required for attribute {}".format(attribute))
            elif datatype == "DATE" and not datevalue:
                setError("Date value is required for attribute {}".format(attribute))
            elif datatype == "NUMERIC" and numericvalue is None:
                setError("Numeric value is required for attribute {}".format(attribute))

    itemspecmbo = itemspecset.moveNext()