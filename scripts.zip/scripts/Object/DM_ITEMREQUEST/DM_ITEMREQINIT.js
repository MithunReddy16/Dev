load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")

//logger.error("Entering SR_INIT script for ticket " + mbo.getString("TICKETID"))
logger.error("***ASH***Sript DM_ITEMREQINIT**START***")
if(mbo.toBeAdded())
{
   

    //service.error(user,vPerson.getString("personid"))
}
else if (mbo.getString("STATUS").equalsIgnoreCase("CLOSED")  || mbo.getString("STATUS").equalsIgnoreCase("CAN"))
{
    mbo.setFlag(MboConstants.READONLY,true)
}

else if  (!(mbo.getString("STATUS").equalsIgnoreCase("NEW") || mbo.getString("STATUS").equalsIgnoreCase("RETURNED"))) {
    //mbo.setFieldFlag("REQUESTTYPE", MboConstants.READONLY, true);
        mbo.setFieldFlag("CLASSIFICATIONID", MboConstants.READONLY, true);
}


if (mbo.getString("classificationid") !== "") {
    mbo.setFieldFlag("dm_isoem", MboConstants.READONLY, true);
} else {
    mbo.setFieldFlag("dm_isoem", MboConstants.READONLY, false);
}


/*
var userInfo = mbo.getUserInfo();
var userName = userInfo.getUserName();
var groupName = "DM_IRSUP";

if (mbo.getString("STATUS").equalsIgnoreCase("APPROVED") || mbo.getString("STATUS").equalsIgnoreCase("WITEMUPD")) {
    var persongroupset = mbo.getMboSet("$tempGroup", "PERSONGROUPTEAM", "persongroup = '" + groupName + "' AND RESPPARTY = '" + userName + "'");
    var pmbo = persongroupset.getMbo(0);

    if (pmbo) {
        // mbo.setFlag(MboConstants.READONLY, true)
         mbo.setFieldFlag(["itemnum"], False, MboConstants.READONLY, True)
         
    }
    else
    {
        mbo.setFlag(MboConstants.READONLY,true)
    }
    

    persongroupset.close();
}*/