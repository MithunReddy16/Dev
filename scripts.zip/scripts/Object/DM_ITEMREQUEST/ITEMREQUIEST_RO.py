wfAssignmentSet = mbo.getMboSet("WFASSIGNMENT")
assigned = False
currentuser = mbo.getUserInfo().getPersonId()
wfMbo = wfAssignmentSet.moveFirst()
assign_user=""
if wfMbo:
    assign_user = wfMbo.getString("ASSIGNCODE")
    assigned = True
wfAssignmentSet.close()
'''
for i in range(wfAssignmentSet.count()):
	wfMbo = wfAssignmentSet.getMbo(i)
	assign_user = wfMbo.getString("ASSIGNCODE")
	assign_status = wfMbo.getString("ASSIGNSTATUS")
	if assign_user == currentuser and assign_status in ("ACTIVE"):
		assigned = True
		break

'''

if  assigned and not assign_user == currentuser :
	mbo.setFlag(7L,True)
	
elif  not assigned and not mbo.getString("status") in ('NEW') :
	mbo.setFlag(7L,True)
elif not assigned and mbo.getString("status") in ('NEW') and not mbo.getString('CREATEBY') == currentuser:
	mbo.setFlag(7L,True)