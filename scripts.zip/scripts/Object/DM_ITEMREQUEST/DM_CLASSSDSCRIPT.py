#######################################
#createby:ram
#date-06May25
#DM_CLASSSD-to update the shortdescription and long description of item request
#DM_CLASSSD3-to update the shortdescription and long description of item 
#requirement-if the item spec descrition length > 220 short description will update based on sequence if mandatory
#fields are there,it will be replaced the optional fields
#if the short description <220 then item spec attrbiutes will be updated based on sequence
#for long description,all the entered values comes from itemspec with format desription:value

#######################################
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory
from  psdi.common.context import UIContext
#from psdi.webclient.system.controller import SessionContext, Utility, WebClientEvent

logger = MXLoggerFactory.getLogger("maximo.custom")
logger.debug("Script execution started")

NoCaseChangeAttributes=['I-1001','I-1007','I-1013','I-1016','I-1019','I-1021','I-1022','I-1038','I-1041','I-1046','I-1049','I-1059','I-1064','I-1065','I-1066','I-1067',
    'I-1068','I-1072','I-1073','I-1074','I-1079','I-1081','I-1092','I-1101','I-1103','I-1104','I-1107','I-1108','I-1110','I-1111','I-1113','I-1114',
    'I-1118','I-1120','I-1121','I-1125','I-1131','I-1142','I-1149','I-1152','I-1154','I-1159','I-1160','I-1165','I-1166','I-1170','I-1173','I-1177',
    'I-1179','I-1184','I-1185','I-1186','I-1187','I-1200','I-1201','I-1217','I-1220','I-1221','I-1227','I-1233','I-1244','I-1245','I-1246','I-1247',
    'I-1248','I-1249','I-1252','I-1258','I-1259','I-1260','I-1267','I-1268','I-1280','I-1283','I-1290','I-1293','I-1296','I-1300','I-1311','I-1312',
    'I-1313','I-1315','I-1316','I-1328','I-1329','I-1330','I-1336','I-1339','I-1343','I-1349','I-1352','I-1354','I-1359','I-1360','I-1361','I-1367',
    'I-1373','I-1375','I-1376','I-1378','I-1379','I-1380','I-1382','I-1383','I-1386','I-1387','I-1390','I-1394','I-1428','I-1433','I-1434','I-1435',
    'I-1438','I-1440','I-1441','I-1442','I-1443','I-1445','I-1447','I-1449','I-1454','I-1458','I-1460','I-1461','I-1462','I-1463','I-1466','I-1473',
    'I-1479','I-1480','I-1483','I-1484','I-1486','I-1487','I-1490','I-1491','I-1508','I-1509','I-1514','I-1517','I-1518','I-1523','I-1525','I-1530',
    'I-1532','I-1539','I-1540','I-1542','I-1543','I-1545','I-1547','I-1548','I-1555','I-1560','I-1561','I-1562','I-1564','I-1565','I-1566','I-1569',
    'I-1572','I-1574','I-1578','I-1582','I-1588','I-1590','I-1591','I-1598','I-1608','I-1609','I-1619','I-1623','I-1624','I-1625','I-1627','I-1629',
    'I-1637','I-1641','I-1642','I-1644','I-1646','I-1661','I-1663','I-1667','I-1669','I-1672','I-1678','I-1679','I-1680']

if launchPoint == 'DM_CLASSSD':
    current_classification = mbo.getString("classificationid")
    previous_classification = mbo.getMboValue("classificationid").getPreviousValue().asString()
    logger.debug("Current classification: " + current_classification)
    logger.debug("Previous classification: " + previous_classification)
    

    if current_classification:
        
        itemSpecSet = mbo.getMboSet("dm_itemspec")
        itemSpec = itemSpecSet.moveFirst()
        if itemSpec:
            # Order By and Reset do not work as it is in memeory
            #itemSpecSet.setOrderBy("displaysequence")
            #itemSpecSet.reset()
            ## This concept to replace order by and reset
            specList =[]
            while itemSpec:
                # Change "WONUM" to your sort attribute
                specList.append((itemSpec.getInt("displaysequence"), itemSpec))
                itemSpec = itemSpecSet.moveNext()
            specList.sort(key=lambda x: x, reverse=True)
            
            ##
            Last5=[]
            #itemSpec = itemSpecSet.moveLast()
            #while len(Last5) < 5:
                #if itemSpec.getInt("displaysequence"):
                #    Last5.append(itemSpec.getInt("displaysequence"))
                #itemSpec = itemSpecSet.movePrev()
                
            for listSequence, itemSpec in specList:
                if len(Last5) == 5:
                    break
                Last5.append(listSequence)
                
                
            logger.debug("Last5 :" + str(Last5))
            

        
            long_description_parts = []
            short_description_parts = []

            classdesc = mbo.getString("dm_classdesc.DESCRIPTION").upper()
            logger.debug("Class description: " + classdesc)

            if classdesc:
                                                               
                long_description_parts.append(classdesc + ";")
                short_description_parts.append(classdesc + ";")



            attr_entries = []

            #itemSpec = itemSpecSet.moveFirst()                                                     
            specList.sort(key=lambda x: x)
            FirstOne = True
            min_seq = None
            #while itemSpec:
            for listSequence, itemSpec in specList:
                if not itemSpec.toBeDeleted() and itemSpec.getInt("DISPLAYSEQUENCE") not in Last5:
                                                                      
                    if itemSpec.getString("ASSETATTRID") in NoCaseChangeAttributes:
                        alnvalue = itemSpec.getString("alnvalue")
                        tablevalue = itemSpec.getString("tablevalue")
                        
                    else:
                        alnvalue = itemSpec.getString("alnvalue").upper()
                        tablevalue = itemSpec.getString("tablevalue").upper()                

                    numvalue = itemSpec.getDouble("numvalue")
                    datevalue = itemSpec.getDate("datevalue")                
                    attributedescription = itemSpec.getString("assetattribute.description").upper()
                    attrprefix = itemSpec.getString("assetattribute.attrdescprefix").upper()
                    sequence = itemSpec.getInt("DISPLAYSEQUENCE")
                    mandatory = itemSpec.getBoolean("mandatory")
                    secondary = itemSpec.getBoolean("dm_secmandatory")

                    values = []
                    if alnvalue:
                        values.append(alnvalue)
                    if datevalue:
                        values.append(str(datevalue))
                    if tablevalue:
                        values.append(tablevalue)
                    if numvalue:
                        values.append(str(numvalue))

                    if values:
                        attr_entries.append({
                            "value": ", ".join(values),
                            "description": attributedescription,
                            "prefix": attrprefix,
                            "sequence": sequence,
                            "mandatory": mandatory,
                            "secondary": secondary
                        })
                                        
                    if FirstOne:
                        if values:
                            min_seq = sequence

                        FirstOne= False
                            
                    logger.debug("aa-values :" + str(values))
                    
                #itemSpec = itemSpecSet.moveNext()


            seq10 = []
            mandatory_oem = []
            mandatory_non_oem = []
            non_mandatory = []

            for entry in attr_entries:
                if entry["sequence"] == min_seq:
                    seq10.append(entry)
                    continue

            
                if entry["mandatory"]:
                    mandatory_oem.append(entry)
                elif not entry["mandatory"] and entry["secondary"]:
                    mandatory_non_oem.append(entry)
                
                else:
                    non_mandatory.append(entry)

            mandatory_oem.sort(key=lambda x: x["sequence"])
            mandatory_non_oem.sort(key=lambda x: x["sequence"])
            non_mandatory.sort(key=lambda x: x["sequence"])

            ordered_attrs = seq10 + mandatory_oem + mandatory_non_oem + non_mandatory
            logger.debug("Total attributes to use (ordered): " + str(len(ordered_attrs)))

            # LONG DESCRIPTION
            long_attributes = []
            for entry in ordered_attrs:
                if entry["description"] and entry["value"]:
                    long_attributes.append(entry["description"] + ": " + entry["value"])
            logger.debug("Long attributes: " + str(long_attributes))

            if long_attributes:
                long_description = " ".join(long_description_parts + [", ".join(long_attributes)])
                mbo.setValue("DM_LONGDESC_LONGDESCRIPTION", long_description, MboConstants.NOACCESSCHECK)
            else:
                mbo.setValue("DM_LONGDESC_LONGDESCRIPTION", classdesc, MboConstants.NOACCESSCHECK)

            if classdesc:
                classdesc_part = classdesc + ";"
                classdesc_length = len(classdesc_part)
                short_str = classdesc_part
            else:
                short_str = ""
            
            remaining_space = 220 - len(short_str)
            logger.debug("Remaining space for short desc attributes: " + str(remaining_space))
            
            short_attr_parts = []
            for entry in ordered_attrs:
                if entry["value"]:
                    prefixordesc = entry["prefix"] if entry["prefix"] else entry["description"]
                    part = prefixordesc + ": " + entry["value"]
                    total = ", ".join(short_attr_parts + [part])
                    if len(total) <= remaining_space:
                        short_attr_parts.append(part)
                        logger.debug("Added to short_attr_parts: " + part)
                    else:
                        logger.debug("Skipping attribute due to length limit: " + part)
                        break

            if short_attr_parts:
                short_description = (short_str + " " + ", ".join(short_attr_parts))
                mbo.setValue("DM_SHORTDESCRIPTION_LONGDESCRIPTION", short_description, MboConstants.NOACCESSCHECK)
                logger.debug("Set c: " + short_description)
            else:
                mbo.setValue("DM_SHORTDESCRIPTION_LONGDESCRIPTION", short_str, MboConstants.NOACCESSCHECK)
                logger.debug("Set DM_SHORTDESCRIPTION_LONGDESCRIPTION fallback: " + short_str)

            # Restore itemSpecSet cursor

            if itemSpecSet:
                logger.debug("Amir==> moving First" )
                itemSpecSet.moveFirst()
            
            uiContext = UIContext.getCurrentContext()
            if uiContext != None:
                wcs = uiContext.getWebClientSession()
                logger.debug("Amir==> fireDataChangedEvent" )
                wcs.getDataBean("specification_itemspectable").fireDataChangedEvent()

        
"""
if launchPoint == 'DM_CLASSD2':
    
    classification = mbo.getString("classificationid")

    if classification:
        mbo.setFieldFlag("dm_isoem", MboConstants.READONLY, True)
        
        
        mbo.setValueNull("DM_SHORTDESCRIPTION_LONGDESCRIPTION", MboConstants.NOACCESSCHECK)
        mbo.setValueNull("DM_LONGDESC_LONGDESCRIPTION", MboConstants.NOACCESSCHECK)
        itemSpecSet = mbo.getMboSet("dm_itemspec")
        itemSpecSet.moveFirst()
    else:    
        mbo.setFieldFlag("dm_isoem",MboConstants.READONLY|MboConstants.NOACCESSCHECK, False)
"""    
        


if launchPoint == 'DM_CLASSD3':

    current_classification = mbo.getString("CLASSSTRUCTUREID")
    previous_classification = mbo.getMboValue("CLASSSTRUCTUREID").getPreviousValue().asString()

    if current_classification:
        itemSpecSet = mbo.getMboSet("ITEMSPECCLASS")
        itemSpecSet.setOrderBy("DISPLAYSEQUENCE")
        itemSpecSet.reset()
        Last5 = []
        itemSpec = itemSpecSet.moveLast()
        while itemSpec and len(Last5) < 5:
            dispseq = itemSpec.getInt("DISPLAYSEQUENCE")
            Last5.append(dispseq)
            itemSpec = itemSpecSet.movePrev()

        logger.debug("Last5 :" + str(Last5))

        currentPosition = itemSpecSet.getCurrentPosition()
        long_description_parts = []
        short_description_parts = []

        classdesc = mbo.getString("CLASSSTRUCTURE.DESCRIPTION_CLASS").upper()
        if classdesc:
            short_description_parts.append(classdesc + ";")
            long_description_parts.append(classdesc + ";")

        attr_entries = []

        itemSpec = itemSpecSet.moveFirst()
        FirstOne = True
        min_seq = None
        while itemSpec:
            if not itemSpec.toBeDeleted() and itemSpec.getInt("DISPLAYSEQUENCE") not in Last5:
                    #For Size and Frequency Range,values are not upper
                    if itemSpec.getString("ASSETATTRID") in NoCaseChangeAttributes:
                        alnvalue = itemSpec.getString("alnvalue")
                        tablevalue = itemSpec.getString("tablevalue")
                        
                    else:
                        alnvalue = itemSpec.getString("alnvalue").upper()
                        tablevalue = itemSpec.getString("tablevalue").upper()
                        
                    numvalue = itemSpec.getDouble("numvalue")
                    datevalue = itemSpec.getDate("datevalue")
                    attributedescription = itemSpec.getString("assetattribute.description").upper()
                    attrprefix = itemSpec.getString("assetattribute.attrdescprefix").upper()
                    sequence = itemSpec.getInt("DISPLAYSEQUENCE")
                    mandatory = itemSpec.getBoolean("mandatory")
                    secondary = itemSpec.getBoolean("dm_secmandatory")

                    values = []
                    if alnvalue:
                        values.append(alnvalue)
                    if datevalue:
                        values.append(str(datevalue))
                    if tablevalue:
                        values.append(tablevalue)
                    if numvalue:
                        values.append(str(numvalue))

                    if values:
                        attr_entries.append({
                            "value": ", ".join(values),
                            "description": attributedescription,
                            "prefix": attrprefix,
                            "sequence": sequence,
                            "mandatory": mandatory,
                            "secondary": secondary
                        })
                    
                    if FirstOne:
                        if values:
                            min_seq = sequence

                        FirstOne= False
                            
                        logger.debug("aa-values :" + str(values))
            itemSpec = itemSpecSet.moveNext()

        seq10 = []
        mandatory_oem = []
        mandatory_non_oem = []
        non_mandatory = []

        #if attr_entries:
        #    min_seq = min(entry["sequence"] for entry in attr_entries if entry["sequence"] is not None)
        #else:
        #    min_seq = None

        for entry in attr_entries:
            if entry["sequence"] == min_seq:
                seq10.append(entry)
                continue
            if entry["mandatory"]:
                mandatory_oem.append(entry)
            elif not entry["mandatory"] and entry["secondary"]:
                mandatory_non_oem.append(entry)
            
            else:
                non_mandatory.append(entry)

        mandatory_oem.sort(key=lambda x: x["sequence"])
        mandatory_non_oem.sort(key=lambda x: x["sequence"])
        non_mandatory.sort(key=lambda x: x["sequence"])

        ordered_attrs = seq10 + mandatory_oem + mandatory_non_oem + non_mandatory

        long_attributes = []
        for entry in ordered_attrs:
            if entry["description"] and entry["value"]:
                long_attributes.append(entry["description"] + ": " + entry["value"])

        if long_attributes:
            long_description = " ".join(long_description_parts + [", ".join(long_attributes)])
            mbo.setValue("DESCRIPTION_LONGDESCRIPTION", long_description, MboConstants.NOACCESSCHECK)
        else:
            mbo.setValue("DESCRIPTION_LONGDESCRIPTION", classdesc + ";", MboConstants.NOACCESSCHECK)

        if classdesc:
            classdesc_part = classdesc + ";"
            classdesc_length = len(classdesc_part)
            short_str = classdesc_part
        else:
            short_str = ""

        remaining_space = 220 - len(short_str)
        logger.debug("Remaining space for short desc attributes: " + str(remaining_space))

        short_attr_parts = []
        for entry in ordered_attrs:
            if entry["value"]:
				prefixordesc = entry["prefix"] if entry["prefix"] else entry["description"]
				part = prefixordesc + ": " + entry["value"]
				total = ", ".join(short_attr_parts + [part])
				if len(total) <= remaining_space:
				    short_attr_parts.append(part)
				    logger.debug("Added to short_attr_parts: " + part)
				else:
				    logger.debug("Skipping attribute due to length limit: " + part)
				    break

        if short_attr_parts:
            short_description = (short_str + " " + ", ".join(short_attr_parts))
            mbo.setValue("description", short_description, MboConstants.NOACCESSCHECK)
            logger.debug("Set description: " + short_description)
        else:
            mbo.setValue("description", short_str, MboConstants.NOACCESSCHECK)
            logger.debug("Set description fallback: " + short_str)

        if itemSpecSet:
            itemSpecSet.moveFirst()