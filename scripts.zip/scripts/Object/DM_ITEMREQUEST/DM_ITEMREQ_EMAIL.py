from psdi.server import MXServer

#Trigger mail notification when new Item code request is submitted
if(mbo.isModified("STATUS") and mbo.getString("STATUS") == 'NEW' and app=='DM_ITEMREQ'):
    ctSet = mbo.getMboSet("$CT", "COMMTEMPLATE", "templateid='DM_ITEMREQ_SUB'")
    ct = ctSet.getMbo(0)
    if ct:
        ct.sendMessage(mbo, mbo)
    else:
        service.log("DM_ITEMREQ_SUB: Template DM_ITEMREQ_SUB not found")


#Trigger mail notification when update Item code request is submitted
if(mbo.isModified("STATUS") and mbo.getString("STATUS") == 'NEW' and app=='DM_UPDITEMREQ'):
    ctSet = mbo.getMboSet("$CT", "COMMTEMPLATE", "templateid='DM_UPDITEM_SUB'")
    ct = ctSet.getMbo(0)
    if ct:
        ct.sendMessage(mbo, mbo)
    else:
        service.log("DM_UPDITEM_SUB: Template DM_ITEMREQ_SUB not found")