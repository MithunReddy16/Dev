from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.mbo import MboSet
from psdi.mbo import Mbo	

relatedkey=mbo.getString("RELATEDRECKEY")

			
recwhere ="ticketid in (select recordkey from RELATEDRECORD where  RELATEDRECCLASS='WORKORDER' and class='SR' and  recordkey='"+relatedkey+"') "
			
recset = mbo.getMboSet("$DM_REC$","SR",recwhere)
if not recset.isEmpty():
        
      params=["Multiple Workorder is not allowed on the Ticket"]
      service.error("DM", "genericerror", params)