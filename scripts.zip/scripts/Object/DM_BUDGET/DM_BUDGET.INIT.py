#if not mbo.isNull('year'):
#    mbo.setValue('budgetid',mbo.getString('siteid') + '-' + mbo.getString('year'))

if V_YEAR !=None:
    V_BUDGETID=V_SITE +"-" + V_YEAR