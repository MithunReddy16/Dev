## Mithun Modified below lines 
from psdi.util.logging import MXLoggerFactory
logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("***Mithun***Script Receving Rotating Asset Input**START***")
logger.debug("******1")
SerialNum = mbo.getString("SERIALNUM")
logger.debug("******1serial ***"+str(SerialNum))
if (SerialNum is None or SerialNum==''):
    errorMsg="Error asset " +mbo.getString("assetnum")+ " .Asset Serial is required for serialization";
    service.error("scriptval","scriptvalidationerror",[errorMsg])

ItemLevel4Set =  mbo.getMboSet("LEVEL4_ROTITEM")

if (not ItemLevel4Set.isEmpty()):
    assetTag = mbo.getString("DM_ASSET_TAG")
    if (assetTag is None or assetTag==''):
        errorMsg="Error asset " +mbo.getString("assetnum")+ " .Asset Tag is required for serialization";
        ##service.error("scriptval","scriptvalidationerror",[errorMsg])
        ## Mithun commented above line not to throw DM_ASSET_TAG 
"""
else:
    ItemLevel5Set =  mbo.getMboSet("LEVEL5_ROTITEM")
    if (not ItemLevel5Set.isEmpty()):
        SerialNum = mbo.getString("SERIALNUM")
        if (SerialNum is None or SerialNum==''):
            errorMsg="Error asset " +mbo.getString("assetnum")+ " .Asset Serial is required for serialization";
            service.error("scriptval","scriptvalidationerror",[errorMsg])
    else:
        service.error('scriptval','scriptvalidationerror',["Invalid Item Classification"])
"""
## above else is Modified by Mithun