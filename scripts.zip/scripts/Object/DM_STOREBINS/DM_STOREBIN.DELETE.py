if not mbo.getMboSet("INVBALANCES").isEmpty():
    service.error('deletebin','alreadyinuse')