/*
Modified By: Ashok
Date: 23-MAy-2024
Req: To validate the bin numbers entered by users

*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")

logger.error("***ASH***Sript DM_STOREBIN.SAVE**START***")
logger.error("***ASH***Sript DM_STOREBIN.SAVE**launchPoint="+launchPoint)

storename = mbo.getString("STOREROOMNAME")
seg01  = mbo.getString("BINSEG01")
seg03  = mbo.getString("BINSEG03")
seg04  = mbo.getString("BINSEG04")
seg05  = mbo.getString("BINSEG05")

if(mbo.toBeAdded())
{
    if (seg01 != "" && seg03 != "" && seg04 != "" && seg05 != "" && storename!="")
	{
        //binnum1=storename  + '-' + seg01 + '-' + seg03 + '-' + seg04 + '-' + seg05
        binnum1= seg01 + '-' + seg03 + '-' + seg04 + '-' + seg05
        storeBinSet=mbo.getMboSet("$DM_STOREBINS","DM_STOREBINS","binnum='"+binnum1+"' and siteid=:siteid")
        logger.error("***ASH***Sript DM_STOREBIN.SAVE** storeBinSet.where="+storeBinSet.getCompleteWhere())
        //storeBinSet.reset()
        if(storeBinSet.count()>0)
		{           
            service.error("storebin","binnumunqval")
		}
        else
		{
            mbo.setValue("BINNUM", binnum1)
		}
	}
    else
	{
        service.error("dm_locid","invalidid")
	}
}