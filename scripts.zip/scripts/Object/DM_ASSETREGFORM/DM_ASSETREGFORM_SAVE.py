#------------------------------------------------------------------------

#Script Name :DM_ASSETREGFORM_SAVE
#Description :change asset status when the asset form approved
#Comment     :Used in Asset Register Form Application.
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          20-Sept-2025         Initiate version.

#------------------------------------------------------------------------
from psdi.server import MXServer

service.log_debug("######################################## Start:" + scriptName+" ######################")

# Get the current system date and time.
currentDate = MXServer.getMXServer().getDate()
status = mbo.getString("status")
if status == "APPR":
    assetMboAsset= mbo.getMboSet("ASSETFORM")
    assetMbo = assetMboAsset.moveFirst()
    while assetMbo:
        if "NOT READY" == assetMbo.getString("status"):
            assetMbo.changeStatus("OPERATING",currentDate,"") 
            
        assetMbo = assetMboAsset.moveNext()

#update last change date.
mbo.setValue("CHANGEDDATE",currentDate)





service.log_debug("######################################## Start:" + scriptName+" ######################")