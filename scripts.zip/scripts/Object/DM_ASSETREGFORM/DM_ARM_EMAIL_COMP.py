#Author Mithun 
from psdi.server import MXServer

if(mbo.isModified("STATUS") and mbo.getString("STATUS") == 'COMP'):
    ctSet = mbo.getMboSet("$CT", "COMMTEMPLATE", "templateid='DM_ARM_COMP'")
    ct = ctSet.getMbo(0)

    if ct:
        ct.sendMessage(mbo, mbo)
    else:
        service.log("DM_MR_EMAIL: Template DM_ARM_COMP not found")