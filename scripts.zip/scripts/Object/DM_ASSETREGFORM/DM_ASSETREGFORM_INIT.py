#------------------------------------------------------------------------

#Script Name :DM_ASSETREGFORM_INIT
#Description : script to set fields inputmode conditionally.
#Comment     :Used in Aseet Register Form Application
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          20-Sept-2025         Initiate version.
#Mithun 
#------------------------------------------------------------------------
from psdi.mbo import MboConstants

service.log_debug("######################################## Start:" + scriptName+" ######################")


if not mbo.isNull("MAINTAINERDEPT"):
    mbo.setFieldFlag("ASSIGNEE",MboConstants.READONLY,True)

if not mbo.isNull("ASSIGNEE") and mbo.isNull("MAINTAINERDEPT"):
    mbo.setFieldFlag("MAINTAINERDEPT",MboConstants.READONLY,True)


# below lines added by Mithun 
if onadd and app == 'DM_ASSETREGMANAGE' :
    #mbo.setValue("STATUS","DRAFT")
    service.log_debug("***** loguser**** "+user)
    userMbo=mbo.getMboSet("$rel","MAXUSER","userid='"+user+"'").moveFirst()
    if userMbo :
        personMbo=userMbo.getMboSet("PERSON").moveFirst()
        if personMbo :
            mbo.setValue("ASSIGNEE",personMbo.getString("PERSONID"))
            mbo.setValue("DEPARTMENT",personMbo.getString("DM_DEPARTMENT"))
    

if mbo.getString("STATUS") not in ["DRAFT","WAMDREV","RETDEPTREV"]  and not mbo.isNew():
    editable_fields =["STATUS","CHANGEDDATE"]
    #mbo.setFieldFlag(editable_fields, False, MboConstants.READONLY, True)
    #mbo.setFlag(MboConstants.READONLY, True)

if mbo.getString("STATUS") in ["COMP"] :
    #mbo.setFieldFlag("SOURCE",MboConstants.READONLY,True)
    #mbo.setFieldFlag("SOURCEREF",MboConstants.READONLY,True)
    #mbo.setFieldFlag("ASSIGNEE",MboConstants.READONLY,True)
    #editable_fields =[""]
    #mbo.setFieldFlag(editable_fields, False, MboConstants.READONLY, True)
    mbo.setFlag(MboConstants.READONLY, True)
    
    

service.log_debug("######################################## End:" + scriptName+" ######################")