#script:DM_DISPDOCSCRIPT
#Createdby:Ram
#Creation Date:22-NOV-24
#scope:attachments can not be added or deleted if the disposal record is closed or decommission request record is closed

from psdi.mbo import MboConstants

if launchPoint == "DM_DISPDOC":

    if mboset.getOwner() is not None and mboset.getOwner().getName() == "DM_DISPOSAL" and mboset.getOwner().getString("status") == "CLOSED":
        service.error("dm", "genericerror", ["Attachments can not be Added on closed record"])
    if mboset.getOwner() is not None and mboset.getOwner().getName() == "DM_DISPOSALLINE" and mboset.getOwner().getOwner().getString("status") == "CLOSED":
        service.error("dm", "genericerror", ["Attachments can not be Added on closed record"])
    #05/11/2025: added below code for accident:
    if mboset.getOwner() is not None and mboset.getOwner().getName() == "DM_ACCIDENT" and mboset.getOwner().getString("status") == "CLOSE":
        service.error("dm", "genericerror", ["Attachments can not be Added on closed record"])
    #--------------------------------- below is the code for ARM (Asset Registration management ) by Mithun 
    if mboset.getOwner() is not None and mboset.getOwner().getName() == "DM_ASSETREGFORM" and mboset.getOwner().getString("status") in ["WGRPREG","WTECHATTR","WAMDFINAL","COMP"]:
        service.error("dm", "genericerror", ["Attachments can not be Added on current status."])


if launchPoint == "DM_DISPDOCD":

    currentuser = mbo.getUserInfo().getPersonId()
    groupUserSet = mbo.getMboSet("$GROUPUSER", "GROUPUSER", "GROUPNAME = 'MAXADMIN' AND USERID = '{}'".format(currentuser))
    groupUserSet.reset()
    #05/11/2025: added below code for accident
    if mbo.getOwner() is not None and mbo.getOwner().getName() == "DM_ACCIDENT" and mbo.getOwner().getString("status") == "CLOSE":
        service.error("dm", "genericerror", ["Attachments can not be Deleted on closed record"])
    #---------------    
    if mbo.getOwner() is not None and mbo.getOwner().getName() == "DM_DISPOSAL" and mbo.getOwner().getString("status") == "CLOSED":
        service.error("dm", "genericerror", ["Attachments can not be Deleted on closed record"])
    if mbo.getOwner() is not None and mbo.getOwner().getName() == "DM_DISPOSALLINE" and mbo.getOwner().getOwner().getString("status") == "CLOSED":
        service.error("dm", "genericerror", ["Attachments can not be Deleted on closed record"])
    if mbo.getOwner() is not None and mbo.getOwner().getName() == "DM_DISPOSALLINE":
        wflineset = mbo.getMboSet("$TEMPWF", "wfinstance", """ownerid = (select dm_disposalline.dm_disposallineid from wfinstance, dm_disposalline, doclinks, dm_disposal 
                where wfinstance.active = 1 and wfinstance.ownerid = dm_disposal.dm_disposalid
                and dm_disposalline.dm_disposallineid = doclinks.ownerid and doclinks.ownertable = 'DM_DISPOSALLINE'
                and dm_disposal.disposalnum = dm_disposalline.disposalnum and dm_disposalline.dm_disposallineid = :ownerid 
                and wfinstance.PROCESSNAME = 'DISP-MAIN')""")
        wflineset.reset()
        if groupUserSet.isEmpty():
            if wflineset.count() > 0:
                wfMbo = wflineset.getMbo(0)
                wfAssignmentSet = wfMbo.getMboSet("ACTIVEASSIGNMENTS")
                wfAssignmentSet.setWhere("assigncode = '{}'".format(currentuser))
                wfAssignmentSet.reset()
                if wfAssignmentSet.count() == 0:
                    service.error("dm", "genericerror", ["Attachments can not be Deleted "])
                if mbo.getString("createby") != currentuser and wfAssignmentSet.count() > 0:
                    service.error("dm", "genericerror", ["Attachments can not be Deleted "])
            elif mbo.getString("createby") != currentuser:
                service.error("dm", "genericerror", ["Attachments can not be Deleted "])

    if mbo.getOwner() is not None and mbo.getOwner().getName() == "DM_DISPOSAL":
        wfset = mbo.getMboSet("$TEMPWF", "wfinstance", """ownerid = (select dm_disposal.dm_disposalid from wfinstance, doclinks, dm_disposal 
                where wfinstance.active = 1 and wfinstance.ownerid = dm_disposal.dm_disposalid
                and dm_disposal.dm_disposalid = doclinks.ownerid and doclinks.ownertable = 'DM_DISPOSAL'
                and dm_disposal.dm_disposalid = :ownerid and wfinstance.PROCESSNAME = 'DISP-MAIN')""")
        wfset.reset()
        if groupUserSet.isEmpty():
            if wfset.count() > 0:
                wfMbo = wfset.getMbo(0)
                wfAssignmentSet = wfMbo.getMboSet("ACTIVEASSIGNMENTS")
                wfAssignmentSet.setWhere("assigncode = '{}'".format(currentuser))
                wfAssignmentSet.reset()
                if wfAssignmentSet.count() == 0:
                    service.error("dm", "genericerror", ["Attachments can not be Deleted "])
                if mbo.getString("createby") != currentuser and wfAssignmentSet.count() > 0:
                    service.error("dm", "genericerror", ["Attachments can not be Deleted "])
            elif mbo.getString("createby") != currentuser:
                service.error("dm", "genericerror", ["Attachments can not be Deleted "])
                
                
                
     #--------------------------------- below is the code for ARM (Asset Registration management ) by Mithun 
    if mbo.getOwner() is not None and mbo.getOwner().getName() == "DM_ASSETREGFORM" and mbo.getOwner().getString("status") in ["WGRPREG","WTECHATTR","WAMDFINAL","COMP"]:
        service.error("dm", "genericerror", ["Attachments can not be Delete on current status."])