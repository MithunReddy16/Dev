from org.apache.poi.xssf.usermodel import XSSFWorkbook
from java.io import FileInputStream
from psdi.server import MXServer

mbo = service.getMbo()

docSet = mbo.getMboSet("DOCLINKS")

if not docSet.isEmpty():

    doc = docSet.moveFirst()

    while doc:

        urlname = doc.getString("URLNAME")

        if "DECOMM_ASSET_LIST" in urlname.upper():

            fis = FileInputStream(urlname)
            workbook = XSSFWorkbook(fis)

            sheet = workbook.getSheetAt(0)

            for row in sheet:

                cell1 = row.getCell(0)
                cell2 = row.getCell(1)

                value1 = ""
                value2 = ""

                if cell1:
                    value1 = str(cell1)

                if cell2:
                    value2 = str(cell2)
                    
                    
                msg = "Column1=" + value1 + " Column2=" + value2
                service.error("chk",msg)
                service.log("Column1=" + value1 + " Column2=" + value2)

                # Example:
                # Create or update Maximo records here

            workbook.close()
            fis.close()

        doc = docSet.moveNext()