if not mbo.isNew():
    mbo.setFieldFlag("YEAR",7,True)