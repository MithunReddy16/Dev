from psdi.server import MXServer

mxs = MXServer.getMXServer()
wfstart = mxs.lookup('WORKFLOW')

if mbo.isNew() and mbo.getString("TYPE") == "DEP":
    wfstart.initiateWorkflow('DM_INVEST',mbo)
    
    
if mbo.isModified("STATUS") and mbo.getString("STATUS")=="WPSSAPPR":

    investnum  = mbo.getString("INVESTNUM")
    siteid     = mbo.getString("SITEID")
    department = mbo.getString("DEPARTMENT")
    year       = mbo.getInt("YEAR")

    # Automatically mark the Ad-hoc Flag for the un approved opportunity

    whereClause = (
        "INVESTNUM='{}' AND "
        "SITEID='{}' AND "
        "DEPARTMENT='{}' AND "
        "YEAR={} AND "
        "STATUS NOT IN ('APPR','CANCEL','REJECT')"
    ).format(investnum, siteid, department, year)

    oppSet = mbo.getMboSet(
        "TEMP_OPP",
        "DM_INVESTOPPORTUNITY",
        whereClause
    )

    opp = oppSet.moveFirst()
    while opp:
        opp.setValue("ADHOC", 1)
        opp = oppSet.moveNext()

    oppSet.close()