from psdi.mbo import MboConstants
from psdi.mbo import Mbo

logger = service.getLogger("DM")

Owner=mbo.getOwner()

if Owner is not None:
    #mbo.setValue('wfid',Owner.getInt('wfid'))
    #mbo.setValue('DM_PROCESSNAME',Owner.getString('PROCESSNAME'))
    #mbo.setValue('DM_PROCESSREV',Owner.getInt('revision'))
   # mbo.setValue('DM_PROCESSNAME','')
    #mbo.setValue('DM_PROCESSREV',Owner.getInt('revision'))
    mainprocess=Owner.getString('PROCESSNAME')
    mainwfid=Owner.getInt('wfid')
    ownerid=Owner.getInt('ownerid')
    logger.info("test_1w" + str(mainwfid)) 
    logger.info("test_2w1" + str(ownerid)) 
    logger.info("test_3w2" + mainprocess) 
    #stackSet=mbo.getMboSet("$STACK", "WFCALLSTACk", "wfid = " +str(mainwfid)+ "  and processname!='"+mainprocess+"'")
    #stackSet=mbo.getMboSet("$STACK", "WFCALLSTACk", "wfid = 173608  and processname!='"+mainprocess+"'")
    stackSet=mbo.getMboSet("$STACK", "WFCALLSTACk", "wfid = " +str(mainwfid)+ "  and processname!='"+mainprocess+"' and callseq in (select max(callseq) from wfcallstack where wfid='"+str(mainwfid)+"')")
    childmbo = stackSet.moveFirst()
    if childmbo is not None:
        mbo.setValue('DM_PROCESSNAME',childmbo.getString('PROCESSNAME'))
    elif childmbo is None:   
            tranSet=mbo.getMboSet("$TRAN", "WFTRANSACTION", "ownerid =  '"+str(ownerid)+"'  and processname!='"+mainprocess+"' and  transid in (select max(transid) from WFTRANSACTION where ownerid = '"+str(ownerid)+"' and nodetype='START' )")
            #tranSet=mbo.getMboSet("$TRAN", "WFTRANSACTION", "ownerid =  "+str(ownerid)+"  and processname!='"+mainprocess+"'")    
           # tranSet=mbo.getMboSet("$TRAN", "WFTRANSACTION", "wfid =173584  and processname!='"+mainprocess+"'")
            tranmbo = tranSet.moveFirst()
            if tranmbo is not None:
                       ownerid=Owner.getInt('ownerid')
                       logger.info("test_1w" + str(mainwfid)) 
                       logger.info("test_2w1" + str(ownerid)) 
                       logger.info("test_3w21" + mainprocess)
                       mbo.setValue('DM_PROCESSNAME',tranmbo.getString('PROCESSNAME'))