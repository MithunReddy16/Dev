from psdi.server import MXServer


if mbo.isNew():
    personSet = MXServer.getMXServer().getMboSet("PERSON", mbo.getUserInfo())
    personSet.setWhere("PERSONID= '" + mbo.getUserInfo().getPersonId() + "'" )
    personSet.reset()
    personMbo = personSet.getMbo(0)
    mbo.setValue('DM_SECTOR',personMbo.getString('DM_SECTOR'))
    mbo.setValue('DM_DEPARTMENT',personMbo.getString('DM_DEPARTMENT'))
    mbo.setValue('DM_SECTION',personMbo.getString('DM_SECTION'))
    if app =='DM_DECOM':
        mbo.setValue('DISPOSALTYPE','Decommission',11L)
        mbo.setValue('INTERNALTYPE','Decommission')
        #mbo.setValue('DISPOSALNUM','ADR-' + mbo.getString('DISPOSALNUM'))
    elif app =='DM_DISPOSAL':
        mbo.setValue('INTERNALTYPE','Disposal')
        
else:
    if mbo.getString('STATUS') not in ('DRAFT','REJECTED','WDEPTCO', 'DCREJECTED','WAMDCO'):
        mbo.setFieldFlag('DESCRIPTION',7L,True)