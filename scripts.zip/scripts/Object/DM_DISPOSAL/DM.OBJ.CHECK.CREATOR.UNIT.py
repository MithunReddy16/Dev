from psdi.server import MXServer

personSet = MXServer.getMXServer().getMboSet("PERSON", mboset.getUserInfo())
personSet.setWhere("PERSONID= '" + mboset.getUserInfo().getPersonId() + "'" )
personSet.reset()
personMbo = personSet.getMbo(0)
if personMbo:
	if personMbo.isNull('dm_section') or personMbo.isNull('dm_department') or personMbo.isNull('dm_sector'):
		service.error('dm_itemreq','secfldmissing')
else:
	service.error('dm_itemreq','secfldmissing')