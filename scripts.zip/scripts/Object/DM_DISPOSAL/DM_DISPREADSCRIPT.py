#script:DM_DISPREADSCRIPT
#Createdby:Ram
#Creation Date:13-FEB-25
#scope:if the disposal/decommisison  record is in workflow record can not be edited unless the logged user is the current owner of the workflow

from psdi.mbo import MboConstants

#user = mbo.getUserInfo().getUserName()
user = mbo.getUserInfo().getPersonId()


wfAssignmentSet = mbo.getMboSet("WFASSIGNMENT")
assigned = False

if mbo.getMboSet("DM_DISPOSALLINE").getMbo(0) is not None:
    mbo.setFieldFlag("MAINTAINERDEPT", MboConstants.READONLY, True)
    mbo.setFieldFlag("ISLOCALMAINTAINER", MboConstants.READONLY, True)

if not mbo.toBeAdded() and  wfAssignmentSet.count()>0:
    for i in range(wfAssignmentSet.count()):
        wfMbo = wfAssignmentSet.getMbo(i)
        assign_user = wfMbo.getString("ASSIGNCODE")
        assign_status = wfMbo.getString("ASSIGNSTATUS")

       
        if assign_user == user and assign_status in ("ACTIVE"):
            assigned = True
            break  


    if not assigned:
        
        mboSet = mbo.getThisMboSet()
        #mboSet.setFlag(7L,True)
        mbo.setFlag(7L,True)
        lineblock = mbo.getMboSet("dm_disposalline")
        lineblock.setFlag(7L,True)