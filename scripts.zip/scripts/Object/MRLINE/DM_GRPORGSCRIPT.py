from psdi.mbo import MboConstants
from psdi.mbo import MboRemote
from psdi.util import MXApplicationException
from psdi.util.logging import MXLoggerFactory

logger = service.getLogger("maximo.dm")

logger.debug(">>> Entering script DM_IVCOMP")



        
if launchPoint == "DM_GRPORGL":
    
    app = mboset.getParentApp()
    if app == 'DM_CREATEDR' or app == 'DM_VIEWIDR'  :           
    	if mboset.getOwner() is not None and mboset.getOwner().getName()=="MR" and mboset.getOwner().isNull("DM_GRPORG"): 
            
    			service.error("dm","genericerror",["Warehouse field should be entered before adding a line"])
    			

        if mboset.getOwner() is not None and mboset.getOwner().getName()=="MR" :
                
                mboset.getOwner().setFieldFlag("DM_GRPORG", MboConstants.READONLY, True)
                
    #Work Order STP, SRWN            
    if app in ('DM_PLUSGWO_STP','DM_PLUSGWO_SRWN'): 
        
        if mboset.getOwner() is not None and mboset.getOwner().getName()=="MR" and mboset.getOwner().isNull("DM_GRPORG"):
            service.error("dm","genericerror",["Please enter the Storeroom before adding a line"])
            
        if mboset.getOwner() is not None and mboset.getOwner().getName()=="MR" :
                
                mboset.getOwner().setFieldFlag("DM_GRPORG", MboConstants.READONLY, True)