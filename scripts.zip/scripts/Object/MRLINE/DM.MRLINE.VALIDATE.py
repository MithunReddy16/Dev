# ------------------------------------------------------------------
# Author :     Mithun 
# Script:      DM.MRLINE.VALIDATE  
# Purpose:     Object level validation 
# ------------------------------------------------------------------

from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
logger = MXLoggerFactory.getLogger("maximo.custom.inventory")

def setError(Msg):
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)
application = mbo.getThisMboSet().getParentApp()
if application== "DM_CREATEDR" or application == "DM_VIEWIDR":
    try:
        if  "?" in mbo.getString("GLDEBITACCT"):
            mrlinenum=mbo.getString("MRLINENUM")
            setError("Please verify the GL Debit values in line number "+mrlinenum+".")
    except Exception, e:
        logger.error("****CHECKGLQMARK - error while checking GL lines: " + str(e))