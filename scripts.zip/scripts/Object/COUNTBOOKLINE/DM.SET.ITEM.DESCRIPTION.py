if mbo.isNew():
	owner = mbo.getOwner()
	if owner:
		if not owner.isNull("GLCREDITACCOUNT"):
			mbo.setValue("GLCREDITACCOUNT",owner.getString("GLCREDITACCOUNT"),11L)
		if not owner.isNull("GLDEBITACCOUNT"):
			mbo.setValue("GLDEBITACCOUNT",owner.getString("GLDEBITACCOUNT"),11L)

if not mbo.toBeAdded() and not mbo.isNull("itemnum"):
	mbo.setValue("DM_ITEMDESCRIPTION",mbo.getString("item.description")[:300],11L)