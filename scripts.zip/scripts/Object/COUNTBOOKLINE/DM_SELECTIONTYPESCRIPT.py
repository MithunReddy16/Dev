from psdi.mbo import MboConstants

countbook = mbo.getOwner()
cb = mbo.getOwner()
#if cb is not None:
#    service.error("dm", "genericerror", ["CB selectiontype: " + str(cb.getString("SELECTIONTYPE"))])
#else:
#    service.error("dm", "genericerror", ["No COUNTBOOK owner found"])