from psdi.server import MXServer

if(mbo.isModified("STATUS") and mbo.getString("STATUS") == 'WAPPR'):
    ctSet = mbo.getMboSet("$CT", "COMMTEMPLATE", "templateid='DM_MRR_SUBMIT'")
    ct = ctSet.getMbo(0)
    if ct:
        ct.sendMessage(mbo, mbo)
    else:
        service.log("DM_MRR_EMAIL: Template DM_MRR_SUBMIT not found")