from psdi.server import MXServer


mxServer = MXServer.getMXServer()

if launchPoint == 'MRR.CC':
	personSet =mxServer.getMboSet("PERSON", mxServer.getSystemUserInfo())
	personSet.setWhere("PERSONID= '" + mboset.getUserInfo().getPersonId() + "'" )
	
	personSet.reset()
	personMbo = personSet.getMbo(0)
	
	if personMbo:
		if personMbo.isNull('dm_section') or personMbo.isNull('dm_department') or personMbo.isNull('dm_sector'):
			service.error('dm_itemreq','secfldmissing')
	else:
		service.error('dm_itemreq','secfldmissing')
elif launchPoint =='MRR.INIT':
	if mbo.isNew():
		personSet = mxServer.getMboSet("PERSON", mxServer.getSystemUserInfo())
		personSet.setWhere("PERSONID= '" + mbo.getUserInfo().getPersonId() + "'" )
		
		personSet.reset()
		personMbo = personSet.getMbo(0)
		
		if personMbo:
			mbo.setValue('SECTOR',personMbo.getString('DM_SECTOR'))
			mbo.setValue('DEPARTMENT',personMbo.getString('DM_DEPARTMENT'))
			mbo.setValue('SECTION',personMbo.getString('DM_SECTION'))
	
	
	
	if (mbo.getString('STATUS') not in ('DRAFT','RETURN')) and not mbo.isNew():
		mbo.setFieldFlag(['DESCRIPTION','GLACCOUNT'],7L,True)
	if (mbo.getString('STATUS') in ('CLOSE','ASSIGNED')) :
		mbo.setFieldFlag(['ASSIGNEDTO'],7L,True)
	if not mbo.evaluateCondition("DM_MRR14"):
		mbo.setFieldFlag(['ASSIGNEDTO'],7L,True)
		if not mbo.getString('STATUS') in ('DRAFT','RETURN'):
			mbo.getMboSet("DOCLINKS").setFlag(7L,True)
	
	if app == 'DM_MRR' and not mbo.isNew() :
		wfAssignmentSet = mbo.getMboSet("WFASSIGNMENT")
		assigned = False
		currentuser = mbo.getUserInfo().getPersonId()
		for i in range(wfAssignmentSet.count()):
			wfMbo = wfAssignmentSet.getMbo(i)
			assign_user = wfMbo.getString("ASSIGNCODE")
			assign_status = wfMbo.getString("ASSIGNSTATUS")
			if assign_user == currentuser and assign_status in ("ACTIVE"):
				assigned = True
				break  
		if not assigned and mbo.getString("status") not in ('DRAFT','RETURN'):
			mboSet = mbo.getThisMboSet()
			mbo.setFlag(7L,True)
			lineblock = mbo.getMboSet("DM_MRRLINE")
			lineblock.setFlag(7L,True)