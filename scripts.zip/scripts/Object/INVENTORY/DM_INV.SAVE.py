if mbo.toBeAdded():
    itemSet = mbo.getMboSet("ITEM")
    
    if (itemSet is not None and not itemSet.isEmpty()):
        availability = itemSet.getMbo(0).getString("DM_AVAILABILITY")
        condition = itemSet.getMbo(0).getString("DM_CONDITION")
        mainUser = itemSet.getMbo(0).getString("DM_MAINUSER")
        plan = itemSet.getMbo(0).getString("DM_PLANNING")
        sourcing = itemSet.getMbo(0).getString("DM_SOURCING")

        mbo.setValue("DM_AVAILABILITY",availability)
        mbo.setValue("DM_CONDITION",condition)
        mbo.setValue("DM_MAINUSER",mainUser)
        mbo.setValue("DM_PLANNING",plan)
        mbo.setValue("DM_SOURCING",sourcing)