# Author : Mithun
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants
logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("**** DM_ONHAND.INIT debug Started ***1")

def setError(Msg):
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)

if launchPoint=='DM_ONHAND.INIT':
    if app == 'DM_ONHAND'  :    
        if not  mbo.isNew() :
        	if mbo.getBoolean("SYNCGRP") :
        	    mbo.setFieldFlag("STOREROOM", MboConstants.READONLY, True) 
        	if not  mbo.getBoolean("SYNCGRP") :
        	    mbo.setFieldFlag("STOREROOM", MboConstants.READONLY, False)
        if not  mbo.isNew() :
            if not mbo.getMboSet("DM_ONHANDLINES").isEmpty() :
                mbo.setFieldFlag("STOREROOM", MboConstants.READONLY, True)
            elif mbo.getMboSet("DM_ONHANDLINES").isEmpty() :
                mbo.setFieldFlag("STOREROOM", MboConstants.READONLY, False)
                mbo.setValue("SYNCGRP",0)