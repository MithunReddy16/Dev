# Author : Mithun
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants
logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("**** DM_ONHANDLINE.SAVE debug Started ***1")

def setError(Msg):
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)

if launchPoint=='DM_ONHANDLINE.SAVE':
    if app == 'DM_ONHAND'  :           
    	if  mbo.isNull("STOREROOM"): 
    			setError("Storeroom field should be entered before Saving.")
    	if mbo.getBoolean("SYNCGRP") :
    	    mbo.setFieldFlag("STOREROOM", MboConstants.READONLY, True) 
    	if not  mbo.getBoolean("SYNCGRP") :
    	    mbo.setFieldFlag("STOREROOM", MboConstants.READONLY, False)