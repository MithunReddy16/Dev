# Author Mithun
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

mylogger = MXLoggerFactory.getLogger("maximo.custom.inventory")
mylogger.debug("*****DM_MR.SETVALUESFROMPERSON***1")
if app =='DM_CREATEDR':
    if mbo.isNew():
        person=mbo.getUserInfo().getPersonId()
        mylogger.debug("*****DM_MR.SETVALUESFROMPERSON***2"+str(mbo.getUserInfo().getPersonId()))
        personMbo=mbo.getMboSet("$person","PERSON","personid ='"+person+"'").getMbo(0)
        if personMbo :
            mylogger.debug("*****DM_MR.SETVALUESFROMPERSON***3")
            section=personMbo.getString("DM_SECTION")
            sector=personMbo.getString("DM_SECTOR")
            department=personMbo.getString("DM_DEPARTMENT")
            mbo.setValue("DM_SECTOR",sector)
            mbo.setValue("DM_DEPARTMENT",department)
            mbo.setValue("DM_SECTION",section)
            mylogger.debug("*****DM_MR.SETVALUESFROMPERSON***4")