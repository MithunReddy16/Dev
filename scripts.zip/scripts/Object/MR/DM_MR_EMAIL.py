#Author Mithun 
from psdi.server import MXServer
service.log_debug("**** WHERN MR IS APPROVED ****")
if app == 'DM_VIEWIDR':

    if(mbo.isModified("STATUS") and mbo.getString("STATUS") == 'APPR'):
        ctSet = mbo.getMboSet("$CT", "COMMTEMPLATE", "templateid='DM_MR_APPROVE'")
        ct = ctSet.getMbo(0)
    
        if ct:
            ct.sendMessage(mbo, mbo)
        else:
            service.log("DM_MR_EMAIL: Template DM_MR_APPROVE not found")
            

    
AppName=mbo.getThisMboSet().getParentApp()
if  AppName in ('DM_PLUSTWO')   :
    if(mbo.isModified("STATUS") and mbo.getString("STATUS") == 'APPR'):
        ctSet = mbo.getMboSet("$CT", "COMMTEMPLATE", "templateid='DM_TR_STORE'")
        ct = ctSet.getMbo(0)
    
        if ct:
            ct.sendMessage(mbo, mbo)
        else:
            service.log_debug("DM_TR_STORE: Template DM_TR_STORE not found")