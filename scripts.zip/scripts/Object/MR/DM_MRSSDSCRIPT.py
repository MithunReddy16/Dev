from psdi.server import MXServer
from psdi.mbo import MboConstants

personSet = MXServer.getMXServer().getMboSet("PERSON", mbo.getUserInfo())
personSet.setWhere("PERSONID= '" + mbo.getUserInfo().getPersonId() + "'" )
personSet.reset()
personMbo = personSet.getMbo(0)
if personMbo:
	if personMbo.isNull('dm_section') or personMbo.isNull('dm_department') or personMbo.isNull('dm_sector'):
                service.error("dm","genericerror",["Section,sector,department should not be empty"])
              #	service.error('dm_itemreq','secfldmissing')