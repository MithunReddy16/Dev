#STPSCRIPT

from psdi.mbo import MboConstants

if launchPoint=="DM_MRREAD":

    if app == 'DM_VIEWIDR':
        currentuser = mbo.getUserInfo().getPersonId()
        requestedby = mbo.getString("requestedby")
        
        if currentuser != requestedby:
            mbo.setFieldFlag("requestedby", MboConstants.READONLY, True)
            mbo.setFieldFlag("requestedfor", MboConstants.READONLY, True)
            mbo.setFieldFlag("requireddate", MboConstants.READONLY, True)
            mbo.setFieldFlag("description", MboConstants.READONLY, True)
            mbo.setFieldFlag("dm_trpriority", MboConstants.READONLY, True)
            mbo.setFieldFlag("dm_grporg", MboConstants.READONLY, True)
            mrline = mbo.getMboSet("mrline")
            mrline.setFlag(7L, True)

        
        if currentuser == requestedby and mbo.getString("status")  in ('WAPPR','PENDINGMD', 'CCRETURN', 'MURETURN','PENDING','SMAPPR','DDAPPR','DDRETURN'):
            mbo.setFieldFlag("dm_grporg", MboConstants.READONLY, True)
            mbo.setFieldFlag("requestedby", MboConstants.READONLY, True)
            mbo.setFieldFlag("requestedfor", MboConstants.READONLY, True)
            mrline = mbo.getMboSet("mrline")
            mrline.setFlag(7L, True)
            
if launchPoint == "DM_MRQTYREAD":
    app=mbo.getThisMboSet().getParentApp()
    if app == 'DM_VIEWIDR':
        if mbo.isNew()==0 and mbo.getOwner() is not None and mbo.getOwner().getName() == "MR" and mbo.getOwner().getString("status") not in  ('WAPPR','PENDINGMD', 'CCRETURN', 'MURETURN','PENDING','SMAPPR','DDAPPR','DDRETURN'):
            requestedby=''
            
            currentuser =mbo.getOwner().getUserInfo().getPersonId()
            requestedby = mbo.getOwner().getString("requestedby")
            if currentuser == requestedby and mbo.getBoolean("dm_appr"):
                
                mbo.setFieldFlag("qty", MboConstants.READONLY, True)
            elif  currentuser == requestedby and not mbo.getBoolean("dm_appr"):
                    mbo.setFieldFlag("qty", MboConstants.READONLY, False)