from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

myLogger = MXLoggerFactory.getLogger("maximo.custom")

itemnum = mbo.getString("ITEMNUM")
mrnum = mbo.getString("MRNUM")
mrlinenum = mbo.getInt("MRLINENUM")
requestedby = mbo.getOwner().getString("REQUESTEDBY")

approved_lines_count = 0

if itemnum:
    
    if mbo.isNew()!=0:
        
            mbo.setValue("dm_ccappr", False, MboConstants.NOACCESSCHECK)
            mbo.setValue("dm_muappr", False, MboConstants.NOACCESSCHECK)
            mbo.setValue("dm_appr", False, MboConstants.NOACCESSCHECK)
    ItemSet = MXServer.getMXServer().getMboSet("ITEM", mbo.getUserInfo())
    ItemSet.setWhere("itemnum = '{}'".format(itemnum))
    ItemSet.reset()

    if not ItemSet.isEmpty():
        item = ItemSet.getMbo(0)
        commodity = item.getString("COMMODITY")
        mainuser = item.getString("DM_MAINUSER")
        commodity_parts = commodity.split('-') 

        if len(commodity_parts) > 1:
            commodity_prefix = commodity_parts[0]
            commodity_number = int(commodity_parts[1])

            DM_MRA_Set = MXServer.getMXServer().getMboSet("DM_MRA", mbo.getUserInfo())
            DM_MRA_Set.reset()

            if DM_MRA_Set.count() > 0:
                for j in range(DM_MRA_Set.count()):
                    DM_MRA = DM_MRA_Set.getMbo(j)
                    from_category = DM_MRA.getString("fromcategory")
                    to_category = DM_MRA.getString("tocategory")
                    approver_assigned = DM_MRA.getString("approveby")

                    from_category_parts = from_category.split('-')
                    to_category_parts = to_category.split('-')

                    if len(from_category_parts) > 1 and len(to_category_parts) > 1:
                        from_category_prefix = from_category_parts[0]
                        from_category_number = int(from_category_parts[1])
                        to_category_prefix = to_category_parts[0]
                        to_category_number = int(to_category_parts[1])

                        if commodity_prefix == from_category_prefix == to_category_prefix:
                            myLogger.info('Prefix match: {} == {} == {}'.format(
                                commodity_prefix, from_category_prefix, to_category_prefix))
                            myLogger.info('Commodity {} is within range {}-{}'.format(
                                    commodity, from_category_number, to_category_number))
                            if from_category_number <= commodity_number <= to_category_number:
                                myLogger.info('Commodity {} is within range {}-{}'.format(
                                    commodity, from_category_number, to_category_number))

                                if approver_assigned:
                                    personSet = mbo.getMboSet(
                                        "$EMXPERSONGROUP", 
                                        "PERSONGROUPTEAM", 
                                        "persongroup = '{}' AND respparty = '{}'".format(approver_assigned, requestedby)
                                    )
                                    personMbo = personSet.getMbo(0)

                                    if personMbo:
                                        #if not item.getString("dm_mainuser"):
                                            mbo.setValue("dm_ccappr", True, MboConstants.NOACCESSCHECK)
                                            myLogger.info('MR Line {} approved by approver {}.'.format(mrlinenum, requestedby))
                                            approved_lines_count += 1
                                            break
                                        #elif item.getString("dm_mainuser"):
                                         #   mbo.setValue("dm_ccappr", True, 2L)
                                            myLogger.info(
                                                'Approver {} is not assigned to MR Line {} via DM_MRA.'.format(requestedby, mrlinenum)
                                            )
                                else:
                                    myLogger.info('No approver found for item {}.'.format(itemnum))

        if mainuser:
            personSet = mbo.getMboSet(
                "$EMXPERSONGROUP", 
                "PERSONGROUPTEAM", 
                "persongroup = '{}' AND respparty = '{}'".format(mainuser, requestedby)
            )
            if personSet.count() > 0:
                myLogger.info('Approver {} is a member of persongroup {}.'.format(requestedby, mainuser))
                mbo.setValue("dm_muappr", True, MboConstants.NOACCESSCHECK)
                approved_lines_count += 1
        
            
else:
    if not itemnum:
        mbo.setValue("dm_ccappr", False, MboConstants.NOACCESSCHECK)
        mbo.setValue("dm_muappr", False, MboConstants.NOACCESSCHECK)
        mbo.setValue("dm_appr", False, MboConstants.NOACCESSCHECK)
        myLogger.info("Item-related fields cleared as ITEMNUM is removed.")

myLogger.info("Processed ITEMNUM={} on MRLINE {}. Total approved MR lines: {}".format(itemnum, mrlinenum, approved_lines_count))