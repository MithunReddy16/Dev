#script:DM_AUTOWFS
#Createdby:Ram
#Modifiedby : Mithun
#Creation Date:25-MAY-22
#scope: scrippt validates the workorder for launchpoint (DM_AUTOWOWF) and based on the entered info such as maintenance section,vendor,serviceid,supervisor,contract,crew in workorder script will route the workorder to respective departments for approval
#and the entred information will comes from sr and pm based on the work type,if route is entered in contract related to the workorder contract lines will copy from contract to planned boq tab
#and there are other launchpoints too here and it follows the same rules as above.
from psdi.server import MXServer
from psdi.mbo import Mbo
from psdi.util.logging import MXLoggerFactory
from psdi.server import MXServer
from java.sql import Connection
from java.sql import Statement
from java.text import SimpleDateFormat
from psdi.mbo import MboConstants
from java.util import HashMap
from java.util import Date


logger = MXLoggerFactory.getLogger("maximo.autoscript.autwfs")
logger.debug("DM_AUTOWFS -START")

mxs = MXServer.getMXServer()
wfstart = mxs.lookup('WORKFLOW')
app = mbo.getThisMboSet().getParentApp()

if launchPoint == 'DM_AUTOWFRECEIPTS':
      status = mbo.getString("status") 
      if status =='APPR' and mbo.getString("RECEIPTS")=='NONE':
            wfstart.initiateWorkflow('DM_RECMAIN',mbo)
    
if launchPoint == 'DM_AUTOPOWF':
       wfstart.initiateWorkflow('DM_PORECWF',mbo)
       
if launchPoint == 'DM_PTWWF':
       wfstart.initiateWorkflow('DM_PTWWF',mbo)  
       
if launchPoint == 'DM_MRWFL':
        #if app == "DM_CREATEDR":
        #       wfstart.initiateWorkflow('DM_MRMAIN',mbo)
               
        if app in ("DM_PLUSGWO_STP","DM_PLUSGWO_SRWN") and mbo.getString("status") == "WAPPR":
           # service.error("dm","genericerror")
            wfstart.initiateWorkflow('DM_WOMR',mbo)        
   
if interactive and launchPoint == 'DM_AUTOSRWF' and app not in ("DM_ADVSR",'DM_SR_ADV'):
    if app in ("DM_PLUSGSR_GM","DM_CREATESR_GM","DM_CREATESR_GM_MOB"):
        wfstart.initiateWorkflow('DM_GSRMAIN',mbo)
    if app in ("DM_CREATSR_STP","DM_PLUSGSR_STP"):
        wfstart.initiateWorkflow('DM_SSRMAIN',mbo)   
    if app in ("DM_CREATSR_SRWN"):
        mbo.setValue("DM_INHOUSE",1)
        wfstart.initiateWorkflow('DM_SRWNSR',mbo)
    else:    
        wfstart.initiateWorkflow('DM_SRMAIN',mbo)
	    
if launchPoint == 'DM_ASSETWFL':
    status = mbo.getString("status")
    if status=='NOT READY':
            wfstart.initiateWorkflow('DM_PROCQU2',mbo)
            
         
if launchPoint =='DM_GMWFS':         
            woMbo =mbo.getMboSet("WORKORDER").getMbo(0)
            if woMbo is not None:
                logger.info("GMWO_5" + launchPoint) 
                field1 = mbo.getString("dm_gmwf1")
                woMbo.setValue('dm_gmwf1',field1 , MboConstants.NOACCESSCHECK) 

if launchPoint == 'DM_AUTOWOWF':
     pmMbo =mbo.getMboSet("PM").getMbo(0)
     srMbo =mbo.getMboSet("DM_SR2WO").getMbo(0)
     asset=mbo.getString("assetnum")
     #service.error("dm","genericerror")
     #if mbo.isNew() and not mbo.isNull("PARENT"):
      #  mbo.setValue("DM_MAINTDEPT",mbo.getOwner().getString("DM_MAINTDEPT")) 
     if mbo.isNew() and not mbo.isNull("PARENT"): 
					        currentUser = mxs.getUserInfo(user) 
					        persond = currentUser.getPersonId()  
					        personMbo = mbo.getMboSet('$person', 'person', "personid = '" + persond + "'").getMbo(0)
					        persondept = personMbo.getString("DM_Department")
					        mbo.setValue("dm_maintdept", persondept, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION) 
					        #Added for the PM Priority to copy the child wo
					        #if mbo.getString("DM_TRPRIORITY"):
					            
					            # mbo.setValue("DM_TRPRIORITY", mbo.getOwner().getString("DM_TRPRIORITY"),2L)
     if mbo.isNew() and not mbo.isNull("PARENT") and mbo.getString("WORKTYPE") in ("CP","MD"):
            mbo.setValue("DM_MAINTDEPT",mbo.getOwner().getString("DM_MAINTDEPT"))
            mbo.setValue("WORKTYPE",mbo.getOwner().getString("WORKTYPE"))
            mbo.setValue("DM_VENDCONTRACT", mbo.getOwner().getString("DM_VENDCONTRACT"),2L)
            mbo.setValue("DM_VENDCONTREVNUM", mbo.getOwner().getString("DM_VENDCONTREVNUM"),2L)
            mbo.setValue("DM_INHOUSE", mbo.getOwner().getString("DM_INHOUSE"),2L)
            mbo.setValue("DM_SERVICETYPE", mbo.getOwner().getString("DM_SERVICETYPE"),2L)
     if mbo.isNew() and mbo.getString("worktype")=='FIND':
         wfstart.initiateWorkflow('DM_WINMAIN',mbo)	        
     if srMbo is not None:
        
        owner = srMbo.getString("owner")
        crew=srMbo.getString("AMCREW")
        dm_maintdept=srMbo.getString("dm_maintdept")
        dm_maintsec=srMbo.getString("dm_maintsec")
        dm_serviceid=srMbo.getString("dm_serviceid")
        dm_inhouse=srMbo.getBoolean("dm_inhouse")
        dm_bunit=srMbo.getString("dm_bunit")
        vendor=srMbo.getString("vendor")
        dm_responeng=srMbo.getString("dm_responeng")
        supervisor=srMbo.getString("supervisor")
        pcontract=srMbo.getString("DM_VENDCONTRACT")
        worktype=srMbo.getString("DM_WOTYPE")
        targetstart=srMbo.getDate("TARGETSTART")
        targetfinish=srMbo.getDate("TARGETFINISH")
        rpriority=srMbo.getString("REPORTEDPRIORITY")
        crewType=srMbo.getString("DM_CREWTYPE")
        personGroup=srMbo.getString("DM_PERSONGROUP")
        dataEntryGroup=srMbo.getString("DM_DATAENTRYGROUP")
        mbo.setValue('owner',owner , MboConstants.NOACCESSCHECK)
        mbo.setValue('AMCREW',crew , MboConstants.NOACCESSCHECK)
        mbo.setValue('supervisor',supervisor , MboConstants.NOACCESSCHECK)
        mbo.setValue('dm_maintdept',dm_maintdept , MboConstants.NOACCESSCHECK)
        mbo.setValue('dm_serviceid',dm_serviceid , MboConstants.NOACCESSCHECK)
        mbo.setValue('DM_SERVICETYPE',mbo.getString("DM_SERVICETYPE.TYPE") , MboConstants.NOACCESSCHECK)
        mbo.setValue('dm_bunit',dm_bunit , MboConstants.NOACCESSCHECK)
        #below line DM_CREWTYPE added by Mithun
        mbo.setValue('DM_CREWTYPE',crewType , MboConstants.NOACCESSCHECK)
        mbo.setValue('PERSONGROUP',personGroup , MboConstants.NOACCESSCHECK)
        mbo.setValue('DM_DATAENTRYGROUP',dataEntryGroup , MboConstants.NOACCESSCHECK)
        ownerGroup = srMbo.getString("ownergroup")
        
        if ownerGroup:
            mbo.applyOwnerGroup(ownerGroup)

        if dm_maintsec:
            valueSet = mbo.getMboSet("$value","DM_ORGHIERARCHY","unitid='"+dm_maintsec+"'")
            for i in range(valueSet.count()):
                    maxvalue = valueSet.getMbo(i).getString("abbriviation")
                    unitid = valueSet.getMbo(i).getString("unitid")
                    if   maxvalue in ('DCL','TAS','SRP','STP','SRN') and unitid == dm_maintsec:
                            mbo.setValue('dm_maintsec',dm_maintsec , MboConstants.NOACCESSCHECK)

        maintDeptSet = mbo.getMboSet("$value","DM_ORGHIERARCHY","unitid='"+dm_maintdept+"'")
        maintDeptMbo=maintDeptSet.moveFirst()
        if maintDeptMbo:
            maxvalue = maintDeptMbo.getString("abbriviation")
            #service.error("dm","genericerror",[maxvalue])
            if maxvalue=='GMD':
                #service.error("dm","genericerror",["ERRROR"])
                mbo.setValue('dm_maintsec',dm_maintsec , MboConstants.NOACCESSCHECK)
                mbo.setValue('dm_serviceid',dm_serviceid , MboConstants.NOACCESSCHECK)
                mbo.setValue('vendor',vendor , MboConstants.NOACCESSCHECK)
                mbo.setValue('worktype',worktype , MboConstants.NOACCESSCHECK)
                mbo.setValue('dm_inhouse',dm_inhouse , MboConstants.NOACCESSCHECK)
                mbo.setValue('dm_extsr',srMbo.getBoolean("dm_extsr") , MboConstants.NOACCESSCHECK)
                mbo.setValue('TARGSTARTDATE',targetstart , MboConstants.NOACCESSCHECK)
                mbo.setValue('TARGCOMPDATE',targetfinish , MboConstants.NOACCESSCHECK)
                mbo.setValue('wopriority',rpriority , MboConstants.NOACCESSCHECK)
                cmbo=srMbo.getMboSet("DM_SERVICECATALOG").getMbo(0)
                if cmbo is not None:
                    dm_servicetype=cmbo.getString("type")
                    mbo.setValue('dm_servicetype',dm_servicetype , MboConstants.NOACCESSCHECK)
                if pcontract is not None:
                    vMbo=srMbo.getMboSet("$VENDCONRACT","CONTRACT","contractnum='"+pcontract+"' and status='APPR' order by revisionnum desc").getMbo(0)
                if vMbo is not None:
                    revision=vMbo.getInt("REVISIONNUM")
                    mbo.setValue('DM_VENDCONTRACT',pcontract , MboConstants.NOACCESSCHECK)
                    mbo.setValue('DM_VENDCONTREVNUM',revision , MboConstants.NOACCESSCHECK)
            if maxvalue in ('STP','SRN'):
                
	            mbo.setValue('dm_maintsec',dm_maintsec , MboConstants.NOACCESSCHECK)
	            mbo.setValue('vendor',vendor , MboConstants.NOACCESSCHECK)
	            mbo.setValue('worktype',worktype , MboConstants.NOACCESSCHECK)
	           # service.error(maxvalue,bunit)
	            if maxvalue=='SRN'and dm_bunit=="WSHUNIT":
	               # service.error(maxvalue,bunit)
	                mbo.setValue('dm_inhouse',1 , MboConstants.NOACCESSCHECK)
	            else:
	                mbo.setValue('dm_inhouse',dm_inhouse , MboConstants.NOACCESSCHECK)
	            if not dm_inhouse:
	                mbo.setValue("DM_PTWREQ",True)
	            mbo.setValue('TARGSTARTDATE',targetstart , MboConstants.NOACCESSCHECK)
	            mbo.setValue('TARGCOMPDATE',targetfinish , MboConstants.NOACCESSCHECK)
	            mbo.setValue('wopriority',rpriority , MboConstants.NOACCESSCHECK)  
	            if pcontract is not None:
	                vMbo=srMbo.getMboSet("$VENDCONRACT","purchview","contractnum='"+pcontract+"' and status='APPR' order by revisionnum desc").getMbo(0)
                    if vMbo is not None:
                        revision=vMbo.getInt("REVISIONNUM")
                        ctype=vMbo.getString("dm_contracttype")
                        mbo.setValue('DM_VENDCONTRACT',pcontract , MboConstants.NOACCESSCHECK)
                        mbo.setValue('DM_VENDCONTREVNUM',revision , MboConstants.NOACCESSCHECK)
                        mbo.setValue('dm_contracttype',ctype , MboConstants.NOACCESSCHECK)
            
     if pmMbo is not None:
         service.log_debug("***  pm  is not none *****")
         dm_maintdept=pmMbo.getString("dm_maintdept")
         dm_maintsec=pmMbo.getString("dm_maintsec")
         dm_servicetype=pmMbo.getString("dm_servicetype")
         dm_responeng=pmMbo.getString("dm_responeng")
         supervisor=pmMbo.getString("supervisor")
         vendor=pmMbo.getString("dm_vendor")
         priority=pmMbo.getString("priority")
         dm_bunit=pmMbo.getString("dm_bunit")
         dm_crewtype=pmMbo.getString("DM_CREWTYPE")
         insptype=pmMbo.getString("dm_insptype")
         #service.error("rsr",priority,[dm_maintdept])
         dm_inhouse=pmMbo.getBoolean("dm_inhouse")
         dm_shutdown=pmMbo.getBoolean("dm_shutdown")
         pcontract=pmMbo.getString("DM_VENDCONTRACT")
         if mbo.isNull("estdur") and not pmMbo.isNull("dm_estduration"):
             mbo.setValue('estdur',pmMbo.getDouble("dm_estduration") , MboConstants.NOACCESSCHECK)
         mbo.setValue('dm_maintdept',dm_maintdept , MboConstants.NOACCESSCHECK)
         mbo.setValue('dm_maintsec',dm_maintsec , MboConstants.NOACCESSCHECK)
         mbo.setValue('wopriority',priority , MboConstants.NOACCESSCHECK)
         mbo.setValue('DM_TRPRIORITY',priority , MboConstants.NOACCESSCHECK)
         mbo.setValue("DM_SERVICETYPE", dm_servicetype,2L)
         mbo.setValue("dm_location", pmMbo.getString("dm_floc"),2L)
         mbo.setValue('dm_bunit',dm_bunit , MboConstants.NOACCESSCHECK)
         mbo.setValue('DM_CREWTYPE',dm_crewtype , MboConstants.NOACCESSCHECK)
         maintDeptSet = mbo.getMboSet("$value","DM_ORGHIERARCHY","unitid='"+dm_maintdept+"'")
         maintDeptMbo=maintDeptSet.moveFirst()
         if maintDeptMbo:
            maxvalue = maintDeptMbo.getString("abbriviation")
            if maxvalue in ('APM'):
                
                mbo.setValue('DM_INSPTYPE',insptype , MboConstants.NOACCESSCHECK)
            if maxvalue in ('GMD','STP','SRN'):
                service.log_debug("***  pm  is not none1 *****")
                mbo.setValue('dm_servicetype',dm_servicetype , MboConstants.NOACCESSCHECK)
                mbo.setValue('dm_inhouse',dm_inhouse , MboConstants.NOACCESSCHECK)
                mbo.setValue('dm_shutdown',dm_shutdown , MboConstants.NOACCESSCHECK)
                mbo.setValue('vendor',vendor , MboConstants.NOACCESSCHECK)
                mbo.setValue('supervisor',supervisor , MboConstants.NOACCESSCHECK)
                if pcontract is not None:
                    vMbo=pmMbo.getMboSet("$VENDCONRACT","CONTRACT","contractnum='"+pcontract+"' and status='APPR' order by revisionnum desc").getMbo(0)
                    if vMbo is not None:
                        revision=vMbo.getInt("REVISIONNUM")
                        mbo.setValue('DM_VENDCONTRACT',pcontract , MboConstants.NOACCESSCHECK)
                        mbo.setValue('DM_VENDCONTREVNUM',revision , MboConstants.NOACCESSCHECK)        
                #below lines added by Mithun  
                if maxvalue in ('SRN'):
                    service.log_debug("***  pm  is not none 2*****")
                    if mbo.getString("DM_BUNIT") == "WSHUNIT":
                        ownergroup='DM_SRNWE'
                        mbo.applyOwnerGroup(ownergroup)
                    elif mbo.getString("DM_BUNIT") == "FIUNIT":
                        service.log_debug("***  pm  is not none 3*****")
                        if mbo.getString("DM_CREWTYPE") == "ELEC":
                            service.log_debug("***  pm  is not none 3.1*****")
                            mbo.setValue("PERSONGROUP", "DMSRNFES") 
                            mbo.setValue("DM_DATAENTRYGROUP", "DMSRNFED") 
                            ownergroup='DM_SRNME'
                            mbo.applyOwnerGroup(ownergroup)
                            service.log_debug("***  pm  is not none 4*****")
                        elif mbo.getString("DM_CREWTYPE") == "MECH" :
                            service.log_debug("***  pm  is not none 4.1*****")
                            mbo.setValue("PERSONGROUP", "DMSRNFMS")
                            mbo.setValue("DM_DATAENTRYGROUP", "DMSRNFMD")
                            ownergroup='DM_SRNME'
                            mbo.applyOwnerGroup(ownergroup)
                            service.log_debug("***  pm  is not none 5*****")
     
     
     
     status = mbo.getString("status")
     worktype = mbo.getString("worktype")
     maintdept= mbo.getString("dm_maintdept")
     maintDeptSet = mbo.getMboSet("$value","DM_ORGHIERARCHY","unitid='"+maintdept+"'")
     maintDeptMbo=maintDeptSet.moveFirst()
     if maintDeptMbo:
			maxvalue = maintDeptMbo.getString("abbriviation")
			#service.error("fs","af")
			if (status  == 'WSCH' and  worktype not in ('IN','SPE','SER','CM','PM')) or (status  == 'WAPPR' and  worktype  in ('IN','SPE','SER','CM','AS','PDM','PM','ACC','CP','MD','REG','MISC','VM','WASH','VISIT','FIND')):
					if  maxvalue=='DCL':
							wfstart.initiateWorkflow('DM_DCLMAIN',mbo)
					elif maxvalue=='TAS':
							wfstart.initiateWorkflow('DM_WOTMAIN',mbo) 
					elif maxvalue=='GMD': 
					    if (not mbo.isNull("ROUTE")) or (not mbo.isNull("PMNUM") and not pmMbo.isNull("ROUTE") and not mbo.getBoolean("DM_INHOUSE")):
					        if mbo.isNull("ROUTE"):
					            mbo.setValue("ROUTE",pmMbo.getString("ROUTE"))                            
					        ctx = HashMap()
					        ctx.put("mbo", mbo)
					        service.invokeScript("DM_RCONTLINELSCRIPT", ctx)
					    if (mbo.getString("WORKTYPE") in ('CM','AS','CP','MD','AD')) or (mbo.getString("WORKTYPE") == 'PM' and not mbo.isNull("PMNUM")):
					       wfstart.initiateWorkflow('DM_GMMAIN',mbo)  
					elif (maxvalue in ('STP','WPM','JPO')):
					        wfstart.initiateWorkflow('DM_STPMAIN',mbo) 
					elif maxvalue=='SRP' and unitid == section:
							wfstart.initiateWorkflow('DM_WOSRWMN',mbo)
					elif maxvalue=='SRN' :
					        #service.error("dm","genericerror",[dm_bunit])
					        wfstart.initiateWorkflow('DM_SRNMAIN',mbo)	
				#	elif maxvalue=='APM' :
					        #service.error("dm","genericerror",[dm_bunit])
				#	        wfstart.initiateWorkflow('DM_WINMAIN',mbo)	        
logger.debug("DM_AUTOWFS -END")