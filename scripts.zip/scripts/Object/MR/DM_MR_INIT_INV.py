# Author Mithun 
from java.util import Date
from java.util import Calendar
from psdi.mbo import MboConstants

# Below lines Created by Mithun for Requirenment below
# required Date two days ahead of current date 

if app == 'DM_CREATEDR' and  mbo.isNew() :
    cal = Calendar.getInstance()
    cal.setTime(Date())
    cal.add(Calendar.DAY_OF_MONTH, 2)
    newDate = cal.getTime()
    mbo.setValue("REQUIREDDATE",newDate)