from psdi.mbo import *
from psdi.server import MXServer

accidentMbo = mbo.getOwner()
accidentNum = accidentMbo.getString("ACCIDENTNUM")
revNum = accidentMbo.getInt("REVISIONNUM")

mbo.setValue("REVNUM",revNum+1)
mbo.setValue("ACCIDENTNUM",accidentNum)