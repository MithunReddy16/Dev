from psdi.pluss.app.plussgis.helper import LinkUtil
from com.ibm.tivoli.maximo.map import GeometryUtils
from com.ibm.json.java import JSONObject
from psdi.pluss.app.plussgis import PlusSGISServiceRemote 
from psdi.server import MXServer

featureClass = mbo.getString("PLUSSFEATURECLASS")
linkedGIS = LinkUtil.getLinkedGISMbo(mbo, featureClass)
#Check if is linked
if linkedGIS != None:

	gisService = MXServer.getMXServer().lookup("PLUSSGIS")
	geoJson = gisService.computeGeoJSONFromMbo(mbo.getUserInfo(), mbo)

	print(geoJson)

	geometryData = service.jsonToString(geoJson)

	mbo.setValue("PLUSSGEOJSON", geometryData)

else:
   print("############## Not Linked")
