##############################################
#script:DM_ADV_ASSIGN
#Createdby:NK
#Creation Date:16-06-2026
#scope: Assign Designer
###############################################

from psdi.mbo import MboConstants
from psdi.server import MXServer
from java.util import Date
from java.text import SimpleDateFormat


mxServer = MXServer.getMXServer()
userInfo = mbo.getUserInfo()
currentDate = mxServer.getDate()
flags = MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION
NOACCESS = MboConstants.NOACCESSCHECK

if mbo is not None:

    laborcode = mbo.getString("LABORCODE")
    wonum = mbo.getString("WONUM")
    siteid = mbo.getString("SITEID")
    desc = "Workorder-%s-DES_ASSIGNED-Waiting for your action" % wonum
    appName = "DM_PLUSGWO_ADV"

    if laborcode and wonum and mbo.isNull("PLUSTREASON"):

        # Get Work Order
        woSet = mxServer.getMboSet("WORKORDER", userInfo)
        woSet.setWhere("wonum='%s' and siteid='%s'" % (wonum, siteid))
        woSet.reset()
        wo = woSet.getMbo(0)
        if wo is not None:
            ownerid = wo.getLong("WORKORDERID")

        # Update WORKORDER owner
            wo.setValue("OWNER", laborcode, MboConstants.NOACCESSCHECK)
            wo.setValue("DM_ADV_ASSIGN", currentDate, MboConstants.NOACCESSCHECK)
            wo.setValueNull("OWNERGROUP", MboConstants.NOACCESSCHECK)

        # WFASSIGNMENT records for this WO
            wfSet = mxServer.getMboSet("WFASSIGNMENT", userInfo)
            wfSet.setWhere(
                "ownertable='WORKORDER' and ownerid=%s and assignstatus='ACTIVE'" % ownerid
            )
            wfSet.reset()

            oldwf = None

            wf = wfSet.moveFirst()
            while wf is not None:
                if wf.getString("ASSIGNCODE") == laborcode:
                    oldwf = wf
                    # Complete existing assignment for selected designer
                    wf.setValue("ASSIGNSTATUS", "COMPLETE", MboConstants.NOACCESSCHECK)
                else:
                    # Inactivate other active assignments
                    wf.setValue("ASSIGNSTATUS", "INACTIVE", MboConstants.NOACCESSCHECK)

                wf = wfSet.moveNext()

            # Create new ACTIVE WFASSIGNMENT for selected designer
            # Only create if no ACTIVE assignment was completed for same labor
            if oldwf:
                newwfSet = mxServer.getMboSet("WFASSIGNMENT", userInfo)
                newwf = newwfSet.add()
               
                newwf.setValue("DESCRIPTION", desc,NOACCESS)
                newwf.setValue("APP", appName, flags)
                newwf.setValue("ASSIGNCODE", laborcode, NOACCESS)
                newwf.setValue("WFID", oldwf.getString("WFID"), NOACCESS)
                newwf.setValue("NODEID", "22", NOACCESS)
                newwf.setValue("TIMELIMIT", oldwf.getString("TIMELIMIT"), NOACCESS)
                newwf.setValue("PRIORITY", oldwf.getString("PRIORITY"), NOACCESS)
                newwf.setValue("ORIGPERSON", oldwf.getString("ORIGPERSON"), NOACCESS)
                newwf.setValue("ROLEID", "DM_ADVDES", flags)
                newwf.setValue("PROCESSNAME", oldwf.getString("PROCESSNAME"), NOACCESS)
                newwf.setValue("PROCESSREV", oldwf.getString("PROCESSREV"), NOACCESS)
                newwf.setValue("OWNERTABLE", oldwf.getString("OWNERTABLE"), NOACCESS)
                newwf.setValue("OWNERID", oldwf.getString("OWNERID"), NOACCESS)
                newwf.setValue("TEMPLATEID", "DM_ADV_WO", NOACCESS)
                newwf.setValue("EMAILNOTIFICATION", oldwf.getString("EMAILNOTIFICATION"), NOACCESS)
                newwf.setValue("CONDITION", oldwf.getString("CONDITION"), NOACCESS)
                newwf.setValue("CONDITIONCLASS", oldwf.getString("CONDITIONCLASS"), NOACCESS)
                newwf.setValue("LANGCODE", oldwf.getString("LANGCODE"), NOACCESS)
                newwf.setValue("ESCROLE", oldwf.getString("ESCROLE"), NOACCESS)
                newwf.setValue("CALENDARBASED", oldwf.getString("CALENDARBASED"), NOACCESS)
                newwf.setValue("HASLD", oldwf.getString("HASLD"), NOACCESS)
                newwf.setValue("GROUPNUM", oldwf.getString("GROUPNUM"), NOACCESS)
                newwf.setValue("SEPARATEGROUPS", oldwf.getString("SEPARATEGROUPS"), NOACCESS)
                newwf.setValue("ASSIGN_01", oldwf.getString("ASSIGN_01"), flags)
                newwf.setValue("ASSIGN_02", oldwf.getString("ASSIGN_02"), flags)
                newwf.setValue("ASSIGN_03", oldwf.getString("ASSIGN_03"), flags)
                newwf.setValue("ASSIGN_04", oldwf.getString("ASSIGN_04"), flags)
                newwf.setValue("ASSIGN_05", oldwf.getString("ASSIGN_05"), flags)
                
                newwf.setValue("ASSIGNSTATUS", "ACTIVE", NOACCESS)
                newwf.setValue("STARTDATE", currentDate, NOACCESS)
                newwf.setValue("DUEDATE", currentDate, NOACCESS)
                newwf.setValue("ASSIGNID", mbo.getUniqueIDValue(), 11)
                newwf.setValue("WFASSIGNMENTID", mbo.getUniqueIDValue(), 11)
                
                newwfSet.save()    
                wfSet.save()    
            woSet.save()
            
            
                
            
        wfSet.close()
        woSet.close()