#DM_BUDGETLINE.ADD
def setError(Msg):
		#global errorkey,errorgroup,params
		#errorkey='scriptvalidationerror'
		#errorgroup='scriptval'
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)
        
BudgetMbo = mboset.getOwner()
if BudgetMbo is not None and BudgetMbo.getString('STATUS') !='DRAFT':
    setError('Lines can not be added.')