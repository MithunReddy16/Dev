#------------------------------------------------------------------------
#Script Name :DM_DATACHANGELINE_SAVE
#Description :Data Change Request Line Save Script.
#Comment     :Used in Asset Data Change Request Application. 
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-Aug-2025         Initiate version.
#
#------------------------------------------------------------------------

service.log_debug("######################################## Start:" + scriptName+" ######################")

if mbo.isModified("tocostcenter"):
    if not mbo.isNull("tocostcenter"):
        mbo.setValue("ccsection",mbo.getString("tocostcenter.unitid"))
    else:
        mbo.setValueNull("ccsection")
    
service.log_debug("######################################## End:" + scriptName+" ######################")