#######################################
# Author : Amir
# Script : DM_OBJ_DM_GRPCLASSMAP - Initaliaze record with parent primary key
# V0 - 28-Augest
####################################

if mbo.isNew():
    owner= mbo.getOwner()
    if owner:
        mbo.setValue('CLASSSTRUCTUREID',owner.getString('CLASSSTRUCTUREID'),11L)
        mbo.setValue('classificationid',owner.getString('classificationid'),11L)