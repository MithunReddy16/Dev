/*
Script: DM_PURCHVIEW.COPYSUBCONT
Created By: Ashok
Date: 25-Feb-2025
Req: Copy Sub Contract Rates table for revision

*/

load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Script DM_PURCHVIEW.COPYSUBCONT**START***")
logger.error("***ASH***Script DM_PURCHVIEW.COPYSUBCONT**app="+app)
if(app=="DM_PURCHCONGM")
{
		
	newSubContractSet=mbo.getMboSet("DM_SUBCONTRACTRATE");
	oldSubContractSet=mbo.getMboSet("DM_PREVREVSUBCONTRATE");
	oldSubContractSet.setOrderBy(" DM_MINVALUE ASC ");
	for(i=0;(oldSubContractMbo=oldSubContractSet.getMbo(i))!=null;i++)
	{
	    
		newSubContractMbo=newSubContractSet.add(11);
		newSubContractMbo.setValue("DM_MINVALUE",oldSubContractMbo.getDouble("DM_MINVALUE"),11)
		newSubContractMbo.setValue("DM_MAXVALUE",oldSubContractMbo.getDouble("DM_MAXVALUE"),11)	
		newSubContractMbo.setValue("DM_ABOVEMINVALUE",oldSubContractMbo.getDouble("DM_ABOVEMINVALUE"),11)
		newSubContractMbo.setValue("DM_CONTRACTID",mbo.getLong("CONTRACTID"),2)
		newSubContractMbo.setValue("DM_CONTRACTNUM",mbo.getString("CONTRACTNUM"),2)
		newSubContractMbo.setValue("DM_EXTRAPERCENT",oldSubContractMbo.getDouble("DM_EXTRAPERCENT"),11)
			
		newSubContractMbo.setValue("DM_REVISIONNUM",mbo.getString("REVISIONNUM"),2)
		newSubContractMbo.setValue("ORGID",oldSubContractMbo.getString("ORGID"),2)
		
	}
	
}

logger.error("***ASH***Script DM_PURCHVIEW.VAL**END***")