/*
Script: DM_PURCHVIEW.VAL
Created By: Ashok
Date: 14-Sep-2024
Req: Validations Script to check if the 
1. Sub Contract Rates are defined for type=S to calculate the job calculations
2. Discount is Filled with the values for type='NW'


*/

load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Script DM_PURCHVIEW.VAL**START***")
logger.error("***ASH***Script DM_PURCHVIEW.VAL**app="+app)
if(app=="DM_PURCHCONGM")
{
	errorFlag=0;
	errorMsg="";
	//contractLineSet=mbo.getMboSet("DM_TYPECONTRACTLINE");
	//contractLineSet=mbo.getMboSet("CONTRACTLINE");contractnum=:contractnum and revisionnum = :revisionnum and orgid=:orgid
	contractLineSet=mbo.getMboSet("$ALLCONTRACTLINE", "CONTRACTLINE", "CONTRACTNUM='" + mbo.getString("CONTRACTNUM") + "' AND REVISIONNUM=" + mbo.getInt("REVISIONNUM") )
	logger.error("***ASH***Script DM_PURCHVIEW.VAL**count="+contractLineSet.count())
	hasCalcItem=0;

	logger.error("***ASH***Script DM_PURCHVIEW.VAL**contractLineSet.getCompleteWhere()="+contractLineSet.getCompleteWhere())
	logger.error("***ASH***Script DM_PURCHVIEW.VAL**contractLineSet.count()="+contractLineSet.count())
	
	for(i=0;(contractLineMbo=contractLineSet.getMbo(i))!=null;i++)
	{
		
		logger.error("***ASH***Script DM_PURCHVIEW.VAL**CONTRACTLINENUM="+contractLineMbo.getString("CONTRACTLINENUM"))
		logger.error("***ASH***Script DM_PURCHVIEW.VAL**DM_TYPE="+contractLineMbo.getString("DM_TYPE"))
		logger.error("***ASH***Script DM_PURCHVIEW.VAL**DM_BTYPE="+contractLineMbo.getString("DM_BTYPE"))
	/*	if(contractLineMbo.getString("DM_BTYPE")=="NW")
		{
			if(mbo.getDouble("DM_DISCOUNT")==null || mbo.getDouble("DM_DISCOUNT")<=0)
			{
				//errorFlag=1
				errorMsg="\nType NW Exists, so The Discount Value should be available";
				service.error("dm_contval","appval",[errorMsg])
			}
			
		} */
		if(contractLineMbo.getString("DM_TYPE")=="S")
		{
			subContractRateSet=mbo.getMboSet("DM_SUBCONTRACTRATE");
			logger.error("***ASH***Script DM_PURCHVIEW.VAL**subContractRateSet.getCompleteWhere()="+subContractRateSet.getCompleteWhere())
			logger.error("***ASH***Script DM_PURCHVIEW.VAL**subContractRateSet.count()="+subContractRateSet.count())
			
			if(subContractRateSet.count()==0)
			{
				errorFlag=1
				errorMsg="\nMissing Sub Contract / Supplier Rate Card";
				service.error("dm_contval","appval",[errorMsg])
			}
			aboveFlagcnt=0;
			for(j=0;(subContractRateMbo=subContractRateSet.getMbo(j))!=null;j++)
			{
				if(subContractRateMbo.getBoolean("DM_ABOVEMINVALUE")==true)
				{
					aboveFlagcnt++;
				}
			}
			
			if(aboveFlagcnt!=1)
			{
				errorFlag=1
				errorMsg="\nOne Line should have Above Flag selected";
				service.error("dm_contval","appval",[errorMsg])
			}
		}
		logger.error("***Mithun***Script DM_PURCHVIEW.VAL*****"+i)
		if(contractLineMbo.getString("ITEMNUM")=="SCALC-SUB")
		{
			hasCalcItem=1;
		}
	}
	if(hasCalcItem==0 && mbo.getMboSet("DM_SUBCONTRACTRATE").count()>0)
	{
		errorFlag=1
		errorMsg="\n CALC-SUB Item is manadatory when there are Sub Contract / Supplier Rate Card";
		service.error("dm_contval","appval",[errorMsg])
	}
	
	if(errorFlag==1)
	{
		logger.error("***ASH***Script DM_PURCHVIEW.VAL**ERROR= "+errorMsg)
		service.error("dm_contval","appval",[errorMsg])
	}
}

logger.error("***ASH***Script DM_PURCHVIEW.VAL**END***")