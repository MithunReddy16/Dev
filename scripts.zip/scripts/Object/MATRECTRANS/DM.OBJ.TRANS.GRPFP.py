#-----------------------------------------------------------------------------------------
# Name:        DM.OBJ.TRANS.GRPFP
# Description: Validates and Set Inventory Transaction period to MatRectrans / MatUse
# Author: @Amir A. 
# Version: 1.0 - 23-NOV-2025
#-----------------------------------------------------------------------------------------


from psdi.mbo import SqlFormat
from psdi.server import MXServer
from java.text import SimpleDateFormat
from psdi.util.logging import MXLoggerFactory
mlog = MXLoggerFactory.getLogger("maximo.custom")

def setError(Msg):	
    params=[Msg]
    service.error('scriptval','scriptvalidationerror',params)
	
    
userInfo = MXServer.getMXServer().getSystemUserInfo()

dateFormat = SimpleDateFormat("YYYY-MM-dd")
StoreLoc = ""

if mbo.getName().upper() == "MATUSETRANS":
    StoreLoc = "STORELOC"
elif mbo.getName().upper() == "MATRECTRANS":
    
    if mbo.isNull("TOSTORELOC"):
        StoreLoc = "FROMSTORELOC"
    else:
        StoreLoc = "TOSTORELOC"


IssueType = mbo.getString("ISSUETYPE")
ActualDate = mbo.getDate("ACTUALDATE")

if ActualDate and IssueType not in ("RECEIPT") and not mbo.isNull(StoreLoc): 
    if mbo.getString(StoreLoc) !="HOLDING" and not mbo.getString(StoreLoc).startswith("VS"): 
        formattedActualDate = dateFormat.format(ActualDate)
    
    
        FPSet = MXServer.getMXServer().getMboSet("DM_GRPFINPERIOD", userInfo)
        sqlFormat = SqlFormat(userInfo, "ORGCODE = :1 and TO_DATE(:2,'YYYY-MM-dd')  between TRUNC(startdate) and TRUNC(enddate) " )  
        sqlFormat.setObject(1, "UPPER", mbo.getString(StoreLoc) )
    
        sqlFormat.setObject(2, "UPPER", formattedActualDate)
        #setError(sqlFormat.format())
        FPSet.setWhere(sqlFormat.format())
        FPSet.reset()
        FPMbo = FPSet.moveFirst()
        if FPMbo:
            if FPMbo.getString("STATUS").upper() == "OPEN":
                mbo.setValue("DM_GRPINVFP",FPMbo.getString("PERIODNAME"))
            else:
                setError("No Open Period for transaction date.")
        else:
            setError("No Open Period for transaction date.")
        
        FPSet.close()

#CountBoook
CBSet = MXServer.getMXServer().getMboSet("COUNTBOOK", userInfo)
sqlFormat = SqlFormat(userInfo, "STOREROOM = :1 AND STATUS NOT IN  ('COMP','CAN') AND EXISTS (SELECT 1 FROM COUNTBOOKLINE WHERE COUNTBOOKNUM=COUNTBOOK.COUNTBOOKNUM AND SITEID=COUNTBOOK.SITEID AND ITEMNUM=:2) " )  
sqlFormat.setObject(1, "UPPER", mbo.getString(StoreLoc) )
sqlFormat.setObject(2, "UPPER", mbo.getString('ITEMNUM') )
CBSet.setWhere(sqlFormat.format())
CBSet.reset()
CBMbo = CBSet.moveFirst()
if CBMbo:
    setError("Open Countbook for the same store/item, transaction can not be saved.")

CBSet.close()