from psdi.server import MXServer

maxuserSet = MXServer.getMXServer().getMboSet("MAXUSER", mbo.getUserInfo())
maxuserSet.setWhere("userid='" + user + "'")
defaultSite = maxuserSet.getMbo(0).getString("DEFSITE")
if(mbo.toBeAdded()==True):
    mbo.setValue("DM_OWNERSITE",defaultSite)