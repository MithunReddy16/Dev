from psdi.server import MXServer
from psdi.mbo import MboConstants

logger = service.getLogger("DM")

if launchPoint == 'DM_PMDEPT' or launchPoint=='DM_ROUTESDEPT':
    
    if mbo.isNew() and interactive == True:

        maximo = MXServer.getMXServer()
        currentUser = maximo.getUserInfo(user) 
        persond = currentUser.getPersonId()  
        personMbo = mbo.getMboSet('$person', 'person', "personid = '" + persond + "'").getMbo(0)
        persondept = personMbo.getString("DM_Department")
        orgHirMbo = mbo.getMboSet('$DM_ORGHIERARCHY', 'DM_ORGHIERARCHY', "UNITID = '" + persondept + "'").getMbo(0)
        abbriviation = orgHirMbo.getString("ABBRIVIATION")
        
       
        personSec = personMbo.getString("DM_SECTION")
            #mbo.setValue("dm_maintdept", personSec, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)
        #else:
        mbo.setValue("dm_maintdept", persondept, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)
        #below  if added  by Mithun
        if persondept=='15763':
            mbo.setFieldFlag("WORKTYPE",MboConstants.READONLY,True)
        if abbriviation == 'TAS':
            mbo.setValue("amcrew", 'RECPT', MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)
        
    else:
        
          mbo.setFieldFlag("dm_maintdept",MboConstants.READONLY,True)
          #below  if added  by Mithun
          if mbo.getString("dm_maintdept")=='15763':
            mbo.setFieldFlag("WORKTYPE",MboConstants.READONLY,True)
          
if launchPoint == 'DM_JPDEPT':
    
    if mbo.isNew() and interactive == True:

        maximo = MXServer.getMXServer()
        currentUser = maximo.getUserInfo(user) 
        persond = currentUser.getPersonId()  
        personMbo = mbo.getMboSet('$person', 'person', "personid = '" + persond + "'").getMbo(0)
        persondept = personMbo.getString("DM_Department")
        orgHirMbo = mbo.getMboSet('$DM_ORGHIERARCHY', 'DM_ORGHIERARCHY', "UNITID = '" + persondept + "'").getMbo(0)
        abbriviation = orgHirMbo.getString("ABBRIVIATION")
        mbo.setValue("dm_maintdept", persondept, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)
        
    else:
        
          mbo.setFieldFlag("dm_maintdept",MboConstants.READONLY,True)
          
if launchPoint == 'DM_SR.INITIALIZE':
    
    if mbo.isNew():

        maximo = MXServer.getMXServer()
        currentUser = maximo.getUserInfo(user) 
        persond = currentUser.getPersonId()  
        personMbo = mbo.getMboSet('$person', 'person', "personid = '" + persond + "'").getMbo(0)
        persondept = personMbo.getString("DM_Department")
        orgHirMbo = mbo.getMboSet('$DM_ORGHIERARCHY', 'DM_ORGHIERARCHY', "UNITID = '" + persondept + "'").getMbo(0)
        abbriviation = orgHirMbo.getString("ABBRIVIATION")
        if abbriviation in ('STP','WPM','JPO'):
            personSec = personMbo.getString("DM_SECTION")
            mbo.setValue("DM_MAINTSEC", personSec, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)
        else:
            mbo.setValue("DM_MAINTSEC", persondept, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)
    else:
        
          mbo.setFieldFlag("DM_MAINTSEC",MboConstants.READONLY,True)
          

if launchPoint == 'DM_DECDEPT':
   
        
    if mbo.isNew():

        maximo = MXServer.getMXServer()
        currentUser = maximo.getUserInfo(user) 
        persond = currentUser.getPersonId()  
        personMbo = mbo.getMboSet('$person', 'person', "personid = '" + persond + "'").getMbo(0)
        personsection = personMbo.getString("DM_Section")
        persondept = personMbo.getString("DM_Department")
        personsector = personMbo.getString("DM_Sector")
        mbo.setValue("dm_section", personsection, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)
        mbo.setValue("dm_department", persondept, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)
        mbo.setValue("dm_sector", personsector, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)

if launchPoint == 'DM_WOMS':
    
    
    
    if mbo.isNew():
        sqlQuery = None
        conKey = mbo.getThisMboSet().getUserInfo().getConnectionKey()
        con = mbo.getThisMboSet().getMboServer().getDBConnection(conKey)
        if app == 'DM_PLUSGWO_DCL':
            sqlQuery = "SELECT unitid FROM DM_ORGHIERARCHY WHERE ABBRIVIATION = 'DCL' and unittype='DEPARTMENT'"
        elif app == 'DM_PLUSGWO_GM':
            sqlQuery = "SELECT unitid FROM DM_ORGHIERARCHY WHERE ABBRIVIATION = 'GMD' and unittype='DEPARTMENT'"
        elif app == 'DM_PLUSGWO_SRW':
            sqlQuery = "SELECT unitid FROM DM_ORGHIERARCHY WHERE ABBRIVIATION = 'SRP' and unittype='DEPARTMENT'"
        elif app == 'DM_PLUSGWO_SRWN':
            sqlQuery = "SELECT unitid FROM DM_ORGHIERARCHY WHERE ABBRIVIATION = 'SRN' and unittype='DEPARTMENT'"    
        elif app == 'DM_PLUSGWO_STP':
            sqlQuery = "SELECT unitid FROM DM_ORGHIERARCHY WHERE ABBRIVIATION = 'STP' and unittype='DEPARTMENT'"
        elif app == 'DM_PLUSTWO':
            sqlQuery = "SELECT unitid FROM DM_ORGHIERARCHY WHERE ABBRIVIATION = 'TAS' and unittype='DEPARTMENT'"
        elif app == 'DM_WOTRACK_INSP':
            sqlQuery = "SELECT unitid FROM DM_ORGHIERARCHY WHERE ABBRIVIATION = 'APM' and unittype='DEPARTMENT'"

        if sqlQuery:
                    try:
                 
                        stmt = con.createStatement()
                        resultSet= stmt.executeQuery(sqlQuery)
                        if resultSet.next():
                            unitid = resultSet.getString("unitid")
                            mbo.setValue("dm_maintdept", unitid, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)
                            service.log("Successfully set dm_maintdept to: {}".format(unitid))
                    finally:
                            if stmt != "":
                               stmt.close()
                            
                            if conKey != "" and con != "":
                               mbo.getThisMboSet().getMboServer().freeDBConnection(conKey)

    elif mbo.getString("worktype")!='FIND':
       mbo.setFieldFlag("dm_maintdept", MboConstants.READONLY, True)