from psdi.common.context import UIContext
from psdi.webclient.system.controller import SessionContext, Utility, WebClientEvent

# Get the control instance using its ID from Application Designer
# Replace "1234567890" with your actual Control ID


#----------------------------

qtyCrrYearControl = service.webclientsession().getControlInstance("entrylines_current_year")
if qtyCrrYearControl is not None:
    yearofBudget = int(mbo.getOwner().getString("yearofbudget"))
    qtyCrrYearControl = service.webclientsession().getControlInstance("entrylines_current_year")
    qtyNextYearControl = service.webclientsession().getControlInstance("entrylines_next_year_1")
    qtyNext2YearControl = service.webclientsession().getControlInstance("entrylines_next_year_2")
    curlabel= "Plan For "+str(yearofBudget)
    label1 = "Plan For "+str(yearofBudget+1)
    label2 = "Plan For "+str(yearofBudget+2)
    qtyCrrYearControl.setProperty("label", curlabel)
    qtyNextYearControl.setProperty("label", label1)
    qtyNext2YearControl.setProperty("label", label2)
#--------------------------------
if mbo.getString("REQUESTTYPE") == "REPLACEMENT":  
    mbo.setFieldFlag("QUANTITY",7l,True)