##############################################
#script:DM_ADV_ADVLINES
#Createdby:NK
#Creation Date:10-02-2026
#scope: Create SR -Restrict advertisement lines
###############################################

from psdi.mbo import MboConstants

if mbo.isNew() and mbo.isNull("DM_ADV_LINENUM"):
    owner = mbo.getOwner()
    if owner is not None:
        ticketid = owner.getString("TICKETID")
    else:
        ticketid = mbo.getString("DM_ADV_TICKETID")

    maxLine = 0

    # Use the current in-memory set (includes unsaved UI rows)
    ms = mbo.getThisMboSet()
    if ms is not None:
        for i in range(ms.count()):
            lineMbo = ms.getMbo(i)
            if lineMbo is not None:
                if (lineMbo != mbo and
                    lineMbo.getString("DM_ADV_TICKETID") == ticketid and
                    not lineMbo.toBeDeleted() and
                    not lineMbo.isNull("DM_ADV_LINENUM")):
    
                    ln = lineMbo.getInt("DM_ADV_LINENUM")
                    if ln > maxLine:
                        maxLine = ln

    mbo.setValue("DM_ADV_LINENUM", maxLine + 1, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)