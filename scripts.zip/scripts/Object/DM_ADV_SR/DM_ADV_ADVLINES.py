##############################################
#script:DM_ADV_ADVLINES
#Createdby:NK
#Creation Date:10-02-2026
#scope: Create SR -Restrict advertisement lines
###############################################
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants
from psdi.util import MXApplicationException

owner = mboset.getOwner()
if owner:
    lineSet = owner.getMboSet("DM_ADV_REQADV")
    activeCount = 0
    lineMbo = lineSet.moveFirst()
    while lineMbo:
        if not lineMbo.toBeDeleted():
            activeCount += 1
        lineMbo = lineSet.moveNext()

    if activeCount >= 3:
        service.error(
            "scriptval",
            "scriptvalidationerror",
            ["You cannot add more than 3 Required Advertisement records in the same request"]
        )