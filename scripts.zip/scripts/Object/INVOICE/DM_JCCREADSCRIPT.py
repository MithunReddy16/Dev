#-------------------------------------------------------------
#Created By : Ram
#Created Date : 30-Dec-2025
#Scope: make the jcc application editable only if the status is entered or PM Returned For Contractor
#-------------------------------------------------------------
from psdi.mbo import MboConstants
from psdi.server import MXServer


currentuser = mbo.getUserInfo().getUserName()
groupuserSet= MXServer.getMXServer().getMboSet('GROUPUSER', mbo.getUserInfo())
groupuserSet.setWhere("groupname in ('SG_DM_039') and userid='" + currentuser + "'")

if  not groupuserSet.isEmpty() and app=="DM_JCC" and not mbo.toBeAdded(): 

        assigned = False
        
        if mbo.getString("status") in ('ENTERED','REJECTED'):
                    assigned = True
                      
        
        
        if not assigned:
                
                mboSet = mbo.getThisMboSet()
                #mboSet.setFlag(7L,True)
                mbo.setFlag(7L,True)