##############################################
#script:DM_ADV_WQTY
#Createdby:NK
#Creation Date:14-09-2026
#scope: calculate Workshop total quantity
###############################################

from psdi.mbo import MboConstants

wo = mbo.getOwner()

if wo is not None:
    qtySet = mbo.getThisMboSet()
    totalQty = 0.0

    row = qtySet.moveFirst()

    while row is not None:
        includeRow = not row.toBeDeleted()
        if ondelete and row == mbo:
            includeRow = False

        if includeRow:
            if not row.isNull("DM_ADV_QTY"):
                totalQty += row.getDouble("DM_ADV_QTY")

        row = qtySet.moveNext()

    wo.setValue("DM_ADV_W_QTY", totalQty,MboConstants.NOACCESSCHECK)