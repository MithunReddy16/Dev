# Author Mithun 
from psdi.server import MXServer

#Trigger mail notification, to corresponding storekeepers and store supervisors  
    #when status is changed to Complete. 


if(mbo.isModified("DM_STATUS") and mbo.getString("DM_STATUS") == 'COMPLETE'):
    invuseSet=mbo.getMboSet("DM_INVUSETRSHIPP")
    invline = invuseSet.moveFirst()
    ctSet = mbo.getMboSet("$CT", "COMMTEMPLATE", "templateid='DM_PACK_SHIPPED'")
    commTemp = ctSet.getMbo(0)
    while invline :
        commTemp.sendMessage(invline,invline)
        invline = invuseSet.moveNext()