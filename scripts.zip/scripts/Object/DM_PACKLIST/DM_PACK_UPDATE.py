# Mithun 
from psdi.server import MXServer

if(mbo.isModified("DM_STATUS") and mbo.getString("DM_STATUS") == 'COMPLETE'):
    if mbo.getMboSet("DM_INVUSE").isEmpty() :
        err_msg = ("Pack List can not change status to complete, If there is no Inventory Usuage." )
        service.error("scriptval", "scriptvalidationerror", [err_msg])