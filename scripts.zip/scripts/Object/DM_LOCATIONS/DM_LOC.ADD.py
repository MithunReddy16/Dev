from psdi.server import MXServer

maxLevel = MXServer.getMXServer().getProperty('DM.FUNCATIONLOCATION.MAXLEVL')
intMaxLevel = maxLevel
owner = mboset.getOwner()

if (owner is not None and intMaxLevel is not None):
    
    parentLevel = owner.getInt("LEVELNUM")
    
    if(parentLevel == int(intMaxLevel)):
        service.error("dm_floc.add","maxlevel")