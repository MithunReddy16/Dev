assetSet = mbo.getMboSet("ASSET")
childSet = mbo.getMboSet("CHILDREN")

if ( (assetSet is not None and not assetSet.isEmpty()) or (childSet is not None and not childSet.isEmpty()) ):
    service.error("dm_floc.asset","associatedasset")