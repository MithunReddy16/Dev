owner = mbo.getOwner()

if (owner is not None):
    parentId = owner.getString("ASSETLOCATION")
    parentDesc  = owner.getString("ASSETLOCATIONDESC")
    parentLevel = owner.getInt("LEVELNUM")

    childId = mbo.getString("CHILDID")
    childDesc  = mbo.getString("CHILDDESC")

    mbo.setValue("PARENT", parentId)
    mbo.setValue("LEVELNUM", parentLevel+1)

    if (parentId != '' and childId != '' ):
        #mbo.setValue("ASSETLOCATION", parentId + '-' + childId, 7L)
        mbo.setValue("ASSETLOCATION", parentId + childId, 7L)
    
    if (parentDesc != '' and childDesc != '' ):
        #mbo.setValue("ASSETLOCATIONDESC", parentDesc + '-' + childDesc)
        mbo.setValue("ASSETLOCATIONDESC",  childDesc)

else:
    mbo.setValue("LEVELNUM", 1)