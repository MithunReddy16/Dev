#------------------------------------------------------------------------

#Script Name :DM_BUDGETREQUEST_SAVE
#Description :Budget Request Save Script
#Comment     :Used in Budget Plan Application.  
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-Jan-2026         Initiate version.

#-------------------------------------------------------------------------

from psdi.server import MXServer 

# Create Request Budget Plan for each department
def createDeptBP():
    depMboSet = mbo.getMboSet("DM_ORGHIERARCHY_DEP_$$","DM_ORGHIERARCHY","UNITTYPE='DEPARTMENT'")
    depMboSet.reset()
    depMbo = depMboSet.moveFirst()
    
    while depMbo is not None:
        newDeptBp= mbo.getMboSet("DEPARTMENTREQUEST").add()
        department = depMbo.getString("UNITID")
        newDeptBp.setValue("DEPARTMENT",depMbo.getString("UNITID"))
        newDeptBp.setValue("REQUESTTYPE","DEPARTMENT")
        newDeptBp.setValue("BUDGETNUM",mbo.getString("BUDGETNUM"))
        newDeptBp.setValue("YEAROFBUDGET",mbo.getString("YEAROFBUDGET"))
        newDeptBp.setValue("BUDGETSTARTDATE",mbo.getString("BUDGETSTARTDATE"))
        newDeptBp.setValue("BUDGETENDDATE",mbo.getString("BUDGETENDDATE"))
        newDeptBp.setValue("DESCRIPTION",mbo.getString("DESCRIPTION"))
        newDeptBp.setValue("MAINBPID",mbo.getInt("DM_BUDGETREQUESTID"))
        createSecBP(newDeptBp)
        #createBPCategoryCilling(newDeptBp,department)
        depMbo = depMboSet.moveNext()
        
# Create Request Budget Plan for each Section
def createSecBP(newDeptBp):
    secMboSet = mbo.getMboSet("DM_ORGHIERARCHY_SECTION_$$","DM_ORGHIERARCHY","UNITTYPE='SECTION' and PARENT1ID='"+newDeptBp.getString("DEPARTMENT")+"'")
    secMboSet.reset()
    secMbo = secMboSet.moveFirst()
    while secMbo is not None:
        newSecMbo= mbo.getMboSet("SECTIONREQUEST").add()
        newSecMbo.setValue("DEPARTMENT",newDeptBp.getString("DEPARTMENT"))
        newSecMbo.setValue("SECTION",secMbo.getString("UNITID"))
        newSecMbo.setValue("REQUESTTYPE","SECTION")
        newSecMbo.setValue("MAINBPID",mbo.getInt("DM_BUDGETREQUESTID"))
        newSecMbo.setValue("BUDGETNUM",mbo.getString("BUDGETNUM"))
        newSecMbo.setValue("YEAROFBUDGET",mbo.getString("YEAROFBUDGET"))
        newSecMbo.setValue("BUDGETSTARTDATE",mbo.getString("BUDGETSTARTDATE"))
        newSecMbo.setValue("BUDGETENDDATE",mbo.getString("BUDGETENDDATE"))
        newSecMbo.setValue("DESCRIPTION",mbo.getString("DESCRIPTION"))
        newSecMbo.setValue("DEPBPID",newDeptBp.getInt("DM_BUDGETREQUESTID"))
        secMbo = secMboSet.moveNext()
        

############################### Main #################
requestType =mbo.getString("requesttype")
if mbo.isNew() and  mbo.getString("STATUS") =='DRAFT' and requestType == "DM":
    budgetNo = mbo.getString("BUDGETNUM")
    budgetNo = mbo.getString("YEAROFBUDGET")+"-"+budgetNo
    mbo.setValue("BUDGETNUM",budgetNo)
    mbo.setValue("STATUSDATE",MXServer.getMXServer().getDate())
    createDeptBP()
    

#if requestType == "DEPARTMENT" and not mbo.isNew():   
           

# update change by/date everytime user save the record.
#mbo.setValue("CHANGEDATE",MXServer.getMXServer().getDate())
#mbo.setValue("CHANGEDBY",mbo.getUserInfo().getPersonId())