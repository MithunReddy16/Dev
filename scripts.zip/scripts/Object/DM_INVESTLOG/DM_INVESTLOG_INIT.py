if not mbo.isNew():
    mbo.setFieldFlag("PERCENTAGE",7L,True)
    mbo.setFieldFlag("STATUS",7L,True)
    mbo.setFieldFlag("STATUSDATE",7L,True)
    mbo.setFieldFlag("DESCRIPTION",7L,True)