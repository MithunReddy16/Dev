/*
#-----------------------------------------------------------------------------------------
# Script Name : PAYLOAD
# Description : This script is used to make fields read-only based on their data type in the "Request Payload Fields" section of the "External API's Configuration" application and used to copy WS_ID from parent
#
# Event              : Object Launchpoint Script object name:DM_EXT_API_PAYLOAD_FIELDS
# Author             : Pramod Kumar
# Version            : 1.0
# Date               : 10-Oct-2024
#-----------------------------------------------------------------------------------------
*/
load("nashorn:mozilla_compat.js");
importPackage(Packages.psdi.server);
importPackage(Packages.psdi.mbo);
importPackage(Packages.psdi.mbo.MboConstants);

mbo.setFieldFlag("VALUE", MboConstants.READONLY, true);
mbo.setFieldFlag("DESCRIPTION", MboConstants.READONLY, true);
mbo.setFieldFlag("FIELD_NAME", MboConstants.READONLY, true);
mbo.setFieldFlag("DATATYPE", MboConstants.READONLY, true);

var type = mbo.getString("DATATYPE"); 
    
if (type === "Dynamic") { 
    mbo.setFieldFlag("VALUE", MboConstants.READONLY, false);

    }
    
else if ( type === "") { 
    mbo.setValue("WS_ID",mbo.getOwner().getInt("DM_EXT_API_DETAILID"))
    mbo.setFieldFlag("VALUE", MboConstants.READONLY, false);
    mbo.setFieldFlag("DESCRIPTION", MboConstants.READONLY, false);
    mbo.setFieldFlag("FIELD_NAME", MboConstants.READONLY, false);
    mbo.setFieldFlag("DATATYPE", MboConstants.READONLY, false);

    }