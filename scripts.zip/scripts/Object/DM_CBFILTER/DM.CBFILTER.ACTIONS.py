############################
#
# @author : Amir
# Modified by Mithun 
# V1 - 20-01-26 - Initial Version
###########################
from psdi.util.logging import MXLoggerFactory
logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
def setError(Msg):
		params = [Msg]
		service.error('scriptval', 'scriptvalidationerror', params)

if launchPoint == "DMLINESEL":
	if mbo.getString("STATUS") not in ["WAPPR"]:
		setError("Status must be WAPPR.")
	if mbo.isNull("STOREROOM"):
		setError("Please Select a Store.")
	if mbo.isNull("SELECTIONTYPE"):
		setError("Please set Selection Item.")
	elif not mbo.isNull("SELECTIONTYPE") and mbo.getString("SELECTIONTYPE") !="ITEM":
		setError("This option can only be used with ITEM selection type.")
	else:
		#wcs = service.webclientsession()
		service.launchDialog("DMCBFILTER")
		
elif launchPoint == "CBFILTERINIT":
	owner = mbo.getOwner()
	
	if owner:
		#setError("No Owner2.")
		mbo.setValue("STOREROOM", owner.getString("STOREROOM"),11L)
		mbo.setFieldFlag("STOREROOM", 7l,True)
	else:
		setError("No Owner.")
	
elif launchPoint == "DM_ADDCBLINES":
	LinesSet = mbo.getMboSet("DM_INVENTORY")
	
	LineSelection = LinesSet.getSelection()

	if not LineSelection.size() > 0:
		setError('Please select at least one line.')
	else:
		#if mbo.isNull("selectiontype"):
		#	mbo.setValue("selectiontype", "ITEM")
		CBMbo = mbo.getOwner()
		
		countbookselset = CBMbo.getMboSet("COUNTBOOKSELTYPE")
		
		Items = []
		countbookSel = countbookselset.moveFirst()
		while countbookSel:
			if not countbookSel.isNull("SELECTIONITM"):
				Items.append(countbookselset.getString("SELECTIONITM"))
			else:
				countbookSel.delete()
			countbookSel = countbookselset.moveNext()
		
		for selectedMbo in LineSelection:
			if selectedMbo.getString("ITEMNUM") not in Items:
				newItem = countbookselset.add()
				newItem.setValue("SELECTIONITM", selectedMbo.getString("ITEMNUM"),2l)
				Items.append(selectedMbo.getString("ITEMNUM"))
		
		service.closeDialog()
		itemSelTable = service.webclientsession().getDataBean("main_cbsel_table")
		itemSelTable.refreshTable()
			
		
		
elif launchPoint == "DM_CBLFILTER":
	from java.text import SimpleDateFormat
	dateFormat = SimpleDateFormat("YYYY-MM-dd")
	#setError("AA")
	session=service.webclientsession()
	databean=session.getDataBean("dm_cbfilter_table")

	SQLQuery  = " STATUS='ACTIVE' "
	
	if  mbo.getBoolean("ROTATING"):
	    SQLQuery = SQLQuery + " AND EXISTS (SELECT 1 FROM ITEM WHERE ITEMNUM=INVENTORY.ITEMNUM  and ROTATING=1 )   "
	
	if not mbo.isNull("SHED")  or  not mbo.isNull("CURBALFROM")  or  not mbo.isNull("CURBALTO")  : 
		SQLQuery = SQLQuery + "AND EXISTS (SELECT 1 FROM INVBALANCES WHERE ITEMNUM=INVENTORY.ITEMNUM AND LOCATION=INVENTORY.LOCATION AND SITEID=INVENTORY.SITEID "
	if not mbo.isNull("SHED"):
		SQLQuery = SQLQuery + " AND SUBSTR(BINNUM,1,1) = '{}' ".format(mbo.getString("SHED"))
		
	
	InvBalGroup= False
	if not mbo.isNull("CURBALFROM") : 
		SQLQuery = SQLQuery + " GROUP BY ITEMNUM HAVING SUM(CURBAL) >={}".format(str(mbo.getFloat("CURBALFROM")))
		InvBalGroup = True
		
	
	if not mbo.isNull("CURBALTO"): 
		if InvBalGroup:
			SQLQuery = SQLQuery + " AND SUM(CURBAL) <={}".format(str(mbo.getFloat("CURBALTO")))
		else:
			InvBalGroup = True
			SQLQuery = SQLQuery +  " GROUP BY ITEMNUM HAVING SUM(CURBAL) <={}".format(str(mbo.getFloat("CURBALTO")))
	
	if "INVBALANCES" in SQLQuery:
		SQLQuery = SQLQuery + " )"
	
	if not mbo.isNull("DATEFROM") or not mbo.isNull("DATETO") or not mbo.isNull("QTYFROM") or not mbo.isNull("QTYTO") or  not mbo.isNull("COSTFROM") or not mbo.isNull("COSTTO"):
		SQLQuery = SQLQuery + " AND EXISTS (SELECT 1 FROM DM_COUNTBOOKVIEW WHERE ITEMNUM=INVENTORY.ITEMNUM AND STORELOC=INVENTORY.LOCATION AND SITEID=INVENTORY.SITEID "
	if not mbo.isNull("DATEFROM"):
		formattedActualDateFrom = dateFormat.format( mbo.getDate("DATEFROM"))
		SQLQuery = SQLQuery + " AND ACTUALDATE >= TO_DATE('{}' ,'YYYY-MM-dd') ".format(formattedActualDateFrom)
	if not mbo.isNull("DATETO"):
		formattedActualDateTo = dateFormat.format( mbo.getDate("DATETO"))
		SQLQuery = SQLQuery + " AND ACTUALDATE <= TO_DATE('{}' ,'YYYY-MM-dd') ".format(formattedActualDateTo)
	
	    
	
		 
	Grouped = False
	if not mbo.isNull("QTYFROM"):
		SQLQuery = SQLQuery + " GROUP BY ITEMNUM HAVING SUM(Quantity) >={}".format(str(mbo.getFloat("QTYFROM")))
		Grouped = True
	if  not mbo.isNull("QTYTO"):
		if Grouped:
			SQLQuery = SQLQuery + " AND SUM(Quantity) <={}".format(str(mbo.getFloat("QTYTO")))
		else:
			Grouped = True
			SQLQuery = SQLQuery + " GROUP BY ITEMNUM HAVING SUM(Quantity) >={}".format(str(mbo.getFloat("QTYTO")))
	
	if  not mbo.isNull("COSTFROM"):
		if Grouped:
			SQLQuery = SQLQuery + " AND SUM(LINECOST) >={}".format(str(mbo.getFloat("COSTFROM")))
		else:
			Grouped = True
			SQLQuery = SQLQuery + " GROUP BY ITEMNUM HAVING SUM(LINECOST) >={}".format(str(mbo.getFloat("COSTFROM")))		
		
	if  not mbo.isNull("COSTTO"):
		if Grouped:
			SQLQuery = SQLQuery + " AND SUM(LINECOST) <={}".format(str(mbo.getFloat("COSTTO")))
		else:
			Grouped = True
			SQLQuery = SQLQuery + " GROUP BY ITEMNUM HAVING SUM(LINECOST) <={}".format(str(mbo.getFloat("COSTTO")))
	
	
	if "DM_COUNTBOOKVIEW" in SQLQuery:
		SQLQuery = SQLQuery + " )"
	logger.debug("****SQLQuery is ****"+str(SQLQuery))
	#setError(SQLQuery)
	InvSet = databean.getMboSet()
	InvSet.setWhere(SQLQuery)
	InvSet.reset();
	databean.refreshTable()