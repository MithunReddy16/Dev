print 'x'
PRMbo = mbo.getOwner()
if PRMbo:
    if PRMbo.getString('STATUS') == "GRPRETURN":
        Feilds_to_check=["ITEMNUM","DESCRIPTION","COMMODITYGROUP","COMMODITY","ORDERQTY","UNITCOST"]
        for field in Feilds_to_check:
            if mbo.isModified(field):
                mbo.setValue('DM_CCAPPR',False,11l)
                mbo.setValue('DM_APPR',False,11l)