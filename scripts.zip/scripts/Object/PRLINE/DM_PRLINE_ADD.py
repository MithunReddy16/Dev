#-----------------------------------------------------------------------------------------
# Name:        DM_PRLINE_ADD
# Description: Copy storeloc and shipto to lines 
# Author: Mithun Reddy

#-----------------------------------------------------------------------------------------
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants
logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("**** DM_PRLINE_ADD debug Started ***1")

logger = MXLoggerFactory.getLogger("maximo.custom")
appl = mbo.getThisMboSet().getParentApp()
owner=mbo.getOwner()
if appl=="DM_PLUSGPR":
    if mbo.isNew() :
        store=owner.getString("DM_STORELOC")
        shipto=owner.getString("SHIPTO")

        if store is not None and store != "" :
            mbo.setValue("STORELOC",store)
            mbo.setFieldFlag("STORELOC", MboConstants.READONLY, True)
        
        
        if shipto is not None and shipto != "" :
            mbo.setValue("DM_SHIPTO",shipto)
            mbo.setFieldFlag("DM_SHIPTO", MboConstants.READONLY, True)