from psdi.mbo import MboConstants



if launchPoint=="DM_PRREAD":


    if app == 'DM_PLUSGPR' and mbo.isNew()==0 :
        wfAssignmentSet = mbo.getMboSet("WFASSIGNMENT")
        assigned = False
        
        currentuser = mbo.getUserInfo().getPersonId()
        requestedby = mbo.getString("requestedby")
        
        for i in range(wfAssignmentSet.count()):
            wfMbo = wfAssignmentSet.getMbo(i)
            assign_user = wfMbo.getString("ASSIGNCODE")
            assign_status = wfMbo.getString("ASSIGNSTATUS")

           
            if assign_user == currentuser and assign_status in ("ACTIVE"):
                assigned = True
                break  


        if not assigned and mbo.getString("status") not in ("WAPPR" ,"GRPRETURN"):
            
            mboSet = mbo.getThisMboSet()
            mbo.setFlag(7L,True)
            lineblock = mbo.getMboSet("prline")
            lineblock.setFlag(7L,True)
        
        elif currentuser != requestedby:
            #mbo.setFieldFlag("requestedby", MboConstants.READONLY, True)
            #mbo.setFieldFlag("requireddate", MboConstants.READONLY, True)
            #mbo.setFieldFlag("description", MboConstants.READONLY, True)
            #mbo.setFieldFlag("dm_trpriority", MboConstants.READONLY, True)
            mbo.setFlag(7L,True)
            prline = mbo.getMboSet("prline")
            prline.setFlag(7L, True)
        
        elif currentuser == requestedby and mbo.getString("status") not in ('WAPPR' ,'GRPRETURN','PENDINGMM', 'CCRETURNMM','AMDRETURNMM','ICRETURNMM','WMRETURNMM'):
            #mbo.setFieldFlag("requestedby", MboConstants.READONLY, True)
            mbo.setFlag(7L,True)
            prline = mbo.getMboSet("prline")
            prline.setFlag(7L, True)
            
if launchPoint == "DM_PRQTYREAD":
    app=mbo.getThisMboSet().getParentApp()
    if app == 'DM_PLUSGPR':
        #if not mbo.isNew() and mbo.getOwner() is not None and mbo.getOwner().getName() == "PR" and mbo.getOwner().getString("status") not in  ('PENDINGMD', 'CCRETURN','ICRETURN', 'WMRETURN','PENDING','WMAPPR','ICAPPR','AMDAPPR','AMDRETURN'):
        # status condition is added to allow the user to edit the lines if it was returned from GRP
        PR = mbo.getOwner()
        if PR:
            if not mbo.isNew() and mbo.getBoolean("dm_appr") and PR.getString("status") not in ("GRPRETURN"):
                mbo.setFlag( MboConstants.READONLY, True)