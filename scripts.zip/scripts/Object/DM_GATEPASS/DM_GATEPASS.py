company = mbo.getString("COMPANY")
issuedto = mbo.getString("ISSUEDTO")

if (company == '' and issuedto == ''):
    service.error("DM_GATEPASS","required")