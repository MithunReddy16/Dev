/*
Script: DM_IRLOGS.INIT
Created By: Ashok
Date: 28-Dec-2024
Req: Make item request logs read only


*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)


logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_IRLOGS.INIT**START***")

if(!mbo.toBeAdded())
{
	mbo.setFlag(MboConstants.READONLY,true)
}
logger.error("***ASH***Sript DM_IRLOGS.INIT**END***")