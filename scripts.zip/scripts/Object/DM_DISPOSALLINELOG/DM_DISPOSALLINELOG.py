LineMbo = mbo.getOwner()
MainRecordMbo = LineMbo.getOwner()
if not MainRecordMbo:
    MainRecordMbo = LineMbo
Person = mbo.getUserInfo().getPersonId()
#mbo.setFlag(7L,not mbo.toBeAdded())

if not mbo.toBeAdded():
    if mbo.getDate('ENTERDATE') < MainRecordMbo.getDate('STATUSDATE') or Person <> mbo.getString('ENTERBY'):
        mbo.setFlag(7L,True)