if mbo.isNew():
    if mbo.getOwner().getName()=='DM_DISPOSALLINE':
        mbo.setValue('DISPOSALLINENUM',mbo.getOwner().getInt('DISPOSALLINENUM'),11L)