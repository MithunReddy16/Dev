#DM_DISPOSALLINE.DELETE



if not mbo.getMboSet('REFSOURCELINES').isEmpty():
    SourceLine= mbo.getMboSet('REFSOURCELINES').getMbo(0)
    SourceLine.setValueNull('REFDISPOSALNUM',11L)
    SourceLine.setValueNull('REFDISPOSALLINENUM',11L)
    SourceLine.setValueNull('REFDISPOSALLINEID',11L)