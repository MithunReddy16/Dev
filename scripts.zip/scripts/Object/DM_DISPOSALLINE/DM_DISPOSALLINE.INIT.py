# Not in Use
#ParentSet = mbo.getMboSet('REFSOURCELINES')
#if not ParentSet.isEmpty():
#    mbo.setValue('PARENT',ParentSet.getMbo(0).getString('disposalnum'),11L)
    
App= mbo.getThisMboSet().getParentApp()

#DM_DIS07 =  status in ('WINV','CLOSED')
if App=='DM_DECOM' and mbo.evaluateCondition('DM_DIS07'):
    #mbo.getOwner().setFlag(7L,True)
    mbo.setFieldFlag(['SUGDISPOSALMETHOD','JUSTIFICATION'],7L,True)

# DM_DIS12 =  status in ('WAMDCO','RESUBMIT')   and active WFAssignment
if App=='DM_DECOM' and not mbo.evaluateCondition('DM_DIS12'):
    mbo.setFieldFlag(['DECISION','DISPOSALMETHOD'],7L,True)



DisposalMbo = mbo.getOwner()

if App=='DM_DECOM' and DisposalMbo.getName()=='DM_DISPOSAL' and DisposalMbo and not DisposalMbo.getString('STATUS') in ('DRAFT','REJECTED','WDEPTCO','DCREJECTED'):
    mbo.setFieldFlag(['ASSETNUM','JUSTIFICATION','SUGDISPOSALMETHOD'],7L,True)
    



if DisposalMbo and DisposalMbo.getName()=='DM_DISPOSAL' and App=='DM_DISPOSAL':
    if not DisposalMbo.getString('STATUS') in ('RETURNED','DRAFT','WDEPTCO','DCRETURNED'):
        mbo.setFieldFlag(['DESCRIPTION','QUANTITY','MEASUREUNIT','ADJUSTPRICE'],7L,True)
    
    #if not DisposalMbo.getString('STATUS') in ('AMD-APPR','WAUCCOMM','WRET','WDACOMM','WAUCCO','WEVCOMM'):
        #mbo.setFieldFlag(['AUCPRICE','AWARDCOMPANY'],7L,True)
    
    if not DisposalMbo.getString('STATUS') in ('B-APPR','WRET','WAUCCO','WEVCOMM','WDACOMM'):
        mbo.setFieldFlag(['AUCPRICE','AWARDCOMPANY','AWARDCOCONTACT','AWARDCOPHONE','AWARDPRODATE','AWARDCOEMAIL','AWARDCOADDRESS','DELIVERYMETHOD'],7L,True)
    if DisposalMbo.getString('DISPOSALTYPE') =='Auction' and DisposalMbo.getString('STATUS') in ('WRET','WAUCCO','AMD-APPR'):
        mbo.setFieldFlag(['AUCPRICE','AWARDCOMPANY','AWARDCOCONTACT','AWARDCOPHONE','AWARDPRODATE','AWARDCOEMAIL','AWARDCOADDRESS'],128L,True)

    
    #if mbo.getBoolean('bulk'):
    #    mbo.setFieldFlag(['ASSETNUM'],7L,True)