#DM_BUDGETLINE.ADD
def setError(Msg):
		#global errorkey,errorgroup,params
		#errorkey='scriptvalidationerror'
		#errorgroup='scriptval'
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)


if launchPoint=='DM_DISPOSALLINE.CD':
    DisposalMbo = mbo.getOwner()
else:
    DisposalMbo = mboset.getOwner()
    
if DisposalMbo is not None and (not DisposalMbo.getString('STATUS') in ('REJECTED','DRAFT')):
    setError('Lines can not be added or deleted.')