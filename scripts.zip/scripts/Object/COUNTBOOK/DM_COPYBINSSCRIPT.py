from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.script")

if app == "DM_COUNTBOOK":

    if launchPoint=="DM_CPYSHEDBINS":
        
        countbookselset = mbo.getMboSet("COUNTBOOKSELTYPE")
        countbooklineset = mbo.getMboSet("COUNTBOOKALLITM")
    
        
        if countbookselset.count()>0:
             countbookselset.deleteAll(MboConstants.NOACCESSCHECK)
             #countbookselset.save()
    
        if countbooklineset.count()>0:
            countbooklineset.deleteAll(MboConstants.NOACCESSCHECK)
            
    
    
    if launchPoint == "DM_COPYBINS":
        logger.debug("******DM_COPYBINS is***")
    
        countbooknum = mbo.getString("COUNTBOOKNUM")
        store = mbo.getString("STOREROOM")
        shed = mbo.getString("DM_SHED")
        logger.debug("******DM_COPYBINS before DM_SHED***")
        if mbo.isModified("DM_SHED") or (mbo.isNew() and shed != ""):
            logger.debug("******DM_COPYBINS isinside if in DM_SHED ***")
            countbookselset = mbo.getMboSet("COUNTBOOKSELTYPE")
            countbooklineset = mbo.getMboSet("COUNTBOOKALLITM")
            bin_list = []
    
            binset = mbo.getMboSet("$STORAGEBINS", "DM_STOREBINS",
                "BINSEG01 = '{}' AND STOREROOMNAME = '{}'".format(shed, store))
            logger.debug("******DM_COPYBINS binset before ***")
            binmbo = binset.moveFirst()
            while binmbo:
                logger.debug("******DM_COPYBINS binset inside ***")
                binnum = binmbo.getString("BINNUM")
                if binnum:
                    binnum = binnum.strip()
                    bin_list.append(binnum)
                    newsel = countbookselset.add()
                    newsel.setValue("COUNTBOOKNUM", countbooknum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                    newsel.setValue("SELECTIONTYPE", "SHED", MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                    newsel.setValue("SELECTIONBIN", binnum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                binmbo = binset.moveNext()
    
            if bin_list:
                bin_list_str = "', '".join(bin_list)
                inv_where = "BINNUM IN ('{}') AND LOCATION = '{}' AND CURBAL > 0".format(bin_list_str, store)
    
                invset = mbo.getMboSet("$INVBAL", "INVBALANCES", inv_where)
                invmbo = invset.moveFirst()
                logger.debug("******DM_COPYBINS invmbo before ***")
                while invmbo:
                    binnum = invmbo.getString("BINNUM")
                    itemnum = invmbo.getString("ITEMNUM")
                    logger.debug("******DM_COPYBINS invmbo indise ***")
                    # Avoid duplicate lines
                    checkset = mbo.getMboSet("$CHECKLINE", "COUNTBOOKLINE",
                        "COUNTBOOKNUM = '{}' AND BINNUM = '{}' AND ITEMNUM = '{}'".format(countbooknum, binnum, itemnum))
                    checkset.reset()
                    logger.debug("******DM_COPYBINS checklist before ***")
                    if checkset.isEmpty():
                        # Get item info to check if rotating
                        itemset = invmbo.getMboSet("ITEM")
                        itemset.setWhere("ITEMNUM = '{}'".format(itemnum))
                        itemset.reset()
                        itemmbo = itemset.moveFirst()
                        rotating = itemmbo.getBoolean("ROTATING") if itemmbo else False
                        logger.debug("******DM_COPYBINS checklist indise ***")
                        if rotating:
                            # Query matching assets
                            asset_where = "LOCATION = '{}' AND BINNUM = '{}' AND ITEMNUM = '{}'".format(store, binnum, itemnum)
                            assetset = mbo.getMboSet("$ASSETSET", "ASSET", asset_where)
                            logger.debug("******DM_COPYBINS is ****"+str(asset_where))
                            assetmbo = assetset.moveFirst()
                            logger.debug("******DM_COPYBINS is***1")
                            while assetmbo:
                                assetnum = assetmbo.getString("ASSETNUM")
                                logger.debug("******DM_COPYBINS inside is***1"+str(assetnum))
                                newline = countbooklineset.add()
                                logger.debug("******DM_COPYBINS inside is***1")
                                newline.setValue("COUNTBOOKNUM", countbooknum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                                newline.setValue("BINNUM", binnum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                                newline.setValue("ITEMNUM", itemnum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                                newline.setValue("ROTATING", True, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                                newline.setValue("ASSETNUM", assetnum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                                newline.setValue("CURBAL",1, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                                logger.debug("******DM_COPYBINS inside is***2")
                                assetmbo = assetset.moveNext()
                        else:
                            # For non-rotating items
                            newline = countbooklineset.add()
                            newline.setValue("COUNTBOOKNUM", countbooknum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                            newline.setValue("BINNUM", binnum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                            newline.setValue("ITEMNUM", itemnum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                            newline.setValue("ROTATING", False, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                            newline.setValue("CURBAL", invmbo.getDouble("CURBAL"), MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
    
                    invmbo = invset.moveNext()