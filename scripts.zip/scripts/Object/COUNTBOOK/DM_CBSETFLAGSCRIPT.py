# changed by Mithun 

from psdi.mbo import MboConstants
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory

# Initialize the logger
logger = MXLoggerFactory.getLogger("maximo.script")

countBookLineSet = mbo.getMboSet("COUNTBOOKALLITM")
countBookSelSet = mbo.getMboSet("COUNTBOOKSELTYPE")

if app=="DM_COUNTBOOK":
	'''
	if mbo.getString("status")=='APPR':
		mbo.setFieldFlag("DM_STARTDATE", MboConstants.READONLY, True)
		mbo.setFieldFlag("DM_ENDDATE", MboConstants.READONLY, True)
		mbo.setFieldFlag("DM_COUNTTYPE", MboConstants.READONLY, True)
		mbo.setFieldFlag("DM_SHED", MboConstants.READONLY, True)
		line = countBookLineSet.moveFirst()
		while line:
			line.setFieldFlag("RECON", MboConstants.READONLY, True)
			line.setFieldFlag("PHYSCNT", MboConstants.READONLY, True)
			line = countBookLineSet.moveNext()
	
	'''
	if not mbo.isNew():
		wfAssignmentSet = mbo.getMboSet("WFASSIGNMENT")
		assigned = False
		currentuser = mbo.getUserInfo().getPersonId()
		assign_user = None
		for i in range(wfAssignmentSet.count()):
			wfMbo = wfAssignmentSet.getMbo(i)
			assign_user = wfMbo.getString("ASSIGNCODE")
			assign_status = wfMbo.getString("ASSIGNSTATUS")
			if assign_user == currentuser and assign_status in ("ACTIVE"):
				assigned = True
				break  

		#if  assigned and mbo.getString("status") :
		if  not assigned and not mbo.getString("status") in ('WAPPR','ROUND1','ROUND2','FICO') :
			mboSet = mbo.getThisMboSet()
			mbo.setFlag(7L,True)
			lineblock = mbo.getMboSet("COUNTBOOKALLITM")
			lineblock.setFlag(7L,True)
			
			lineblock2 = mbo.getMboSet("COUNTBOOKALLITM2")
			lineblock2.setFlag(7L,True)
			
			lineblock3 = mbo.getMboSet("COUNTBOOKALLITM3")
			lineblock3.setFlag(7L,True)


		elif mbo.getString("status") in ('WAPPR','ROUND1','ROUND2','FICO'):
			CreatorSet = mbo.getMboSet('DM_CBCREATOR')
			Creator = CreatorSet.moveFirst()
			CreatorID=None if not Creator else Creator.getString('CHANGEBY')
			
			if mbo.getString("status")=="FICO" and not assigned:
				lineblock = mbo.getMboSet("COUNTBOOKALLITM")
				lineblock.setFlag(7L,True)
				
				lineblock2 = mbo.getMboSet("COUNTBOOKALLITM2")
				lineblock2.setFlag(7L,True)
				
				lineblock3 = mbo.getMboSet("COUNTBOOKALLITM3")
				lineblock3.setFlag(7L,True)
			elif not assigned and CreatorID and CreatorID!=currentuser:				
					mbo.setFlag(7L,True)
					lineblock = mbo.getMboSet("COUNTBOOKALLITM")
					lineblock.setFlag(7L,True)
					
					lineblock2 = mbo.getMboSet("COUNTBOOKALLITM2")
					lineblock2.setFlag(7L,True)
					
					lineblock3 = mbo.getMboSet("COUNTBOOKALLITM3")
					lineblock3.setFlag(7L,True)
					
		if  mbo.getString("status") not in ('WAPPR'):
		    mbo.setFieldFlag("YEAR",7L,True)
		    mbo.setFieldFlag("MONTH",7L,True)