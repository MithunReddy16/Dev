if (mbo.isModified("STARTDATE") or mbo.isModified("ENDDATE") or mbo.isModified("LICENSENUM")):
    assetSet=mbo.getMboSet("PLUSTASSET")
    if (not assetSet.isEmpty() and assetSet.moveFirst().getBoolean("DM_PUBLISHTOFTS")):
        assetSet.moveFirst().setValue("DM_PUBLISHTOFTS", 0)
    else:
        assetSet.moveFirst().setValue("DM_PUBLISHTOFTS", 1)