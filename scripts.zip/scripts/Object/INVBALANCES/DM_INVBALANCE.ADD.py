#-----------------------------------------------------------------------------------------
# Name:        DM_INVBALANCE.ADD
# Description: whilw adding invbalances set binnum is mandatory
# Author: Mithun Reddy
# Version: 1.0 - 23-Jun-2025
#-----------------------------------------------------------------------------------------
def setError(Msg):
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)


binnum=mbo.getString("BINNUM")
if binnum is None or binnum=='' :
    setError('Binnum should not be blank while adding the invbalances.')