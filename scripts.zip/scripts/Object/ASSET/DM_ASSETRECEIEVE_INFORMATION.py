#DM_ASSETRECEIEVE_INFORMATION
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

myLogger = MXLoggerFactory.getLogger("maximo.custom")

AssetMbo=mbo
MatRecRecord=AssetMbo.getOwner()

#myLogger.debug("DM_ASSETRECEIEVE_INFORMATION <<" + MatRecRecord.getName())
if MatRecRecord is not None:
    if MatRecRecord.getName().upper()=='MATRECTRANS':
        #itemNum = AssetMbo.getString('itemnum')
        #AssetMbo.setValue('DM_SERIALCLASS',itemNum,11L)
        #AssetMbo.setValue('DM_SERIALNUM',int(asset.getString('assetnum')[len(itemNum)+1:]),11L)
        PO = MatRecRecord.getOwner()
        AssetInputSet = PO.getMboSet('ASSETINPUT')
        AssetInput =AssetInputSet.moveFirst()
        while AssetInput:
            if AssetInput.getString('ASSETNUM') == AssetMbo.getString('ASSETNUM'):
                AssetMbo.setValue('SERIALNUM',AssetInput.getString('SERIALNUM'),MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK)
                AssetMbo.setValue('DM_ASSET_TAG',AssetInput.getString('DM_ASSET_TAG'),MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK)
                break;
                
            AssetInput=AssetInputSet.moveNext()