from java.util import Date
from java.util import Calendar
from java.util.concurrent import TimeUnit
from java.text import SimpleDateFormat
from psdi.server import MXServer
from java.lang import Math

currentDate = MXServer.getMXServer().getDate()
installDate = mbo.getDate("INSTALLDATE")
usefulLife = mbo.getDouble("DM_USEFULLLIFE")

if (currentDate is not None and installDate is not None):
    if(installDate >= currentDate):
        mbo.setValue("DM_REMAINUSEFULLIFE", float(usefulLife),11L)
    else:
        diffInMillies = Math.abs(currentDate.getTime() - installDate.getTime())
        diffDays = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS)
        diffYears = float(diffDays) / float(365)
        
        remainUsefulLife = float(usefulLife) - float(diffYears)
        
        if(remainUsefulLife > 0):
            mbo.setValue("DM_REMAINUSEFULLIFE", remainUsefulLife,11L)
        else:
            mbo.setValue("DM_REMAINUSEFULLIFE", 0,11L)