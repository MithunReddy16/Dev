assetTransSet = mbo.getMboSet("ASSETTRANS")
pocount=assetTransSet.count()
print(pocount)

if (pocount>0):
    poNum=mbo.getMboSet("ASSETTRANS").getMbo(0).getString("PONUM")
    

    if (poNum != ""):
        mbo.setValue("DM_INT_PONUM", poNum)