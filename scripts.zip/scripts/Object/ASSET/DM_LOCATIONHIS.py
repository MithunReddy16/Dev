from java.util import Calendar
from psdi.mbo import MboConstants

print "Asset DM Location"

cal = Calendar.getInstance()
currentDateTime = cal.getTime()
CurrentLocation = mbo.getMboValue("DM_LOCATION").getCurrentValue().asString()
DatabaseLocation = mbo.getMboValue("DM_LOCATION").getInitialValue().asString()

if(not mbo.toBeAdded() and mbo.getMboValue("DM_LOCATION").isModified() and (CurrentLocation != DatabaseLocation)):
    
    
    AssetTransSet = mbo.getMboSet('ASSETTRANS')
    AssetTrans = AssetTransSet.add()
    AssetTrans.setValue('ASSETNUM', mbo.getString('ASSETNUM'),MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK)
    AssetTrans.setValue('SITEID', mbo.getString('SITEID'),MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK)
    AssetTrans.setValue('TOSITEID', mbo.getString('SITEID'),MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK)
    AssetTrans.setValue('ORGID', mbo.getString('ORGID'),MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK)
    AssetTrans.setValue('TOORGID', mbo.getString('ORGID'),MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK)
    AssetTrans.setValue('TRANSTYPE', "MOVED",MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK)
    AssetTrans.setValue('DM_FROMLOC', DatabaseLocation,MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK)
    AssetTrans.setValue('DM_TOLOC', CurrentLocation,MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK)
    AssetTrans.setValue('DATEMOVED', currentDateTime,MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK)
    AssetTrans.setValue('TRANSDATE', currentDateTime,MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK)
    AssetTrans.setValue('ENTERBY', user,MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK)
    
    AssetTransSet.save()