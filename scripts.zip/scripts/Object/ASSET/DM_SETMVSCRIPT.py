#script:DM_SETMVSCRIPT
#Createdby:Ram
#Creation Date:23-SEP-22
#scope:if vendor and manufacturer values are not null then scripts will set the names of manufcaturer and vendors respectively.

from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.mbo import Mbo

mafc= mbo.getString("MANUFACTURER")
vendor= mbo.getString("VENDOR")

mcomp =mbo.getMboSet("MANUFACTURER").getMbo(0)
vcomp =mbo.getMboSet("COMPANIES").getMbo(0)
if mcomp is not None:
        mname= mcomp.getString("Name")
        mbo.setValue("dm_manfctrdesc",mname,MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK )

if vcomp is not None:
        vname= vcomp.getString("Name")
        mbo.setValue("dm_vendordesc",vname,MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK )