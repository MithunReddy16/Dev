from psdi.mbo import MboConstants


revEngSet = mbo.getMboSet("DM_ASSETREVENG")

if revEngSet is not None and not revEngSet.isEmpty():
    checked = False
    
    for i in range(revEngSet.count()):
        childMbo = revEngSet.getMbo(i)
        
        reviewer = childMbo.getBoolean("DM_ISREV3")  
        engineer = childMbo.getBoolean("dm_iseng3")
        
       
        if reviewer == True or engineer == True:
            checked = True
    
    if not checked:
        service.error("dm","genericerror", ["Either Reviewer or Engineer must be selected."])