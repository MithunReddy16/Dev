from psdi.pluss.app.plussgis.helper import LinkUtil
from com.ibm.tivoli.maximo.map import GeometryUtils
from com.ibm.json.java import JSONObject
from psdi.pluss.app.plussgis import PlusSGISServiceRemote 
from psdi.server import MXServer

featureClass = mbo.getString("PLUSSFEATURECLASS")
linkedGIS = LinkUtil.getLinkedGISMbo(mbo, featureClass)
#Check if is linked
if linkedGIS != None:

	gisService = MXServer.getMXServer().lookup("PLUSSGIS")
	geoJson = gisService.computeGeoJSONFromMbo(mbo.getUserInfo(), mbo)

	print(geoJson)

	geometryData = service.jsonToString(geoJson)

	mbo.setValue("PLUSSGEOJSON", geometryData)

else:
   print("############## Not Linked")

#08-08-2025 update maintenace department value eaveytime maintenance section changes.-- start.   
if mbo.isModified("dm_maintsec"):
    if not mbo.isNull("dm_maintsec"):
        mbo.setValue("DM_MAINTDEPT",mbo.getString("DM_MAINTSEC.PARENT1ID"))
    else:
        mbo.setValueNull("DM_MAINTDEPT")
#--------- end