LineSet = mbo.getMboSet('DM_MRRLINE')

MrrLine = LineSet.moveFirst()
while MrrLine:
    MrrLine.setValue('QWINSP',MrrLine.getFloat('QUANTITY'))
    MrrLine = LineSet.moveNext()