from psdi.server import MXServer
from  psdi.common.context import UIContext
from psdi.webclient.system.controller import SessionContext, Utility, WebClientEvent
from com.ibm.tivoli.maximo.script import ScriptService
from psdi.mbo import SqlFormat
from psdi.util import MXException

mxServer = MXServer.getMXServer()
from psdi.util.logging import MXLoggerFactory
myLogger = MXLoggerFactory.getLogger("maximo.custom")

def setError(Msg):
		#global errorkey,errorgroup,params
		#errorkey='scriptvalidationerror'
		#errorgroup='scriptval'
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)

def getNewAsset(MrrLineMbo):
	AssetSet = mxServer.getMboSet('ASSET',mxServer.getSystemUserInfo())
	Asset = AssetSet.add()
	Asset.setValue('ITEMNUM',MrrLineMbo.getString('ITEMNUM'))
	Asset.setValue('DM_ASSET_TAG',MrrLineMbo.getString('DM_ASSET_TAG'))
	#Asset.setValue('DM_SECTOR',MrrLineMbo.getOwner().getString('SECTOR'))
	Asset.setValue('DM_MAINTDEPT',MrrLineMbo.getOwner().getString('DEPARTMENT'))
	Asset.setValue('DM_MAINTSEC',MrrLineMbo.getOwner().getString('SECTION'))
	#Asset.setValue('DM_SECTION',MrrLineMbo.getOwner().getString('SECTION'))
	AssetSet.save()
	MrrLineMbo.setValue('ROTASSETNUM',Asset.getString('ASSETNUM'),11L)
	
	return Asset.getString('ASSETNUM')

def AddCheckLot(MrrLineMbo):
	InvLotSet = mxServer.getMboSet('INVLOT',mxServer.getSystemUserInfo())
	
	sqf1 =SqlFormat(mxServer.getSystemUserInfo(),"ORGID=:1 AND SITEID=:2 AND ITEMSETID=:3 AND ITEMNUM=:4 AND LOCATION=:5 AND LOTNUM=:6")
	
	sqf1.setObject(1, "UPPER", MrrLineMbo.getString('ORGID'))
	sqf1.setObject(2, "UPPER", MrrLineMbo.getString('SITEID'))
	sqf1.setObject(3, "UPPER", MrrLineMbo.getString('ITEM.ITEMSETID'))
	sqf1.setObject(4, "UPPER", MrrLineMbo.getString('ITEMNUM'))
	sqf1.setObject(5, "UPPER", MrrLineMbo.getString('STORELOC'))
	sqf1.setObject(6, "UPPER", MrrLineMbo.getString('LOTNUM'))
	
	
	InvLotSet.setWhere(sqf1.format())
	InvLotSet.reset()
	InvLot = InvLotSet.moveFirst()
	
	if not InvLot:
		newInvLot = InvLotSet.add()
		newInvLot.setValue('ORGID',MrrLineMbo.getString('ORGID'))
		newInvLot.setValue('SITEID',MrrLineMbo.getString('SITEID'))
		newInvLot.setValue('ITEMSETID',MrrLineMbo.getString('ITEM.ITEMSETID'))
		newInvLot.setValue('ITEMNUM',MrrLineMbo.getString('ITEMNUM'))
		newInvLot.setValue('LOCATION',MrrLineMbo.getString('STORELOC'))
		newInvLot.setValue('LOTNUM',MrrLineMbo.getString('LOTNUM'))
		newInvLot.setValue('USEBY',MrrLineMbo.getDate('EXPIRYDATE'))
		
		InvLotSet.save()
		
		
if launchPoint=='DM_MRRACCALL':
	inspTable = service.webclientsession().getDataBean("insp_tab_table")
	inspMboSet = inspTable.getMboSet()
	inspMob = inspMboSet.moveFirst()
	while inspMob:
		inspMob.setValue('QACCEPT_NP',inspMob.getFloat('QWINSP'))
		inspMob.setValue('QREJECT_NP',0.00)
		inspMob=inspMboSet.moveNext()
		
	inspTable.refreshTable()
	
elif launchPoint=='DM_MRRREJALL':
	inspTable = service.webclientsession().getDataBean("insp_tab_table")
	inspMboSet = inspTable.getMboSet()
	inspMob = inspMboSet.moveFirst()
	while inspMob:
		inspMob.setValue('QREJECT_NP',inspMob.getFloat('QWINSP'))
		inspMob.setValue('QACCEPT_NP',0.00)
		inspMob=inspMboSet.moveNext()
		
	inspTable.refreshTable()

elif launchPoint=='DM_MRRINSPOK':
	inspTable = service.webclientsession().getDataBean("insp_tab_table")
	inspMboSet = inspTable.getMboSet()
	inspMob = inspMboSet.moveFirst()
	error1 = False
	while inspMob:
		qWINSP = inspMob.getFloat('QWINSP')
		qREJECT_NP = inspMob.getFloat('QREJECT_NP')
		qACCEPT_NP = inspMob.getFloat('QACCEPT_NP')
		
		qREJECT = inspMob.getFloat('QREJECT')
		qACCEPT = inspMob.getFloat('QACCEPT')
		
		
		
		if ((qREJECT_NP + qACCEPT_NP)>qWINSP):
			error1=True
			break
			
			
		inspMob.setValue('QACCEPT', qACCEPT + qACCEPT_NP)
		inspMob.setValue('QREJECT',qREJECT + qREJECT_NP)
		inspMob.setValue('QWINSP', qWINSP - qACCEPT_NP - qREJECT_NP)
	
		if not inspMob.isNull('REJECTREASON_NP') and qREJECT_NP > 0.0 :
			RejectionMboSet = inspMob.getMboSet('DM_MRRREJREASON')
			RejectionMbo = RejectionMboSet.addAtEnd()
			RejectionMbo.setValue('MRRNUM',inspMob.getString('MRRNUM'))
			RejectionMbo.setValue('MRRLINENUM',inspMob.getString('MRRLINENUM'))
			RejectionMbo.setValue('REJECTREASON',inspMob.getString('REJECTREASON_NP'))
			RejectionMbo.setValue('QREJECT',qREJECT_NP)
		
		inspMob=inspMboSet.moveNext()
		
	
	if error1:
		setError('Total accept and reject exceed waiting inspection quantity for one of the lines.')
		
	else:
		inspMboSet.save()
		service.closeDialog()
		
elif launchPoint=='DM_INSPVAL':
	if  not (mbo.getString('STATUS')=='ASSIGNED'):
		setError('Status must be ASSIGNED')
	elif not mbo.getString("ASSIGNEDTO") == mbo.getUserInfo().getPersonId():
	    setError('Action is limited to assigned storekeeper')
	else:
		service.launchDialog('INSP')
		#wcs = service.webclientsession()
		#wcs.loadDialog('INSP')
		#Utility().sendEvent(WebClientEvent("INSP", wcs.getCurrentPageId(), None, SessionContext(wcs)))
			
elif launchPoint=='DM_MRRGENIU':
	#if not mbo.evaluateCondition("DM_MRR12") and not mbo.evaluateCondition("DM_MRR13"):
	mrrLineSet = mbo.getMboSet("DM_MRRLINE")
	if mrrLineSet is not None:
		mrrLine = mrrLineSet.moveFirst()
		while mrrLine is not None:
			lineNum = mrrLine.getString("MRRLINENUM")
			debitGL = mrrLine.getString("GLDEBITACCT")
			creditGL = mrrLine.getString("GLCREDITACCT")
			myLogger.debug("*** Mithun line1**")
			# Validate GLDEBITACCT in chartofaccounts table
			if mrrLine.getFloat('QRETURN') < mrrLine.getFloat('QACCEPT'):
				'''
				if debitGL:
					coaSet1 = MXServer.getMXServer().getMboSet("CHARTOFACCOUNTS", MXServer.getMXServer().getSystemUserInfo())
					sql1 = SqlFormat(MXServer.getMXServer().getSystemUserInfo(), "GLACCOUNT = :1 and ACTIVE=1")
					sql1.setObject(1, "CHARTOFACCOUNTS", "GLACCOUNT", debitGL)
					coaSet1.setWhere(sql1.format())
					coaSet1.reset()
					if coaSet1.isEmpty():
						setError("Invalid GL Debit Account in line: " + lineNum)
				'''
				# Validate GLDEBITACCT in chartofaccounts table
				if creditGL:
					'''
					coaSet2 = MXServer.getMXServer().getMboSet("CHARTOFACCOUNTS", MXServer.getMXServer().getSystemUserInfo())
					sql2 = SqlFormat(MXServer.getMXServer().getSystemUserInfo(), "GLACCOUNT = :1 and ACTIVE=1")
					sql2.setObject(1, "CHARTOFACCOUNTS", "GLACCOUNT", creditGL)
					coaSet2.setWhere(sql2.format())
					coaSet2.reset()
					if coaSet2.isEmpty():
					'''
					if '?' in creditGL:
						setError("Invalid GL Credit Account in line: " + lineNum)						
			mrrLine = mrrLineSet.moveNext()
	if  not (mbo.getString('STATUS')=='ASSIGNED'):
		setError('Status must be ASSIGNED')
	elif not mbo.getString("ASSIGNEDTO") == mbo.getUserInfo().getPersonId():
	    setError('Action is limited to assigned storekeeper')
	
	elif mbo.evaluateCondition('DM_MRR08'):
		setError('One or more lines missing Bin number')
	elif mbo.evaluateCondition('DM_MRR09'):
		setError('One or more lines missing Asset number/tag number')
	
	elif mbo.evaluateCondition('DM_MRR10'):
		setError('One or more lines have the asset number missing for the entered tag number')
	
	elif mbo.evaluateCondition('DM_MRR11'):
		setError('One or more lines missing lot information')	
	elif mbo.evaluateCondition('DM_MRR12'):
		setError('One or more lines missing GL Credit Account information')
	elif mbo.evaluateCondition('DM_MRR13'):
		setError('Select store GL account is not defined')
	elif mbo.evaluateCondition('DM_MRR15'):
		setError('One or more lines transaction date is not in open period')
		
	else:
		userInput = service.yncuserinput()
		if userInput == ScriptService.YNC_NULL:
			service.yncerror('scriptval', 'scriptyn',["This action will Create Inventory Usage for all accepted items. Are you sure you want to continue?"])
		elif userInput == ScriptService.YNC_YES:
			
			wcs = service.webclientsession()
			mxServer = MXServer.getMXServer()
			MrrLineSet = mbo.getMboSet('DM_MRRLINE')
			MrrLineMbo = MrrLineSet.moveFirst()
			if not MrrLineMbo:
				setError('No Lines')
			else:
				try:
					InvUseSet = mxServer.getMboSet('INVUSE',mxServer.getSystemUserInfo())
					InvUseSet.setApp("DM_MRR")				
				
					Created = False
					IV = None
					while MrrLineMbo:
						if MrrLineMbo.getFloat('QRETURN') < MrrLineMbo.getFloat('QACCEPT'):
							if not Created:
								InvUseMbo = InvUseSet.add()
								IV = InvUseMbo.getString('INVUSENUM')
								
								InvUseMbo.setValue('DESCRIPTION','Auto Generated From MRR:' + mbo.getString('MRRNUM'))
								InvUseMbo.setValue('USETYPE','ISSUE')
								InvUseMbo.setValue('FROMSTORELOC',mbo.getString('STORELOC'))
								
								InvUseMbo.setValue('DM_MRRNUM',mbo.getString('MRRNUM'))
								InvUseMbo.setValue('DM_MRRSITE',mbo.getString('SITEID'))
								
								InvUseLineSet = InvUseMbo.getMboSet('INVUSELINE')
								Created = True
							
							InvUseLine =InvUseLineSet.addAtEnd()
							InvUseLine.setValue('USETYPE','RETURN')
							InvUseLine.setValue('ITEMNUM',MrrLineMbo.getString('ITEMNUM'))
							
							InvUseLine.setValue('QUANTITY',MrrLineMbo.getFloat('QACCEPT') - MrrLineMbo.getFloat('QRETURN'))
							MrrLineMbo.setValue('QRETURN', MrrLineMbo.getFloat('QACCEPT') )
							
							InvUseLine.setValue('DM_MRRLINEID',MrrLineMbo.getString('DM_MRRLINEID'))
							# below line added by Mithun 
							InvUseLine.setValue('ACTUALDATE',MrrLineMbo.getDate('DM_ACTUALDATE'))
							InvUseLine.setValue('UNITCOST',MrrLineMbo.getString('UNITCOST'))
							
							if MrrLineMbo.getBoolean('ITEM.ROTATING'):
								if MrrLineMbo.isNull('ROTASSETNUM'):
									InvUseLine.setValue('ROTASSETNUM',getNewAsset(MrrLineMbo),64L)
								else:
									InvUseLine.setValue('ROTASSETNUM',MrrLineMbo.getString('ROTASSETNUM'),64L)
							if MrrLineMbo.getString('ITEM.LOTTYPE') == 'LOT' and not MrrLineMbo.isNull('LOTNUM'):
								AddCheckLot(MrrLineMbo)
								InvUseLine.setValue('FROMLOT',MrrLineMbo.getString('LOTNUM'))
								#InvUseLine.setValue('USEBY',MrrLineMbo.getDate('EXPIRYDATE'))
								
							if not MrrLineMbo.isNull('BINNUM'):
								InvUseLine.setValue('FROMBIN',MrrLineMbo.getString('BINNUM'))
							if not MrrLineMbo.isNull('WONUM'):
								InvUseLine.setValue('WONUM',MrrLineMbo.getString('WONUM'))
							if not MrrLineMbo.isNull('LOCATION'):
								InvUseLine.setValue('LOCATION',MrrLineMbo.getString('LOCATION'))
							if not MrrLineMbo.isNull('ASSETNUM'):
								InvUseLine.setValue('ASSETNUM',MrrLineMbo.getString('ASSETNUM'))
							
							InvUseLine.setValue('GLCREDITACCT',MrrLineMbo.getString('GLCREDITACCT'))
							gldebit=MrrLineMbo.getString('GLDEBITACCT')
							'''
							if gldebit is not None and gldebit!="":
								InvUseLine.setValue('GLDEBITACCT',MrrLineMbo.getString('GLDEBITACCT'))
							else :
								InvUseLine.setValue('GLDEBITACCT',mbo.getString('STORELOC.CONTROLACC'))
							'''
							InvUseLine.setValue('GLDEBITACCT',mbo.getString('STORELOC.CONTROLACC'))
						MrrLineMbo = MrrLineSet.moveNext()
						
					if Created:
						myLogger.debug("Amir->Before Change Status")
						
						InvUseMbo.changeStatus('COMPLETE',mxServer.getDate(),'Auto Completed by MRR')
						myLogger.debug("Amir->Before Save")
						InvUseSet.save()
						myLogger.debug("Amir->Before Save2")
						mbo.getThisMboSet().save()
						wcs.showMessageBox("scriptval", "scriptinfo", ["IU "+IV+" has been created." ])
					else:
						wcs.showMessageBox("scriptval", "scriptinfo", ["No IV Created, nothing to return" ])
				except MXException,e:
					MrrLineSet.rollback()
					MrrLineSet.reset()
					setError("Something Went Wrong, Please report this error to sysem Administrator. \r\n " + e.getMessage())