from psdi.server import MXServer
from  psdi.common.context import UIContext
from psdi.webclient.system.controller import SessionContext, Utility, WebClientEvent

whereClause ='''
 PROCESSNAME ='DISPOSAL-A' and  actionid=111 and ownerid in
(select DM_DISPOSALID from maximo.DM_DISPOSAL where DISPOSALNUM in 
(select DISPOSALNUM from maximo.DM_DISPOSAL where status in 
('AMD-APPR','WINV','CLOSED','WACOLLECT') and disposalnum 
not in( select DISPOSALNUM from MAXIMO.DM_DISPOSALSTATUS where status in ('AMD-APPR'))  ))
'''

wftransset = mbo.getMboSet("XXMJJHGDDO","WFTRANSACTION",where)

wftransset.reset()

service.error("count",str (wftransset.count()))

'''
StatusHistorySet = DisposalMbo.getMboSet(HeaderStatusSet)
StatusHistoryMbo = StatusHistorySet.addAtEnd()

StatusHistoryMbo.setValue('ORGID',DisposalMbo.getString('ORGID'))	
StatusHistoryMbo.setValue('SITEID',DisposalMbo.getString('SITEID'))
StatusHistoryMbo.setValue('DISPOSALNUM',DisposalMbo.getString('DISPOSALNUM'))	
StatusHistoryMbo.setValue('STATUSDATE',DisposalMbo.getDate('STATUSDATE'))
'''