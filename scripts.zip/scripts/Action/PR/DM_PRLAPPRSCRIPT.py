from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

myLogger = MXLoggerFactory.getLogger("maximo.custom")

myLogger.info('Script execution started')

prnum = mbo.getString('prnum')
approver_personid = mbo.getUserInfo().getPersonId()

# Fetch the prlineSet with unapproved lines
#prlineSet = mbo.getMboSet("prline")
#prlineSet.setWhere("prnum = '{}' AND dm_appr = 0".format(prnum))

#prlineSet.reset()
prlineSet = mbo.getMboSet("prline")
prlineSet.setOrderBy("prlinenum ASC")
#prlineSet.setWhere("prnum = '{}'".format(prnum))
#prlineSet.reset()
approved_lines_count = 0
prMbo=prlineSet.moveFirst()

if prMbo:
    myLogger.info('Processing pr: {}'.format(prnum))
    myLogger.info('Processing {} lines for pr: {}'.format(prlineSet.count(), prnum))
        
    for i in range(prlineSet.count()):
        prline = prlineSet.getMbo(i)
        #prline = prlineSet.getMbo(0)
        itemnum = prline.getString("ITEMNUM")
        prlinenum = prline.getInt("prlineNUM")
        dm_ccappr = prline.getBoolean("dm_ccappr")
        dm_appr = prline.getBoolean("dm_appr")
        
        myLogger.info('Processing line {} with item number: {}'.format(prlinenum, itemnum))
        myLogger.info("Line Approval Status - dm_ccappr: {}, dm_appr: {}".format(dm_ccappr, dm_appr))

        # Fetch the item and commodity information
        ItemSet = MXServer.getMXServer().getMboSet("ITEM", mbo.getUserInfo())
        ItemSet.setWhere("itemnum = '{}'".format(itemnum))
        ItemSet.reset()

        if not ItemSet.isEmpty():
            item = ItemSet.getMbo(0)
            commodity = item.getString("COMMODITY")
            if  commodity and not dm_ccappr:
					itemnum2=item.getString("itemnum")
					commodity_parts = commodity.split('-')
					if len(commodity_parts) > 1:
						commodity_prefix = commodity_parts[0]
						commodity_number = int(commodity_parts[1])

						# Fetch DM_MRA data for approval validation
						DM_MRA_Set = MXServer.getMXServer().getMboSet("DM_MRA", mbo.getUserInfo())
						DM_MRA_Set.reset()

						if DM_MRA_Set.count() > 0:
							for j in range(DM_MRA_Set.count()):
								DM_MRA = DM_MRA_Set.getMbo(j)
								from_category = DM_MRA.getString("fromcategory")
								to_category = DM_MRA.getString("tocategory")
								approver_assigned = DM_MRA.getString("approveby")

								from_category_parts = from_category.split('-')
								to_category_parts = to_category.split('-')

								if len(from_category_parts) > 1 and len(to_category_parts) > 1:
									from_category_prefix = from_category_parts[0]
									from_category_number = int(from_category_parts[1])
									to_category_prefix = to_category_parts[0]
									to_category_number = int(to_category_parts[1])

									if commodity_prefix == from_category_prefix == to_category_prefix:
										myLogger.info('Prefix match: {} == {} == {}'.format(
											commodity_prefix, from_category_prefix, to_category_prefix))

										if from_category_number <= commodity_number <= to_category_number:
												myLogger.info('Commodity {} is within range {}-{}'.format(
													commodity, from_category_number, to_category_number))

												if approver_assigned:
														personSet = mbo.getMboSet("$EMXPERSONGROUP", "PERSONGROUPTEAM", "persongroup = '{}' AND respparty = '{}'".format(approver_assigned, approver_personid))
														personMbo = personSet.getMbo(0)
								
													   
														
														if personMbo:
															
																	   # service.error("dm", "genericerror", [str(prlineSet.count())+"dfds-"+itemnum2+"-m-"+str(prlinenum)])
																		prline.setValue("dm_appr", True, MboConstants.NOACCESSCHECK)
																		prline.setValue("dm_ccappr", True, MboConstants.NOACCESSCHECK)
																		myLogger.info('pr Line {} approved by approver {}.'.format(prlinenum, approver_personid))
																		approved_lines_count += 1
																		
																	   # service.error("dm", "genericerror", [str(prlineSet.count())+"dfds-"+itemnum2+"-m-"+str(prlinenum)+"-s-"+str(dm_ccappr)])
																		break;
																		
															
																		myLogger.info('Approver {} is not assigned to pr Line {} via DM_MRA.'.format(approver_personid, prlinenum))
												
												else:
													myLogger.info('No approver found for item {}.'.format(itemnum))
												#service.error("dm", "genericerror", [str(prlineSet.count())+"dfds-"+itemnum+"-m-"+str(prlinenum)+"-so-"+str(dm_ccappr)+"-itha-"+str(dm_appr)])                                                                 
myLogger.info('approved lines count: {}'.format(approved_lines_count))
myLogger.info('Total approved pr lines: {}'.format(prlineSet.count()))
myLogger.info('before reset pr lines: {}'.format(prlineSet.count()))
myLogger.info('after reset pr lines: {}'.format(prlineSet.count()))