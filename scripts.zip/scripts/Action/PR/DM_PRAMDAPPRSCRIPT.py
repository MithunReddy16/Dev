from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

myLogger = MXLoggerFactory.getLogger("maximo.custom")

prnum = mbo.getString('prnum')
tc=mbo.getDouble("totalcost")
approver_personid = mbo.getUserInfo().getPersonId()
approved_lines_count=0;
prlineSet = mbo.getMboSet("prline")

prMbo=prlineSet.moveFirst()

if prMbo:
    myLogger.info('Processing pr: {}'.format(prnum))
    
    for i in range(prlineSet.count()):
        prline = prlineSet.getMbo(i)
        itemnum = prline.getString("ITEMNUM")
        prlinenum = prline.getInt("prlineNUM")
        dm_ccappr = prline.getBoolean("dm_ccappr")
        dm_appr = prline.getBoolean("dm_appr")
       
        #service.error("dm", "genericerror", [str(prlineSet.count())+"dfds-"+itemnum+"-m-"+str(prlinenum)+"-s-"+str(dm_ccappr)+"-ms-"+str(dm_appr)+"-ka-"])
        ItemSet = MXServer.getMXServer().getMboSet("ITEM", mbo.getUserInfo())
        ItemSet.setWhere("itemnum = '{}'".format(itemnum))
        ItemSet.reset()

        if ItemSet.count() > 0:
            Item = ItemSet.getMbo(0)
            #commoditygroup = Item.getString("COMMODITYGROUP")
            commodity = Item.getString("COMMODITY")
            

            #personid = 'PRAMD1'
            personSet = mbo.getMboSet("$EMXPERSON", "PERSON", "personid = '{}'".format(approver_personid))

            if personSet.count() > 0:
                #myLogger.info('Approver {} is a member of personid {}.'.format(approver_personid, personid))
               
                if not commodity   and tc > 50000:
                     prline.setValue("dm_appr", True, 2L)
                     prline.setValue("dm_amdappr", True, 2L)
                     approved_lines_count += 1
                     myLogger.info('Line {} in pr {} updated with dm_appr=1 and dm_amdappr=True.'.format(prlinenum, prnum))
                elif ((commodity and dm_ccappr==1) or (not commodity)) and tc > 50000:  
                         prline.setValue("dm_appr", True, 2L)
                         
                else:
                   # prline.setValue("dm_amdappr", True, 2L)
                    myLogger.info('Line {} in pr {} updated with dm_amdappr=True.'.format(prlinenum, prnum))
                
 
    
myLogger.info('Total approved pr lines: {}'.format(prlineSet.count()))
myLogger.info('before reset pr lines: {}'.format(prlineSet.count()))
myLogger.info('after reset pr lines: {}'.format(prlineSet.count()))