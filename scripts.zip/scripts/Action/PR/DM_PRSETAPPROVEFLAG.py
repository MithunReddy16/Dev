#DM_PRSETAPPROVEFLAG
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

myLogger = MXLoggerFactory.getLogger("maximo.custom")

#tc=mbo.getDouble("totalcost")
#approver_personid = mbo.getUserInfo().getPersonId()
#approved_lines_count=0;
prlineSet = mbo.getMboSet("PRLINE")

prLineMbo=prlineSet.moveFirst()

while prLineMbo:
    myLogger.info('Processing pr: {}'.format(mbo.getString('prnum')))
    
    if not prLineMbo.getBoolean('DM_APPR'):        
        commodity=None
        if not prLineMbo.isNull('ITEMNUM'):
            itemMbo = prLineMbo.getMboSet('ITEM').moveFirst()
            if itemMbo:
                commodity = itemMbo.getString("COMMODITY")
        elif not prLineMbo.isNull('COMMODITY'):
            commodity = prLineMbo.getString("COMMODITY")
        
        needMRA = False
        if commodity:
            MRASet = MXServer.getMXServer().getMboSet("DM_MRA", MXServer.getMXServer().getSystemUserInfo())
            commParts = commodity.split("-")
            commParts1 = commParts[0]
            commParts2 = int(commParts[1])
            WhereClause = "SUBSTR(FROMCATEGORY, 1, INSTR(FROMCATEGORY, '-') - 1)='" +commParts1+"' and " + str(commParts2) + "  between TO_NUMBER (SUBSTR(FROMCATEGORY, INSTR(FROMCATEGORY, '-') + 1) ) and TO_NUMBER (SUBSTR(tocategory, INSTR(tocategory, '-') + 1) ) "
            myLogger.info('Require MRA Where Clasue: {}'.format(WhereClause))
            MRASet.setWhere(WhereClause)
            MRASet.reset()
            
            MRAMbo = MRASet.moveFirst()
            if MRAMbo :
                needMRA=True
            
            MRASet.cleanup()
            MRASet.close()
            
               
        if not needMRA :
             prLineMbo.setValue("DM_APPR", True, 2L)


    
    prLineMbo=prlineSet.moveNext()
                
 
    
myLogger.info('Total approved pr lines: {}'.format(prlineSet.count()))
myLogger.info('before reset pr lines: {}'.format(prlineSet.count()))
myLogger.info('after reset pr lines: {}'.format(prlineSet.count()))