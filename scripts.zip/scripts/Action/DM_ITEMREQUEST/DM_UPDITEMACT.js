load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)


logger = MXLoggerFactory.getLogger("maximo.dm")

//logger.error("Entering SR_INIT script for ticket " + mbo.getString("TICKETID"))
logger.error("***ASH***Sript DM_UPDITEMACT**START***")