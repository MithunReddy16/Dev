from psdi.mbo import MboConstants
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.custom")

logger.error("***ASH*** Script DM_IRCREATEITEM **START***")
#"COMMODITYGROUP", "COMMODITY"
fieldsString = ["ITEMNUM", "ITEMSETID", "CLASSSTRUCTUREID", "GROUPNAME", "METERNAME", "LOTTYPE",
				"MAXISSUE", "ORDERUNIT", "ISSUEUNIT", "MSDSNUM", "DM_PLANNING", "DM_SOURCING", "DM_MAINUSER", "DM_AVAILABILITY", 
				"DM_CONDITION", "DM_GRP_USERITEMTYPE"]

fieldsInt = ["CONDITIONENABLED", "ISKIT", "CAPITALIZED", "INSPECTIONREQUIRED", "SPAREPARTAUTOADD",
			 "ATTACHONISSUE", "TAXEXEMPT", "ROTATING","DM_ISOEM"]

itemMbo = None

requestType = mbo.getString("REQUESTTYPE")

if requestType == "NEW":
	itemSet = mbo.getMboSet("ITEM")
	
	if itemSet.count() > 0:
		# Item exists, use the first one
		itemMbo = itemSet.getMbo(0)
		logger.error("***ASH*** Script DM_IRCREATEITEM **Existing item found: " + itemMbo.getString("ITEMNUM"))
	'''
	else:
		# Item does not exist, create new one
		itemMbo = itemSet.add()
		# Set mandatory keys for new item - at least ITEMNUM is mandatory
		itemMbo.setValue("ITEMNUM", mbo.getString("ITEMNUM"), MboConstants.NOACCESSCHECK | MboConstants.NOACTION)
		logger.error("***ASH*** Script DM_IRCREATEITEM **New item created: " + mbo.getString("ITEMNUM"))
	'''
else:
	itemSet = mbo.getMboSet("DM_UPDITEMDESC")
	itemMbo = itemSet.getMbo(0)
	logger.error("***ASH*** Script DM_IRCREATEITEM **Update item: " + itemMbo.getString("ITEMNUM") if itemMbo else "*** No item found in DM_UPDITEMDESC")

if itemMbo is not None:
	# Copy string fields
	for i in range(len(fieldsString)):
		field = fieldsString[i]
		try:
			if i == 2:  # CLASSSTRUCTUREID set with NOACCESSCHECK | NOACTION
				itemMbo.setValue(field, mbo.getString(field), MboConstants.NOACCESSCHECK | MboConstants.NOACTION)
			else:
				itemMbo.setValue(field, mbo.getString(field), 2)
		except:
			logger.error("***ASH*** Failed to set string field: " + field)
	
	# Copy double field RECEIPTTOLERANCE,DESCRIPTIONS
	try:
		itemMbo.setValue("RECEIPTTOLERANCE", mbo.getDouble("RECEIPTTOLERANCE"), 2)
		itemMbo.setValue("DESCRIPTION", mbo.getString("DM_SHORTDESCRIPTION_LONGDESCRIPTION"), 2)
		itemMbo.setValue("DESCRIPTION_LONGDESCRIPTION", mbo.getString("DM_LONGDESC_LONGDESCRIPTION"), 2)
	except:
		logger.error("***ASH*** Failed to set fields")
	
	# Copy int fields
	for i in range(len(fieldsInt)):
		field = fieldsInt[i]
		try:
			itemMbo.setValue(field, mbo.getInt(field), 11)
		except:
			logger.error("***ASH*** Failed to set int field: " + field)
	
	# Copy classification attributes from DM_ITEMSPEC to ITEMSPEC
	irClassAttribuitesSet = mbo.getMboSet("DM_ITEMSPEC")
	itemClassAttrSet = itemMbo.getMboSet("ITEMSPECCLASS")
	
	itemnum = itemMbo.getString("ITEMNUM")
	if itemClassAttrSet.count() > 0:
		whereClause = "ITEMNUM='" + itemnum + "'"
		logger.debug("***ASH*** WHERE clause for delete = " + whereClause)
		
		# Delete existing ITEMSPEC records
		def execDelete(objectName, where):
			sql = "delete from " + objectName + " where " + where
			logger.debug("***ASH*** Executing SQL: " + sql)
			mxserver = MXServer.getMXServer()
			conKey = mxserver.getSystemUserInfo().getConnectionKey()
			con = mxserver.getDBManager().getConnection(conKey)
			s = con.createStatement()
			count = s.executeUpdate(sql)
			logger.debug("***ASH*** Rows deleted = " + str(count))
			s.close()
			con.commit()
			mxserver.getDBManager().freeConnection(conKey)
		
		execDelete("ITEMSPEC", whereClause)
		logger.error("***ASH*** Script DM_IRCREATEITEM ** ITEMSPEC records deleted")

	# Now copy classification attributes
	for i in range(irClassAttribuitesSet.count()):
		irClassAttribuitesMbo = irClassAttribuitesSet.getMbo(i)
		if irClassAttribuitesMbo is None:
			break
		
		itemClassAttrMbo = itemClassAttrSet.add(2)
		itemClassAttrMbo.setValue("ITEMNUM", itemnum, 2)
		itemClassAttrMbo.setValue("ASSETATTRID", irClassAttribuitesMbo.getString("ASSETATTRID"), 2)
		itemClassAttrMbo.setValue("CLASSSTRUCTUREID", irClassAttribuitesMbo.getString("CLASSSTRUCTUREID"), 2)
		itemClassAttrMbo.setValue("DISPLAYSEQUENCE", irClassAttribuitesMbo.getInt("DISPLAYSEQUENCE"), 2)
		itemClassAttrMbo.setValue("MANDATORY", irClassAttribuitesMbo.getInt("MANDATORY"), 2)
		itemClassAttrMbo.setValue("DM_SECMANDATORY", irClassAttribuitesMbo.getInt("DM_SECMANDATORY"), 2)
		
		if irClassAttribuitesMbo.getDate("DATEVALUE") is not None:
			itemClassAttrMbo.setValue("DATEVALUE", irClassAttribuitesMbo.getDate("DATEVALUE"), 2)
		elif irClassAttribuitesMbo.getString("ALNVALUE"):
			itemClassAttrMbo.setValue("ALNVALUE", irClassAttribuitesMbo.getString("ALNVALUE"), 2)
		elif irClassAttribuitesMbo.getString("NUMVALUE"):
			itemClassAttrMbo.setValue("NUMVALUE", irClassAttribuitesMbo.getDouble("NUMVALUE"), 2)
		elif irClassAttribuitesMbo.getString("TABLEVALUE"):
			itemClassAttrMbo.setValue("TABLEVALUE", irClassAttribuitesMbo.getString("TABLEVALUE"), 2)
		
	   
		# if irClassAttribuitesMbo.getString("MEASUREUNITID"):
		#	 itemClassAttrMbo.setValue("MEASUREUNITID", irClassAttribuitesMbo.getString("MEASUREUNITID"), 2)
		
		if irClassAttribuitesMbo.getString("SECTION") is not None:
			itemClassAttrMbo.setValue("SECTION", irClassAttribuitesMbo.getString("SECTION"), 2)

	logger.error("***ASH*** Script DM_IRCREATEITEM **before setting status CLOSED")
	mbo.setValue("STATUS", "CLOSED", 2)
	
	# Save changes to current MBO set (the incoming mbo)
	mbo.getThisMboSet().save(2)
	logger.error("***ASH*** Script DM_IRCREATEITEM **after setting status CLOSED")

else:
	logger.error("***ASH*** Script DM_IRCREATEITEM **No ITEM MBO found, skipping update")