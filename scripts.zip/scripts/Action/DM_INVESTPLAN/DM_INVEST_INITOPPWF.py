#------------------------------------------------------------------------

#Script Name :DM_INVEST_INITOPPWF
#Description :script to nitate Investment Opportunity WF
#Comment     :Used in Investment Plan Workflow
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
# Samer Al Fakih      SWORD_salfakih@dm.ae     1.0          29-APRIL-2026         Initiate version.

#------------------------------------------------------------------------

from psdi.server import MXServer

mxs = MXServer.getMXServer()
wfstart = mxs.lookup('WORKFLOW')


investOppSet = mbo.getMboSet(
    "$value",
    "DM_INVESTOPPORTUNITY",
    "INVESTNUM=:INVESTNUM and SITEID=:SITEID and DEPARTMENT=:DEPARTMENT and status='DRAFT' and ADHOC=0"
)

investOppMbo = investOppSet.moveFirst()

while investOppMbo:
    investOppMbo.setValue('STATUS','WAMDREVIEW')
    wfstart.initiateWorkflow('DM_INVESTO', investOppMbo)
    investOppMbo = investOppSet.moveNext()