#DISPOSAL_GEN_DECOMM_REQUEST
from psdi.server import MXServer 

LineSet = mbo.getMboSet('DM_DISPOSALLINE')

NewDisposalSet = mbo.getMboSet('DM_DISPOSAL_' + str(mbo.getUniqueIDValue()),'DM_DISPOSAL','1=2')

for x in range (LineSet.count()):
    LineMbo = LineSet.getMbo(x)
    if LineMbo.getString('DECISION') != 'Decommission':
        AssetMbo = LineMbo.getMboSet('ASSET').getMbo(0)
        if AssetMbo is not None:
            print 'x'
            ## TODO
            ## #wsrmt = MXServer.getMXServer().lookup("WORKFLOW")
            #wsrmt.initiateWorkflow('ASSET-PLANING', AssetMbo)

LineSet.setWhere("DECISION='Decommission'")
LineSet.reset()
if not LineSet.isEmpty():
    NewDisposalSet = mbo.getMboSet('DM_DISPOSAL_' + str(mbo.getUniqueIDValue()),'DM_DISPOSAL','1=2')
    NewDisposalMbo= NewDisposalSet.add()
    NewDisposalMbo.setValue('ORGID',mbo.getString('ORGID'))
    NewDisposalMbo.setValue('SITEID',mbo.getString('SITEID'))
    NewDisposalMbo.setValue('DISPOSALTYPE','Decommission')
    NewDisposalMbo.setValue('DESCRIPTION',mbo.getString('DESCRIPTION'))
    NewDisposalLineSet = NewDisposalMbo.getMboSet('DM_DISPOSALLINE')
    for i in range (LineSet.count()):
        LineMbo = LineSet.getMbo(i)
        NewDisposalLineMbo = NewDisposalLineSet.addAtEnd()
        NewDisposalLineMbo.setValue('ORGID',NewDisposalMbo.getString('ORGID'))
        NewDisposalLineMbo.setValue('SITEID',NewDisposalMbo.getString('SITEID'))
        NewDisposalLineMbo.setValue('DISPOSALNUM',NewDisposalMbo.getString('DISPOSALNUM'))
        NewDisposalLineMbo.setValue('ASSETNUM',LineMbo.getString('ASSETNUM'))
        LineMbo.setValue('REFDISPOSALNUM',NewDisposalLineMbo.getString('DISPOSALNUM'),11L)
        LineMbo.setValue('REFDISPOSALLINENUM',NewDisposalLineMbo.getInt('DISPOSALLINENUM'),11L)
        LineMbo.setValue('REFDISPOSALLINEID',NewDisposalLineMbo.getUniqueIDValue(),11L)
        
    DisWF = MXServer.getMXServer().lookup("WORKFLOW")
    DisWF.initiateWorkflow('DISP-MAIN', NewDisposalMbo)