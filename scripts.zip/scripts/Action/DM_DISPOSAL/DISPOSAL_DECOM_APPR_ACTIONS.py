#DISPOSAL_DECOM_APPR_ACTIONS
from psdi.server import MXServer 
from psdi.util.logging import MXLoggerFactory
from psdi.util import MXException

myLogger = MXLoggerFactory.getLogger("maximo.custom")

mxServer=MXServer.getMXServer()
#userInfo=mxServer.getSystemUserInfo()

userInfo=mbo.getUserInfo()

LineSet = mbo.getMboSet('DM_DISPOSALLINE')

#NewDisposalSet = mbo.getMboSet('DM_DISPOSAL_' + str(mbo.getUniqueIDValue()),'DM_DISPOSAL','1=2')
NewDisposalSet = mxServer.getMboSet('DM_DISPOSAL',userInfo)


LineOptions =["Auction","Direct Appointment","Donate"]


X=0
NewDisCreated = False
while(X<3):
    #LineSet.setWhere(LineOptions[X])
    #LineSet.reset()
    y=0
    NewDisCreated = False
    myLogger.debug('AMIR>6>line count' + str(LineSet.count()))
    for y in range (LineSet.count()):
        LineMbo = LineSet.getMbo(y)
        myLogger.debug('AMIR>6>line count loop' + str(y+1))
        if LineMbo.getString('DISPOSALMETHOD') != LineOptions[X]:
            continue     
        
            
            
        if not NewDisCreated:

            NewDisposalMbo= NewDisposalSet.add()
            NewDisposalMbo.setValue('ORGID',mbo.getString('ORGID'))
            NewDisposalMbo.setValue('SITEID',mbo.getString('SITEID'))
            NewDisposalMbo.setValue('DISPOSALTYPE',LineMbo.getString('DISPOSALMETHOD'))
            NewDisposalMbo.setValue('DESCRIPTION',mbo.getString('DESCRIPTION'))
            
            NewDisposalMbo.setValue('DM_SECTION',mbo.getString('DM_SECTION'))
            NewDisposalMbo.setValue('DM_DEPARTMENT',mbo.getString('DM_DEPARTMENT'))
            NewDisposalMbo.setValue('DM_SECTOR',mbo.getString('DM_SECTOR'))
            
            NewDisposalMbo.setValue('INTERNALTYPE','Disposal')
            NewDisposalLineSet = NewDisposalMbo.getMboSet('DM_DISPOSALLINE')

            
            myLogger.debug('AMIR>6>disposal created ' + str(NewDisposalMbo.getString('DISPOSALNUM')) +" type=" +LineMbo.getString('DISPOSALMETHOD')  )            
            NewDisCreated = True
        

            
        NewDisposalLineMbo = NewDisposalLineSet.addAtEnd()
        NewDisposalLineMbo.setValue('ORGID',NewDisposalMbo.getString('ORGID'))
        NewDisposalLineMbo.setValue('SITEID',NewDisposalMbo.getString('SITEID'))
        NewDisposalLineMbo.setValue('BULK',False)
        NewDisposalLineMbo.setValue('DISPOSALNUM',NewDisposalMbo.getString('DISPOSALNUM'))
        NewDisposalLineMbo.setValue('ASSETNUM',LineMbo.getString('ASSETNUM'),11L)
        LineMbo.setValue('REFDISPOSALNUM',NewDisposalLineMbo.getString('DISPOSALNUM'),11L)
        LineMbo.setValue('REFDISPOSALLINENUM',NewDisposalLineMbo.getInt('DISPOSALLINENUM'),11L)
        LineMbo.setValue('REFDISPOSALLINEID',NewDisposalLineMbo.getUniqueIDValue(),11L)
   
    if  NewDisCreated:
        DisWF = MXServer.getMXServer().lookup("WORKFLOW")
        DisWF.initiateWorkflow('DISP-MAIN', NewDisposalMbo)
    
   

    X=X+1