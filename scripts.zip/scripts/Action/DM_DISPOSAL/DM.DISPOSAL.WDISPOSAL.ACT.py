#DM.DISPOSAL.WDISPOSAL.ACT
from psdi.server import MXServer 
from psdi.util.logging import MXLoggerFactory
from psdi.util import MXException
from psdi.util  import MXApplicationException


myLogger = MXLoggerFactory.getLogger("maximo.custom")

mxServer=MXServer.getMXServer()
#userInfo=mxServer.getSystemUserInfo()

userInfo=mbo.getUserInfo()

if launchPoint == "DIS_WDISPOSAL":
    LineSet = mbo.getMboSet('DM_DISPOSALLINE')
    
    for z in range (LineSet.count()):
        LineMbo = LineSet.getMbo(z)
        AssetMbo = LineMbo.getMboSet('ASSET').getMbo(0)
        if AssetMbo is not None:
            try:
                AssetMbo.changeStatus('WDISPOSAL',MXServer.getMXServer().getDate(),'By Decomission Application',2L)
            except MXException ,e:
                myLogger.debug('AMIR>>ERROR' + AssetMbo.getString('ASSETNUM') +">>"+ e.getMessage())
elif launchPoint == "DIS_WDISPOSALMOVE":

    
    AssetSet = mbo.getMboSet('ASSET')
    
    AssetMbo = AssetSet.moveFirst()
    while AssetMbo:
        
        AssetMbo.setValue('NEWSITE','DM')
        AssetMbo.setValue('NEWLOCATION','SCRAPYARD')
        
        
        AssetMbo = AssetSet.moveNext()
    
    AssetSet.moveAsset()
    AssetSet.clearWarnings()