#DM_DISPOSAL_AUCTION_HISTORY

if launchPoint=='DA.HIS.ACT':
    LineSet = mbo.getMboSet('DM_DISPOSALLINE')
    for i in range (LineSet.count()):
        Line = LineSet.getMbo(i)
        Line.setValueNull('AUCPRICE',11L)
        Line.setValueNull('AWARDCOMPANY',11L)
    
    
else:

    LineSet = mbo.getMboSet('DM_DISPOSALLINE')
    for i in range (LineSet.count()):
        Line = LineSet.getMbo(i)
        if not Line.isNull('AUCPRICE') or not Line.isNull('AWARDCOMPANY'):
            AuctionHistorySet=Line.getMboSet('DM_DISAUCHIST')
            LineCount = AuctionHistorySet.count()
            AuctionHistoryMbo = AuctionHistorySet.addAtEnd()
            
            AuctionHistoryMbo.setValue('ORGID',Line.getString('ORGID'))
            AuctionHistoryMbo.setValue('SITEID',Line.getString('SITEID'))
            
            AuctionHistoryMbo.setValue('DISPOSALNUM',Line.getString('DISPOSALNUM'))
            AuctionHistoryMbo.setValue('DISPOSALLINENUM',Line.getString('DISPOSALLINENUM'))
            
            AuctionHistoryMbo.setValue('LINENUM',LineCount+1)
            AuctionHistoryMbo.setValue('AUCPRICE',Line.getString('AUCPRICE'))
            AuctionHistoryMbo.setValue('AWARDCOMPANY',Line.getString('AWARDCOMPANY'))
            
            AuctionHistoryMbo.setValue('AWARDCOADDRESS',Line.getString('AWARDCOADDRESS'))
            AuctionHistoryMbo.setValue('AWARDCOCONTACT',Line.getString('AWARDCOCONTACT'))
            AuctionHistoryMbo.setValue('AWARDCOEMAIL',Line.getString('AWARDCOEMAIL'))
            AuctionHistoryMbo.setValue('AWARDCOPHONE',Line.getString('AWARDCOPHONE'))
            AuctionHistoryMbo.setValue('AWARDPRODATE',Line.getString('AWARDPRODATE'))
            
        Line.setValueNull('AUCPRICE',11L)
        Line.setValueNull('AWARDCOMPANY',11L)
        
        Line.setValueNull('AWARDCOADDRESS',11L)
        Line.setValueNull('AWARDCOCONTACT',11L)
        Line.setValueNull('AWARDCOEMAIL',11L)
        Line.setValueNull('AWARDCOPHONE',11L)
        Line.setValueNull('AWARDPRODATE',11L)