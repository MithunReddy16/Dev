#auto script to perform lines massive update
# update line approved methods and approve disposline

if not mbo.isNull("DISPOSALMETHOD"):
    method = mbo.getString("DISPOSALMETHOD")
    lines = mbo.getMboSet("DM_DISPOSALLINE")
    line = lines.moveFirst()
    while line:
        line.setValue("DISPOSALMETHOD",method,11l)
        line.setValue("APPROVED",True,11l)
        line = lines.moveNext()
    
    mbo.setValueNull("DISPOSALMETHOD",11l)    
    session = service.webclientsession()
    session.getDataBean("mainrecord").SAVE()
    

service.closeDialog()