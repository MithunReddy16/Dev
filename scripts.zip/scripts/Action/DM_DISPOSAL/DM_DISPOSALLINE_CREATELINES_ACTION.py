#------------------------------------------------------------------------

#Script Name :DM_DISPOSALLINE_CREATELINES_ACTION
#Description :Create Decommission Request Lines from the selected Assets Script
#Comment     :Used in Decommission Request application
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-09-2025         Initiate version.

#------------------------------------------------------------------------


service.log_debug("######################################## Start:" + scriptName+" ######################")
session=service.webclientsession()
mainBean = session.getDataBean("mainrecord") 
requestMbo = mainBean.getMbo()

assetDatabean = session.getDataBean("dm_selectassetable")
if assetDatabean is None:
    assetDatabean = session.getDataBean("dm_selectassetable_A")


    
requestLineMboSet=requestMbo.getMboSet("DM_DISPOSALLINE")
if assetDatabean is not None:
    assetSet=assetDatabean.getMboSet()
   
    selectedRecords=assetSet.getSelection()
    iterator=selectedRecords.iterator()
    #create new line for each select asset
    while (iterator.hasNext()):  
        assetMbo=iterator.next()
        requestLineMbo= requestLineMboSet.add()
        requestLineMbo.setValue("assetnum",assetMbo.getString("assetnum"))
        
    requestLineMboSet.save()
        
    
    service.closeDialog()
    mainBean.SAVE()
    wcs = service.webclientsession()
service.log_debug("######################################## End:" + scriptName+" ######################")