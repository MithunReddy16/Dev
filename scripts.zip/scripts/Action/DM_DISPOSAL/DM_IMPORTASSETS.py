#DM_IMPORTASSETS


def setError(Msg):
		#global errorkey,errorgroup,params
		#errorkey='scriptvalidationerror'
		#errorgroup='scriptval'
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)

LineSet = mbo.getMboSet('IMPORTASSETS')
LineSelection = LineSet.getSelection()
if not LineSelection.size() > 0:
	setError('Please select at least one line.')


elif (not mbo.getString('STATUS') in ('RETURNED','DRAFT','WAMDCO')):
    setError('Lines can not be added.')

else:
    DisposalLineSet = mbo.getMboSet('DM_DISPOSALLINE')
    
    LineSet.resetWithSelection()
    
    for i in range (LineSet.count()):
        SelectedLineMbo = LineSet.getMbo(i)
        
        DisposalLineMbo = DisposalLineSet.addAtEnd(11L)
        DisposalLineMbo.setValue('BULK',False)
        DisposalLineMbo.setValue('DISPOSALNUM',mbo.getString('DISPOSALNUM'))
        DisposalLineMbo.setValue('SITEID',mbo.getString('SITEID'))
        DisposalLineMbo.setValue('ORGID',mbo.getString('ORGID'))
        
        DisposalLineMbo.setValue('ASSETNUM',SelectedLineMbo.getString('ASSETNUM'))
    
        SelectedLineMbo.setValue('REFDISPOSALNUM',DisposalLineMbo.getString('DISPOSALNUM'),11L)
        SelectedLineMbo.setValue('REFDISPOSALLINENUM',DisposalLineMbo.getInt('DISPOSALLINENUM'),11L)
        SelectedLineMbo.setValue('REFDISPOSALLINEID',DisposalLineMbo.getUniqueIDValue(),11L)
    
    LineSet.save()
    service.closeDialog()