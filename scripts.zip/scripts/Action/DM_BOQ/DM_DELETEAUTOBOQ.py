#Script Name :DM_DELETEAUTOBOQ
#Description :Clear Auto-Calculated BOQ
#Comment     :Used in GM WO Application 
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
# Samer Al Fakih      SWORD_salfakih@dm.ae     1.0          15-MAY-2026         Initiate version.

#------------------------------------------------------------------------

from psdi.mbo import MboConstants
session = service.webclientsession()
main_bean = session.getDataBean("mainrecord")

def yes ():
    woMbo = mbo.getOwner()
    wpServiceSet = woMbo.getMboSet("WPSERVICE")
    if wpServiceSet.count() > 0:
        wpServiceSet.deleteAll()
        main_bean.SAVE()
def no ():
    service.log("BOQ has not been deleted")
def dflt ():
    service.yncerror('dm_custom', 'userinput',["Are you sure you want to clear the auto-calculated CM BOQ?"])

cases = {service.YNC_NULL:dflt, service.YNC_YES:yes, service.YNC_NO:no}

if interactive:
    x = service.yncuserinput()
    cases[x]()