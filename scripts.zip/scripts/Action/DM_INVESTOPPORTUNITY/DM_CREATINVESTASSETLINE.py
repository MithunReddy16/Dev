#------------------------------------------------------------------------

#Script Name :DM_CREATEDATACHANGELINES
#Description :Create Change Data Request Lines from Assets Script.
#Comment     :Used in Asset Data Change Request Application.  
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-Aug-2025         Initiate version.

#------------------------------------------------------------------------


service.log_debug("######################################## Start:" + scriptName+" ######################")
session=service.webclientsession()
assetDatabean = session.getDataBean("dm_selectassetable")   #dm_selectassetdialog
mainBean = session.getDataBean("mainrecord") 
oppMbo = mainBean.getMbo()
assetLineMboSet=oppMbo.getMboSet("DM_SELECTINVESTASSETS_$$","DM_INVESTASSET","1=2")
if assetDatabean is not None:
    assetSet=assetDatabean.getMboSet()
    selectedRecords=assetSet.getSelection()
    iterator=selectedRecords.iterator()
   
    while (iterator.hasNext()):
        assetMbo=iterator.next()
        assetLineMbo= assetLineMboSet.add()
        assetLineMbo.setValue("assetnum",assetMbo.getString("assetnum"))
        assetLineMbo.setValue("SITEID",oppMbo.getString("siteid"))
        assetLineMbo.setValue("OPPORTUNITYNUM",oppMbo.getString("OPPORTUNITYNUM"))

       
    assetLineMboSet.save()
        
    
    service.closeDialog()
    mainBean.SAVE()
    wcs = service.webclientsession()
    #wcs.showMessageBox("dmdatachange", "applyaction",[])
    
    service.log_debug("######################################## End:" + scriptName+" ######################")