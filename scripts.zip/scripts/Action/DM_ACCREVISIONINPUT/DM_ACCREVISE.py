from psdi.mbo import MboConstants

accnum = mbo.getString("ACCIDENTNUM")
desc = mbo.getString("REVDESC")
owner = mbo.getOwner()
rev = owner.getInt("REVISIONNUM")
status = owner.getString("STATUS")

print "Current Mbo Name = " + str(mbo.getName())
print "Owner Name = " + str(owner.getName())
print "Accident Number = " + str(mbo.getString("ACCIDENTNUM"))

if(status == "PNDREV"):
    service.error("","This Record Already Revised")

if(desc == "" or desc is None):
    service.error("","Revision Description is required")


mboSet = owner.getThisMboSet()
mboSet.setAutoKeyFlag(False);
newAccident = owner.duplicate()
newAccidentMboID = newAccident.getUniqueIDValue();
#if(owner.isModified()):
newAccident.setValue("ACCIDENTNUM",accnum,11L)
owner.setValue("STATUS","PNDREV")
newAccident.setValue("REVISIONNUM",rev+1)
mboSet.save()
mboSet.getMboForUniqueId(newAccidentMboID)


service.closeDialog()

#service.error("dm_revisesecc","dm_succmsg")