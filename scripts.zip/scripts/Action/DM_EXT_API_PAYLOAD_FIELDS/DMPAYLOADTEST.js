/*
#-----------------------------------------------------------------------------------------
# Script Name : DMPAYLOADTEST
# Description : This script is used to test the API payload and response when the "Test API Request Payload" button is clicked in the "External API's Configuration" application
#
# Event              : Action Script object nam e:DM_EXT_API_PAYLOAD_FIELDS
# Author             : Pramod Kumar
# Version            : 1.0
# Date               : 10-Oct-2024
#-----------------------------------------------------------------------------------------
*/
load("nashorn:mozilla_compat.js");
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.server);
importPackage(Packages.psdi.mbo);
importPackage(Packages.psdi.iface.mic);
importPackage(Packages.java.io);
importPackage(Packages.java.util);
importPackage(Packages.java.net);
importPackage(Packages.psdi.util);
importPackage(Packages.org.json);
importPackage(Packages.org.apache.http);
importPackage(Packages.org.apache.http.client.methods);
importPackage(Packages.org.apache.http.impl.client);
importPackage(Packages.org.apache.http.entity);
importPackage(Packages.org.apache.http.message);

importPackage(Packages.psdi.mbo.MboConstants);
importClass(Packages.java.text.SimpleDateFormat);


var DocumentBuilderFactory = Packages.javax.xml.parsers.DocumentBuilderFactory;
var DocumentBuilder = Packages.javax.xml.parsers.DocumentBuilder;
var InputSource = Packages.org.xml.sax.InputSource;
var StringReader = Packages.java.io.StringReader;

importPackage(Packages.org.apache.commons.httpclient);
importPackage(Packages.org.apache.commons.httpclient.methods);
importPackage(Packages.org.apache.commons.httpclient.methods.StringRequestEntity);

var conn = null;
var pstmt = null;
var transid = null;
var mxServer = MXServer.getMXServer();	
params = {}
url=mbo.getString("WS_URL")
payload=mbo.getString("REQUEST_PAYLOAD")
endpoint=mbo.getString("ENDPOINT_NAME")
active = mbo.getBoolean("ACTIVE")
adhoc = mbo.getBoolean("ADHOC_CALL")
payload_working = mbo.getBoolean("PAYLOAD_WORKING")
trans_processed = mbo.getBoolean("TRANS_PROCESSED")
active = mbo.getBoolean("ACTIVE")	
		
var res = service.invokeEndpoint(endpoint, params, payload);
var response=res.toString();
    	
if (response){
    
    mbo.setValue("RESPONSE",response);
    mbo.setValue("PAYLOAD_WORKING",true)
    service.error("", "API Response Data:\n"+response);
    
    }else {
        service.error("API Response:", "No response");
    	}

function callApi(url, payload,SOAPAction) {
		
			var url = new URL(url); 

			var connection = url.openConnection();
			connection.setRequestMethod("POST"); 
			
			connection.setDoOutput(true); 
			connection.setRequestProperty("Content-Type", "text/xml");
			connection.setRequestProperty("SOAPAction", "urn:getAssetGCCDtlQuery");
			connection.setRequestProperty("x-Gateway-APIKey", "c2036d4a-e480-491e-8b07-7a830c98ee0d");
			// Write the payload to the output stream
			var outputStream = new DataOutputStream(connection.getOutputStream());
			outputStream.writeBytes(payload);
			outputStream.flush();
			outputStream.close();
			// Get the response
			var responseCode = connection.getResponseCode();
			
			var responseMessage = connection.getResponseMessage();
            
			// Read the response
			var reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			var response = "";
			var line;
			while ((line = reader.readLine()) != null) {
				response += line;
			}
			reader.close();

			print("HTTP POST Response Message: " + responseMessage);
			print("HTTP POST Response Body: " + response);
			
            return response;

}