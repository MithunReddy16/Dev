#script:DM_WOCLCOSCRIPT
#Createdby:Ram
#Creation Date:16-SEP-24
#scope: script will change the status of MR and WO status from close to O-Return Status based on its launchpoint

from psdi.mbo import MboConstants
from psdi.server import MXServer

if launchPoint=="DM_WOCLCO"	:
    
    if mbo is not None and mbo.getString("STATUS") == 'CLOSE':
    
    	if not mbo.isNull("ASSETNUM"):
    		mbo.getMboSet("$assethierarchy_del$","assethierarchy","wonum = :wonum and assetnum = :assetnum and siteid = :siteid").deleteAll(2l)
    		mbo.getMboSet("$assetrollup$","ASSETROLLUPSTATUS","wonum = :wonum and assetnum = :assetnum and siteid = :siteid").deleteAll(2l)
    	mbo.setValue("HISTORYFLAG",0,2l)
    	mbo.setValue("STATUSDATE",MXServer.getMXServer().getDate(),2l)
    	mbo.setValue("STATUS","O-Return",2l)
    	woStatusMbo = mbo.getMboSet("WOSTATUS").add(2l)
    	woStatusMbo.setValue("status","O-Return",2l)
    	woStatusMbo.setValue("memo","Re-Opened",2l)
    
    	
    	mbo.getThisMboSet().save(2l)

if launchPoint=="DM_MRCLCO"	:
	
    if mbo is not None and mbo.getString("STATUS") == 'CLOSE':
    
    	
    	mbo.setValue("HISTORYFLAG",0,2l)
    	mbo.setValue("STATUSDATE",MXServer.getMXServer().getDate(),2l)
    	mbo.setValue("STATUS","O-Return",2l)
    	woStatusMbo = mbo.getMboSet("MRSTATUS").add(2l)
    	woStatusMbo.setValue("status","O-Return",2l)
    	woStatusMbo.setValue("memo","Re-Opened",2l)
    
    	
    	mbo.getThisMboSet().save(2l)