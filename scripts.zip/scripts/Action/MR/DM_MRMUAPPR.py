#DM_MRMUAPPR
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

myLogger = MXLoggerFactory.getLogger("maximo.custom")

mrnum = mbo.getString('MRNUM')
tc=mbo.getDouble("totalcost")
approver_personid = mbo.getUserInfo().getPersonId()
MRLineSet = mbo.getMboSet("MRLINE")

MRLine=MRLineSet.moveFirst()
	
while MRLine:
	myLogger.info('Processing MR: {}'.format(mrnum))

	
	mrlinenum = MRLine.getInt("MRLINENUM")
	itemnum = MRLine.getString("ITEMNUM")
	dm_ccappr = MRLine.getBoolean("dm_ccappr")
	dm_muappr = MRLine.getBoolean("dm_muappr")
	dm_appr = MRLine.getBoolean("dm_appr")
	#service.error("dm", "genericerror", [str(MRLineSet.count())+"test4-"+itemnum+"-m-"+str(mrlinenum)+"-s-"+str(dm_muappr)])	
	myLogger.info("muxLog - dm_ccappr: {}, dm_muappr: {}, dm_appr: {}".format(dm_ccappr, dm_muappr, dm_appr))
	
	myLogger.info('Processing line {} with item number: {}'.format(mrlinenum, itemnum))
	if not dm_appr:
		ItemSet = MXServer.getMXServer().getMboSet("ITEM", MXServer.getMXServer().getSystemUserInfo())
		ItemSet.setWhere("itemnum = '{}'".format(itemnum))
		ItemSet.reset()

		if ItemSet.count() > 0:
			Item = ItemSet.getMbo(0)
			commoditygroup = Item.getString("COMMODITYGROUP")
			commodity = Item.getString("COMMODITY")
			dm_mainuser = Item.getString("dm_mainuser")

			if dm_mainuser:
				personSet = MXServer.getMXServer().getMboSet("PERSONGROUPTEAM",MXServer.getMXServer().getSystemUserInfo() )
				personSet.setWhere("persongroup = '{}' AND respparty = '{}'".format(dm_mainuser, approver_personid))
				personSet.reset()
				if personSet.count() > 0:										
					MRLine.setValue("dm_appr", True, 2L)
					MRLine.setValue("dm_muappr", True, 2L)	 
	MRLine=MRLineSet.moveNext()


	'''
	from psdi.server import MXServer
	from psdi.util.logging import MXLoggerFactory
	from psdi.mbo import MboConstants

	myLogger = MXLoggerFactory.getLogger("maximo.custom")

	mrnum = mbo.getString('MRNUM')
	tc=mbo.getDouble("totalcost")
	approver_personid = mbo.getUserInfo().getPersonId()
	MRLineSet = mbo.getMboSet("MRLINE")
	MRLineSet.setOrderBy("mrlinenum ASC")
	#MRLineSet.setWhere("mrnum = '{}'".format(mrnum))
	#MRLineSet.reset()
	approved_lines_count = 0
	MrMbo=MRLineSet.moveFirst()

	if MrMbo:
		myLogger.info('Processing MR: {}'.format(mrnum))
		myLogger.info('Processing {} lines for MR: {}'.format(MRLineSet.count(), mrnum))
			
		for i in range(MRLineSet.count()):
			MRLine = MRLineSet.getMbo(i)
			itemnum = MRLine.getString("ITEMNUM")
			mrlinenum = MRLine.getInt("MRLINENUM")
			myLogger.info('Processing line {} with item number: {}'.format(mrlinenum, itemnum))
			itemnum = MRLine.getString("ITEMNUM")
			dm_ccappr = MRLine.getBoolean("dm_ccappr")
			dm_muappr = MRLine.getBoolean("dm_muappr")
			dm_appr = MRLine.getBoolean("dm_appr")
			#service.error("dm", "genericerror", [str(MRLineSet.count())+"test4-"+itemnum+"-m-"+str(mrlinenum)+"-s-"+str(dm_muappr)])    
			myLogger.info("muxLog - dm_ccappr: {}, dm_muappr: {}, dm_appr: {}".format(dm_ccappr, dm_muappr, dm_appr))
			
			myLogger.info('Processing line {} with item number: {}'.format(mrlinenum, itemnum))

			ItemSet = MXServer.getMXServer().getMboSet("ITEM", mbo.getUserInfo())
			ItemSet.setWhere("itemnum = '{}'".format(itemnum))
			ItemSet.reset()

			if ItemSet.count() > 0:
				Item = ItemSet.getMbo(0)
				commoditygroup = Item.getString("COMMODITYGROUP")
				commodity = Item.getString("COMMODITY")
				dm_mainuser = Item.getString("dm_mainuser")

				
				personSet = mbo.getMboSet("$EMXPERSONGROUP", "PERSONGROUPTEAM", "persongroup = '{}' AND respparty = '{}'".format(dm_mainuser, approver_personid))

				if personSet.count() > 0:
					myLogger.info('Approver {} is a member of persongroup {}.'.format(approver_personid, dm_mainuser))
				   
					if dm_mainuser and dm_ccappr==1 and commodity: 
							
							 MRLine.setValue("dm_appr", True, 2L)
							 MRLine.setValue("dm_muappr", True, 2L)
							 approved_lines_count += 1
							 myLogger.info('Line {} in MR {} updated with dm_appr=1 and dm_smappr=True.'.format(mrlinenum, mrnum))
							  
					elif dm_mainuser and not commodity :
							 #service.error("dm", "genericerror", [str(MRLineSet.count())+"tes6-"+itemnum+"-m-"+str(mrlinenum)+"-s-"+str(dm_muappr)])    
							 MRLine.setValue("dm_appr", True, 2L)
							 MRLine.setValue("dm_muappr", True, 2L)
							 approved_lines_count += 1
							 myLogger.info('Line {} in MR {} updated with dm_appr=1 and dm_smappr=True.'.format(mrlinenum, mrnum))
							 #mbo.getThisMboSet().save()
					elif dm_mainuser and  commodity and dm_ccappr==0 :
							 
							 MRLine.setValue("dm_muappr", True, 2L)
							 approved_lines_count += 1
							 myLogger.info('Line {} in MR {} updated with dm_appr=1 and dm_smappr=True.'.format(mrlinenum, mrnum))         
	myLogger.info("muxLogafter - dm_ccappr: {}, dm_muappr: {}, dm_appr: {}".format(dm_ccappr, dm_muappr, dm_appr)) 
	myLogger.info('Total approved MR lines: {}'.format(MRLineSet.count()))
	myLogger.info('before reset MR lines: {}'.format(MRLineSet.count()))
	myLogger.info('after reset MR lines: {}'.format(MRLineSet.count()))

	'''