from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

myLogger = MXLoggerFactory.getLogger("maximo.custom")

mrnum = mbo.getString('MRNUM')
tc = mbo.getDouble("totalcost")
approver_personid = mbo.getUserInfo().getPersonId()
approved_lines_count = 0
MRLineSet = mbo.getMboSet("MRLINE")
MrMbo = MRLineSet.moveFirst()
	
if MrMbo:
	myLogger.info('Processing MR: {}'.format(mrnum))
	
	for i in range(MRLineSet.count()):
		MRLine = MRLineSet.getMbo(i)
		itemnum = MRLine.getString("ITEMNUM")
		mrlinenum = MRLine.getInt("MRLINENUM")
		#dm_ccappr = MRLine.getBoolean("dm_ccappr")
		dm_appr = MRLine.getBoolean("dm_appr")
		#dm_muappr = MRLine.getBoolean("dm_muappr")
		
		# Get Item data
		ItemSet = MXServer.getMXServer().getMboSet("ITEM", mbo.getUserInfo())
		ItemSet.setWhere("itemnum = '{}'".format(itemnum))
		ItemSet.reset()

		if ItemSet.count() > 0:
			Item = ItemSet.getMbo(0)
			commodity = Item.getString("COMMODITY")
			dm_mainuser = Item.getString("dm_mainuser")

			needMRA = False
			needMU = False		
			
						
			if commodity:
				MRASet = MXServer.getMXServer().getMboSet("DM_MRA", MXServer.getMXServer().getSystemUserInfo())
				commParts = commodity.split("-")
				commParts1 = commParts[0]
				commParts2 = int(commParts[1])
				WhereClause = "SUBSTR(FROMCATEGORY, 1, INSTR(FROMCATEGORY, '-') - 1)='" +commParts1+"' and " + str(commParts2) + "  between TO_NUMBER (SUBSTR(FROMCATEGORY, INSTR(FROMCATEGORY, '-') + 1) ) and TO_NUMBER (SUBSTR(tocategory, INSTR(tocategory, '-') + 1) ) "
				myLogger.info('Require MRA Where Clasue: {}'.format(WhereClause))
				MRASet.setWhere(WhereClause)
				MRASet.reset()
				
				MRAMbo = MRASet.moveFirst()
				if MRAMbo :
					needMRA=True
				
				MRASet.cleanup()
				MRASet.close()
				
			if dm_mainuser:
				MainUserSet = MXServer.getMXServer().getMboSet("PERSONGROUPTEAM", MXServer.getMXServer().getSystemUserInfo())
				
				WhereClause = "PERSONGROUP='" +dm_mainuser+"'"
				myLogger.info('Require MRA Where Clasue: {}'.format(WhereClause))
				MainUserSet.setWhere(WhereClause)
				MainUserSet.reset()
				
				MainUserMbo = MainUserSet.moveFirst()
				if MainUserMbo :
					needMU=True
				
				MainUserSet.cleanup()
				MainUserSet.close()
				
			if not needMU and not needMRA:
				MRLine.setValue("dm_appr",True,11L)

'''
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

myLogger = MXLoggerFactory.getLogger("maximo.custom")

mrnum = mbo.getString('MRNUM')
tc = mbo.getDouble("totalcost")
approver_personid = mbo.getUserInfo().getPersonId()
approved_lines_count = 0
MRLineSet = mbo.getMboSet("MRLINE")
MrMbo = MRLineSet.moveFirst()

if MrMbo:
    myLogger.info('Processing MR: {}'.format(mrnum))
    
    for i in range(MRLineSet.count()):
        MRLine = MRLineSet.getMbo(i)
        itemnum = MRLine.getString("ITEMNUM")
        mrlinenum = MRLine.getInt("MRLINENUM")
        dm_ccappr = MRLine.getBoolean("dm_ccappr")
        dm_appr = MRLine.getBoolean("dm_appr")
        dm_muappr = MRLine.getBoolean("dm_muappr")
        
        # Get Item data
        ItemSet = MXServer.getMXServer().getMboSet("ITEM", mbo.getUserInfo())
        ItemSet.setWhere("itemnum = '{}'".format(itemnum))
        ItemSet.reset()

        if ItemSet.count() > 0:
            Item = ItemSet.getMbo(0)
            commodity = Item.getString("COMMODITY")
            dm_mainuser = Item.getString("dm_mainuser")

            if not commodity and not dm_mainuser and tc < 50000:
                MRLine.setValue("dm_appr", True, 2L)
                MRLine.setValue("dm_smappr", True, 2L)
                approved_lines_count += 1
                myLogger.info('Line {} in MR {} updated with dm_appr=1 and dm_smappr=True.'.format(mrlinenum, mrnum))
            
            elif ((commodity and dm_ccappr == 1 and not dm_mainuser) or 
                  (not commodity and dm_mainuser and dm_muappr == 1) or 
                  (commodity and dm_ccappr == 1 and dm_mainuser and dm_muappr == 1)) and tc < 50000:
                MRLine.setValue("dm_appr", True, 2L)
            else:
                myLogger.info('Line {} in MR {} updated with dm_smappr=True.'.format(mrlinenum, mrnum))
            
            
            if commodity:
                commodity_parts = commodity.split('-')
                if len(commodity_parts) > 1:
                    commodity_prefix = commodity_parts[0]
                    commodity_number = int(commodity_parts[1])
                    
                    # Fetch matching DM_MRA records
                    DM_MRA_Set = MXServer.getMXServer().getMboSet("DM_MRA", mbo.getUserInfo())
                    DM_MRA_Set.reset()

                    if DM_MRA_Set.count() > 0:
                        matched = False  
                        for j in range(DM_MRA_Set.count()):
                            DM_MRA = DM_MRA_Set.getMbo(j)
                            from_category = DM_MRA.getString("fromcategory")
                            to_category = DM_MRA.getString("tocategory")

                            from_category_parts = from_category.split('-')
                            to_category_parts = to_category.split('-')

                            if len(from_category_parts) > 1 and len(to_category_parts) > 1:
                                from_category_prefix = from_category_parts[0]
                                from_category_number = int(from_category_parts[1])
                                to_category_prefix = to_category_parts[0]
                                to_category_number = int(to_category_parts[1])

                                if commodity_prefix == from_category_prefix == to_category_prefix:
                                    myLogger.info('Prefix match: {} == {} == {}'.format(commodity_prefix, from_category_prefix, to_category_prefix))

                                    if from_category_number <= commodity_number <= to_category_number:
                                        matched = True  

                        
                        if not matched:
                            #MRLine.setValue("dm_appr", True, 2L) commented by Mithun
                            MRLine.setValue("dm_smappr", True, 2L)
                            myLogger.info('Line {} in MR {} updated with dm_appr and dm_smappr because no matching category for commodity {}.'.format(mrlinenum, mrnum, commodity))
                    else:
                        # No DM_MRA records, handle case here if needed
                        myLogger.info('No DM_MRA records found for commodity {}'.format(commodity))

myLogger.info('Total approved MR lines: {}'.format(approved_lines_count))
myLogger.info('before reset MR lines: {}'.format(MRLineSet.count()))
myLogger.info('after reset MR lines: {}'.format(MRLineSet.count()))

'''