#################
# Script DM_MRLAPPR
# Set CCAPPR to true based on loged in User
# And Set APPR to true if line does not require MUa
############################

from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

myLogger = MXLoggerFactory.getLogger("maximo.custom")

myLogger.info('Script execution started')

mrnum = mbo.getString('MRNUM')
approver_personid = mbo.getUserInfo().getPersonId()

MRLineSet = mbo.getMboSet("MRLINE")
MRLineSet.setOrderBy("mrlinenum ASC")
approved_lines_count = 0
MRLine=MRLineSet.moveFirst()

while MRLine:
	itemnum = MRLine.getString("ITEMNUM")
	mrlinenum = MRLine.getInt("MRLINENUM")
	dm_ccappr = MRLine.getBoolean("dm_ccappr")
	dm_appr = MRLine.getBoolean("dm_appr")
	dm_muappr = MRLine.getBoolean("dm_muappr")

	if not dm_appr and not dm_ccappr:
		# Fetch the item and commodity information
		ItemSet = MXServer.getMXServer().getMboSet("ITEM", MXServer.getMXServer().getSystemUserInfo())
		ItemSet.setWhere("itemnum = '{}'".format(itemnum))
		ItemSet.reset()

		
		item = ItemSet.getMbo(0)
		commodity = item.getString("COMMODITY")
		if  commodity :
			commParts = commodity.split("-")
			commParts1 = commParts[0]
			commParts2 = int(commParts[1])
			MRASet = MXServer.getMXServer().getMboSet("DM_MRA", MXServer.getMXServer().getSystemUserInfo())
			WhereClause = "SUBSTR(FROMCATEGORY, 1, INSTR(FROMCATEGORY, '-') - 1)='" +commParts1+"' and " + str(commParts2) + "  between TO_NUMBER (SUBSTR(FROMCATEGORY, INSTR(FROMCATEGORY, '-') + 1) ) and TO_NUMBER (SUBSTR(tocategory, INSTR(tocategory, '-') + 1) ) "
			MRASet.setWhere(WhereClause)
			MRASet.reset()
			
			MRAMbo = MRASet.moveFirst()
			if MRAMbo:
				approver_assigned = MRAMbo.getString("Approveby")
				if approver_assigned:
					personSet = MXServer.getMXServer().getMboSet("PERSONGROUPTEAM",MXServer.getMXServer().getSystemUserInfo() )
					personSet.setWhere("persongroup = '{}' AND respparty = '{}'".format(approver_assigned, approver_personid))
					personSet.reset()
					if personSet.moveFirst():
						MRLine.setValue("dm_ccappr", True, 2L)
						
						
						if item.getString("dm_mainuser"):
							personSet = MXServer.getMXServer().getMboSet("PERSONGROUPTEAM",MXServer.getMXServer().getSystemUserInfo() )
							personSet.setWhere("persongroup = '{}'".format(item.getString("dm_mainuser")))
							personSet.reset()
							personMbo = personSet.moveFirst()
							if not personMbo:
								MRLine.setValue("dm_appr", True, 2L)
						else:
							MRLine.setValue("dm_appr", True, 2L)
					
					personSet.cleanup()
					personSet.close()
					ItemSet.cleanup()
					ItemSet.close()
					MRASet.cleanup()
					MRASet.close()
									
	MRLine=MRLineSet.moveNext()

'''

from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

myLogger = MXLoggerFactory.getLogger("maximo.custom")

myLogger.info('Script execution started')

mrnum = mbo.getString('MRNUM')
approver_personid = mbo.getUserInfo().getPersonId()

# Fetch the MRLineSet with unapproved lines
#MRLineSet = mbo.getMboSet("MRLINE")
#MRLineSet.setWhere("mrnum = '{}' AND dm_appr = 0".format(mrnum))

#MRLineSet.reset()
MRLineSet = mbo.getMboSet("MRLINE")
MRLineSet.setOrderBy("mrlinenum ASC")
#MRLineSet.setWhere("mrnum = '{}'".format(mrnum))
#MRLineSet.reset()
approved_lines_count = 0
MrMbo=MRLineSet.moveFirst()

if MrMbo:
    myLogger.info('Processing MR: {}'.format(mrnum))
    myLogger.info('Processing {} lines for MR: {}'.format(MRLineSet.count(), mrnum))
        
    for i in range(MRLineSet.count()):
        MRLine = MRLineSet.getMbo(i)
        #MRLine = MRLineSet.getMbo(0)
        itemnum = MRLine.getString("ITEMNUM")
        mrlinenum = MRLine.getInt("MRLINENUM")
        dm_ccappr = MRLine.getBoolean("dm_ccappr")
        dm_appr = MRLine.getBoolean("dm_appr")
        dm_muappr = MRLine.getBoolean("dm_muappr")
        myLogger.info('Processing line {} with item number: {}'.format(mrlinenum, itemnum))
        myLogger.info("Line Approval Status - dm_ccappr: {}, dm_appr: {}".format(dm_ccappr, dm_appr))

        # Fetch the item and commodity information
        ItemSet = MXServer.getMXServer().getMboSet("ITEM", mbo.getUserInfo())
        ItemSet.setWhere("itemnum = '{}'".format(itemnum))
        ItemSet.reset()

        if not ItemSet.isEmpty():
            item = ItemSet.getMbo(0)
            commodity = item.getString("COMMODITY")
            if  commodity and not dm_ccappr:
					itemnum2=item.getString("itemnum")
					commodity_parts = commodity.split('-')
					if len(commodity_parts) > 1:
						commodity_prefix = commodity_parts[0]
						commodity_number = int(commodity_parts[1])

						# Fetch DM_MRA data for approval validation
						DM_MRA_Set = MXServer.getMXServer().getMboSet("DM_MRA", mbo.getUserInfo())
						DM_MRA_Set.reset()

						if DM_MRA_Set.count() > 0:
							for j in range(DM_MRA_Set.count()):
								DM_MRA = DM_MRA_Set.getMbo(j)
								from_category = DM_MRA.getString("fromcategory")
								to_category = DM_MRA.getString("tocategory")
								approver_assigned = DM_MRA.getString("approveby")

								from_category_parts = from_category.split('-')
								to_category_parts = to_category.split('-')

								if len(from_category_parts) > 1 and len(to_category_parts) > 1:
									from_category_prefix = from_category_parts[0]
									from_category_number = int(from_category_parts[1])
									to_category_prefix = to_category_parts[0]
									to_category_number = int(to_category_parts[1])

									if commodity_prefix == from_category_prefix == to_category_prefix:
										myLogger.info('Prefix match: {} == {} == {}'.format(
											commodity_prefix, from_category_prefix, to_category_prefix))

										if from_category_number <= commodity_number <= to_category_number:
												myLogger.info('Commodity {} is within range {}-{}'.format(
													commodity, from_category_number, to_category_number))

												if approver_assigned:
														personSet = mbo.getMboSet("$EMXPERSONGROUP", "PERSONGROUPTEAM", "persongroup = '{}' AND respparty = '{}'".format(approver_assigned, approver_personid))
														personMbo = personSet.getMbo(0)
								
													   
														
														if personMbo:
															if not item.getString("dm_mainuser") :
															            #service.error("dm", "genericerror", [str(MRLineSet.count())+"dfds-"+itemnum2+"-m-"+str(mrlinenum)])
															            MRLine.setValue("dm_appr", True, MboConstants.NOACCESSCHECK)
															            MRLine.setValue("dm_ccappr", True, MboConstants.NOACCESSCHECK)
															            myLogger.info('MR Line {} approved by approver {}.'.format(mrlinenum, approver_personid))
															            approved_lines_count += 1
															            #service.error("dm", "genericerror", [str(MRLineSet.count())+"dfds-"+itemnum2+"-m-"+str(mrlinenum)+"-s-"+str(dm_ccappr)])
															            break;
																		
															elif item.getString("dm_mainuser") and MRLine.getBoolean("dm_muappr")==1:
																		
																		MRLine.setValue("dm_ccappr", True, 2L)
																		MRLine.setValue("dm_appr", True, MboConstants.NOACCESSCHECK)
																		approved_lines_count += 1
																		
																	   # mbo.getThisMboSet().save()
																		myLogger.info('Approver {} is not assigned to MR Line {} via DM_MRA.'.format(approver_personid, mrlinenum))
															elif item.getString("dm_mainuser") and MRLine.getBoolean("dm_muappr")==0:
																		MRLine.setValue("dm_ccappr", True, 2L)
																		approved_lines_count += 1
																		 
																	   # mbo.getThisMboSet().save()
																		myLogger.info('Approver {} is not assigned to MR Line {} via DM_MRA.'.format(approver_personid, mrlinenum))
												
												else:
													myLogger.info('No approver found for item {}.'.format(itemnum))
												#service.error("dm", "genericerror", [str(MRLineSet.count())+"dfds-"+itemnum+"-m-"+str(mrlinenum)+"-so-"+str(dm_ccappr)+"-sob-"+str(dm_muappr)+"-itha-"+str(dm_appr)])                                                                 
myLogger.info('approved lines count: {}'.format(approved_lines_count))
myLogger.info('Total approved MR lines: {}'.format(MRLineSet.count()))
myLogger.info('before reset MR lines: {}'.format(MRLineSet.count()))
myLogger.info('after reset MR lines: {}'.format(MRLineSet.count()))

'''