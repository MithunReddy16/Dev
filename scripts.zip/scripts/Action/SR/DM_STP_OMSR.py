from psdi.server import MXServer 

dm_location = mbo.getString("asset.dm_location")

whereClause = (
            "APPROVALLEVEL=1 "
            "AND DM_MAINTDEPT='60181' "
            "AND VENDOR=:vendor "
            "AND DM_LOCATION='{}' "
            "AND WORKTYPE='CM'").format(dm_location) 

respMatrixSet = mbo.getMboSet("$respMatrixSet","DM_RESPMANAGER",whereClause)
respMatrixMbo = respMatrixSet.moveFirst()
service.log_debug("The DM_STP_OMSR--------23")
if respMatrixMbo:
    service.log_debug("The DM_STP_OMSR--------25")
    #service.error("floc",dm_location)
    ownerGroup = respMatrixMbo.getString("RESPONSIBLEGROUP")
    supervisorGroup = respMatrixMbo.getString("SUPERVISORGROUP") 
    mbo.applyOwnerGroup(ownerGroup)
    woSet = mbo.getMboSet("WORKORDEROMDM","WORKORDER","1=2")
    woList = mbo.createWorkorder(woSet, False)
    wo = woList[1]
    wo.applyOwnerGroup(ownerGroup)
    wo.setValue("PERSONGROUP", supervisorGroup)
    mbo.changeStatus("INPROG",MXServer.getMXServer().getDate(),"",2L)
    service.log_debug("The DM_STP_OMSR--------34")