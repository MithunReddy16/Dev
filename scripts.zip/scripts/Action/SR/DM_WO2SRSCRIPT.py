#-----------------------------------------------------------------------------
#Date:13-Aug-2026
#remarks- change the status of SR from workorder
#createdby:ram

#-------------------------------------------------------------------------------
from psdi.server import MXServer
from psdi.mbo import Mbo
from psdi.util.logging import MXLoggerFactory
logger = MXLoggerFactory.getLogger("maximo.script")
logger.debug("-----------wo2sr starteed-----------")

userInfo = MXServer.getMXServer().getSystemUserInfo()
maintDeptSet = mbo.getMboSet("$value","DM_ORGHIERARCHY","unitid=:dm_maintdept")
maintDeptMbo=maintDeptSet.moveFirst()
if maintDeptMbo:
    maxvalue = maintDeptMbo.getString("abbriviation")

if maxvalue == 'SRN' and mbo.getString("DM_BUNIT") == 'WSHUNIT':
        logger.error("-----------wo2sr unit-----------")
        
        if launchPoint== "DM_SR2W":
            
            logger.error("-----------wo2sr sr-----------")
            origRecordId = mbo.getString("ORIGRECORDID")
            origRecordClass = mbo.getString("ORIGRECORDCLASS")
           # service.error(origRecordId,origRecordClass)
            logger.error("----------- Starting SR to Related Work Order Lookup -----------")
            srTicketId = mbo.getString("TICKETID")
            #service.error(srTicketId,srTicketId)
            if srTicketId:
                
                relRecSet = mbo.getMboSet(
                    "$SRRELREC", 
                    "RELATEDRECORD", 
                    "recordkey = '{}' and class = 'SR' and relatedrecclass = 'WORKORDER'".format(srTicketId)
                )
                
                if not relRecSet.isEmpty():
                    
                    relRec = relRecSet.getMbo(0)
                    
                    wonum = relRec.getString("relatedreckey")
                    #service.error(wonum,srTicketId)
                    logger.debug("----------- Found linked WONUM reference: {} -----------".format(wonum))
        
       
                    woSet = mbo.getMboSet(
                        "$TARGETWO", 
                        "WORKORDER", 
                        "wonum = '{}'".format(wonum)
                    )
                    
                    if not woSet.isEmpty():
                        woMbo = woSet.getMbo(0)
                        #service.error(wonum,srTicketId)
                        logger.debug("----------- Successfully retrieved Work Order Record. Status: {} -----------".format(woMbo.getString("STATUS")))
                        if woMbo:    
                                logger.debug("-----------wo2sr rec-----------")
                                if mbo.getString("STATUS") == "CLOSED":
                    
                                            woMbo.changeStatus(
                                    "COMP",
                                    MXServer.getMXServer().getDate(),
                                    "SR Closed"
                                )
                                if mbo.getString("STATUS") == "INPROG":
                    
                                            woMbo.changeStatus(
                                    "REWORK",
                                    MXServer.getMXServer().getDate(),
                                    "SR Rework"
                                )
                                
        if launchPoint== "DM_WO2SR":
            logger.debug("-----------wo2sr wo-----------")
            origRecordId = mbo.getString("ORIGRECORDID")
            origRecordClass = mbo.getString("ORIGRECORDCLASS")
            
            if origRecordId and origRecordClass == "SR":
                
                logger.debug("-----------wo2sr sr origin-----------")
                srSet = mbo.getMboSet(
                    "$RELATEDSR",
                    "SR",
                    "TICKETID='{}'".format(origRecordId))
                srMbo = srSet.moveFirst()    
                if srMbo:   
                        
                        logger.debug("-----------wo2sr sr record-----------")
                        if mbo.getString("STATUS") == "WOAPPROVED":
                                    logger.debug("-----------wo2sr appr-----------")        
                                    srMbo.changeStatus(
                            "INPROG",
                            MXServer.getMXServer().getDate(),
                            "Work Order approved"
                        )
                        if mbo.getString("STATUS") == "WINSP":
            
                                    srMbo.changeStatus(
                            "RESOLVED",
                            MXServer.getMXServer().getDate(),
                            "Work Order is waiting for inspection"
                        )