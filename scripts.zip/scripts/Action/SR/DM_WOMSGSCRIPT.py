#Author        : ram
#Created Date  : 30-Jul-2026
#Remarks       : generate the work order message for srwn sr workflow 
    
session = service.webclientsession()

relatedSet = mbo.getMboSet("RELATEDRECORD")

woNum = ""

if not relatedSet.isEmpty():
    for i in range(relatedSet.count()):
        relatedMbo = relatedSet.getMbo(i)

        if relatedMbo.getString("RELATEDRECCLASS") == "WORKORDER":
            woNum = relatedMbo.getString("RELATEDRECKEY")
            break

if woNum:
    params = [woNum]
    session.showMessageBox(
        "dm_womsg",
        "dm_wotext",
        params
    )