#------------------------------------------------------------------------

#Script Name :Apply Owner Group
#Description :script to Change Section Budget Plan Status
#Comment     :Used in Department Budget Plan and Section Budget Plan 
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
# Samer Al Fakih      SWORD_salfakih@dm.ae     1.0          01-FEB-2026         Initiate version.
#Modifiedby : Mithun
#------------------------------------------------------------------------


from psdi.server import MXServer
from psdi.mbo import Mbo

# Initialize variables
zoneId = None
serviceType = None
# Get basic values
location = mbo.getString("LOCATION")
assetnum = mbo.getString("ASSETNUM")
serviceId = mbo.getString("DM_SERVICEID")
serviceType = mbo.getString("DM_SERVICETYPE")
maintdept = mbo.getString("DM_MAINTDEPT")
bunit = mbo.getString("dm_bunit")

dm_location = None
maxvalue = None

if launchPoint == "DM_APPLY_OWNER_SR":
    workType = mbo.getString("DM_WOTYPE")
    #mbo.getThisMboSet().save()
else:
    workType = mbo.getString("WORKTYPE")

    if mbo.getString("pmnum"):
        pmMbo = mbo.getMboSet("PM").moveFirst()
        if pmMbo:
             route = pmMbo.getString("ROUTE")

# -----------------------------
# Get department abbriviation
# -----------------------------        
maintDeptSet = mbo.getMboSet("$value","DM_ORGHIERARCHY","unitid='"+maintdept+"'")
maintDeptMbo=maintDeptSet.moveFirst()
if maintDeptMbo:
    maxvalue = maintDeptMbo.getString("abbriviation")
# -----------------------------  
    
if maxvalue == "STP":
    #service.error("dm","genericerror",[""+route])
    if assetnum:

        # Get Functional Location from the Asset
        assetSet = mbo.getMboSet(
        "TEMP_ASSET",
        "ASSET",
        "ASSETNUM='{}'".format(assetnum))

        assetMbo = assetSet.moveFirst()
        if assetMbo:
            dm_location = assetMbo.getString("dm_location")
            #service.error("dm","genericerror",[""+route])
    elif route:
        
        routeStopSet = mbo.getMboSet(
        "TEMP_ROUTESTOP",
        "ROUTE_STOP",
        "ROUTE='{}' AND ASSETNUM IS NOT NULL".format(route))

        routeStopMbo = routeStopSet.moveFirst()

        if routeStopMbo:
            routeasset = routeStopMbo.getString("ASSETNUM")
           
            # Get Functional Location from the Asset
            routeassetSet = routeStopMbo.getMboSet(
            "TEMP_ASSET",
            "ASSET",
            "ASSETNUM='{}'".format(routeasset))

            routeassetMbo = routeassetSet.moveFirst()
            if routeassetMbo:
                dm_location = routeassetMbo.getString("dm_location")

        else:
            service.error(
                "custom",
                "Functional location not available. Please contact the system administrator."
            )
    else:
            service.error(
                "custom",
                "Functional location not available. Please contact the system administrator."
            ) 
        
# -----------------------------
# Get Zone from Location
# -----------------------------
if location:
    locSet = mbo.getMboSet(
        "TEMP_LOCATIONS",
        "LOCATIONS",
        "LOCATION='{}'".format(location)
    )
    locMbo = locSet.moveFirst()
    if locMbo:
        zoneId = locMbo.getString("DM_ZONES")
        community= locMbo.getString("dm_community")
# -----------------------------
# Get Service Type
# -----------------------------

if serviceId and not serviceType:
    serviceSet = mbo.getMboSet(
        "TEMP_DM_SERVICECATALOG",
        "DM_SERVICECATALOG",
        "SERVICEID='{}'".format(serviceId)
    )
    serviceMbo = serviceSet.moveFirst()
    if serviceMbo:
        serviceType = serviceMbo.getString("TYPE")

# -----------------------------
# Build WHERE clause
# -----------------------------

if maxvalue == "STP":
    assetType = mbo.getString("asset.DM_CONTRACTPURCH.dm_contracttype")
    if mbo.getBoolean("DM_INHOUSE") or "AMC" == assetType:
        whereClause = (
            "APPROVALLEVEL=1 "
            "AND DM_MAINTDEPT=:dm_maintdept "
            "AND DM_BUNIT='{}' "
            "AND WORKTYPE='{}'"
            "AND SERVICETYPE='{}'").format(bunit, workType,serviceType)
    else:
            #service.error(mbo.getString("vendor"),"")
            whereClause = (
            "APPROVALLEVEL=1 "
            "AND DM_MAINTDEPT=:dm_maintdept "
            "AND VENDOR=:vendor "
            "AND DM_BUNIT='{}' "
            "AND WORKTYPE='{}'").format(bunit,workType)    
            
if maxvalue == "SRN":
    # service.error(mbo.getString("DM_BUNIT"), "")

    if mbo.getString("DM_BUNIT") == "WSHUNIT":
        
        whereClause = "RESPONSIBLEGROUP='DM_SRNWE'"
    # below elif lines added by Mithun 
    elif mbo.getString("DM_BUNIT") == "FIUNIT":
        if mbo.getString("DM_CREWTYPE") == "ELEC":
            #whereClause = "RESPONSIBLEGROUP='DM_SRNEE'"
            mbo.applyOwnerGroup("DM_SRNEE")
        elif mbo.getString("DM_CREWTYPE") == "MECH" :
            #whereClause = "RESPONSIBLEGROUP='DM_SRNME'"
            mbo.applyOwnerGroup("DM_SRNME")
            
    else:
        whereClause =  " DM_MAINTDEPT=:DM_MAINTDEPT AND DM_BUNIT=:DM_BUNIT "          
 
if maxvalue == "GMD":
    if mbo.getBoolean("DM_INHOUSE"):
        whereClause = (
            "APPROVALLEVEL=1 "
            "AND DM_MAINTDEPT=:dm_maintdept "
            "AND WORKTYPE IN ('CM','AS') "
            "AND SERVICETYPE IS NULL "
            "AND ZONEID IS NULL"
        )

    elif workType in ("CM", "AS"):
        if location == "814-07373" or location.startswith("814-07373-"):
            zoneId = "E2"

        whereClause = (
            "APPROVALLEVEL=1 "
            "AND DM_MAINTDEPT=:dm_maintdept "
            "AND WORKTYPE IN ('CM','AS') "
            "AND ZONEID='{}' "
            "AND SERVICETYPE='{}'"
        ).format(zoneId, serviceType)

    else:
        whereClause = (
            "APPROVALLEVEL=1 "
            "AND DM_MAINTDEPT=:dm_maintdept "
            "AND VENDOR=:vendor "
            "AND WORKTYPE='{}'"
        ).format(workType)

# -----------------------------
# Get Responsible Group
# -----------------------------

respMatrixSet = mbo.getMboSet( "$respMatrixSet","DM_RESPMANAGER",   whereClause)

respMatrixMbo = respMatrixSet.moveFirst()
if respMatrixMbo:
    
    ownerGroup = respMatrixMbo.getString("RESPONSIBLEGROUP")
    if ownerGroup:
        
        mbo.applyOwnerGroup(ownerGroup)
    
    
        
    if launchPoint == "DM_APPLY_OWNER_WO":
        supervisorGroup = respMatrixMbo.getString("SUPERVISORGROUP")
        
        if supervisorGroup:
            if maxvalue == 'SRN' and mbo.getString("DM_BUNIT") and mbo.getString("DM_BUNIT") not in ('FIUNIT', 'RWUNIT'):
                mbo.setValue("PERSONGROUP", supervisorGroup)
        
            elif maxvalue != 'SRN':
                mbo.setValue("PERSONGROUP", supervisorGroup)
    if launchPoint == "DM_APPLY_OWNER_SR":
    
            if maxvalue == 'SRN' and mbo.getString("DM_BUNIT") and mbo.getString("DM_BUNIT")  in ('WSHUNIT'):    
                mbo.setValue('dm_inhouse',1 , 2L)
            # Below Lines written by Mithun     
            if maxvalue == 'SRN' :    
                mbo.setValue('dm_inhouse',1 , 2L)
                if mbo.getString("DM_BUNIT") == "FIUNIT":
                    if mbo.getString("DM_CREWTYPE") == "ELEC":
                        mbo.setValue("DM_PERSONGROUP", "DMSRNFES") 
                        mbo.setValue("DM_DATAENTRYGROUP", "DMSRNFED") 
                    elif mbo.getString("DM_CREWTYPE") == "MECH" :                        
                        mbo.setValue("DM_PERSONGROUP", "DMSRNFMS")
                        mbo.setValue("DM_DATAENTRYGROUP", "DMSRNFMD")