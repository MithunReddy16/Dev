##############################################
#script:DM_ADV_VIEWDETAILS
#Createdby:NK
#Creation Date:16-02-2026
#scope: Create SR view details
###############################################

from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

myLogger = MXLoggerFactory.getLogger("maximo.custom")
myLogger.debug("****This is DM_ADV_VIEWDETAILS****")

wcs = service.webclientsession()
app = wcs.getCurrentApp()
bean = app.getAppBean()

mbo = bean.getMbo()
if mbo is not None:
    ticketid = mbo.getString("TICKETID")
    wcs.gotoApp("DM_SR_ADV")
    advApp = wcs.getCurrentApp()
    advBean = advApp.getAppBean()
    
    advBean.setQbe("TICKETID", ticketid)
    advBean.executeQuery()
    advBean.getMboSet().moveFirst()