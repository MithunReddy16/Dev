'''Sample script
Automatically run Auto Create Spatial for Service Request when action ACSRACTIONLP is run.'''

print "Auto Creating Spatial SR"
print "WONUM:"+mbo.getString("TICKETID")
print "SITEID"+mbo.getString("SITEID")
success = mbo.autoCreateSpatial(True)
if (success):
    print "SR Spatial successfully created"
else:
    print "SR Spatial creation failed"