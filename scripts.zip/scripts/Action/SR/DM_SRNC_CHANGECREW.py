# ------------------------------------------------------------
# Script     : DM_SRNC_CHANGECREW
# Launch pt  : Action | SR | Action DM_SRNC_CHANGECREW
# Purpose    : Swap DM_CREWTYPE: ELEC -> MECH, MECH -> ELEC
# Author/Date: Mithun / 2026-11-01
# ------------------------------------------------------------
from psdi.mbo import MboConstants

crewType = mbo.getString("DM_CREWTYPE")
service.log_debug("*********DM_CREWTYPE is %s, now %s" % (crewType, mbo.getString("DM_CREWTYPE")))
if crewType == "MECH":
    mbo.setValue("DM_CREWTYPE", "ELEC", MboConstants.NOACCESSCHECK)
elif crewType == "ELEC":
    mbo.setValue("DM_CREWTYPE", "MECH", MboConstants.NOACCESSCHECK)


session = service.webclientsession()
appBean=session.getCurrentApp().getAppBean()
appBean.save()

service.log_debug("*******DM_CREWTYPE was %s, now %s" % (crewType, mbo.getString("DM_CREWTYPE")))