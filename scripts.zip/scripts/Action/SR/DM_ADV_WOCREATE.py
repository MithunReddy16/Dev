##############################################
#script:DM_ADV_WO
#Createdby:NK
#Creation Date:22-12-2025
#scope: Create workorder from SR
###############################################

from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants
from java.text import SimpleDateFormat
from psdi.common.context import UIContext

logger = MXLoggerFactory.getLogger("maximo.custom")
logger.debug("*******DM_ADV_WOCREATE - START**********")

mxServer   = MXServer.getMXServer()
userInfo = mbo.getUserInfo()

if mbo and mbo.getString("STATUS") == "NEW":
    if launchPoint in ("DM_ADV_WOCREATE"):
        orgid    = mbo.getString("ORGID")
        siteid   = mbo.getString("SITEID")
        ticketid = mbo.getString("TICKETID")
        
        srDesc  = mbo.getString("DESCRIPTION")
        srPrio  = mbo.getString("REPORTEDPRIORITY")
        srSect  = mbo.getString("DM_SECTOR")
        srDept  = mbo.getString("DM_DEPARTMENT")
        srSec   = mbo.getString("DM_SECTION")
        
        flags = MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION
        
        # --- generate reference number-----
        def set_adv_ref(woMbo):
            currentDate = MXServer.getMXServer().getDate()
            formattedDate = SimpleDateFormat("ddMMyyyy").format(currentDate)
            
            woMbo.getMboValue("DM_ADV_REFSEQ").autoKey()
            seqInt = woMbo.getInt("DM_ADV_REFSEQ")
            seqStr = "%03d" % seqInt
            referenceNumber = formattedDate + "-" + seqStr
            woMbo.setValue("DM_ADV_REF", referenceNumber, MboConstants.NOACCESSCHECK)
            
        
        # --- create RELATEDRECORD for SR -> WO
        def link_sr_to_wo(srMbo, woMbo, rrSet):
            logger.debug("*******DM_ADV_WOCREATE - CONDITION-11 **********")
            if srMbo is not None and woMbo is not None:
                logger.debug("*******DM_ADV_WOCREATE - CONDITION-12 **********")
                sr_key = srMbo.getString("TICKETID")
                wo_key = woMbo.getString("WONUM")
                logger.debug("*******DM_ADV_WOCREATE - WOKEY="+str(wo_key))
                if sr_key and wo_key:
                # check duplicate
                    logger.debug("*******DM_ADV_WOCREATE - CONDITION-13 **********")
                    chk = srMbo.getMboSet(
                        "$RRCHK", "RELATEDRECORD",
                        "class='SR' and recordkey='%s' and relatedrecclass='WORKORDER' and relatedreckey='%s' and orgid='%s' and siteid='%s'"
                        % (sr_key, wo_key, orgid, siteid) )
                    try:
                        if chk.isEmpty():
                            logger.debug("*******DM_ADV_WOCREATE - CONDITION-14 **********")
                            #rrSet = srMbo.getMboSet("RELATEDRECORD")  # standard relationship exists on SR in most configs
                            rr = rrSet.add()
                            rr.setValue("ORGID", orgid, flags)
                            rr.setValue("SITEID", siteid, flags)
                            rr.setValue("RELATEDRECORGID", orgid, flags)
                            rr.setValue("RELATEDRECSITEID", siteid, flags)
        
                            rr.setValue("CLASS", "SR", flags)
                            rr.setValue("RECORDKEY", sr_key, flags)
        
                            rr.setValue("RELATEDRECCLASS", "WORKORDER", flags)
                            rr.setValue("RELATEDRECKEY", wo_key, flags)
        
                            #rrSet.save()
                    finally:
                        chk.close()
        
        #---------------------------------------------------
        
        # ADV mapping: DM_ADV_REQADV -> (WO Qty field, WO Checkbox field)
        ADV_MAP = {
            "FRAMES": ("DM_ADV_FRAME_Q", "DM_ADV_FRAMES"),
             "BANNER": ("DM_ADV_BAN_Q", "DM_ADV_BANNER"),
             "STICKER": ("DM_ADV_ST_Q", "DM_ADV_ST"),
             "POSTER": ("DM_ADV_PO_Q", "DM_ADV_PO"),
             "SMALLSIGN": ("DM_ADV_SSIGN_Q", "DM_ADV_SSIGN"),
             "MIDSIGN": ("DM_ADV_MSIGN", "DM_ADV_MIDSIGN"),
             "BIGSIGN": ("DM_ADV_BSIGN_Q", "DM_ADV_BIGSIGN"),
             "3D": ("DM_ADV_3D_Q", "DM_ADV_3D"),
             "RollUp": ("DM_ADV_ROLLUP_Q", "DM_ADV_ST"),
             "DeskBar": ("DM_ADV_DBAR_Q", "DM_ADV_DBAR"),
            
        }
        
        def apply_adv_mapping(woMbo, reqAdvValue, qtyValue):
        #Sets the mapped qty field and checkbox on the WO based on DM_ADV_REQADV.
            if woMbo is not None and reqAdvValue is not None:
                key = reqAdvValue.strip().upper()
                if key:
                    mapping = ADV_MAP.get(key)
                    if mapping:
                        qtyField, chkField = mapping
                        if qtyValue is not None:
                            woMbo.setValue(qtyField, qtyValue, flags)
                            woMbo.setValue(chkField, 1, flags)
        
        #---------------------------------------------------
      
        
        #---------------------------------------------------
       
        reqAdvSet = mxServer.getMboSet("DM_ADV_SR", userInfo)#-->use this when using SR workflow
        reqAdvSet.setWhere("DM_ADV_TICKETID='%s'" % ticketid)#-->use this when using SR workflow
        #reqAdvSet = mbo.getMboSet("DM_ADV_REQADV") #-->using this from create SR submit button
        reqAdvSet.reset()
        logger.info("DM_ADV_WOCREATE reqAdvSet.count=" + str(reqAdvSet.count()))
        
        if reqAdvSet is not None:
            logger.debug("*******DM_ADV_WOCREATE - CONDITION-2 **********")
            woSet = mxServer.getMboSet("WORKORDER", userInfo)
            
            try:
                rrSet = mbo.getMboSet("RELATEDRECORD")
                for i in range(reqAdvSet.count()):
                    logger.debug("*******DM_ADV_WOCREATE - CONDITION-3 **********")
                    reqAdvMbo = reqAdvSet.getMbo(i)
                    if reqAdvMbo is not None:
                        logger.debug("*******DM_ADV_WOCREATE - CONDITION-4 **********")
                        wo = woSet.add()
                        wo.setValue("ORGID", orgid, flags)
                        wo.setValue("SITEID", siteid, flags)
                        wo.setValue("WORKTYPE", "ADV", flags)
                        woDesc = u"%s - %s - %s" % (
                            srDesc,
                            reqAdvMbo.getString("DM_ADV_REQTYPE"),
                            reqAdvMbo.getString("DM_ADV_REQADV")
                        )
                        wo.setValue("DESCRIPTION", woDesc, flags)
            
                        wo.setValue("LOCATION", reqAdvMbo.getString("DM_ADV_LOC"), flags)
                        wo.changeStatus("WASSIGN", mxServer.getDate(), "Auto from SR")
                        wo.setValue("WOPRIORITY", srPrio, flags)
                        wo.setValue("DM_DEPARTMENT", srDept, flags)
                        wo.setValue("DM_SECTION", srSec, flags)
                        wo.setValue("DM_SECTOR", srSect, flags)
                        wo.setValue("DM_ADV_REQ", ticketid, flags)
                        wo.setValue("DM_ADV_REQTYPE", reqAdvMbo.getString("DM_ADV_REQTYPE"), flags)
                        wo.setValue("DM_ADV_SIZE", reqAdvMbo.getString("DM_ADV_SIZE"), flags)
                        set_adv_ref(wo)
                        
                        wo.setValue("DM_ADV_REQADV", reqAdvMbo.getString("DM_ADV_REQADV"), flags)
                        wo.setValue("DM_ADV_QTY", reqAdvMbo.getString("DM_ADV_QTY"), flags)
                        wo.setValue("DM_ADV_FIXINGON", reqAdvMbo.getString("DM_ADV_FIXINGON"), flags)
                        wo.setValue("DM_ADV_SIGNTYPE", reqAdvMbo.getString("DM_ADV_SIGNTYPE"), flags)
                        wo.setValue("DM_ADV_LINENUM", reqAdvMbo.getInt("DM_ADV_LINENUM"), flags)
                        wo.setValue("DM_ADV_DNOTES", reqAdvMbo.getString("DM_ADV_DESC"), flags)
                        wo.setValue("DM_ADV_SAMPLE", 'Sample Only', flags)
                        wo.setValue("DM_ADV_ETR", "0", flags)
                        
                        #apply mapping-based qty + checkbox on WO
                        advVal = reqAdvMbo.getString("DM_ADV_REQADV")
                        qtyVal = None
                        qtyVal = reqAdvMbo.getInt("DM_ADV_QTY")
                        apply_adv_mapping(wo, advVal, qtyVal)
                        #------------------------------------------
                        
                        wonum = wo.getString("WONUM")
                        logger.debug("*******DM_ADV_WOCREATE - WONUM="+str(wonum))
                        link_sr_to_wo(mbo, wo, rrSet)
                       
    
                woSet.save()
                rrSet.save()
                
               
                #Update SR-------------------------------------------------------
                srSet = MXServer.getMXServer().getMboSet("SR", userInfo)
                srSet.setWhere("TICKETID='%s'" % ticketid)
                srSet.reset()
            
                if not srSet.isEmpty():
                    srMbo = srSet.getMbo(0)
                    srMbo.setValue("DM_ADV_WOGEN", 1, flags)
                    srMbo.changeStatus("SUBMITTED", mxServer.getDate(), "wWrkorders created")
                    
                    srSet.save()
              #----------------------------------------------------------------
                
            finally:
                woSet.close()
                srSet.close()