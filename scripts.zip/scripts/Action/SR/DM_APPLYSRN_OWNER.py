#------------------------------------------------------------------------
#Script Name :Apply SRN Owner Group
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
# Mithun           1.0          01-NOV-2026         Initiate version.
#------------------------------------------------------------------------


from psdi.server import MXServer
from psdi.mbo import Mbo

# Initialize variables
zoneId = None
serviceType = None
# Get basic values
location = mbo.getString("LOCATION")
assetnum = mbo.getString("ASSETNUM")
serviceId = mbo.getString("DM_SERVICEID")
serviceType = mbo.getString("DM_SERVICETYPE")
maintdept = mbo.getString("DM_MAINTDEPT")
bunit = mbo.getString("dm_bunit")

maxvalue = None


# -----------------------------
# Get department abbriviation
# -----------------------------        
maintDeptSet = mbo.getMboSet("$value","DM_ORGHIERARCHY","unitid='"+maintdept+"'")
maintDeptMbo=maintDeptSet.moveFirst()
if maintDeptMbo:
    maxvalue = maintDeptMbo.getString("abbriviation")
if launchPoint == "DM_APPLY_SRNOWNER_SR":            
    if maxvalue == "SRN":
        mbo.setValue('dm_inhouse',1 , 2L)
        
        if mbo.getString("DM_BUNIT") == "WSHUNIT":
            mbo.applyOwnerGroup("DM_SRNWE")
        elif mbo.getString("DM_BUNIT") == "FIUNIT":
            if mbo.getString("DM_CREWTYPE") == "ELEC":
                mbo.setValue("DM_PERSONGROUP", "DMSRNFES") 
                mbo.setValue("DM_DATAENTRYGROUP", "DMSRNFED") 
                mbo.applyOwnerGroup("DM_SRNEE")
            elif mbo.getString("DM_CREWTYPE") == "MECH" :
                mbo.setValue("DM_PERSONGROUP", "DMSRNFMS")
                mbo.setValue("DM_DATAENTRYGROUP", "DMSRNFMD")
                mbo.applyOwnerGroup("DM_SRNME")