#DM_CHANGELINESTATUSCHECK
from psdi.server import MXServer
from  psdi.common.context import UIContext
from psdi.webclient.system.controller import SessionContext, Utility, WebClientEvent
from psdi.util.logging import MXLoggerFactory

def setError(Msg):
		#global errorkey,errorgroup,params
		#errorkey='scriptvalidationerror'
		#errorgroup='scriptval'
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)
	
	
def convertStatusToInt(status) :
	if status == 'DRAFT':
		return 0
	if status == 'PENDING':
		return 1
	if status == 'REVIEWED':
		return 2
	if status == 'D-APPR':
		return 3
	if status == 'APPR':
		return 4
	if status == 'CLOSE':
		return 5
	if status == 'CAN':
		return 6
	return -1

statusChangeMatrix = [ [True, False, False, False, False , False , False ], [False, True, False, False, False , False , False ], [False, True, True, False, False , False , False ],[False, True, True, True, False , False , False ] ,[False, False, False, False, False , False , False ],[False, False, False, False, False , False , False ],[False, False, False, False, False , False , False ] ]


if statusChangeMatrix[convertStatusToInt(mbo.getString('STATUS'))][convertStatusToInt(mbo.getOwner().getString('STATUS'))] == False:
	setError('Status can not be changed for this line')
else:
	uiContext = UIContext.getCurrentContext()
	if uiContext != None:
		wcs = uiContext.getWebClientSession()
		Utility().sendEvent(WebClientEvent("CHANGELINESTATUS", wcs.getCurrentPageId(), None, SessionContext(wcs)))