#------------------------------------------------------------------------

#Script Name :DM_CREATEDATACHANGELINES
#Description :Create Change Data Request Lines from Assets Script.
#Comment     :Used in Asset Data Change Request Application.  
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-Aug-2025         Initiate version.

#------------------------------------------------------------------------


service.log_debug("######################################## Start:" + scriptName+" ######################")
session=service.webclientsession()
mainBean = session.getDataBean("mainrecord") 
requestMbo = mainBean.getMbo()
toLoc= None
toCC= None
toFloc= None
toMaint= None

if requestMbo.getBoolean("APPLYTOLOC"):
    toLoc = requestMbo.getString("TOLOCATION")
    
if requestMbo.getBoolean("APPLYTOCC"):
    toCC = requestMbo.getString("TOCOSTCENTER")
    toccSection= requestMbo.getString("tosection")

if requestMbo.getBoolean("APPLYTOFLOC"):
    toFloc = requestMbo.getString("TOFLOC")

if requestMbo.getBoolean("APPLYTOMAINTSEC"):
    toMaint = requestMbo.getString("TOMAINTSEC")

assetDatabean = session.getDataBean("dm_selectassetable")   #dm_selectassetdialog
requestLineMboSet=requestMbo.getMboSet("DM_DATACHANGELINE")
if assetDatabean is not None:
    assetSet=assetDatabean.getMboSet()
    selectedRecords=assetSet.getSelection()
    iterator=selectedRecords.iterator()
   
    while (iterator.hasNext()):
        assetMbo=iterator.next()
        requestLineMbo= requestLineMboSet.add()
        requestLineMbo.setValue("assetnum",assetMbo.getString("assetnum"))
        requestLineMbo.setValue("FROMCOSTCENTER",assetMbo.getString("DM_SECTION"))
        requestLineMbo.setValue("FROMFLOC",assetMbo.getString("DM_LOCATION"))
        requestLineMbo.setValue("FROMLOCATION",assetMbo.getString("LOCATION"))
        requestLineMbo.setValue("FROMMAINTSEC",assetMbo.getString("DM_MAINTSEC"))
        requestLineMbo.setValue("FROMCLASSSTRUCTUREID",assetMbo.getString("CLASSSTRUCTUREID"))
        if toLoc:
            requestLineMbo.setValue("TOLOCATION",toLoc)
        if toCC:
            requestLineMbo.setValue("TOCOSTCENTER",toCC)
            requestLineMbo.setValue("ccsection",toccSection)
        if toFloc:
            requestLineMbo.setValue("TOFLOC",toFloc)
        if toMaint:
            requestLineMbo.setValue("TOMAINTSEC",toMaint)
       
       
    requestLineMboSet.save()
        
    
    service.closeDialog()
    mainBean.SAVE()
    wcs = service.webclientsession()
    #wcs.showMessageBox("dmdatachange", "applyaction",[])
    
    service.log_debug("######################################## End:" + scriptName+" ######################")