/*
#-----------------------------------------------------------------------------------------
# Script Name : DMGENPAYLOAD
# Description : This script is used to generate a dynamic payload based on the request payload fields configured in the "External API's Configuration" application.
#
# Event              : Action Script object nam e:DM_EXT_API_DETAIL
# Author             : Pramod Kumar
# Version            : 1.0
# Date               : 10-Oct-2024
#-----------------------------------------------------------------------------------------
*/
owner=mbo.getOwner()

reqPayload=owner.getString("REQUEST_PAYLOAD")
soapHeader=owner.getString("SOAP_HEADER")
soapFooter=owner.getString("SOAP_FOOTER")

payloadFieldSet=owner.getMboSet("API_PAYLOAD_FIELDS")

if (payloadFieldSet.count()>0){
    payloadStr="\n"
    payload2Str="\n"
    
    for(payloadFieldMbo=payloadFieldSet.moveFirst(); payloadFieldMbo!=null; payloadFieldMbo=payloadFieldSet.moveNext())
    {
        type=payloadFieldMbo.getString("DATATYPE")
        desc=payloadFieldMbo.getString("DESCRIPTION")
        desc2=payloadFieldMbo.getString("DESCRIPTION")
        fieldName=payloadFieldMbo.getString("FIELD_NAME")
        value=payloadFieldMbo.getString("VALUE")
        if(type==="Dynamic"){
           desc=desc.replace("$"+fieldName+"$",value)
        }
        payloadStr=payloadStr+desc+"\n";
        payload2Str=payload2Str+desc2+"\n";
    }
    
    FinalPayload=soapHeader+payloadStr+soapFooter;
    DynamicPayload=soapHeader+payload2Str+soapFooter;
    owner.setValue("REQUEST_PAYLOAD",FinalPayload)
    owner.setValue("DYNAMIC_REQUEST_PAYLOAD",DynamicPayload)
    owner.setValue("RESPONSE","")
    owner.setValue("TRANS_PROCESSED",false)
  
  payloadFieldSet.close()
  service.error("Request Payload", "Generated successfully, please save the record");  
}