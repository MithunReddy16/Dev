/*
#-----------------------------------------------------------------------------------------
# Script Name : DMADHOCAPICALL
# Description : Invoke the data insertion into the interface table upon clicking the "Ad-Hoc API Call" button in the "External API's Configuration" application, based on the ad-hoc API call
#
# Event              : Action Script object nam e:DM_EXT_API_DETAIL
# Author             : Pramod Kumar
# Version            : 1.0
# Date               : 10-Oct-2024
#-----------------------------------------------------------------------------------------
*/

load("nashorn:mozilla_compat.js");
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.server);
importPackage(Packages.psdi.mbo);
importPackage(Packages.psdi.iface.mic);
importPackage(Packages.java.io);
importPackage(Packages.java.util);
importPackage(Packages.java.net);
importPackage(Packages.psdi.util);
importPackage(Packages.org.json);
importPackage(Packages.org.apache.http);
importPackage(Packages.org.apache.http.client.methods);
importPackage(Packages.org.apache.http.impl.client);
importPackage(Packages.org.apache.http.entity);
importPackage(Packages.org.apache.http.message);
importPackage(Packages.psdi.util.logging)

logger = MXLoggerFactory.getLogger("maximo.custom")

importPackage(Packages.psdi.mbo.MboConstants);
importClass(Packages.java.text.SimpleDateFormat);


var DocumentBuilderFactory = Packages.javax.xml.parsers.DocumentBuilderFactory;
var DocumentBuilder = Packages.javax.xml.parsers.DocumentBuilder;
var InputSource = Packages.org.xml.sax.InputSource;
var StringReader = Packages.java.io.StringReader;


importPackage(Packages.org.apache.commons.httpclient);
importPackage(Packages.org.apache.commons.httpclient.methods);
importPackage(Packages.org.apache.commons.httpclient.methods.StringRequestEntity);
HashMap = Java.type('java.util.HashMap');
var ctx = new HashMap();


var conn = null;
var count = 0;
var pstmt = null;
var transid = null;
var mxServer = MXServer.getMXServer();	
var conKey = mxServer.getSystemUserInfo().getConnectionKey();
conn = mxServer.getDBManager().getConnection(conKey);

params = {}
url=mbo.getString("WS_URL")
payload=mbo.getString("REQUEST_PAYLOAD")
endpoint=mbo.getString("ENDPOINT_NAME")
active = mbo.getBoolean("ACTIVE")
adhoc = mbo.getBoolean("ADHOC_CALL")
//payload_working = mbo.getBoolean("PAYLOAD_WORKING")
trans_processed = mbo.getBoolean("TRANS_PROCESSED")
active = mbo.getBoolean("ACTIVE")	
mbo.setValue("ERROR_MSG","")

if (SourceObject){
	
	if (SourceObject == "ASSET" || SourceObject == "PR" || SourceObject == "PO")
		{
		    payload=mbo.getString("DYNAMIC_REQUEST_PAYLOAD");
            payload=payload.replace("$KeyValue$",keyValueMap["$KeyValue$"]);
		    logger.debug("DM_TESTAPI Script started-keyValue Replaced " );
			if (SourceObject == "PR" || SourceObject == "PO")
			{
				payload=payload.replace("$OWNERTABLE$",keyValueMap["$OWNERTABLE$"]);
			}
		    
		    
		}
	}
		
		
logger.debug("DM_TESTAPI Script started-----------------------------x3 payload=:" + payload)	
logger.debug("DM_TESTAPI Script started-----------------------------x3 endpoint=:" + endpoint)
logger.debug("DM_TESTAPI Script started-----------------------------x3 active=:" + active)
logger.debug("DM_TESTAPI Script started-----------------------------x3 adhoc=:" + adhoc)
logger.debug("DM_TESTAPI Script started-----------------------------x3 trans_processed=:" + trans_processed)

var res = service.invokeEndpoint(endpoint, params, payload);
//var res = callApi(url, payload,"urn:getEmpInfoDMInfo");
var response=res.toString();

if (response){
    logger.debug("DM_TESTAPI Script started-----------------------------x3 response=:" + response)    
   // mbo.setValue("RESPONSE",response);
    //.setValue("PAYLOAD_WORKING",true)
    ifaceTable=mbo.getString("IFACE_TABLE")
	readTagName=mbo.getString("READ_RESP_TAG")
	wsid=mbo.getString("DM_EXT_API_DETAILID")
	count=0;
	
	processXML(response,readTagName,ifaceTable,wsid,mbo);
	createApiTransRecord(mbo)
	errorMsg=mbo.getString("ERROR_MSG").trim()	
    mboname=mbo.getName()
    //service.error("", "API Response Data:\n"+response);
	if(errorMsg){
		if (interactive)
		{service.error("", errorMsg);}
	}else{
		if (interactive)
		{service.error("", "No. of row inserted to Interface table:\n"+count);}
		if (SourceObject){
	
	if (SourceObject == "ASSET")
		{
		ctx.put("arg","FIXEDASSET_INTERFACE");
		ctx.put("runAsUserInfo",mxServer.getSystemUserInfo());
		
		service.invokeScript("DM_PUSHTOINTERFACETABLEQUEUE",ctx);
		}
	}
	}
    
    
    }
else {
	if (interactive)
	{service.error("API Response:", "No response");}
	}

function callApi(url, payload,SOAPAction) {
		
			var url = new URL(url); 

			var connection = url.openConnection();
			connection.setRequestMethod("POST"); 
			
			connection.setDoOutput(true); 
			//Content-Type: text/xml;charset=UTF-8,SOAPAction="urn:getEmpInfoDM",x-Gateway-APIKey:c2036d4a-e480-491e-8b07-7a830c98ee0d
			connection.setRequestProperty("Content-Type", "text/xml");
			connection.setRequestProperty("SOAPAction", "urn:getAssetGCCDtlQuery");
			//connection.setRequestProperty("maxauth", "bWF4YWRtaW46bWF4YWRtaW4=");
			connection.setRequestProperty("x-Gateway-APIKey", "c2036d4a-e480-491e-8b07-7a830c98ee0d");
			//connection.setRequestProperty("Authorization", "Bearer c2036d4a-e480-491e-8b07-7a830c98ee0d"); 

			// Write the payload to the output stream
			var outputStream = new DataOutputStream(connection.getOutputStream());
			outputStream.writeBytes(payload);
			outputStream.flush();
			outputStream.close();
			// Get the response
			var responseCode = connection.getResponseCode();
			
			var responseMessage = connection.getResponseMessage();
            
			// Read the response
			var reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			var response = "";
			var line;
			while ((line = reader.readLine()) != null) {
				response += line;
			}
			reader.close();

			// Log the response
			
			//print("HTTP POST Response Code: " + responseCode);
			print("HTTP POST Response Message: " + responseMessage);
			print("HTTP POST Response Body: " + response);
			
            return response;

}

function processXML(xmlString, readTagName, ifaceTable, wsid, mbo) {
logger.debug("DM_TESTAPI Script started-----------------------------x3 processXML=: started")    
	try {

		// Create a new DocumentBuilderFactory
		var factory = DocumentBuilderFactory.newInstance();
		// Create a DocumentBuilder instance
		var builder = factory.newDocumentBuilder();
		// Parse the XML string
		var inputSource = new InputSource(new StringReader(xmlString));
		var document = builder.parse(inputSource);
		var fldMappingMboSet = MXServer.getMXServer().getMboSet("DM_EXT_API_FIELDS_MAPPING", mbo.getUserInfo());
		fldMappingMboSet.setWhere("WS_ID="+wsid+" AND EXCLUDE_FIELD=0" );
		fldMappingMboSet.reset();
		print("fldMappingMboSet.count()-----------------------------XXX=:" + fldMappingMboSet.count())
		// Now you can use the document object to traverse the XML
		//var entries = document.getElementsByTagName("AssetGCCDtlInfo");
		var entries = document.getElementsByTagName(readTagName);
		count=entries.getLength();
		//service.error("", "readTagName"+readTagName);
		//print("entries.getLength()=:" + entries.getLength())
		
		for (var i = 0; i < entries.getLength(); i++) {
			var entry = entries.item(i);
			print("Item=:" + i)
			fieldsName=""
			Values=""
			for(fldMappingMbo=fldMappingMboSet.moveFirst(); fldMappingMbo!=null; fldMappingMbo=fldMappingMboSet.moveNext())
			{
				fldName=fldMappingMbo.getString("WS_FIELD_NAME")
				 print("fldName-----------------------------XXX=:" + fldName)
				
				iface_fldName=fldMappingMbo.getString("IFACETABLE_FIELD_NAME")
				dataType=fldMappingMbo.getString("MAXIMO_FIELD_DATA_TYPE")
				defaultValue=fldMappingMbo.getString("IFACETABLE_DEFAULT_VALUE")
				seqQuery=fldMappingMbo.getString("MAXIMO_DEFAULT_VALUE")
				value=""
				if (defaultValue){
					value = defaultValue;
					if (iface_fldName=="TRANSID" && defaultValue=="99"){
						if (seqQuery){
							print("seqQuery-----------------------------=:" + seqQuery)
						
							transid = getTransIDSeq(conn,seqQuery);
							//service.error("", "transid:\n"+transid);
							print("transid-----------------------------=:" + transid)
							value=transid;
						}						
					}
				}
				else{
					 
					value = entry.getElementsByTagName(fldName).item(0).getTextContent();
					value=value.replaceAll("'", " ")
					if ((dataType.toUpperCase() === "ALN" || dataType.toUpperCase() === "UPPER") && !fldMappingMbo.isNull("MAXIMO_FIELD_LENGTH"))
					{
							value = value.substring(0, fldMappingMbo.getInt("MAXIMO_FIELD_LENGTH")); 
					}
				}
			//	value = entry.getElementsByTagName(fldName).item(0).getTextContent();
               
               //service.error("", "value:"+fldName+"="+value);
			   if (value)
                {
				if (fieldsName){
					fieldsName=fieldsName+","+iface_fldName;
					if(dataType==="DATE" || dataType==="DATETIME"){
						value="TO_TIMESTAMP_TZ('" + value.replaceAll("T", ' ') + "', 'YYYY-MM-DD HH24:MI:SS.FF3TZH:TZM')";
						Values=Values+","+value+""
				    }else{
						 if (dataType==="YORN") {
                                 if (value==="Y" || value==="YES" ||value==="y" ||value==="Yes"){
                                     value=1;
                                 }else{
                                     value=0;
                                 }
                            }
						
							if(dataType==="INTEGER"){
				        	     Values=Values+","+value+" "
				        	}
				        	else{
				        	    Values=Values+",'"+value+"'"
				        	}
					}
				}
				else{
					fieldsName=iface_fldName;
					if(dataType==="DATE" || dataType==="DATETIME"){
						value="TO_TIMESTAMP_TZ('" + value.replaceAll("T", ' ') + "', 'YYYY-MM-DD HH24:MI:SS.FF3TZH:TZM')";
						Values=""+value+"";
				    }else{
				        	if (dataType==="YORN") {
                                 if (value==="Y" || value==="YES" ||value==="y" ||value==="Yes"){
                                     value=1;
                                 }else{
                                     value=0;
                                 }
                            }
				        	
				        	if(dataType==="INTEGER"){
				        	     Values=value;
				        	}
				        	else{
				        	    Values="'"+value+"'";
				        	}
				        
				    }
					
			
				}

            }


				
			}
			insertQuery = "INSERT INTO "+ifaceTable+" ("+fieldsName+") VALUES ("+Values+")";
			//service.error("", "insertQuery:\n"+insertQuery)
			logger.debug("DM_TESTAPI Script started-----------------------------x3 insertQuery=: " +insertQuery)    
			print("fieldsName-----------------------------=:" + fieldsName)
			print("Values-----------------------------=:" + Values)
			print("insertQuery-----------------------------=:" + insertQuery)
			
			
			//service.error("", "insertQuery:\n"+insertQuery);
			var conKey = mxServer.getSystemUserInfo().getConnectionKey();
	        conn = mxServer.getDBManager().getConnection(conKey);
			insertDateToInterfaceTable(conn, insertQuery, mbo);
		}
		fldMappingMboSet.cleanup()
		fldMappingMboSet.close();
		//mbo.setValue("TRANS_PROCESSED",true)
	} catch (e) {
		// Handle parsing error
		//print("Error parsing XML: " + e.message);
		mbo.setValue("TRANS_PROCESSED",false)
		mbo.setValue("ERROR_MSG",e.message)
		service.error("", "Error parsing XML::\n"+e);
	}
}

function getTransIDSeq(conn,sql) {
    var pstmt = null;
    var rs = null;
    try {
        //var sql = "SELECT maxseq.nextval FROM dual";
        print("Executing SQL: " + sql);
        pstmt = conn.prepareStatement(sql);
        rs = pstmt.executeQuery();
        if (rs.next()) {
            var nextVal = rs.getInt(1);
            print("Fetched sequence value: " + nextVal);
            return nextVal;
        } else {
            print("No value fetched from sequence.");
            return 1;
        }

    } catch (e) {
        print("Error: " + e.message);
        return null;

    } finally {
        if (rs !== null) {
            rs.close();
        }
        if (pstmt !== null) {
            pstmt.close();
        }
    }
}

function createApiTransRecord(mbo) {
	
	print("OPERATION----------------------------------:" + mbo.getString("OPERATION"));
	print("WS_ID----------------------------------:" + mbo.getInt("DM_EXT_API_DETAILID"));
	//print("REQUEST_PAYLOAD----------------------------------:" + mbo.getString("REQUEST_PAYLOAD"));
	//print("RESPONSE----------------------------------:" + mbo.getString("RESPONSE"));
	print("LAST_TRAN_DATE----------------------------------:" +mbo.getDate("LAST_TRAN_DATE"));
	print("ERROR_MSG----------------------------------:" + mbo.getString("ERROR_MSG"));
	print("FROM_DATE----------------------------------:" +mbo.getDate("LAST_TRAN_DATE"));
	print("TO_DATE----------------------------------:" +mbo.getDate("LAST_TRAN_DATE"));
	print("TRANS_PROCESSED----------------------------------:" + mbo.getBoolean("TRANS_PROCESSED"));
	print("WS_NAME----------------------------------:" + mbo.getString("WS_NAME"));

	var extApiTransMboSet = mbo.getMboSet("API_TRANS_DETAILS");
	extApiTransMbo = extApiTransMboSet.addAtEnd();
		extApiTransMbo.setValue("OPERATION",  mbo.getString("OPERATION"));
			extApiTransMbo.setValue("DESCRIPTION",  ""+count);
		extApiTransMbo.setValue("WS_ID", mbo.getInt("DM_EXT_API_DETAILID"));
		extApiTransMbo.setValue("REQUEST_PAYLOAD", mbo.getString("REQUEST_PAYLOAD"));
		extApiTransMbo.setValue("RESPONSE", mbo.getString("RESPONSE"));
	//	extApiTransMbo.setValue("LAST_TRAN_DATE", mbo.getDate("LAST_TRAN_DATE"));
		extApiTransMbo.setValue("LAST_TRAN_DATE",MXServer.getMXServer().getDate());
		extApiTransMbo.setValue("ERROR_MSG", mbo.getString("ERROR_MSG"));
		extApiTransMbo.setValue("FROM_DATE", mbo.getDate("LAST_TRAN_DATE"));
		extApiTransMbo.setValue("TO_DATE", mbo.getDate("LAST_TRAN_DATE"));
		extApiTransMbo.setValue("TRANS_PROCESSED", mbo.getBoolean("TRANS_PROCESSED"));
		extApiTransMbo.setValue("WS_NAME", mbo.getString("WS_NAME"));
	extApiTransMboSet.save();
}

function insertDateToInterfaceTable(conn, insertQuery,mbo) {
    
	
	try {

	
		pstmt = conn.prepareStatement(insertQuery);
		
		var rowsUpdated = pstmt.executeUpdate();
		
		if (rowsUpdated > 0) {
			print("Interface data inserted successfully.");
		
			
		} else {
			mbo.setValue("TRANS_PROCESSED",false)
			print("No data inserted");
		}
		conn.commit();

	} catch (e) {
		if (conn !== null) {
			conn.rollback();
		}
			mbo.setValue("TRANS_PROCESSED",false)
			mbo.setValue("ERROR_MSG","Error while inserting row into interface table :"+e.message)
		print("Error: " + e.message);
		

	} finally {
		if (pstmt !== null) {
			pstmt.close();
		}

	}
}