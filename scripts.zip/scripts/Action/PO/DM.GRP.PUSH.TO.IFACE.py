from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.util import MXApplicationException
from java.lang import System

logger = MXLoggerFactory.getLogger("maximo.custom")
server = MXServer.getMXServer()
userInfo = MXServer.getMXServer().getSystemUserInfo()

try:
    if launchPoint == "GRPPOPUSH":
        server.lookup("MIC").exportData("GRPPOInterface", "GRPINV_TEST", "SITEID='"+mbo.getString('siteid')+"'  and PONUM='"+mbo.getString('PONUM')+"'", userInfo, 100)
        service.setWarning("DM", "genericerror", ["Data propagated"])
	logger.debug("***Data export triggered successfully")

except Exception as e:
    logger.error("Error occurred: " + str(e))
    raise MXApplicationException("customcron", "updatefailed", [str(e)])