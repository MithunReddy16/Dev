/*
Script: DM_RECEIVEPO
Created By: Ashok
Date: 13-Aug-2024
Req: Receive PO 

*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_CRTRELPO**START***")
//Auto Receive the PO
	/*
	polineset=poHeaderMbo.getMboSet('POLINE')
	logger.error("***ASH***Sript DM_RECEIVEPO**Before select ALL polines")	
	polineset.selectAll()
	logger.error("***ASH***Sript DM_RECEIVEPO**Before completeReceipts()")
	polineset.completeReceipts()
	logger.error("***ASH***Sript DM_RECEIVEPO**After completeReceipts()")
	*/
	
	//poHeaderMbo.getThisMboSet().save();
	poHeaderMbo=mbo;
	//poHeaderMboSet=mbo.getMboSet("$PO","PO")
	//poHeaderMboSet.setWhere("ponum='"+ponum+"' and revisionnum='0' and siteid='"+mbo.getString("SITEID")+"' and status='APPR'")
	//logger.error("***ASH***Sript DM_RECEIVEPO**poHeaderMboSet.getCompleteWhere()="+poHeaderMboSet.getCompleteWhere())
	//poHeaderMbo=poHeaderMboSet.getMbo(0)
	logger.error("***ASH***Sript DM_RECEIVEPO**poHeaderMbo="+poHeaderMbo)
	logger.error("***ASH***Sript DM_RECEIVEPO**ponum="+poHeaderMbo.getString("PONUM"))
	if(poHeaderMbo!=null)
	{
		servrecTransSet=poHeaderMbo.getMboSet("SERVRECTRANS");
		matrecTransSet=poHeaderMbo.getMboSet("MATRECTRANS");
		polineSet=poHeaderMbo.getMboSet("POLINE")
		matrecTempFlag=0;
		servrecTempFlag=0;
		
		for(i=0;(polineMbo=polineSet.getMbo(i))!=null;i++)	
		//for(i=0;(polineServiceMbo=polineServiceSet.getMbo(i))!=null;i++)
		{
			
			logger.error("***ASH***Sript DM_RECEIVEPO**i="+i+" polinenum="+polineMbo.getString("POLINENUM"))
			if(launchPoint=="DM_RECEIVEPOMAT" && (polineMbo.getString("LINETYPE")=="ITEM" || polineMbo.getString("LINETYPE")=="MATERIAL"))
			{
				logger.error("***ASH***Sript DM_RECEIVEPO**i="+i+" LINETYPE="+polineMbo.getString("LINETYPE"))
				if(polineMbo.getInt("ORDERQTY")!=null )
				{
					logger.error("***ASH***Sript DM_RECEIVEPO**i="+i+" ORDERQTY="+polineMbo.getString("ORDERQTY"))
					matrecTransMbo=matrecTransSet.add(2)
					qty=polineMbo.getInt("ORDERQTY")
					logger.error("***ASH***Sript DM_RECEIVEPO**i="+i+" matrecTransMbo="+matrecTransMbo)
					if(polineMbo.getInt("RECEIVEDQTY")!=null)
					{
						qty=polineMbo.getInt("ORDERQTY")-polineMbo.getInt("RECEIVEDQTY")
					}
					logger.error("***ASH***Sript DM_RECEIVEPO**qty="+qty) 
					//matrecTransMbo.setValue("PONUM",polineMbo.getString("PONUM"));
					//matrecTransMbo.setValue("POREVISIONNUM",polineMbo.getString("PONUM"));	
					//logger.error("***ASH***Sript DM_RECEIVEPO** matrecTransMbo.isInspectionRequired()= "+matrecTransMbo.isInspectionRequired()) 
					
					matrecTransMbo.setValue("positeid",polineMbo.getString("SITEID"));
					matrecTransMbo.setValue("POLINENUM",polineMbo.getString("POLINENUM"),2);
					logger.error("***ASH***Sript DM_RECEIVEPO** 2") 
					matrecTransMbo.setValue("siteid",polineMbo.getString("SITEID")); 
					matrecTransMbo.setValue("CONVERSION",polineMbo.getString("CONVERSION")); 
					matrecTransMbo.setValue("ISSUE",polineMbo.getInt("ISSUE"),2); 
					if(polineMbo.getString("LINETYPE")=="MATERIAL")
					{
						matrecTransMbo.setValue("DESCRIPTION",polineMbo.getString("DESCRIPTION"),2);
					}
					matrecTransMbo.setValue("orgid",polineMbo.getString("ORGID"));
					matrecTransMbo.setValue("itemnum",polineMbo.getString("ITEMNUM"),2);
					matrecTransMbo.setValue("refwo",polineMbo.getString("refwo"),2);
					matrecTransMbo.setValue("QUANTITY",qty,2);
					matrecTransMbo.setValue("ACCEPTEDQTY",qty,2);
					//matrecTransMbo.setValue("inspectedqty",qty,2);
					matrecTransMbo.setValue("unitcost",polineMbo.getDouble("UNITCOST"),2);
					matrecTransMbo.setValue("DM_CONTREFLINEID",polineMbo.getLong("CONTREFLINEID"),2);
					matrecTransMbo.setValue("DM_WPITEMID",polineMbo.getLong("DM_WPITEMID"),2);
					logger.error("***ASH***Sript DM_RECEIVEPO**Inspectedqty="+matrecTransMbo.getString("Inspectedqty")) 
					logger.error("***ASH***Sript DM_RECEIVEPO**RECEIPTQUANTITY="+matrecTransMbo.getString("RECEIPTQUANTITY")) 
					//ACCEPTEDQTY
					//matrecTransMbo.select();
					logger.error("***ASH***Sript DM_RECEIVEPO**STATUS="+matrecTransMbo.getString("STATUS")) 
					if(matrecTransMbo.getString("STATUS")!="COMP")
					{
						logger.error("***ASH***Sript DM_RECEIVEPO**i="+i+" before matrecTransMbo approve ")
						matrecTransMbo.approve(MXServer.getMXServer().getDate());
						logger.error("***ASH***Sript DM_RECEIVEPO**i="+i+" after matrecTransMbo approve ")
					}
					//matrecTransMbo.setValue("STATUS","COMP",2);
					//polineMbo.select();
					matrecTempFlag=1;
					
					 
				}
			}
			else if(launchPoint=="DM_RECEIVEPO" && (polineMbo.getString("LINETYPE")=="SERVICE" || polineMbo.getString("LINETYPE")=="STDSERVICE"))
			{
				logger.error("***ASH***Sript DM_RECEIVEPO**i="+i+" LINETYPE="+polineMbo.getString("LINETYPE"))
				if(polineMbo.getInt("ORDERQTY")!=null )
				{
					logger.error("***ASH***Sript DM_RECEIVEPO**i="+i+" ORDERQTY="+polineMbo.getString("ORDERQTY"))
					servrecTransMbo=servrecTransSet.add(2)
					qty=polineMbo.getInt("ORDERQTY")
					logger.error("***ASH***Sript DM_RECEIVEPO**i="+i+" servrecTransMbo="+servrecTransMbo)
					if(polineMbo.getInt("RECEIVEDQTY")!=null)
					{
						qty=polineMbo.getInt("ORDERQTY")-polineMbo.getInt("RECEIVEDQTY")
					}
					logger.error("***ASH***Sript DM_RECEIVEPO**qty="+qty) 
					servrecTransMbo.setValue("POLINENUM",polineMbo.getString("POLINENUM"),2);
					//logger.error("***ASH***Sript DM_RECEIVEPO** servrecTransMbo.isInspectionRequired()= "+servrecTransMbo.isInspectionRequired()) 
					servrecTransMbo.setValue("siteid",polineMbo.getString("SITEID"));
					logger.error("***ASH***Sript DM_RECEIVEPO** 2") 
					
					servrecTransMbo.setValue("positeid",polineMbo.getString("SITEID"));
					servrecTransMbo.setValue("siteid",polineMbo.getString("SITEID"));
					servrecTransMbo.setValue("orgid",polineMbo.getString("ORGID"));
					servrecTransMbo.setValue("itemnum",polineMbo.getString("ITEMNUM"),2);
					if(polineMbo.getString("LINETYPE")=="SERVICE")
					{
						servrecTransMbo.setValue("DESCRIPTION",polineMbo.getString("DESCRIPTION"),2);
					}
					servrecTransMbo.setValue("refwo",polineMbo.getString("refwo"),2);
					servrecTransMbo.setValue("QUANTITY",qty,2);
					//servrecTransMbo.setValue("inspectedqty",qty,2);
					servrecTransMbo.setValue("ACCEPTEDQTY",qty,2);
					servrecTransMbo.setValue("unitcost",polineMbo.getDouble("UNITCOST"),2);
					servrecTransMbo.setValue("DM_CONTREFLINEID",polineMbo.getLong("CONTREFLINEID"),2);
					servrecTransMbo.setValue("DM_WPITEMID",polineMbo.getLong("DM_WPITEMID"),2);
					logger.error("***ASH***Sript DM_RECEIVEPO**i="+i+" before servrecTransMbo approve ")
					//logger.error("***ASH***Sript DM_RECEIVEPO**RECEIPTQUANTITY="+servrecTransMbo.getString("RECEIPTQUANTITY")) 
					//servrecTransMbo.approve(MXServer.getMXServer().getDate());
					if(servrecTransMbo.getString("STATUS")!="COMP")
					{
						logger.error("***ASH***Sript DM_RECEIVEPO**i="+i+" before servrecTransMbo approve ")
						servrecTransMbo.approve(MXServer.getMXServer().getDate());
						logger.error("***ASH***Sript DM_RECEIVEPO**i="+i+" after servrecTransMbo approve ")
					}
					//servrecTransMbo.select();
					logger.error("***ASH***Sript DM_RECEIVEPO**i="+i+" after servrecTransMbo approve ")
					//servrecTransMbo.setValue("STATUS","COMP",2);
					//polineMbo.select(); 
					servrecTempFlag=1;
				}
			}
			
		}
		if(matrecTempFlag==1)
		{
			logger.error("***ASH***Sript DM_RECEIVEPO** before matrecTransSet.approveReceipts() ")
			//matrecTransSet.approveReceipts(MXServer.getMXServer().getDate())
			logger.error("***ASH***Sript DM_RECEIVEPO** after matrecTransSet.approveReceipts() ")
		}
		if(servrecTempFlag==1)
		{
			logger.error("***ASH***Sript DM_RECEIVEPO** before servrecTransMbo.approveReceipts() ")
			servrecTransSet.approveReceipts(MXServer.getMXServer().getDate())
			servrecTransSet.checkAcceptAndRejectCost();
			logger.error("***ASH***Sript DM_RECEIVEPO** after servrecTransMbo.approveReceipts() ")
		}
		//polineSet.completeReceipts();
		logger.error("***ASH***Sript DM_RECEIVEPO**after approve ")
		
		//logger.error("***ASH***Sript DM_RECEIVEPO**i=" ")
	}
	//poHeaderMboSet.save();
logger.error("***ASH***Sript DM_RECEIVEPO**END***")