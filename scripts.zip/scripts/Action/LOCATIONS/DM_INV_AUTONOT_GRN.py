#---------------------------------------------------------
# *** Initial Version v1 : Mithun Reddy 09-Mar-2026 
#---------------------------------------------------------
from psdi.server import MXServer
from java.util import Date
from psdi.mbo import SqlFormat
from java.io import File
from java.text import SimpleDateFormat
from java.io import    FileOutputStream;
from com.ibm.tivoli.maximo.report.birt.admin    import ReportAdminService
from com.ibm.tivoli.maximo.report.birt.admin    import ReportAdminServiceRemote
from com.ibm.tivoli.maximo.report.birt.runtime    import ReportParameterData
from psdi.app.asset.topology.cron import SQLRunner
from psdi.util import MXException
from java.util import Vector
from psdi.common.commtmplt import CommUtil
from  psdi.util import CommonUtil
from psdi.util.logging import MXLoggerFactory

def getEmailsFromPersonGroup(personGroup, userInfo):
    mxServer = MXServer.getMXServer()
    emailList = []

    pgtSet = None
    pSet = None

    try:
        # ********* to get all persons in the person group *********
        pgtSet = mxServer.getMboSet("PERSONGROUPTEAM", userInfo)
        pgtSet.setWhere("PERSONGROUP='" + personGroup + "'")
        pgtSet.reset()
        pgtMbo = pgtSet.moveFirst()
        while pgtMbo:
            personId = pgtMbo.getString("RESPPARTYGROUP")
            if personId:
                pSet = mxServer.getMboSet("PERSON", userInfo)
                pSet.setWhere("PERSONID='" + personId + "'")
                pSet.reset()
                pMbo = pSet.moveFirst()
                if pMbo:
                    email = pMbo.getString("PRIMARYEMAIL")
                    if email and email.strip():
                        emailList.append(email.strip())
                pSet.close()
                pSet = None
            pgtMbo = pgtSet.moveNext()

    finally:
        if pSet:
            pSet.close()
        if pgtSet:
            pgtSet.close()
    return emailList

def getEmailsFromSecurityGroup(groupName, userInfo):
    mxServer = MXServer.getMXServer()
    emailList = []

    grpSet = None
    muSet = None 
    pSet = None

    try:
        # *********to get all users in the group *********
        grpSet = mxServer.getMboSet("GROUPUSER", userInfo)
        grpSet.setWhere("GROUPNAME in ('INV_WHMANAGER','INV_PLANNER')")
        grpSet.reset()
        grpMbo = grpSet.moveFirst()
        while grpMbo:
            userId = grpMbo.getString("USERID")
            # ****** to get the personid from maxuser *****
            muSet = mxServer.getMboSet("MAXUSER", userInfo)
            muSet.setWhere("USERID='" + userId + "'")
            muSet.reset()
            muMbo = muSet.moveFirst()
            if muMbo:
                personId = muMbo.getString("PERSONID")
                #  **** to get primary email from person
                if personId:
                    pSet = mxServer.getMboSet("PERSON", userInfo)
                    pSet.setWhere("PERSONID='" + personId + "'")
                    pSet.reset()

                    pMbo = pSet.moveFirst()
                    if pMbo:
                        email = pMbo.getString("PRIMARYEMAIL")
                        if email and email.strip():
                            emailList.append(email.strip())
                    pSet.close()
                    pSet = None
            muSet.close()
            muSet = None

            grpMbo = grpSet.moveNext()

    finally:
        if pSet:
            pSet.close()
        if muSet:
            muSet.close()
        if grpSet:
            grpSet.close()

    return emailList


def buildMailBody(MsgBody):
    mailBody = ""
    mailBody = mailBody + "<HTML><BODY>"
    mailBody = mailBody + MsgBody
    mailBody = mailBody + " " + "\r\n"
    mailBody = mailBody + "\r\n"
    mailBody = mailBody + "<br>"
    mailBody = mailBody + " " + "\r\n"
    mailBody = mailBody + " " + "\r\n"
    mailBody = mailBody + "=========================================================================================================================\r\n"
    mailBody = mailBody + "<br>"
    mailBody = mailBody + "Please Note - This is Auto Generated email from - Maximo System\r\n"
    mailBody = mailBody + "<br>"
    mailBody = mailBody + "=========================================================================================================================\r\n"
    mailBody = mailBody + "</BODY></HTML>" + "\r\n"
    return mailBody


## ******* Starting the Script***************    
logger = MXLoggerFactory.getLogger("maximo.crontask.ESCALATION")
logger.debug("** Send Email Notification with attachment for GRN ****")
mxServer = MXServer.getMXServer()
userInfo = mxServer.getSystemUserInfo()
reportservice = mxServer.lookup("BIRTREPORT")
now = Date()

#tempfolder = "/output"
#tempfolder = "/doclinks/ReportsTemp"

tempfolder = "/tmp"

conKey = None
con = None
stmt = None
rs = None

logger.debug("*****Starting query check before report generation*******")

# Step 1: Run direct SQL query
now = Date()
logger.debug("*****Starting query check before report location is *******"+str(mbo.getString("LOCATION")))
fmt = SimpleDateFormat("yyyyMMddHHmmss")
sql =" select count(*) as cnt from dm_INV_GRN where loc='"+mbo.getString("LOCATION")+"' "

conKey = mxServer.getSystemUserInfo().getConnectionKey()
con = mxServer.getDBManager().getConnection(conKey)
stmt = con.createStatement()
rs = stmt.executeQuery(sql)

recordCount = 0
if rs.next():
    recordCount = rs.getInt("cnt")
    #recordCount = 1

logger.debug("******Record count from query: " + str(recordCount))

# Step 2: If records exist, generate report
if recordCount > 0:
    logger.debug("*****Records found. Generating report****")
    filename = "GRNAsOnDate" + fmt.format(now) + ".pdf"
    para = ReportParameterData()
    para.addParameter("WH", "=" + str(mbo.getString("LOCATION")))
    #para.addParameter("where", " 1=1 ")
    outputFile = File(tempfolder, filename)
    outputFile.getParentFile().mkdirs()
    logger.debug("*****Records found. Generating report* before running report****")
    reportOutput = reportservice.runReport(userInfo,"DM_INV_GRN.rptdesign","DM_PLUSTREC",para, outputFile.getName(),ReportAdminServiceRemote.OUTPUT_FORMAT_PDF )
    logger.debug("*****Report byte size: " + str(len(reportOutput)))
    fileoutputstream = FileOutputStream(outputFile.getAbsolutePath())
    fileoutputstream.write(reportOutput)
    fileoutputstream.flush()
    fileoutputstream.close() 
    logger.debug("*****Report generated: " + outputFile.getAbsolutePath())
    logger.debug("*****File size: " + str(outputFile.length()))
    
    # Step 3: Send email with attachment
    fileNameVector =Vector()
    fileNameVector.append(outputFile.getAbsolutePath())
    MsgBody = "Dear/s,</br>FYA, Please find attachment with list of Items in Inventory GRN AsOnDate for the store "+mbo.getString("LOCATION")+"</br>"
    mailBody = buildMailBody(MsgBody)
    subject="Inventory Items GRN AsOn Date for store "+mbo.getString("LOCATION")
    sgEmails = getEmailsFromSecurityGroup("", userInfo)
    pgEmails = getEmailsFromPersonGroup(mbo.getString("DM_INVSTK"),userInfo)
    emails = sgEmails + pgEmails
    logger.debug("******emails is ****** ")
    emailList = []
    for e in emails:
        emailList.append(str(e))
    logger.debug(str(emailList))
    emailString = ",".join(emailList)
    logger.debug("************Emails: " + emailString)
    MXServer.sendEMail(emailString, None, None, "maxadmin@maximo.dm.ae",subject,mailBody,None, [outputFile.getAbsolutePath()], None)
    logger.debug("****Email sent successfully***")
    outputFile.delete()
else:
    logger.debug("****No records found. Report not generated. Email not sent***")

if rs is not None:
    rs.close()

if stmt is not None:
    stmt.close()

if conKey is not None:
    mxServer.getDBManager().freeConnection(conKey)