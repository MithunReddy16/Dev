# Script : DM.MAIL.NOTIF.ACTION
# Description: SEND EMAIL WITH ALL ERROR MESSAGE IN LAST 1 HOUR
# @author Amir Anwar
# Revision History :
# Feb26 AANWAR - Intial Version
#-----------------------------------------------------------------------------------------
from psdi.server import MXServer
from java.util import Date
from psdi.util import MXException
from psdi.app.common import DateUtility
from java.text import SimpleDateFormat
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import SqlFormat
from java.util import HashMap


logger = MXLoggerFactory.getLogger("maximo.custom")
logger.debug("==================== DM.MAIL.NOTIF.ACTION: START  =================================")
mxServer=MXServer.getMXServer()


###############################################################################################################
def getResultinTable(SQLTEXT):
	dbManager = mxServer.getDBManager();
	con = dbManager.getConnection(mxServer.getSystemUserInfo().getConnectionKey());
	stmt = con.createStatement();
	rs = stmt.executeQuery(SQLTEXT);
	#md = rs.getMetaData();	
	dbManager.freeConnection(mbo.getUserInfo().getConnectionKey());	
	return rs
###############################################################################################################

# @param1 = tableHeader , @para2 = rowAttributes {fieldName:filedType}, @param3 = emailTo ["aa@dm.ae","bb@dm.ae"],  @param4 = emailFrom ,
#   @param5 = emailCC
# @param6 = mboDataSet , @para7 = subject , @param8= MsgBody , @param9= types
def callTemplateScript(args):
	
	service.invokeScript("DM.MAIL.NOTIF.TEMPLATE",args)
	

if launchPoint == "ACTION1":
	IntErrorSet = mxServer.getMboSet('MAXINTMSGTRKDTL',mxServer.getSystemUserInfo())
	IntErrorSet.setWhere("STATUS='ERROR' AND  EXISTS (SELECT 1 FROM MAXINTERROR MSGREP WHERE MSGREP.MESSAGEID = MAXINTMSGTRKDTL.MEAMSGID and deleteflag =0) and datediff(HOUR,MAXINTMSGTRKDTL.statusdate,GETDATE()) <= 1")
	MsgBody = "Dear/s,</br> FYA, Errnomous records in the last hour.</br>"
	vars = HashMap()
	
	vars.put("tableHeader",["Asset","Description"])
	vars.put("rowAttributes",{"ASSETNUM":"ALN","DESRIPTION":"ALN"})
	vars.put("emailTo",["sword_aanwar@dm.ae","sword_aanwar@dm.ae"])
	vars.put("emailFrom","maximo-stg@dm.ae")
	vars.put("emailCC",None)
	#vars.put("mboDataSet",IntErrorSet)
	#vars.put("type","mboset")
	vars.put("type","RS")
	vars.put("rs",getResultinTable("SELECT ASSETNUM,DESCRIPTION FROM ASSET WHERE ASSETNUM='1436040' "))
	vars.put("subject","Asset Without xx")
	vars.put("MsgBody",MsgBody)
	callTemplateScript(vars)
	
	


logger.debug("==================== .DM.MAIL.NOTIF.ACTION: END  =================================")