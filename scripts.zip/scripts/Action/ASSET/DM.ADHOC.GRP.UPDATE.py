############################
#
# By Amir
# V1 - 20-09-25 - Initial Version
###########################

from psdi.server import MXServer
from  psdi.common.context import UIContext
#from psdi.webclient.system.controller import SessionContext, Utility, WebClientEvent
from com.ibm.tivoli.maximo.script import ScriptService
from psdi.mbo import SqlFormat
from psdi.util import MXException
from java.util import HashMap


def setError(Msg):
		#global errorkey,errorgroup,params
		#errorkey='scriptvalidationerror'
		#errorgroup='scriptval'
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)
        
mxServer = MXServer.getMXServer();	
ctx = HashMap()
ctx.put("mbo", mbo)

mboName = mbo.getName().upper()
OperationName = None
keyValue = None
keyValueMap = {}
if mboName == "ASSET":
    OperationName = "FixedAssets-SingleAsset" 
    keyValue = str(mbo.getInt("DM_GRPASSETID"))
    keyValueMap["$KeyValue$"] = keyValue
    if mbo.isNull("DM_GRPASSETID"):
        setError("This Asset does not hava a valid GRP number, Please contact system administrator")

elif mboName == "PR":
    OperationName = "getPOPRApprovalHist"
    keyValue = str(mbo.getInt("DM_GRPPRHEADERID"))
    
    if mbo.isNull("DM_GRPPRHEADERID"):
        setError("This PR does not hava a valid GRP number, Please contact system administrator")
    keyValueMap["$KeyValue$"] = keyValue
    keyValueMap["$OWNERTABLE$"] = "REQUISITION"
elif mboName == "PO":
    OperationName = "getPOPRApprovalHist"
    keyValue = str(mbo.getInt("DM_POHEADERID")    )
    if mbo.isNull("DM_POHEADERID"):
        setError("This PO does not hava a valid GRP number, Please contact system administrator") 
    keyValueMap["$KeyValue$"] = keyValue
    keyValueMap["$OWNERTABLE$"] = "PO"

        




extApiMboSet = mxServer.getMboSet("DM_EXT_API_DETAIL", mxServer.getSystemUserInfo());
extApiMboSet.setWhere("OPERATION='"+OperationName+"'" );
extApiMboSet.reset()
extApiMbo = extApiMboSet.moveFirst()
if (extApiMbo):
    ctx.put("mbo",extApiMbo)
    ctx.put("SourceObject",mboName)
    ctx.put("keyValueMap",keyValueMap)
    service.invokeScript("DMADHOCAPICALL", ctx)
    if interactive:
        session = service.webclientsession();
        session.showMessageBox("scriptval", "scriptinfo", ["Request is in progress , come back in few seconds."]);
    
else:
    setError("Something went wronge, Please contact system administrator")