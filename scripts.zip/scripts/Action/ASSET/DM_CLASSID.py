classid = mbo.getString("CLASSSTRUCTUREID")
mbo.setValueNull("CLASSSTRUCTUREID")
mbo.setValue('CLASSSTRUCTUREID',classid,2l)