# lines Modified by Mithun 
from psdi.server import MXServer
from java.util import Date
from psdi.mbo import SqlFormat
from java.io import File
from java.text import SimpleDateFormat
from java.io import    FileOutputStream;
from com.ibm.tivoli.maximo.report.birt.admin    import ReportAdminService
from com.ibm.tivoli.maximo.report.birt.admin    import ReportAdminServiceRemote
from com.ibm.tivoli.maximo.report.birt.runtime    import ReportParameterData
from psdi.app.asset.topology.cron import SQLRunner
from psdi.util import MXException
from java.util import Vector
from psdi.common.commtmplt import CommUtil
from  psdi.util import CommonUtil
from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("******Mithun Script execution started for DM_GKNOTIFICATION *******")

def buildMailBody(MsgBody):
    mailBody = ""
    mailBody = mailBody + "<HTML><BODY>"
    mailBody = mailBody + MsgBody
    mailBody = mailBody + " " + "\r\n"
    mailBody = mailBody + "\r\n"
    mailBody = mailBody + "<br>"
    mailBody = mailBody + " " + "\r\n"
    mailBody = mailBody + " " + "\r\n"
    mailBody = mailBody + "=========================================================================================================================\r\n"
    mailBody = mailBody + "<br>"
    mailBody = mailBody + "Please Note - This is Auto Generated email from - Maximo System\r\n"
    mailBody = mailBody + "<br>"
    mailBody = mailBody + "=========================================================================================================================\r\n"
    mailBody = mailBody + "</BODY></HTML>" + "\r\n"
    return mailBody
    

def getToEmaillist(fromStore) :
    emailList = []
    fromStoreTemplate="INV_"+fromStore+"_GK"
    ctSet = mbo.getMboSet("$CT", "COMMTEMPLATE", "templateid='"+fromStoreTemplate+"'")
    ct = ctSet.getMbo(0)
    if ct:
        emailList = ct.convertSendTo("COMMTMPLT_SENDTO",mbo)
        """
        ctSendEmailSet=ct.getMboSet("COMMTMPLT_SENDTOEMAIL")
        ctSendEmailMbo=ctSendEmailSet.moveFirst()
        while(ctSendEmailMbo):
            emailValue =ctSendEmailMbo.getString("SENDTOVALUE")
            if emailValue:     
                emailList.append(emailValue)
            ctSendEmailMbo=ctSendEmailSet.moveNext()
        logger.debug("*****emaillistbefore*******")  """ 
    return emailList

    
## ******* Starting the Script***************    
    
mxServer = MXServer.getMXServer()
userInfo = mxServer.getSystemUserInfo()
reportservice = mxServer.lookup("BIRTREPORT")

tempfolder = "/tmp"

logger.debug("*****Starting query check before report generation*******")



packlistnum=mbo.getString("DM_PACKLISTNUM")
storeroom=mbo.getString("DM_STOREROOM")
logger.debug("*****GK Generating report****")
filename = "GatePassForm-PL" + packlistnum + ".pdf"
para = ReportParameterData()
para.addParameter("ref_num", "=" + str(mbo.getString("DM_PACKLISTNUM")))
outputFile = File(tempfolder, filename)
outputFile.getParentFile().mkdirs()
reportOutput = reportservice.runReport(userInfo,"DM_INV_GatePassForm.rptdesign","DM_PACKLIST",para, outputFile.getName(),ReportAdminServiceRemote.OUTPUT_FORMAT_PDF )
logger.debug("*****Report byte size: " + str(len(reportOutput)))
fileoutputstream = FileOutputStream(outputFile.getAbsolutePath())
fileoutputstream.write(reportOutput)
fileoutputstream.flush()
fileoutputstream.close() 
logger.debug("*****Report generated: " + outputFile.getAbsolutePath())
logger.debug("*****File size: " + str(outputFile.length()))

# Step 3: Send email with attachment
fileNameVector =Vector()
fileNameVector.append(outputFile.getAbsolutePath())
MsgBody = "Dears ,</br></br>FYA, Please find attachment with list of Items in  Ready to Move from WH stores. </br>"
mailBody = buildMailBody(MsgBody)
subject="PL-"+packlistnum+" Items are ready to move from WH store."

emaillist=getToEmaillist(storeroom)
#toStr = ",".join(emaillist)
logger.debug("*****email list : " + str(emaillist))


if emaillist:
   MXServer.sendEMail(emaillist, None, None, "maxadmin@maximo.dm.ae",subject,mailBody,None, [outputFile.getAbsolutePath()], None)
   logger.debug("*****Email Sent Sucessfully ")
else:
    logger.debug("***No recipients found for template INV_" + storeroom + "_GK")


outputFile.delete()
logger.debug("*****output file deleted***** ")