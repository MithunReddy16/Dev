/*
Script: DM_UPDIU
Created By: Ashok
Date: 23-Nov-2024
Req: Update the Pack List Number to the Inventory Usage which are created from pick list whith status of STAGED


*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)



//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_UPDIU**START***")
logger.error("***ASH***Sript DM_UPDIU**mbo="+mbo)
//logger.error("***ASH***Sript DM_UPDIU**Owner mbo="+mbo.getOwner())
session=service.webclientsession()
databean=session.getDataBean("DM_ISSUEIU_grid2_1_1_contlines_table")
logger.error("***ASH***Sript DM_UPDIU**databean="+databean)
if(databean!=null)
{
	//woMbo=mbo.getOwner();
	
	logger.error("***ASH***Sript DM_UPDIU**DM_PACKLISTNUM="+mbo.getString("DM_PACKLISTNUM"))
	//invReserveSet=mbo.getMboSet("DM_CONTRACTLINES")
	invUseSet1=databean.getMboSet();
	selectedRecords=invUseSet1.getSelection()
	logger.error("***ASH***Sript DM_UPDIU**invUseSet1 selectedRecords size ="+selectedRecords.size())
	
	if (selectedRecords.size()>0)
	{
		iterator=selectedRecords.iterator()
		while (iterator.hasNext())
		{
			invUseMbo1=iterator.next()
			logger.error("***ASH***Sript DM_UPDIU**IVR Created invusenum="+invUseMbo1.getString("invUseNum"));
			invUseMbo1.setValue("DM_PACKLISTNUM",mbo.getString("DM_PACKLISTNUM"),2)
			
		}
	}
	else
	{
		logger.error("***ASH***Sript DM_UPDIU**selectedRecords size is 0")
	}

}
else
{
	logger.error("***ASH***Sript DM_UPDIU**databean is null ")
}
invUseSet1.save();
service.closeDialog();
logger.error("***ASH***Sript DM_UPDIU**END***")