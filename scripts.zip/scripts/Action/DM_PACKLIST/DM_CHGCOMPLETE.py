from psdi.server import MXServer
from psdi.mbo import SqlFormat
from psdi.util import MXException


from psdi.util.logging import MXLoggerFactory

mxServer = MXServer.getMXServer()
logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_CHGCOMPLETE**START***")
logger.error("***ASH***Sript DM_CHGCOMPLETE**mbo=");

if mbo.getString('DM_STATUS') in ('ENTERED') :
	
	
	invUseSet = MXServer.getMXServer().getMboSet("INVUSE",MXServer.getMXServer().getSystemUserInfo())
	invUseSet.setWhere("DM_PACKLISTNUM='" + mbo.getString("DM_PACKLISTNUM") + "' AND STATUS not in ('COMPLETE','CANCELLED','SHIPPED')")
	invUseSet.reset();
	invUseMbo=invUseSet.moveFirst()
	
	while invUseMbo:
		useType = invUseMbo.getString("USETYPE")
		if (useType in ('ISSUE','MIXED')):
			invUseMbo.changeStatus("COMPLETE",	 MXServer.getMXServer().getDate(), "Status change from Pack List "+mbo.getString("DM_PACKLISTNUM"), 2)

		elif (useType == 'TRANSFER'):
			invUseMbo.changeStatus("SHIPPED",	 MXServer.getMXServer().getDate(), "Status change from Pack List "+mbo.getString("DM_PACKLISTNUM"), 2)
			invuseLine = invUseMbo.getMboSet('INVUSELINE').moveFirst()
			ShipNum=invUseMbo.getString('INVUSENUM')
			if invuseLine :
				if not invuseLine.isNull('PONUM'):
					ShipNum= invuseLine.getString('PONUM') + "-" + ShipNum
			invUseMbo.setValue('SHIPMENT.SHIPMENTNUM',ShipNum )

		invUseSet.save()
		invUseSet = MXServer.getMXServer().getMboSet("INVUSE",MXServer.getMXServer().getSystemUserInfo())
		invUseSet.setWhere("DM_PACKLISTNUM='" + mbo.getString("DM_PACKLISTNUM") + "' AND STATUS not in ('COMPLETE','CANCELLED','SHIPPED')")
		invUseSet.reset();
		invUseMbo=invUseSet.moveFirst()


	invUseSet.close()
	invUseSet.cleanup()
	mbo.setValue("DM_STATUS","COMPLETE",2)
	mbo.getThisMboSet().save(2);

else:
	errorgroup="dm_picklist"
	errorkey="notvalidstatus"