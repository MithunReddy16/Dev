/*
#-----------------------------------------------------------------------------------------
# Script Name : DM_PUSHTOINTERFACETABLEQUEUE
# Description : Push data to Maximo Interface Table Queue
#
# Event              : Script called from Cron task(GRP_MASTER_PROC)
# Author             : Pramod Kumar
# Version            : 1.0
# update Date               : 23-May-2025
# Version 2 - 28-Auguest-2025 - AA - Extend Classification Mapping to ONe-to-Many ( Asset Interface )
# Version 3 - 21-OCT-2025 - AA - Add Vendor Code to Asset Interface
# Version 4 - 22-OCT-2025 - AA - Inventory Add Finicial Period
# Version 4 - 27-OCT-2025 - AA - Add POPR Approval History
# Version 5 - 27-OCT-2025 - AA - Employee Interface - used GRPNUM instead of Email to find existing persons
#-----------------------------------------------------------------------------------------
*/
 
load("nashorn:mozilla_compat.js");
importPackage(Packages.psdi.util.logging)
var logger = MXLoggerFactory.getLogger("maximo.custom");
 
importPackage(Packages.psdi.server);
importPackage(Packages.psdi.mbo);
importPackage(Packages.psdi.iface.mic);
importPackage(Packages.java.io);
importPackage(Packages.java.util);
importPackage(Packages.psdi.util);
importPackage(Packages.org.json);
importPackage(Packages.org.apache.http);
importPackage(Packages.org.apache.http.client.methods);
importPackage(Packages.org.apache.http.impl.client);
importPackage(Packages.org.apache.http.entity);
importPackage(Packages.org.apache.http.message);

importPackage(Packages.psdi.mbo.MboConstants);
importClass(Packages.java.text.SimpleDateFormat);

var conn = null;
var pstmt = null;
var transid = null;
var mxServer = MXServer.getMXServer();
/*----------------------------------------------Main code execution started here--------------------------------------*/


var conKey = mxServer.getSystemUserInfo().getConnectionKey();
conn = mxServer.getDBManager().getConnection(conKey);

if (arg == "EXCHANGE_INTERFACE") {
	/*Code to handle Exchange Rate -----------------------------------------------------------*/
	getDataFromInterfaceTable(conn, "EXCHANGE_INTERFACE", "EX_GRP", "ES_EXCHANGERATE")
} else if (arg == "CHARTOFACCOUNTS_INTERFACE") {
	/*Code to handle Chart Fo Accounts -------------------------------------------------------*/
	getDataFromInterfaceTable(conn, "CHARTOFACCOUNTS_INTERFACE", "EX_GRP", "ES_CHARTOFACCOUNTS")
} else if (arg == "FIXEDASSET_INTERFACE") {
	/*Code to handle Fixed Asset -------------------------------------------------------------*/
	getDataFromInterfaceTable(conn, "FIXEDASSET_INTERFACE", "EX_GRP", "ES_FIXEDASSET");
} else if (arg == "FINANCIALPERIOD_INTERFACE") {
	/*Code to handle Financial Period --------------------------------------------------------*/
	getDataFromInterfaceTable(conn, "FINANCIALPERIOD_INTERFACE", "EX_GRP", "ES_FINANCIALPERIOD");
} else if (arg == "LOCATION_INTERFACE") {
	/*Code to handle Location ----------------------------------------------------------------*/
	getDataFromInterfaceTable(conn, "LOCATION_INTERFACE", "EX_GRP", "ES_MAINLOCATION");
} else if (arg == "EMPLOYEE_INTERFACE") {
	/*Code to handle Employee ----------------------------------------------------------------*/
	getDataFromInterfaceTable(conn, "EMPLOYEE_INTERFACE", "EX_GRP", "ES_EMPLOYEE");
}else if (arg == "GRPSTOREORG_IFACE") {
	/*Code to handle Employee ----------------------------------------------------------------*/
	getDataFromInterfaceTable(conn, "GRPSTOREORG_IFACE", "GRPINVENTORY", "DM_GRPSTOREORG");
}else if (arg == "ORGADDRESS_IFACE") {
	/*Code to handle Employee ----------------------------------------------------------------*/
	getDataFromInterfaceTable(conn, "ORGADDRESS_IFACE", "GRPINVENTORY", "DM_ORGADDRESS");
}
else if (arg == "GRPFINPERIOD_IFACE") {
	/*Code to handle Employee ----------------------------------------------------------------*/
	getDataFromInterfaceTable(conn, "GRPFINPERIOD_IFACE", "GRPINVENTORY", "GRP_GRPFINPERIOD");
}

else if (arg == "GRPPOPRAPPRHIST_IFACE") {
	/*Code to handle Employee ----------------------------------------------------------------*/
	getDataFromInterfaceTable(conn, "GRPPOPRAPPRHIST_IFACE", "GRPINVENTORY", "GRP_POPRAPPRHIST");
}

if (conn !== null) {
		mxServer.getDBManager().freeConnection(conKey);
	}

/*----------------------------------------------Main code execution Ended --------------------------------------*/

function getDataFromInterfaceTable(conn, interfaceTable, extSys, es) {

	var interfaceTableSet = MXServer.getMXServer().getMboSet(interfaceTable, runAsUserInfo);
	interfaceTableSet.setWhere("CURRENT_DATA_STATUS='RECEIVED'");
	interfaceTableSet.reset();
	var interfaceTableMbo = interfaceTableSet.moveFirst();
	while (interfaceTableMbo !== null) {
		var sendToUque = true;
		transid = interfaceTableMbo.getInt("TRANSID");
		/*----Code to process EXCHANGE_INTERFACE Interface data to Maximo Interface Queue -----------------------------------------------------------*/
		if (interfaceTable == "EXCHANGE_INTERFACE") {
			var activateDate = interfaceTableMbo.getDate("CONVERSION_DATE");
			var from_currency = interfaceTableMbo.getString("FROM_CURRENCY");
			var to_currency = interfaceTableMbo.getString("TO_CURRENCY");
			var sdf = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
			var expire_date = Calendar.getInstance();
			expire_date.setTime(activateDate);
			expire_date.add(Calendar.YEAR, 20)
			var expireDate = sdf.format(expire_date.getTime());
			var exchangeMboSet = MXServer.getMXServer().getMboSet("EXCHANGE", runAsUserInfo);
			exchangeMboSet.setWhere(" CURRENCYCODE='" + from_currency + "' and CURRENCYCODETO='" + to_currency + "' and ACTIVEDATE < to_date('" + sdf.format(activateDate) + "','YYYY-MM-DD HH24:MI:SS') and expiredate > to_date('" + sdf.format(activateDate) + "','YYYY-MM-DD HH24:MI:SS')");
			exchangeMboSet.reset();
			
			if (exchangeMboSet.count() > 0) {
				var expDate = Calendar.getInstance();
				expDate.setTime(activateDate);
				expDate.add(Calendar.HOUR_OF_DAY, -24)
				exchangeMbo = exchangeMboSet.getMbo(0);
				exchangeMbo.setValue("expiredate", expDate.getTime(), MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
				exchangeMboSet.save();

			}
			query = "update EXCHANGE_INTERFACE set EXPIREDATE=to_date('" + expireDate + "','YYYY-MM-DD HH24:MI:SS') where transid=" + transid + " ";
			updateInterface(conn, interfaceTable, query)
			sendToUque = true;
			exchangeMboSet.cleanup()
			exchangeMboSet.close();
		}
		/*----Code to process CHARTOFACCOUNTS_INTERFACE Interface data to Maximo Interface Queue -----------------------------------------------------------*/
		if (interfaceTable == "CHARTOFACCOUNTS_INTERFACE") {
			getGLComponentDataFromInterfaceTable(interfaceTable, transid);
		}
		/*----Code to process FINANCIALPERIOD_INTERFACE Interface data to Maximo Interface Queue -----------------------------------------------------------*/
		if (interfaceTable == "FINANCIALPERIOD_INTERFACE") {
			var CLOSING_STATUS = interfaceTableMbo.getString("CLOSING_STATUS")
			if (CLOSING_STATUS == "C") {
				var sdf1 = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
				var currentDate = MXServer.getMXServer().getDate();
				var closeDate = sdf1.format(currentDate);
				SqlQuery = "UPDATE FINANCIALPERIOD_INTERFACE set PERIODCLOSEDATE=TO_DATE('" + closeDate + "', 'YYYY-MM-DD HH24:MI:SS'),CLOSEDATE= TO_DATE('" + closeDate + "', 'YYYY-MM-DD HH24:MI:SS')";
				updateInterface(conn, interfaceTable, SqlQuery)
			}

		}

		/*----Code to process LOCATION_INTERFACE Interface data to Maximo Interface Queue -----------------------------------------------------------*/
		if (interfaceTable == "LOCATION_INTERFACE") {
			var status = interfaceTableMbo.getString("STATUS")
			var city = interfaceTableMbo.getString("CITY")
			var cityDescription = interfaceTableMbo.getString("CITYDESCRIPTION")
			var site = interfaceTableMbo.getString("SITE")
			var siteDescription = interfaceTableMbo.getString("SITEDESCRIPTION")
			var builDing = interfaceTableMbo.getString("BUILDING")
			var buildingDescription = interfaceTableMbo.getString("BUILDINGDESCRIPTION")
			var owner = interfaceTableMbo.getString("OWNER")
			var ownerDescription = interfaceTableMbo.getString("OWNERDESCRIPTION")
			var parent1=city + "-" + site + "-" + builDing + "-" + owner;

			if (status = "Active") {
				status = "OPERATING"
			}
			SqlQuery = "update LOCATION_INTERFACE set LOCHIERARCHY_SYSTEMID='DM', LOCHIERARCHY_PARENT='" + parent1 + "', STATUS='" + status + "' where transid=" + transid + " ";
			//SqlQuery = "update LOCATION_INTERFACE set  STATUS='" + status + "' where transid=" + transid + " ";
			updateInterface(conn, interfaceTable, SqlQuery)
			/*----Code to create Parent Locations -----------------------------------------------------------*/
			createParentLocations(city, cityDescription);
			createParentLocations(city + "-" + site, cityDescription+" "+siteDescription);
			createParentLocations(city + "-" + site + "-" + builDing, cityDescription+" "+siteDescription+" "+buildingDescription);
			createParentLocations(city + "-" + site + "-" + builDing + "-" + owner, cityDescription+" "+siteDescription+" "+buildingDescription+" "+ownerDescription);
           /*----Code to create Location Hierarchy -----------------------------------------------------------*/
			createLocationHierarchy(city, "DM", "DM", true, "DM", "DMORG")
			createLocationHierarchy(city + "-" + site, city, "DM", true, "DM", "DMORG")
			createLocationHierarchy(city + "-" + site + "-" + builDing, city + "-" + site, "DM", true, "DM", "DMORG")
			createLocationHierarchy(city + "-" + site + "-" + builDing + "-" + owner, city + "-" + site + "-" + builDing, "DM", true, "DM", "DMORG")

		}
		/*----Code to process EMPLOYEE_INTERFACE Interface data to Maximo Interface Queue -----------------------------------------------------------*/
		if (interfaceTable == "EMPLOYEE_INTERFACE") {
			    /*
				var status="";
				var EMPLOYEE_NUMBER=""
				var DM_GRPEMPNUM=""
				var EMPLOYEE_NUMBER = interfaceTableMbo.getString("EMPLOYEE_NUMBER")
				var CONTINGENT_NUMBER = interfaceTableMbo.getString("CONTINGENT_NUMBER")
				if (CONTINGENT_NUMBER){
					EMPLOYEE_NUMBER=CONTINGENT_NUMBER;
				}
				DM_GRPEMPNUM=EMPLOYEE_NUMBER
				//------------------------------------------------------------------------


                var personSet = MXServer.getMXServer().getMboSet("PERSON", runAsUserInfo);
				personSet.setWhere(" DM_GRPEMPNUM='" + DM_GRPEMPNUM + "' ");
				personSet.reset();
                person= personSet.moveFirst()

			    if (person){
			        EMPLOYEE_NUMBER = person.getString("PERSONID");        		    
			    }

                /*
                //Disabled Since email can be duplicated for some ppl
			    var EMAIL_ADDRESS = interfaceTableMbo.getString("EMAIL_ADDRESS")
			    if (EMAIL_ADDRESS!=""){
			        var emailMboSet = MXServer.getMXServer().getMboSet("EMAIL", runAsUserInfo);
        			 emailMboSet.setWhere("upper(emailaddress)='" + EMAIL_ADDRESS.toUpperCase() + "' and ISPRIMARY=1");
        			 emailMboSet.reset();
        			 if (emailMboSet.count() > 0) {
        				EMPLOYEE_NUMBER = emailMboSet.getMbo(0).getString("PERSONID");
        				
        		    }
			    }
                
				//------------------------------------------------------------------------				
				
				var SUPERVISOR_NUMBER = interfaceTableMbo.getString("SUPERVISOR_NUMBER")
				var SUPERVISOR_CONTINGENT_NUMBER = interfaceTableMbo.getString("SUPERVISOR_CONTINGENT_NUMBER")
				
				if (SUPERVISOR_CONTINGENT_NUMBER){
					SUPERVISOR_NUMBER=SUPERVISOR_CONTINGENT_NUMBER;
				}
				var ASSIGNMENT_STATUS_EN = interfaceTableMbo.getString("ASSIGNMENT_STATUS_EN")
				
				if (ASSIGNMENT_STATUS_EN == "Active Contingent Assignment" || ASSIGNMENT_STATUS_EN =="Active Assignment") {
					status = "ACTIVE"
				}
                else
                    {
					status = "INACTIVE"
				}
				//--------------------------------------------------------------------------------------------
		        var orgid = interfaceTableMbo.getString("ORGANIZATION_ID")
		        var emp_section = "";
                var emp_department = "";
                var emp_sector = "";
		        var orgHierarchyMboSet1 = MXServer.getMXServer().getMboSet("DM_ORGHIERARCHY", runAsUserInfo);
                   orgHierarchyMboSet1.setWhere("UNITID='" + orgid + "' ");
                   //orgHierarchyMboSet1.setWhere("COSTCENTER='" + orgid + "' ");
                   orgHierarchyMboSet1.reset();
                   if (orgHierarchyMboSet1.count() > 0) {
                      orgHierarchyMbo1 = orgHierarchyMboSet1.getMbo(0)
                      sectionType = orgHierarchyMbo1.getString("UNITTYPE")
                      departmentType = orgHierarchyMbo1.getString("PARENT1TYPE")
                      sectorType = orgHierarchyMbo1.getString("PARENT2TYPE")
                      if (sectionType == "SECTION") {
                         emp_section = orgid;//orgHierarchyMbo1.getString("UNITID")
                      }
                      if (departmentType == "DEPARTMENT") {
                         emp_department = orgHierarchyMbo1.getString("PARENT1ID")
                      }
                      if (sectorType == "SECTOR") {
                         emp_sector = orgHierarchyMbo1.getString("PARENT2ID")
                      }
                   }
				   
                orgHierarchyMboSet1.cleanup()
                orgHierarchyMboSet1.close()
    			
			    SqlQuery = "update EMPLOYEE_INTERFACE set DM_GRPEMPNUM='" + DM_GRPEMPNUM + "' , EMPLOYEE_NUMBER='" + EMPLOYEE_NUMBER + "' ,SUPERVISOR_NUMBER='" + SUPERVISOR_NUMBER + "',DM_SECTOR='" + emp_sector + "',DM_DEPARTMENT='" + emp_department + "',DM_SECTION='" + emp_section + "',  STATUS='" + status + "' where transid=" + transid + " ";
		 //--------------------------------------------------------------------------------------------
         
				//SqlQuery = "update EMPLOYEE_INTERFACE set EMPLOYEE_NUMBER='" + EMPLOYEE_NUMBER + "' ,SUPERVISOR_NUMBER='" + SUPERVISOR_NUMBER + "',  STATUS='" + status + "' where transid=" + transid + " ";
				updateInterface(conn, interfaceTable, SqlQuery)
				
				var personMboSet = MXServer.getMXServer().getMboSet("PERSON", runAsUserInfo);
				personMboSet.setWhere(" PERSONID='" + EMPLOYEE_NUMBER + "' and DM_SKIPUPDATE=1");
				personMboSet.reset();
				
				if (personMboSet.count() > 0) {
					sendToUque=false;
				} */
				sendToUque=true
		}
		/*----Code to process FIXEDASSET_INTERFACE Interface data to Maximo Interface Queue -----------------------------------------------------------*/
		if (interfaceTable == "FIXEDASSET_INTERFACE") {
			var classstructureId = interfaceTableMbo.getString("CLASSSTRUCTUREID");
			var MAJOR_CATEGORY = interfaceTableMbo.getString("MAJORCATEGORY")
			var MINOR_CATEGORY = interfaceTableMbo.getString("MINORCATEGORY")
			var DM_MODEL = interfaceTableMbo.getString("MODEL_NUMBER")
			var PRODUCTCODE = interfaceTableMbo.getString("PRODUCTCODE")
			var FLOC1 = interfaceTableMbo.getString("SEGMENT5")
			var FLOC2 = interfaceTableMbo.getString("SEGMENT6")
			var FLOC3 = interfaceTableMbo.getString("SEGMENT7")
			var AssetNum = interfaceTableMbo.getString("ASSET_NUMBER")
			var Cust_location = interfaceTableMbo.getString("LOCATION_CODE");
			logger.debug("Model==>" + DM_MODEL );
			
			if (DM_MODEL) {
			    var assetModelSet = MXServer.getMXServer().getMboSet("DM_ASSETMODEL", runAsUserInfo);
			    assetModelSet.setWhere("MODEL='" + DM_MODEL + "'  or MODEL='" + DM_MODEL.trim() + "'");
			    assetModelSet.reset();
				logger.debug("CompWHere==>" + assetModelSet.getCompleteWhere() );
				var assetmodel = assetModelSet.moveFirst();
			    if(!assetmodel){
			        assetModelMbo = assetModelSet.addAtEnd();
			        assetModelMbo.setValue("MODEL", DM_MODEL)
			        assetModelMbo.setValue("MANUFACTURER", "M-UNKNOWN")
			        assetModelMbo.setValue("ACTIVE", true)
			        assetModelSet.save();
			    }
			    
			}

			//Vendor 
			var Vendor_Number = interfaceTableMbo.getString("VENDOR")
			
			if (Vendor_Number) {
			    var companiesSet = MXServer.getMXServer().getMboSet("COMPANIES", runAsUserInfo);
			    companiesSet.setWhere("COMPANY='" + Vendor_Number + "'  AND ORGID='DMORG'");
			    companiesSet.reset();
				
				var companyMbo = companiesSet.moveFirst();
			    if(!companyMbo){
					var Vendor_Name = interfaceTableMbo.getString("VENDOR_NAME")
			        NewcompanyMbo = companiesSet.addAtEnd();
			        NewcompanyMbo.setValue("COMPANY", Vendor_Number);
			        NewcompanyMbo.setValue("NAME", Vendor_Name);
			        //NewcompanyMbo.setValue("ORGID", "DMORG");
					NewcompanyMbo.setValue("TYPE", "V");
			        companiesSet.save();
			    }

				companiesSet.cleanup();
				companiesSet.close();
			    
			}

			

				
				

			
			var assign_to = interfaceTableMbo.getString("ASSIGNED_TO");
			var glaccount = interfaceTableMbo.getString("EXPENSE_ACCOUNT");
			var asset_number = interfaceTableMbo.getString("ASSET_NUMBER");
			var AssetTag = interfaceTableMbo.getString("TAG_NUMBER")
			var AssetSerialNum = interfaceTableMbo.getString("SERIALNUMBER")
			var section = "";
			var department = "";
			var sector = "";
			var SqlQuery = null;
			var asset_status = "";
			if (glaccount) {
				var splitedArray = glaccount.split(/-/);
				var arrayLength = splitedArray.length;
				if (arrayLength > 2) {
					var unitid = splitedArray[2];
					var orgHierarchyMboSet = MXServer.getMXServer().getMboSet("DM_ORGHIERARCHY", runAsUserInfo);
					//orgHierarchyMboSet.setWhere("UNITID='" + unitid + "' ");
					orgHierarchyMboSet.setWhere("COSTCENTER='"+unitid+"' ");
					orgHierarchyMboSet.reset();
					if (orgHierarchyMboSet.count() > 0) {
					    sendToUque=true;
						orgHierarchyMbo = orgHierarchyMboSet.getMbo(0)
						sectionType = orgHierarchyMbo.getString("UNITTYPE")
						departmentType = orgHierarchyMbo.getString("PARENT1TYPE")
						sectorType = orgHierarchyMbo.getString("PARENT2TYPE")
						if (sectionType == "SECTION") {
							section = orgHierarchyMbo.getString("UNITID")
						}
						if (departmentType == "DEPARTMENT") {
							department = orgHierarchyMbo.getString("PARENT1ID")
						}
						if (sectorType == "SECTOR") {
							sector = orgHierarchyMbo.getString("PARENT2ID")
						}
					}
					orgHierarchyMboSet.cleanup()
					orgHierarchyMboSet.close()
				}
			}


			/*
            var classificationMboSet = MXServer.getMXServer().getMboSet("CLASSSTRUCTURE", runAsUserInfo);
			classificationMboSet.setWhere(" DM_GRP_DG_MAJOR_CATEGORY_ID='" + MAJOR_CATEGORY + "' and DM_GRP_DG_MINOR_CATEGORY_ID='" + MINOR_CATEGORY + "' and DM_GRP_DG_PRODUCTCODE='" + PRODUCTCODE + "'");
            */
           var classificationMboSet = MXServer.getMXServer().getMboSet("DM_GRPCLASSMAP", runAsUserInfo);
			classificationMboSet.setWhere(" MAJOR_CATEGORY_ID='" + MAJOR_CATEGORY + "' and MINOR_CATEGORY_ID='" + MINOR_CATEGORY + "' and PRODUCTCODE='" + PRODUCTCODE + "'");
			classificationMboSet.reset();
			if (classificationMboSet.count() > 0) {
				classificationMbo = classificationMboSet.getMbo(0)
				classstructureId = classificationMbo.getString("CLASSSTRUCTUREID")
			}



			// DM_LOCATION=FLOC1+FLOC2+FLOC3;
			var DM_LOCATION=FLOC3;
			
			var assetMboSet = MXServer.getMXServer().getMboSet("ASSET", runAsUserInfo);
			//assetMboSet.setWhere("DM_GRPNUM='" + asset_number + "' OR DM_ASSET_TAG='"+AssetTag+"' OR SERIALNUM='"+AssetSerialNum+"'");
			// Removing serial number as it was found that some assets migh have same serial number
			assetMboSet.setWhere("DM_GRPNUM='" + asset_number + "' OR DM_ASSET_TAG='"+AssetTag+"'");
			assetMboSet.reset();
			if (assetMboSet.count() > 0) {
				assetMbo = assetMboSet.getMbo(0)
				AssetNum = assetMbo.getString("ASSETNUM")
				asset_status = assetMbo.getString("STATUS")
				
				if (assign_to) {
				SqlQuery = "update FIXEDASSET_INTERFACE set DM_LOCATION='" + DM_LOCATION + "', STATUS='" + asset_status + "', ISCUSTODIAN=1, ASSETNUM='" + AssetNum + "',classstructureId='" + classstructureId + "',EXPENSE_ACCOUNT='',DM_SECTOR='',DM_DEPARTMENT='',DM_SECTION='', ASSETUSERCUST_LOCATION='" + Cust_location + "' where transid=" + transid + " ";
				} else {			
					SqlQuery = "update FIXEDASSET_INTERFACE set DM_LOCATION='" + DM_LOCATION + "', STATUS='" + asset_status + "', ASSETNUM='" + AssetNum + "',classstructureId='" + classstructureId + "',EXPENSE_ACCOUNT='',DM_SECTOR='',DM_DEPARTMENT='',DM_SECTION='' ,ISCUSTODIAN='',ASSETUSERCUST_LOCATION='' where transid=" + transid + " ";
				}
				
			} else {
				asset_status = "NOT READY"
				
				if (assign_to) {
				SqlQuery = "update FIXEDASSET_INTERFACE set DM_LOCATION='" + DM_LOCATION + "', STATUS='" + asset_status + "', ISCUSTODIAN=1, ASSETNUM='" + AssetNum + "',classstructureId='" + classstructureId + "',DM_SECTOR='" + sector + "',DM_DEPARTMENT='" + department + "',DM_SECTION='" + section + "', ASSETUSERCUST_LOCATION='" + Cust_location + "' where transid=" + transid + " ";
				} else {
					SqlQuery = "update FIXEDASSET_INTERFACE set DM_LOCATION='" + DM_LOCATION + "', STATUS='" + asset_status + "', ASSETNUM='" + AssetNum + "',classstructureId='" + classstructureId + "',DM_SECTOR='" + sector + "',DM_DEPARTMENT='" + department + "',DM_SECTION='" + section + "' ,ISCUSTODIAN='',ASSETUSERCUST_LOCATION='' where transid=" + transid + " ";
				}
			}
						
			//SqlQuery="update FIXEDASSET_INTERFACE set ASSETNUM='"+AssetNum+"',classstructureId='"+classstructureId+"',DM_SECTOR='"+sector+"',DM_DEPARTMENT='"+department+"',DM_SECTION='"+section+"', ASSETUSERCUST_LOCATION='"+Cust_location+"' where transid="+transid+" ";
			updateInterface(conn, interfaceTable, SqlQuery)
			assetMboSet.cleanup()
			assetMboSet.close()
			classificationMboSet.cleanup()
			classificationMboSet.close()
		}
		if (sendToUque) {
		/*----Code to insert Interface data to Maximo Interface Queue -----------------------------------------------------------*/
			pushToMaximoInterfaceQueueTable(transid, extSys, es)
		/*---Code to update Interface table status after sending to interface queue table----------------------------------------*/	
			updateInterfaceDataStatus(conn, transid, interfaceTable)
		}
		interfaceTableMbo = interfaceTableSet.moveNext();
	}
	interfaceTableSet.save()
	interfaceTableSet.cleanup()
	interfaceTableSet.close();

}

function getGLComponentDataFromInterfaceTable(interfaceTable, transid) {

	var glComponentsSet = MXServer.getMXServer().getMboSet(interfaceTable, runAsUserInfo);
	glComponentsSet.setWhere("CURRENT_DATA_STATUS='RECEIVED' and TRANSID=" + transid + " ");
	glComponentsSet.reset();

	var glComponentsMbo = glComponentsSet.moveFirst();

	while (glComponentsMbo !== null) {

		var segment1 = glComponentsMbo.getString("SEGMENT1");
		var segment2 = glComponentsMbo.getString("SEGMENT2");
		var segment3 = glComponentsMbo.getString("SEGMENT3");
		var segment4 = glComponentsMbo.getString("SEGMENT4");
		var segment5 = glComponentsMbo.getString("SEGMENT5");
		var segment6 = glComponentsMbo.getString("SEGMENT6");
		var segment7 = glComponentsMbo.getString("SEGMENT7");
		var segment8 = glComponentsMbo.getString("SEGMENT8");

		var segment1_description = glComponentsMbo.getString("SEGMENT1_DESC");
		var segment2_description = glComponentsMbo.getString("SEGMENT2_DESC");
		var segment3_description = glComponentsMbo.getString("SEGMENT3_DESC");
		var segment4_description = glComponentsMbo.getString("SEGMENT4_DESC");
		var segment5_description = glComponentsMbo.getString("SEGMENT5_DESC");
		var segment6_description = glComponentsMbo.getString("SEGMENT6_DESC");
		var segment7_description = glComponentsMbo.getString("SEGMENT7_DESC");
		var segment8_description = glComponentsMbo.getString("SEGMENT8_DESC");
		var status = glComponentsMbo.getString("STATUS");

		createUpdateGLComponent("DMORG", "ENTITY", segment1, segment1_description, status);
		createUpdateGLComponent("DMORG", "LOCATION", segment2, segment2_description, status);
		createUpdateGLComponent("DMORG", "COST CENTER", segment3, segment3_description, status);
		createUpdateGLComponent("DMORG", "ACCOUNT", segment4, segment4_description, status);
		createUpdateGLComponent("DMORG", "SUB-ACCOUNT", segment5, segment5_description, status);
		createUpdateGLComponent("DMORG", "PROJECT", segment6, segment6_description, status);
		createUpdateGLComponent("DMORG", "PROGRAMME", segment7, segment7_description, status);
		createUpdateGLComponent("DMORG", "SPARE", segment8, segment8_description, status);

		glComponentsMbo = glComponentsSet.moveNext();
	}
	glComponentsSet.cleanup()
	glComponentsSet.close();

}

function createUpdateGLComponent(orgid, component, component_value, component_desc, enabled_flag) {
	active = false;
	if (enabled_flag == "ACTIVE" || enabled_flag == "Active") {
		active = true;
	}
	glConfigureSet = MXServer.getMXServer().getMboSet("GLCONFIGURE", runAsUserInfo);
	glConfigureSet.setWhere("ORGID=" + "'" + orgid + "'" + " AND GLACCOUNTFIELD=" + "'" + component + "' ");
	glConfigureSet.reset();

	if (glConfigureSet.count() > 0) {
		glConfigureMbo = glConfigureSet.getMbo(0);

		glComponentSet = MXServer.getMXServer().getMboSet("GLCOMPONENTS", runAsUserInfo);
		glComponentSet.setWhere("GLORDER=" + glConfigureMbo.getInt("GLORDER") + " AND COMPVALUE=" + "'" + component_value + "'" + " AND ORGID=" + "'" + orgid + "' ");
		glComponentSet.reset();
		if (glComponentSet.count() > 0) {
			glComponentMbo = glComponentSet.getMbo(0)
			glComponentMbo.setValue("COMPTEXT", component_desc, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
			glComponentMbo.setValue("ACTIVE", active, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)

		} else {
			glComponentMbo = glComponentSet.addAtEnd();
			glComponentMbo.setValue("GLORDER", glConfigureMbo.getInt("GLORDER"), MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
			glComponentMbo.setValue("COMPVALUE", component_value, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
			glComponentMbo.setValue("COMPTEXT", component_desc, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
			glComponentMbo.setValue("ACTIVE", active, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
			glComponentMbo.setValue("ORGID", orgid, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
		}
	}

	glComponentSet.save();
	glComponentSet.cleanup();
	glConfigureSet.save();
	glConfigureSet.cleanup();
}

function createParentLocations(loc, LocDesc) {

	locationMboSet = MXServer.getMXServer().getMboSet("LOCATIONS", runAsUserInfo);
	locationMboSet.setWhere("LOCATION='" + loc + "'");
	locationMboSet.reset();


	if (locationMboSet.count() == 0) {
		locationMbo = locationMboSet.addAtEnd();
		locationMbo.setValue("LOCATION", loc, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
		locationMbo.setValue("DESCRIPTION", LocDesc, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
		locationMbo.setValue("STATUS", "OPERATING", MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
		locationMbo.setValue("TYPE", "GEOGRAPHIC", MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
		locationMbo.setValue("SITEID", "DM", MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
		//locationMbo.setValue("DM_GRPLOCATIONID",null,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
	}

	locationMboSet.save();
	locationMboSet.cleanup();
}

function createLocationHierarchy(loc, LocParent, systemid, children, siteid, orgid) {
	
	locMboSet = MXServer.getMXServer().getMboSet("LOCATIONS", runAsUserInfo);
	locMboSet.setWhere("LOCATION='" + loc + "'");
	locMboSet.reset();


	if (locMboSet.count() > 0) {
		locMbo=locMboSet.getMbo(0)
		locHierarchyMboSet = locMbo.getMboSet("LOCHIERARCHY");
		//locHierarchyMboSet.setWhere("LOCATION='" + loc + "' and PARENT='" + LocParent + "'");
		locHierarchyMboSet.reset();
		

		if (locHierarchyMboSet.count() == 0) {
			locHierarchyMbo = locHierarchyMboSet.addAtEnd();
			locHierarchyMbo.setValue("LOCATION", loc, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
			locHierarchyMbo.setValue("PARENT", LocParent, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
			locHierarchyMbo.setValue("SYSTEMID", systemid, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
			locHierarchyMbo.setValue("CHILDREN",children, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
			locHierarchyMbo.setValue("SITEID", siteid, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
			locHierarchyMbo.setValue("ORGID", orgid, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
		}
       
		locHierarchyMboSet.save();
		locHierarchyMboSet.cleanup();
		locMboSet.cleanup();
	}
}

function pushToMaximoInterfaceQueueTable(transid, extSys, es) {

	var mxintIntTransSet = MXServer.getMXServer().getMboSet("MXIN_INTER_TRANS", runAsUserInfo);
	mxintIntTrans = mxintIntTransSet.addAtEnd();
	mxintIntTrans.setValue("IFACENAME", es, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION);
	mxintIntTrans.setValue("TRANSID", transid, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION);
	mxintIntTrans.setValue("ACTION", "AddChange", MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION);
	mxintIntTrans.setValue("EXTSYSNAME", extSys, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION);
	mxintIntTrans.setValue("TRANSLANGUAGE", "EN", MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION);
	mxintIntTransSet.save();
	mxintIntTransSet.cleanup();
	mxintIntTransSet.close()
}

function updateInterfaceDataStatus(conn, transid, interfaceTable) {


	try {
		var sql = "update " + interfaceTable + " set CURRENT_DATA_STATUS='SENT TO QUEUE' WHERE TRANSID = ?";
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, transid);
		var rowsUpdated = pstmt.executeUpdate();
		if (rowsUpdated > 0) {
			print("Interface data status updated successfully.");
		} else {
			print("No matching asset found.");
		}
		conn.commit();

	} catch (e) {
		if (conn !== null) {
			conn.rollback();
		}
		print("Error: " + e.message);

	} finally {
		if (pstmt !== null) {
			pstmt.close();
		}

	}
}

function updateInterfaceValues(conn, transid, interfaceTable, orgid) {


	try {
		var sql = "update " + interfaceTable + " set ORGID=?  ,CURRENT_DATA_STATUS='SENT TO QUEUE' WHERE TRANSID = ?";
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, orgid);
		pstmt.setString(2, transid);
		var rowsUpdated = pstmt.executeUpdate();
		if (rowsUpdated > 0) {
			print("Interface data status updated successfully.");
		} else {
			print("No matching asset found.");
		}
		conn.commit();

	} catch (e) {
		if (conn !== null) {
			conn.rollback();
		}
		print("Error: " + e.message);

	} finally {
		if (pstmt !== null) {
			pstmt.close();
		}

	}
}

function updateInterface(conn, interfaceTable, query) {


	try {
		// query = "update " +interfaceTable+" set ORGID=?  ,CURRENT_DATA_STATUS='SENT TO QUEUE' WHERE TRANSID = ?";
		pstmt = conn.prepareStatement(query);
		var rowsUpdated = pstmt.executeUpdate();
		if (rowsUpdated > 0) {
			print("Interface data status updated successfully.");
		} else {
			print("No matching asset found.");
		}
		conn.commit();

	} catch (e) {
		if (conn !== null) {
			conn.rollback();
		}
		print("Error: " + e.message);

	} finally {
		if (pstmt !== null) {
			pstmt.close();
		}

	}
}