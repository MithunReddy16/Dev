MissingAdressSet = mbo.getMboSet('DM_MISSINGSHIPTO')
MissingAddressMbo = MissingAdressSet.moveFirst()
siteAddSet = mbo.getMboSet('BILLTOSHIPTO')
while MissingAddressMbo:
    
    siteAddSetMbo = siteAddSet.add()
    siteAddSetMbo.setValue('ADDRESSCODE',MissingAddressMbo.getString('ADDRESSCODE'),2L)
    siteAddSetMbo.setValue('BILLTO',False,2L)
    siteAddSetMbo.setValue('BILLTODEFAULT',False,2L)
    siteAddSetMbo.setValue('SHIPTO',True,2L)
    siteAddSetMbo.setValue('SHIPTODEFAULT',False,2L)

    MissingAddressMbo = MissingAdressSet.moveNext()