/*
Script: DM_AUTOCREATEIVR
Created By: Ashok
Date: 21-Aug-2024
Req: Check if there if there is inventory reservation that has required date after 3 days ( Require date = System date+ 3days) 
For those set, create inventory usage records that follows: 
	For items that only has balance in hand  
	Inventory usages grouped by WONUM ( MRNUM if not WONUM) 
	If item current balance is not sufficient to cover all reservation for the same due date,  start with reservation that has HARD reservation type, then based on request date  order. 
	Pick inventory bin that has oldest stock: 
		
Once IV created, WF will be pushed , will advice the name of the workflow later, you can name it INVUSAGE-MAIN 

Solution Approach:
1. IVR will be created against WO-STORE-RESERVATIONTYPE
2. Lines are Created Against the same criteria which has enough balances
3. IF the Current Inventory Balance is not Sufficient including the Open IVR Transcation qty, then the IVR will not create 
for eg, IF requestqty <= (Total Inventory Balance Qty - Total Open IVRLInes Qty) then IVR is created ELSE Not Created
4. Reserve Lines are copied to INVUSELINE and set the FROM BIN as per the DM_BALANCEDATE in ASC
5. By Default the BIN is selected as per the balance date, irrespective of balance exists. During the INVUSE Completion the user has to change the bin or split the line accordingly.

var workorderMap = new HashMap();
workorderMap.put(workorderId, wo);
var mboRemote = workorderMap.get(workorderId);

workorderMap.put(workorderId, wo);



*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)

//from psdi.mbo import DBShortcut,SqlFormat


//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_AUTOCREATEIVR**START***")
 //workorderMap = new HashMap();

try
{
	dbShortcut= new DBShortcut()
	dbShortcut2= new DBShortcut()
	invUseMbo=null;
	resultSet2=null;
	resultSet1=null;
    dbShortcut.connect(mbo.getThisMboSet().getUserInfo().getConnectionKey())
	dbShortcut2.connect(mbo.getThisMboSet().getUserInfo().getConnectionKey())
	sqfQuery=new SqlFormat("select  ir.location,ir.wonum,ir.restype,ir.siteid,ir.resnumber from ("
			+" select  location,wonum,restype restype1,case when restype='HARD' or restype='APHARD' then '1' "
			+" when restype='SOFT' or restype='APSOFT' then '2' "
			+" else '3' end resnumber,"
			+" case when restype='HARD' or restype='APHARD' then 'HARD' "
			+" when restype='SOFT' or restype='APSOFT' then 'SOFT' "
			+" else restype end restype,siteid"
			+" from invreserve where  trunc(requireddate)=trunc(sysdate+3)"
			+" ) ir group by ir.location,ir.wonum,ir.restype,ir.siteid,ir.resnumber order by resnumber asc")
    //sqfQuery.setObject(1,"ASSET","SITEID","BEDFORD")
    resultSet1=dbShortcut.executeQuery(sqfQuery.format())
	//logger.error("***ASH***Sript DM_AUTOCREATEIVR**resultSet1="+resultSet1);
	invUseSet=mbo.getThisMboSet();
	
    while( resultSet1.next())
	{
		//logger.error("***ASH***Sript DM_AUTOCREATEIVR**inside while 1"); 
		canDM_AUTOCREATEIVR=0;
		isIVRCreated=0;
		invUseNum=null;
		invUseMbo=null;
		restype =" ('"+resultSet1.getString("restype")+"')"
		//logger.error("***ASH***Sript DM_AUTOCREATEIVR**location="+resultSet1.getString("location")); 
		//logger.error("***ASH***Sript DM_AUTOCREATEIVR**WONUM="+resultSet1.getString("WONUM"));  
		//logger.error("***ASH***Sript DM_AUTOCREATEIVR**restype="+resultSet1.getString("restype")); 	
		if(resultSet1.getString("resnumber")==1)
		{
			restype =" ('HARD','APHARD')"
		}
		else if(resultSet1.getString("resnumber")==2)
		{
			restype =" ('SOFT','APSOFT')"
		}
		//logger.error("***ASH***Sript DM_AUTOCREATEIVR** upd restype="+restype); 
		query2="select requestnum,itemnum,RESERVEDQTY, pendingqty,remnqty,requesteddate,binnum,totalbal,totopeninvuseqty from (select requestnum,itemnum,RESERVEDQTY, pendingqty,(RESERVEDQTY-pendingqty-stagedqty-shippedqty) remnqty,requesteddate,binnum,"
				+" coalesce((select sum(curbal) from invbalances ib where ib.location=ir.location and ib.siteid=ir.siteid and ib.itemnum=ir.itemnum ),0) totalbal,"
				+" coalesce((select sum(invuseline.QUANTITY) from invuseline  where invuseline.USETYPE='ISSUE' and invuseline.itemnum=ir.itemnum and invuseline.fromstoreloc=ir.location and "
				+" invuseline.invusenum in ( select invusenum from invuse where siteid=ir.siteid and status in ( select value from synonymdomain where "
				+" domainid = 'INVUSESTATUS' and maxvalue = 'ENTERED'))),0) totopeninvuseqty"
				+" from invreserve ir where wonum='"+resultSet1.getString("wonum")+"' and location='"+resultSet1.getString("location")+"' and restype in "+restype+" and trunc(requireddate)=trunc(sysdate+3)) where remnqty>0 and remnqty<=(totalbal-totopeninvuseqty) order by requesteddate asc";
		//logger.error("***ASH***Sript DM_AUTOCREATEIVR**query2="+query2);
		sqfQuery2= new SqlFormat(query2)
		//sqfQuery2.setObject(1,"invreserve","wonum", resultSet1.getString("wonum"));  
		//sqfQuery2.setObject(2,"invreserve","location", resultSet1.getString("location"));
		//sqfQuery2.setObject(3,"invreserve","restype", resultSet1.getString("restype"));
		
		resultSet2=dbShortcut2.executeQuery(sqfQuery2.format())
		//logger.error("***ASH***Sript DM_AUTOCREATEIVR**resultSet2="+resultSet2); 
		i=0;
		while( resultSet2.next())
		{
			//logger.error("***ASH***Sript DM_AUTOCREATEIVR** beforeLine i="+i); 
			i++;
			//logger.error("***ASH***Sript DM_AUTOCREATEIVR**Line i="+i); 
			//logger.error("***ASH***Sript DM_AUTOCREATEIVR**requestnum="+resultSet2.getString("requestnum")); 
			//logger.error("***ASH***Sript DM_AUTOCREATEIVR**itemnum="+resultSet2.getString("itemnum")); 
			//logger.error("***ASH***Sript DM_AUTOCREATEIVR**remnqty="+resultSet2.getString("remnqty")); 
			//logger.error("***ASH***Sript DM_AUTOCREATEIVR**totalbal="+resultSet2.getString("totalbal")); 
			
			
			if(resultSet2.getDouble("remnqty")<=resultSet2.getDouble("totalbal"))
			{
				canDM_AUTOCREATEIVR=1;
				//logger.error("***ASH***Sript DM_AUTOCREATEIVR**canDM_AUTOCREATEIVR="+canDM_AUTOCREATEIVR); 
				//resultSet2.next()
			}
			if(canDM_AUTOCREATEIVR==1)
			{
				
				if(isIVRCreated==0)
				{
					//logger.error("***ASH***Sript DM_AUTOCREATEIVR**isIVRCreated="+isIVRCreated); 
					
					invUseMbo=invUseSet.add();
					invUseNum=invUseMbo.getString("INVUSENUM");
					logger.error("***ASH***Sript DM_AUTOCREATEIVR**IVR Created invusenum="+invUseNum);
					invUseMbo.setValue("FROMSTORELOC",resultSet1.getString("location"),2);
					invUseMbo.setValue("USETYPE","MIXED",2);
					invUseMbo.setValue("DESCRIPTION","Created for Work Order "+resultSet1.getString("WONUM")+" Reservation "+resultSet1.getString("restype"),2);
					isIVRCreated=1;
					
					//Create the IVR Header and return invUseNum value
					
				}
				if(invUseNum!=null)
				{
					//logger.error("***ASH***Sript DM_AUTOCREATEIVR**invUseNum="+invUseNum); 
					// add reserved lines to INVUSE
					if(invUseMbo!=null)
					{
						if(resultSet2.getDouble("remnqty")<=resultSet2.getDouble("totalbal"))
						{
							invReserveSet=invUseMbo.getMboSet("INVRESERVE");
							invReserveSet.setWhere("requestnum='"+resultSet2.getString("requestnum")+"'")
							//logger.error("***ASH***Sript DM_AUTOCREATEIVR**IVR Created invReserveSet where="+invReserveSet.getCompleteWhere());
							invReserveSet.reset();
							//logger.error("***ASH***Sript DM_AUTOCREATEIVR**IVR Created invReserveSet reset() where="+invReserveSet.getCompleteWhere());
							invuseLineSet=invUseMbo.getMboSet("INVUSELINE")
							//logger.error("***ASH***Sript DM_AUTOCREATEIVR** before addInvUseLineFromInvReserve");
							invuseLineMbo=invuseLineSet.addInvUseLineFromInvReserve(invReserveSet.getMbo(0));
							//logger.error("***ASH***Sript DM_AUTOCREATEIVR** after addInvUseLineFromInvReserve");
							//logger.error("***ASH***Sript DM_AUTOCREATEIVR**IVR Created invuseLinenum="+invuseLineMbo.getString("invuseLinenum"));
							//logger.error("***ASH***Sript DM_AUTOCREATEIVR**IVR Created invuseLineITEMnum="+invuseLineMbo.getString("ITEMNUM"));
							//logger.error("***ASH***Sript DM_AUTOCREATEIVR**IVR Created invuseLine QTY="+invuseLineMbo.getString("QUANTITY"));
							if(invuseLineMbo.getString("QUANTITY")<=0)
							{
								//invuseLineMbo.setValue("QUANTITY",resultSet2.getDouble("remnqty"),2);
							}
							invbalSet=invuseLineMbo.getMboSet("DM_INVBALANCES");
							invbalSet.setOrderBy("DM_BALANCEDATE ASC");
							//logger.error("***ASH***Sript DM_AUTOCREATEIVR**IVR Created invbalSet where ="+invbalSet.getCompleteWhere());
							invbalMbo=invbalSet.getMbo(0);
							//logger.error("***ASH***Sript DM_AUTOCREATEIVR** invbalMbo="+invbalMbo);
							if(invbalMbo!=null)
							{
								//logger.error("***ASH***Sript DM_AUTOCREATEIVR** binnum="+invbalMbo.getString("BINNUM"));
								//logger.error("***ASH***Sript DM_AUTOCREATEIVR** balancedate="+invbalMbo.getDate("DM_BALANCEDATE"));
								//logger.error("***ASH***Sript DM_AUTOCREATEIVR** curbal="+invbalMbo.getString("curbal"));
								if(invbalMbo.getString("BINNUM")==null)
								{
									invuseLineMbo.setValue("FROMBIN","",11)
								}
								else
								{
									invuseLineMbo.setValue("FROMBIN",invbalMbo.getString("BINNUM"),11)
								}
							}
						}
					}
				}
				
				
			}
		}
		resultSet2.close();
		if(canDM_AUTOCREATEIVR==1)
		{
			invUseSet.save();
		}
		//save the IVR 
	}
	resultSet1.close();
}
catch(e)
{
	logger.error("***ASH***Sript DM_AUTOCREATEIVR**EXCEPTION="+e);
	//logger.error("***ASH***Sript DM_AUTOCREATEIVR**EXCEPTION="+e.printStackTrace());
	if(invUseMbo!=null)
	{
		logger.error("***ASH***Sript DM_AUTOCREATEIVR**EXCEPTION="+invUseMbo.getString("invusenum")+" is deleted");
		invUseMbo.delete(2);
		
	}
}
finally
{
	if(resultSet2!=null)
	{
		resultSet2.close();
	}
	if(resultSet1!=null)
	{
		resultSet1.close();
	}
	dbShortcut.close();
	dbShortcut2.close();
}
//logger.error("***ASH***Sript DM_AUTOCREATEIVR**END***")