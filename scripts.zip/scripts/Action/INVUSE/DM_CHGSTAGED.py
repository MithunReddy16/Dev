# -------------------------------------------------------------
# Script: DM_CHGSTAGED
# Modified By Mithun
# -------------------------------------------------------------

from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("***Mithun***Script DM_CHGSTAGED**START***")

try:
    invusenum = mbo.getString("INVUSENUM")
    logger.debug("***Mithun***Script DM_CHGSTAGED**invusenum=" + invusenum)

    womrnum = ""

    invuseLineSet = mbo.getMboSet("INVUSELINE")
    invuseLineMbo = None
    if invuseLineSet is not None:
        invuseLineMbo = invuseLineSet.getMbo(0)

    if invuseLineMbo is not None:
        womrnum = "WO" + invuseLineMbo.getString("REFWO")

        if len(womrnum) <= 3:
            womrnum = "MR" + invuseLineMbo.getString("MRNUM")

    binnum = "PL" + mbo.getString("DM_PICKLISTNUM") + "-IU" + invusenum + "-" + womrnum

    logger.debug("***Mithun***Script DM_CHGSTAGED**binnum=" + binnum)
    logger.debug("***Mithun***Script DM_CHGSTAGED**before change status=" + mbo.getString("STATUS"))

    # changeStatus(String status, Date date, String memo, String binflag, String stagingbin, boolean listtab, long accessModifier)
    mbo.changeStatus("STAGED", MXServer.getMXServer().getDate(), "", "1", binnum, False, 2)

    logger.debug("***Mithun***Script DM_CHGSTAGED**after change status=" + mbo.getString("STATUS"))

except Exception, e:
    logger.debug("***Mithun***Script DM_CHGSTAGED**ERROR** " + str(e))
    raise