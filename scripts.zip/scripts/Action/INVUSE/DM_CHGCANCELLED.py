#Author : Mithun 
from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory
from com.ibm.tivoli.maximo.script import ScriptService

logger = MXLoggerFactory.getLogger("custom.maximo.inventory")

logger.debug("***ASH***Script DM_CHGCANCELLED**START***")
logger.debug("***ASH***Script DM_CHGCANCELLED**mbo=" + str(mbo))
def setError(Msg):
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)



if launchPoint == "DM_PLINVUSEDEL":
    if mbo.getString("Status") in "ENTERED" :
        mbo.changeStatus("CANCELLED", MXServer.getMXServer().getDate(), "Cancelled from Pick List", MboConstants.NOACCESSCHECK)
        mbo.setValue("DM_PLUSEDELFLAG", "1", MboConstants.NOACCESSCHECK)
        mbo.getThisMboSet().save()
    else:

        errorgroup = "dm_picklist"
        errorkey = "notvalidstatus"
if launchPoint == "DM_CHGCANCELLED":
    if mbo.getString("Status") in ["ENTERED","STAGED"] :
        userInput = service.yncuserinput()
        if userInput == ScriptService.YNC_NULL:
            service.yncerror('dm_custom', 'userinput',["Are you sure you want to Cancel Inventory Usuage ?"])
        elif userInput == ScriptService.YNC_YES:
            mbo.changeStatus("CANCELLED", MXServer.getMXServer().getDate(), "Cancelled from Pick List", MboConstants.NOACCESSCHECK)
        
    elif mbo.getString("Status") in ["SHIPPED","COMPLETE"] :
        setError('You can not cancel the Inventory Usuage which is already Shipped or Completed.')

    
    logger.debug("***ASH***Script DM_CHGCANCELLED**after change status=" + mbo.getString("STATUS"))


session = service.webclientsession()
databean = session.getDataBean("1731953822332IU")
databean.refreshTable()
databean.reloadTable()