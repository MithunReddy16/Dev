#---------------------------------------------------------------------------------------------
#Script Name :DM_GM_REASSIGNINHOUSE
#Description :Prepare the work order and originating SR for reassignment to the in-house team.
#             Check and delete related planned services and BOQ records.
#             Set In-House and clear vendor/contract on the WO and originating SR.
#             Clear Actual Start on the WO.
#
#Launch Point:Action
#Object      :WORKORDER
#Action      :DM_GM_REASSIGNINHOUSE
#
#Author/Modifiedby       Email                Version      Date               Comment
#---------------------------------------------------------------------------------------------
#Muhammad Darwish        MDARWISH.V@dm.ae     1.2          2026-10-26         Check records before deletion.
#---------------------------------------------------------------------------------------------

from psdi.mbo import MboConstants

# 1. Check and delete related planned services.

wpServiceSet = mbo.getMboSet("WPSERVICE")

if not wpServiceSet.isEmpty():
    wpServiceSet.deleteAll()

# 2. Check and delete related BOQ records.

boqSet = mbo.getMboSet("DM_BOQ")

if not boqSet.isEmpty():
    boqSet.deleteAll()

# 3. Update the current work order.

mbo.setValueNull("DM_VENDCONTRACT", MboConstants.NOACCESSCHECK)
mbo.setValueNull("VENDOR", MboConstants.NOACCESSCHECK)
mbo.setValueNull("ACTSTART", MboConstants.NOACCESSCHECK)
mbo.setValueNull("ACTFINISH", MboConstants.NOACCESSCHECK)
mbo.setValue("DM_INHOUSE", True, MboConstants.NOACCESSCHECK)

# 4. Update the originating service request, when one exists.

srSet = mbo.getMboSet("DM_SR2WO")
sr = srSet.getMbo(0)

if sr is not None:
    sr.setValueNull("DM_VENDCONTRACT", MboConstants.NOACCESSCHECK)
    sr.setValueNull("VENDOR", MboConstants.NOACCESSCHECK)
    sr.setValue("DM_INHOUSE", True, MboConstants.NOACCESSCHECK)