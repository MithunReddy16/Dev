# Script : AssetNotTagged
# Description: Notify emails to Asset Tagging Team assets which are not tagged and assets is issued 
# @author Mithun
#-----------------------------------------------------------------------------------------
from psdi.server import MXServer
from java.util import Date
from psdi.util import MXException
from psdi.app.common import DateUtility
from java.text import SimpleDateFormat
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import SqlFormat
from java.lang import String
from jarray import array
from java.util import ArrayList
from java.util import HashMap

logger = MXLoggerFactory.getLogger("maximo.crontask.ESCALATION")
logger.debug("==================== .AssetNotTaggedAfterIssue: START  =================================")
def getResultinTable(SQLTEXT):
	dbManager = mxServer.getDBManager();
	con = dbManager.getConnection(mxServer.getSystemUserInfo().getConnectionKey());
	stmt = con.createStatement();
	rs = stmt.executeQuery(SQLTEXT);
	#md = rs.getMetaData();	
	dbManager.freeConnection(mbo.getUserInfo().getConnectionKey());	
	return rs

def getEmailsFromSecurityGroup(groupName, userInfo):
    mxServer = MXServer.getMXServer()
    emailList = []

    grpSet = None
    muSet = None 
    pSet = None

    try:
        # *********to get all users in the group *********
        grpSet = mxServer.getMboSet("GROUPUSER", userInfo)
        grpSet.setWhere("GROUPNAME='" + groupName + "'")
        grpSet.reset()
        grpMbo = grpSet.moveFirst()
        while grpMbo:
            userId = grpMbo.getString("USERID")
            # ****** to get the personid from maxuser *****
            muSet = mxServer.getMboSet("MAXUSER", userInfo)
            muSet.setWhere("USERID='" + userId + "'")
            muSet.reset()
            muMbo = muSet.moveFirst()
            if muMbo:
                personId = muMbo.getString("PERSONID")
                #  **** to get primary email from person
                if personId:
                    pSet = mxServer.getMboSet("PERSON", userInfo)
                    pSet.setWhere("PERSONID='" + personId + "'")
                    pSet.reset()

                    pMbo = pSet.moveFirst()
                    if pMbo:
                        email = pMbo.getString("PRIMARYEMAIL")
                        if email and email.strip():
                            emailList.append(email.strip())
                    pSet.close()
                    pSet = None
            muSet.close()
            muSet = None

            grpMbo = grpSet.moveNext()

    finally:
        if pSet:
            pSet.close()
        if muSet:
            muSet.close()
        if grpSet:
            grpSet.close()

    return emailList

def callTemplateScript(args):	
	service.invokeScript("DM.MAIL.NOTIF.TEMPLATE",args)



#################################### Script Starting ################################
mxServer=MXServer.getMXServer()
userInfo=mxServer.getSystemUserInfo()
assetSet = mxServer.getMboSet('ASSET',mxServer.getSystemUserInfo())
assetSet.setWhere("assetnum in   ('1436077','1436076','1436045','1436044','1436043','1436042','1436041','1436040') and  status not in ('DECOMMISSIONED')   and  itemnum is not null and dm_asset_tag is null and exists ( select 1 from item i where i.itemnum = itemnum and i.commodity like '900%' )  ")
assetSet.reset()
MsgBody = "Dear/s,</br>FYA, List of assets currently in stores without a Tag Number.</br>"
emails = getEmailsFromSecurityGroup("INV_ASSETTAG", userInfo)
#toemails = array(emails, String)
logger.debug("******emails is ****** ")
emailList = []
for e in emails:
    emailList.append(str(e))
logger.debug(str(emailList))
vars = HashMap()
vars.put("tableHeader",["Asset","Description"])
vars.put("rowAttributes",{"ASSETNUM":"ALN","DESCRIPTION":"ALN"})
#vars.put("emailTo",["sword_aanwar@dm.ae","sword_aanwar@dm.ae"])
vars.put("emailTo",emailList)
vars.put("emailFrom","maximo-stg@dm.ae")
vars.put("emailCC",None)
#vars.put("mboDataSet",assetSet)
#vars.put("type","mboset")
sql = """SELECT ASSETNUM as "Asset", DESCRIPTION as "Asset Description" FROM ASSET WHERE location='M01' and purchaseprice in ('10')"""
vars.put("rs",getResultinTable(sql ))
vars.put("type","RS")
vars.put("subject","Asset Without Tag")
vars.put("MsgBody",MsgBody)


callTemplateScript(vars)
 
    
logger.debug("==================== AssetNotTaggedAfterIssue: END  =================================")