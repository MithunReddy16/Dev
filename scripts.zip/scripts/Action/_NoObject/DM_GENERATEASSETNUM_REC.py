#DM_GENERATEASSETNUM_REC


#GENERATEASSETNUM
from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory

from  psdi.common.context import UIContext
from psdi.webclient.system.controller import SessionContext, Utility, WebClientEvent
myLogger = MXLoggerFactory.getLogger("maximo.custom")

#errorkey=str(mboset.count())
#errorgroup='B'

classStartingSerialNumber = ''
classID = ''
serialNumber = ''
assetnum = ''

def serialNumberFormat(serialValue, paramLen):
    myLogger.debug("Amir--> serialNumberFormat 1=<< " + serialValue)
    
    length = len(serialValue)
    while (length < paramLen and length > 0):
        serialValue = "0" + serialValue
        length = len(serialValue)
	
    myLogger.debug("Amir--> serialNumberFormat 2=<< " + serialValue)
    return serialValue


def getclassStartingSerialNumber(assetSet,classID):
    
	myLogger.debug("Amir--> getclassStartingSerialNumber =<< " + classID)

	assetSet.setWhere("DM_SERIALNUM = (select max(DM_SERIALNUM) from asset where   DM_SERIALCLASS='"+classID+"') and DM_SERIALCLASS='"+classID+"'")
	assetSet.reset()
	if ( not assetSet.isEmpty()):
		classStartingSerialNumber = assetSet.getMbo(0).getInt("DM_SERIALNUM")
	else:
		classStartingSerialNumber = 0
	myLogger.debug("Amir--> getclassStartingSerialNumber =<< " + str(classStartingSerialNumber))
	return (classStartingSerialNumber + 1)


		

mboset = mbo.getThisMboSet()

myLogger.debug("Amir--> DM GEN asset script started")

myLogger.debug("Amir--> " + str(mboset.count()))

if (not mboset.isEmpty()):	
	
    classID = mboset.getMbo(0).getString("itemnum")
    
    myLogger.debug("Amir-->  DM GEN asset script << " +classID )
    
    assetSet = MXServer.getMXServer().getMboSet("ASSET", MXServer.getMXServer().getSystemUserInfo())
    classStartingSerialNumber = getclassStartingSerialNumber(assetSet, classID)
    serialNumber = classStartingSerialNumber
    
    for i in range (mboset.count()):
        if serialNumber >= 99999:
            assetnum = classID + str(serialNumber)
            
        else:
            assetnum = classID + '-'+  serialNumberFormat(str(serialNumber),5)
            

		#tempClassID = mboset.getMbo(i).getString("itemnum")
		
        tempClassID = mboset.getMbo(i).getString("itemnum")
        
        if (not classID==tempClassID):
            classID = tempClassID
            
            classStartingSerialNumber = getclassStartingSerialNumber(assetSet, classID)
            serialNumber = classStartingSerialNumber
            if serialNumber >= 99999:
			    assetnum = classID + str(serialNumber)
            else:
                assetnum = classID + '-'+ serialNumberFormat(str(serialNumber),5)
                
        myLogger.debug("Amir-->  DM GEN asset script << " +assetnum )

        mboset.getMbo(i).setValue("ASSETNUM", assetnum, MboConstants.NOACCESSCHECK)
        mboset.getMbo(i).setFieldFlag("ASSETNUM", MboConstants.READONLY, True)
		
        #mboset.getMbo(i).setValue("serialnum", serialNumber, MboConstants.NOACCESSCHECK)
		#mboset.getMbo(i).setFieldFlag("serialnum", MboConstants.READONLY, True)
		
        serialNumber = serialNumber + 1
        
        myLogger.debug("Amir-->  DM GEN asset script << End of " + str(i+1) )
        myLogger.debug(str(int(mboset.getMbo(i).getString('assetnum')[len(mboset.getMbo(i).getString('itemnum'))+1:])))
        
    #TableDB = service.webclientsession().getDataBean("rotasset_rotatingitems_table")
    #if not TableDB== None:
    #    TableDB.refreshTable()
    uiContext = UIContext.getCurrentContext()
    if uiContext != None:
    	wcs = uiContext.getWebClientSession()
    	if uiContext != None:
    		wcs = uiContext.getWebClientSession();
    		wcs.getDataBean("rotasset").refreshTable()