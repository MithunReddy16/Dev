session=service.webclientsession()
mainBean = session.getDataBean("mainrecord") 
requestMbo = mainBean.getMbo()

duedate = requestMbo.getDate("DUEDATE")

departmentDatabean = session.getDataBean("dm_investselectdepartments")  

investPlanMboSet=requestMbo.getMboSet("DM_INVESTPLAN")

if departmentDatabean is not None:
    departmentSet=departmentDatabean.getMboSet()
    selectedRecords=departmentSet.getSelection()
    iterator=selectedRecords.iterator()
   
    while (iterator.hasNext()):
        departmentMbo=iterator.next()
        newInvestPlan= investPlanMboSet.add()
        department=departmentMbo.getString("UNITID")
        investnum=requestMbo.getString("INVESTNUM")
        description=requestMbo.getString("description")
        newInvestPlan.setValue("DUEDATE",duedate)
        newInvestPlan.setValue("DEPARTMENT",department)
        newInvestPlan.setValue("type","DEP")
        newInvestPlan.setValue("INVESTID",investnum + "-" + department)
        newInvestPlan.setValue("description",description + "-"+ department)
    investPlanMboSet.save()
    service.closeDialog()
    mainBean.SAVE()