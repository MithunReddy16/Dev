session = service.webclientsession()
main_bean = session.getDataBean("mainrecord")
request_mbo = main_bean.getMbo()

# Initialize variables
opportunity_databean = None

# Check each DataBean in priority order
opportunity_databean = session.getDataBean("dm_renewopportunity_select_table_adhoc")


# Proceed if any opportunity bean was found
if opportunity_databean is not None:
    opportunity_set = opportunity_databean.getMboSet()
    selected_records = opportunity_set.getSelection()
    invest_num = request_mbo.getString("INVESTNUM")
    iterator=selected_records.iterator()
    #create new line for each select asset
    while (iterator.hasNext()):  
        opportunity_mbo=iterator.next()
        opportunity_mbo.setValue("INVESTNUM", invest_num)

    opportunity_set.save()
    service.closeDialog()
    main_bean.SAVE()