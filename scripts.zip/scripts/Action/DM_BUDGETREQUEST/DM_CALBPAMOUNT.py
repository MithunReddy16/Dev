requestType =mbo.getString("requesttype")

if requestType == "DEPARTMENT":
    inCeilingEntrySet = mbo.getMboSet("DM_BUDGETENTRYWITHCEILING","DM_BUDGETENTRY","DEPBPID =:DM_BUDGETREQUESTID and WITHINCEILING = 'Y'")
    inCeilingEntrySet.reset()
    totalInCeilingAmount = inCeilingEntrySet.sum("ESTIMATEDCOST")
    mbo.setValue("INCEILINGAMOUNT",totalInCeilingAmount)
    abvCeilingEntrySet = mbo.getMboSet("DM_BUDGETENTRYAbvCEILING","DM_BUDGETENTRY","DEPBPID =:DM_BUDGETREQUESTID and WITHINCEILING = 'N'")
    abvCeilingEntrySet.reset()
    totalAbvCeilingAmount = abvCeilingEntrySet.sum("ESTIMATEDCOST")
    mbo.setValue("ABOVECEILINGAMOUNT",totalAbvCeilingAmount)
    
#-- MAINBPID    

if requestType == "DM":
    allEntrySet = mbo.getMboSet("DM_BPALLBUDGETENTRYS","DM_BUDGETENTRY","MAINBPID =:DM_BUDGETREQUESTID")
    allEntrySet.reset()
    totalInCeilingAmount = allEntrySet.sum("COMMITTEDCOST")
    totalAbvCeilingAmount = allEntrySet.sum("ABVCEILINGAMOUNT")
    budgetDeptSet = mbo.getMboSet("DEPARTMENTREQUEST")
    budgetDeptSet.reset()
    allocatedAmount = budgetDeptSet.sum("BUDGETAMOUNT")
    totalBudget = mbo.getDouble("BUDGETAMOUNT")
    mbo.setValue("ABOVECEILINGAMOUNT",totalAbvCeilingAmount)
    mbo.setValue("INCEILINGAMOUNT",totalInCeilingAmount)
    mbo.setValue("ALLOCATEDAMOUNT",allocatedAmount)
    mbo.setValue("REMAININGAMOUNT",totalBudget-allocatedAmount)
   
 
session=service.webclientsession()
mainBean = session.getDataBean("mainrecord") 
mainBean.SAVE()