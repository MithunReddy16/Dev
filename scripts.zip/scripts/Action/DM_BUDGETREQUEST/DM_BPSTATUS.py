#------------------------------------------------------------------------

#Script Name :DM_BPSTATUS
#Description :script to Change Section Budget Plan Status
#Comment     :Used in Department Budget Plan and Section Budget Plan 
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
# Samer Al Fakih      SWORD_salfakih@dm.ae     1.0          01-FEB-2026         Initiate version.

#------------------------------------------------------------------------
from psdi.mbo import MboConstants

sectionBPMboSet = mbo.getMboSet("SBP$$","DM_BUDGETREQUEST",
    "depbpid={}".format(mbo.getInt("dm_budgetrequestid"))
)

status_map = {
    "DM_BPSWDDAPPR": "WDDAPPR",
    "DM_BPSAPPR": "APPR",
    "DM_BPSCLOSE": "CLOSE"
}

sectionBPMbo = sectionBPMboSet.moveFirst()

while sectionBPMbo is not None:
    if launchPoint in status_map:
        sectionBPMbo.setValue(
            "status",
            status_map[launchPoint],
            MboConstants.NOACCESSCHECK
        )
    sectionBPMbo = sectionBPMboSet.moveNext()

sectionBPMboSet.close()