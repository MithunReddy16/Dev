#------------------------------------------------------------------------

#Script Name :DM_PBACTIVATE_ACT
#Description :Activate Budget Plan Action Script
#Comment     :Used in Budget Plan Application.  
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-Jan-2026         Initiate version.

#-------------------------------------------------------------------------
from psdi.server import MXServer 

def activateBP():
    deptBPMboSet = mbo.getMboSet("DM_BUDGETREQUEST_SS_ACT","DM_BUDGETREQUEST","MAINBPID =:DM_BUDGETREQUESTID")
    deptBPMboSet.reset()
    deptBPMbo = deptBPMboSet.moveFirst()
    while deptBPMbo:
         deptBPMbo.setValue("STATUSDATE",MXServer.getMXServer().getDate())
         deptBPMbo.setValue("budgetenddate",mbo.getDate("budgetenddate"))
         deptBPMbo.setValue("status","ACTIVE")
         deptBPMbo.setValue("CHANGEDATE",MXServer.getMXServer().getDate())
         deptBPMbo.setValue("BUDGETSTARTDATE",MXServer.getMXServer().getDate())
         deptBPMbo.setValue("CHANGEDBY",mbo.getUserInfo().getPersonId())
         deptBPMbo = deptBPMboSet.moveNext()
         
# create async job to start workflow 
def createAsyncJob():
    asyncSet = mbo.getMboSet("DM_ASYNCSCRIPT_$$","ASYNCSCRIPT","1=1")
    asyncMbo = asyncSet.setup() 
    asyncMbo.setValue("AUTOSCRIPT", "DM_BPSTARTDEPWF") 
    asyncMbo.setValue("OBJECTNAME", "DM_BUDGETREQUEST") 
    asyncMbo.setValue("WHERECLAUSE", "requesttype='DEPARTMENT' and status='ACTIVE'") 
    asyncSet.execute() 


#------------Main------------------
requestType =mbo.getString("requesttype")
if mbo.getString("status") == "DRAFT" and requestType == "DM":
    # check  the budget dead line and the budget amount
    if mbo.isNull("budgetamount") or mbo.isNull("budgetenddate"):
        service.error("dm_budgtplan","dm_bpactive")
    else:
        mbo.setValue("status","ACTIVE")
        mbo.setValue("BUDGETSTARTDATE",MXServer.getMXServer().getDate())
        activateBP()
        session = service.webclientsession()
        session.getDataBean("mainrecord").SAVE()
        createAsyncJob()