#------------------------------------------------------------------------

#Script Name :DM_BPSTRTWF
#Description :Start Section Budget Plan WF
#Comment     :Used in Budget Plan Application.  
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-Jan-2026         Initiate version.

#------------------------------------------------------------------------


from psdi.server import MXServer
if mbo.getString("requesttype") == "SECTION" and mbo.getString("status") == "ACTIVE":
    if mbo.isNull("SECCOORDINATOR"):
        service.error("dm_bp","dm_nosectcoor")
    else:
        mbo.setValue("status","ASSIGNED")
        wfstart = MXServer.getMXServer().lookup('WORKFLOW')
        wfstart.initiateWorkflow('DM_BPMAIN',mbo)
        mbo.getThisMboSet().save()
        session = service.webclientsession()
        session.getDataBean("mainrecord").SAVE()