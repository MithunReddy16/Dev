#Author : Mithun
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants
from psdi.app.inventory import InvBalancesRemote
from psdi.app.inventory import InvCostRemote
logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
userInfo = MXServer.getMXServer().getSystemUserInfo()
logger.debug("****Virtual Store Balances Adjustment started *****")

def issueUnitCheck(mbo,virtualStore):
    logger.debug("****issueUnitCheck def start***")
    itemnum = mbo.getString("ITEMNUM")
    issueQty = abs(mbo.getDouble("QUANTITY"))
    conversion = 1.0   # default = no conversion needed
    invSet = MXServer.getMXServer().getMboSet("INVENTORY", userInfo)
    Where="itemnum='"+item+"' and location='M04' and  siteid='DM' "
    invSet.setWhere(Where)
    invSet.reset()
    invVSet = MXServer.getMXServer().getMboSet("INVENTORY", userInfo)
    Where2="itemnum='"+item+"' and location='"+virtualStore+"' and  siteid='DM' "
    invVSet.setWhere(Where2)
    invVSet.reset()
    if not invSet.isEmpty() and not invVSet.isEmpty():
        invMbo=invSet.moveFirst()
        invVMbo=invVSet.moveFirst()
        invIssue = invMbo.getString("ISSUEUNIT")
        invVIssue = invVMbo.getString("ISSUEUNIT")
        invIssueNorm = (invIssue or "").strip().upper()
        virIssueNorm = (invVIssue or "").strip().upper()
        if invIssueNorm != virIssueNorm :
            invService = MXServer.getMXServer().lookup("INVENTORY")
            
            convResult = invService.getConversionFactor(userInfo, invIssueNorm, virIssueNorm, "ITEMSET", itemnum)
            if convResult==1 :
                params= ["*******Error :Conversion error from "+invIssueNorm+" to "+virIssueNorm+ " has not specified in the conversion table."]
                service.error('scriptval', 'scriptvalidationerror', params)
                 

            if convResult:
                conversion = convResult
                issueQty = issueQty * conversion
    return issueQty, conversion

def updateVirtualStoreInvCost(mbo, virtualStore, conversion) :
    logger.debug("****updateVirtualStoreInvCost method started ****")
    invSet = MXServer.getMXServer().getMboSet("INVCOST", userInfo)
    Where="itemnum='"+item+"' and location='M04' and  siteid='DM' "
    invSet.setWhere(Where)
    invSet.reset()
    invMbo=invSet.moveFirst()
    invavgCost=invMbo.getDouble("AVGCOST")

    if conversion:
        newinvavgCost = invavgCost / conversion
    else:
        newinvavgCost = invavgCost

    invcostSet = MXServer.getMXServer().getMboSet("INVCOST", userInfo)
    Where2="itemnum='"+item+"' and location='"+virtualStore+"' and  siteid='DM' "
    invcostSet.setWhere(Where2)
    invcostSet.reset()
    invcostMbo=invcostSet.moveFirst()
    if invcostMbo :
        invcostMbo.setValue("CONTROLACCOUNT","00-000-0000-00000-00-00000-00000-00000")
        invcostMbo.setValue("INVCOSTADJACCOUNT","00-000-0000-00000-00-00000-00000-00000")
        invcostMbo.setValue("NEWAVGCOST",newinvavgCost, 2l)
        invTrans=invcostMbo.adjustAverageCost(newinvavgCost)
        logger.debug("****average cost updated ******")
        invcostSet.save()
    invcostSet.close()



# ***** Main Code start here **********************************
mrnum=mbo.getString("MRNUM")
item=mbo.getString("itemnum")
matusetransid=mbo.getString("MATUSETRANSID")
today = MXServer.getMXServer().getDate()
mrMbo=mbo.getMboSet("$mr","MR","MRNUM='"+mrnum+"'").getMbo(0)
if mrMbo :
    if not mrMbo.isNull("DM_VSTORE") :
        virtualStore=mrMbo.getString("DM_VSTORE")
        invBalSet=MXServer.getMXServer().getMboSet("INVBALANCES",MXServer.getMXServer().getSystemUserInfo())
        conversionqty, conversion = issueUnitCheck(mbo, virtualStore)
        Where="itemnum='"+item+"' and location='"+virtualStore+"' and  siteid='DM' "
        invBalSet.setWhere(Where)
        invBalSet.reset()
        
        if not invBalSet.isEmpty():
            invBalMbo = invBalSet.getMbo(0)
            if invBalMbo :
                invcurbal=invBalMbo.getDouble("CURBAL")
                newCurBal=conversionqty+invcurbal
                logger.debug("****Virtual Store Balances Adjustment ITEM ***** {} --{}".format(invBalMbo.getString('ITEMNUM'),invBalMbo.getString('LOCATION')))
                invBalMbo.setValue("CONTROLACC","00-000-0000-00000-00-00000-00000-00000")
                invBalMbo.setValue("SHRINKAGEACC","00-000-0000-00000-00-00000-00000-00000")
                invBalMbo.setValue("NEWCURBAL",newCurBal,2l)
                invTrans = invBalMbo.adjustCurrentBalance(newCurBal)
                invTrans.setValue("Memo","Balance Adjust Based on Issue from M04")
                invBalSet.save()
                updateVirtualStoreInvCost(mbo, virtualStore, conversion)
        invBalSet.close()

logger.debug("****Virtual Store Balances Adjustment End *****")