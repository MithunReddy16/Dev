##############################################
#script:DM_ADV_BULKUPDATE
#Createdby:NK
#Creation Date:15-08-2026
#scope: Adv -  one time Bulk Update of WO status
###############################################

from psdi.mbo import MboConstants

status = mbo.getString("STATUS")

pendingWith = ""

# With Designer
if status in ("DES_ASSIGNED", "DES_QC_APPR", "REQAPPR",'INPROGRESS'):
    pendingWith = "Designer"

# With Design Quality Check
elif status == "DES_QC_WAPPR":
    pendingWith = "Design QC"

# With Requester
elif status == "REQWAPPR":
    pendingWith = "Requester"

# With Printer
elif status in ("WPRINT", "PRINTQCCOMP"):
    pendingWith = "Printer"

# With Print Quality Check
elif status == "PRINT-QC":
    pendingWith = "Print QC"

# With Workshop
elif status in ("WWORKSHOP", "WS-QA-COMP"):
    pendingWith = "Workshop"

# With Workshop Quality Check
elif status == "WORKSHOP-QA":
    pendingWith = "WorkshopQC"

# not assigned
elif status == "WASSIGN":
    pendingWith = "NotAssignd"

# not assigned
elif status in ("CLOSE",'CAN'):
    pendingWith = "CLOSED"


# Update WOLO9
if pendingWith:
    mbo.setValue(
        "WOLO9",
        pendingWith,
        MboConstants.NOACCESSCHECK
    )