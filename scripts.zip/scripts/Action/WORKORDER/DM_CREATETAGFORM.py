#------------------------------------------------------------------------

#Script Name :DM_CREATETAGFORM
#Description :Create Asset Tagging Form Action Script 
#Comment     :Action to Create Asset Tagging form- this action used by workflow in GM WO.
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          20-Nov-2025         Initiate version.

#------------------------------------------------------------------------
from psdi.server import MXServer

service.log_debug("######################################## Start:" + scriptName+" ######################")

# Get the current system date and time.
currentDate = MXServer.getMXServer().getDate()
assetFormSet =  mbo.getMboSet("DM_ASSETREGFORM")
assetFormMbo = assetFormSet.getMbo(0)
if not assetFormMbo:
    assetFormMbo = assetFormSet.add()
    assetFormMbo.setValue("wonum",mbo.getString("wonum"))
    assetFormMbo.setValue("source","MAXIMO")
    
assetWhereClause=  '''
                    dm_wonum=:wonum and siteid=:siteid and assetnum 
                    not in (select assetnum from DM_ASSETREGFORMLINE where siteid =:siteid ) 
                    '''
newAssetMboSet = mbo.getMboSet("DM_CAPITALASSET_NEW","ASSET",assetWhereClause)
newAssetMboSet.reset()

    
assetMbo = newAssetMboSet.moveFirst()
while assetMbo:
    assetFormLineMbo= assetFormMbo.getMboSet("DM_ASSETREGFORMLINE").add()
    assetFormLineMbo.setValue("formnum",assetFormMbo.getString("formnum"))
    assetFormLineMbo.setValue("siteid",assetFormMbo.getString("siteid"))
    assetFormLineMbo.setValue("assetnum",assetMbo.getString("assetnum"))
    assetMbo = newAssetMboSet.moveNext()
    
assetFormSet.save()
newAssetMboSet.save()

newAssetMboSet = mbo.getMboSet("DM_CAPITALASSET_NEW","ASSET",assetWhereClause)
assetMbo = newAssetMboSet.moveFirst()
while assetMbo:
        assetMbo.changeStatus("WGRP",currentDate,"") 
        assetMbo = newAssetMboSet.moveNext()
newAssetMboSet.save()

        
service.log_debug("######################################## Finish:" + scriptName+" ######################")