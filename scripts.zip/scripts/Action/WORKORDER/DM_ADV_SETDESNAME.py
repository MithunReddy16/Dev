from psdi.mbo import MboConstants

personSet = mbo.getMboSet("DM_ADV_OWNER")
person = personSet.getMbo(0)

if person is not None:
    displayName = person.getString("DISPLAYNAME")

    if displayName:
        mbo.setValue(
            "dm_adv_designcolor",
            displayName,
            MboConstants.NOACCESSCHECK
        )