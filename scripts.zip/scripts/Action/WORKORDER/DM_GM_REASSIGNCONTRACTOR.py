#---------------------------------------------------------------------------------------------
#Script Name :DM_GM_REASSIGNCONTRACTOR
#Description :Prepare the work order and originating SR for reassignment to a contractor.
#             Delete related planned services and BOQ records.
#             Determine the contractor and contract based on the work order location zone.
#             Clear In-House and update the vendor and contract on the WO and originating SR.
#             Clear Actual Start and Actual Finish on the WO.
#
#Launch Point:Action
#Object      :WORKORDER
#Action      :DM_GM_REASSIGNCONTRACTOR
#
#Author/Modifiedby       Email                Version      Date               Comment
#---------------------------------------------------------------------------------------------
#Muhammad Darwish        MDARWISH.V@dm.ae     1.2          2026-10-27         Update location zone retrieval.
#---------------------------------------------------------------------------------------------

from psdi.mbo import MboConstants

if mbo.getString("DM_MAINTDEPT") == "1996":

    # Initialize the contractor and contract values.
    vendor = None
    contractNum = None
    zone = None

    # 1. Determine the contractor and contract from the location zone.
    if not mbo.isNull("LOCATION"):

        location = mbo.getString("LOCATION")

        if location == "814-07373" or location.startswith("814-07373-"):
            zone = "E2"
        else:
            locationSet = mbo.getMboSet("LOCATION")
            locationMbo = locationSet.getMbo(0)

            if locationMbo is not None:
                zone = locationMbo.getString("DM_ZONES")

        if zone:
            zoneWhere = "DOMAINID = 'DM_ZONEMAPPING' AND VALUE = '%s'" % zone.replace("'", "''")
            zoneMappingSet = mbo.getMboSet("DM_GM_DOMAINZZ", "ALNDOMAIN", zoneWhere)
            zoneMappingSet.reset()

            zoneMappingMbo = zoneMappingSet.getMbo(0)

            if zoneMappingMbo is not None:

                mappedContract = zoneMappingMbo.getString("DESCRIPTION")
                orgId = mbo.getString("ORGID")

                if mappedContract and orgId:
                    contractWhere = "CONTRACTNUM = '%s' AND ORGID = '%s' AND STATUS = 'APPR'" % (mappedContract.replace("'", "''"), orgId.replace("'", "''"))
                    contractSet = mbo.getMboSet("DM_GM_CONTRACTZZ", "PURCHVIEW", contractWhere)
                    contractSet.reset()

                    contractMbo = contractSet.getMbo(0)

                    if contractMbo is not None:
                        mappedVendor = contractMbo.getString("VENDOR")
                        if mappedVendor:
                            vendor = mappedVendor
                            contractNum = mappedContract

    # 3. Update the current work order.
    mbo.setValue("DM_INHOUSE", False, MboConstants.NOACCESSCHECK)

    if vendor is not None:
        mbo.setValue("VENDOR", vendor, MboConstants.NOACCESSCHECK)
        mbo.setValue("DM_VENDCONTRACT", contractNum, MboConstants.NOACCESSCHECK)
    else:
        mbo.setValueNull("VENDOR", MboConstants.NOACCESSCHECK)
        mbo.setValueNull("DM_VENDCONTRACT", MboConstants.NOACCESSCHECK)

    mbo.setValueNull("ACTSTART", MboConstants.NOACCESSCHECK)
    mbo.setValueNull("ACTFINISH", MboConstants.NOACCESSCHECK)

    # 4. Update the originating service request, when one exists.
    srSet = mbo.getMboSet("DM_SR2WO")
    sr = srSet.getMbo(0)

    if sr is not None:

        sr.setValue("DM_INHOUSE", False, MboConstants.NOACCESSCHECK)

        if vendor is not None:
            sr.setValue("VENDOR", vendor, MboConstants.NOACCESSCHECK)
            sr.setValue("DM_VENDCONTRACT", contractNum, MboConstants.NOACCESSCHECK)
        else:
            sr.setValueNull("VENDOR", MboConstants.NOACCESSCHECK)
            sr.setValueNull("DM_VENDCONTRACT", MboConstants.NOACCESSCHECK)