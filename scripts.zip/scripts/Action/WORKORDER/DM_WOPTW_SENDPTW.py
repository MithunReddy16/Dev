#------------------------------------------------------------------------
#STPSCRIPT
#Script Name :DM_WOPTW_SENDPTW
#Description :script to Retrieve Permit to Work latter Script
#Comment     :Used in STP Work Order /
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          20-MAY-2026         Initiate version.
#---------------------------------------------------------------------------------------------

service.invokeScript("DM_EMAILPTW_ACTION", "generatePTWReport", [mbo.getString("DM_PTWNO"), not mbo.getBoolean("DM_INHOUSE"),mbo.getUserInfo()])