# DM_JOBCALC 
# Created by: Mithun / Ashok
# Date: 16-Sep-2024

from psdi.util.logging import MXLoggerFactory
from psdi.mbo import SqlFormat
from psdi.server import MXServer
from psdi.security import ConnectionKey
from java.sql import Connection, Statement
from java.text import SimpleDateFormat

logger = MXLoggerFactory.getLogger("maximo.custom")

stmt = None
rs = None
con = None

status = mbo.getString("STATUS")

if status in ["WAPPR", "WSCH", "ZERETURNED"]:

	# Delete old calculated lines in wpitem (dm_iscalcline=1)
	calcSet = mbo.getMboSet("DM_CALCLINES")
	if calcSet.count() > 0:
		calcSet.deleteAll()

	try:
		subContractRateSet = mbo.getMboSet("DM_SUBCONTRACTRATE") # Calculate the sum(linecost) of all PS lines copied from the contract to the wpItem set.	Then check if this total amount is within the min and max range of the subcontract rate defined for the contract.
		logger.error("***Mithun***Script DM_JOBCALC**subContractRateSet where=" + subContractRateSet.getCompleteWhere())
		logger.error("***Mithun***Script DM_JOBCALC**subContractRateSet count=" + str(subContractRateSet.count()))

		subContractRateMbo = subContractRateSet.getMbo(0)
		wpserviceSet = mbo.getMboSet("WPSERVICE")

		logger.error("***Mithun***Script DM_JOBCALC** addcost 1")

		if subContractRateMbo is not None:
			addPSMbo = wpserviceSet.add()
			psTotalCost = mbo.getMboSet("DM_WPBTYPEPS").sum("LINECOST")  # From the wpItem set, get all lines where btype = 'PS' and iscalcline = 0 (not calculated).
			logger.error("***Mithun***Script DM_JOBCALC**WPITEM psTotalCost=" + str(psTotalCost))

			psPercent = 0.0
			if not subContractRateMbo.isNull("DM_EXTRAPERCENT"):
				psPercent = subContractRateMbo.getDouble("DM_EXTRAPERCENT")

			PsPercentValue = (psPercent * psTotalCost) / 100
			logger.error("***Mithun***Script DM_JOBCALC**WPITEM PsPercentValue=" + str(PsPercentValue))

			addPSMbo.setValue("LINETYPE", "STDSERVICE")
			addPSMbo.setValue("ITEMNUM", "SCALC-SUB")
			addPSMbo.setValue("ITEMQTY", 1)
			addPSMbo.setValue("UNITCOST", PsPercentValue)
			addPSMbo.setValue("DM_NEWLINETYPE", "JOBCALC")
			addPSMbo.setValue("DM_BTYPE", "PS", 11)
			addPSMbo.setValue("DM_TYPE", "S")
			addPSMbo.setValue("DM_CATEGORY", "CO")   # why  here category defaulted to CO ?
			addPSMbo.setValue("DM_CALCAMT", PsPercentValue)
			addPSMbo.setValue("DM_ISCALCLINE", 1)
			addPSMbo.setValue("DM_APPRQTY", 0)
			addPSMbo.setValue("DM_ACCEPTQTY", 0)

			jobcontrLinesMbo = mbo.getMboSet("DM_SUBCONTLINE").getMbo(0) # get the item= SCALC-SUB  from contract and copy the contractineId 
			if jobcontrLinesMbo is not None:
				addPSMbo.setValue("DM_CONTREFLINEID", jobcontrLinesMbo.getLong("CONTRACTLINEID"))

		logger.error("***Mithun***Script DM_JOBCALC** addcost 2")

		cmLinesSet = mbo.getMboSet("DM_CONTWPMATERIAL1")  # from weserviceSet which is copied from contract get the lines DM_BTYPE='CM' and DM_CATEGORY is not null and dm_iscalcline=0 


		sqlStr = ("select DM_CATEGORY, sum(linecost) totsum from wpitem "
				  "where wonum = :1 and siteid = :2 and DM_BTYPE = 'CM' and DM_CATEGORY is not null "
				  "and DM_CONTREFLINEID is not null and DM_ISCALCLINE = 0 group by DM_CATEGORY")

		sqfQuery = SqlFormat(mbo, sqlStr)
		sqfQuery.setObject(1, "WORKORDER", "WONUM", mbo.getString("WONUM"))
		sqfQuery.setObject(2, "WORKORDER", "SITEID", mbo.getString("SITEID"))
		queryStr = sqfQuery.format()


		conKey = mbo.getThisMboSet().getUserInfo().getConnectionKey()
		con = mbo.getThisMboSet().getMboServer().getDBConnection(conKey)
		stmt = con.createStatement()
		rs = stmt.executeQuery(queryStr)

		while rs.next():
			category = rs.getString("DM_CATEGORY")
			totsum = rs.getDouble("totsum")
			wpItemSet = mbo.getMboSet("WPITEM")
			logger.error("***Mithun*** DM_JOBCALC** found category = " + str(category))
			itemList = []
			itemDescList = []

			for i in range(wpItemSet.count()):
				wpItem = wpItemSet.getMbo(i)
				if (wpItem.getString("DM_CATEGORY") == category and wpItem.getString("DM_BTYPE") == "CM" and not wpItem.isNull("DM_CONTREFLINEID") and not wpItem.getBoolean("DM_ISCALCLINE")):
					item = wpItem.getString("ITEMNUM")
					desc = wpItem.getString("DESCRIPTION")
					if item:
						itemList.append(item)
					
					if item and desc:
						itemDescList.append(item + " " + desc)
					elif item:
						itemDescList.append(item)
					elif desc:
						itemDescList.append(desc)

			if itemList:
				shortDesc = "Category " + category + ": " + " | ".join(itemList)
			else:
				shortDesc = "Category " + category + ": No Item"

			if itemDescList:
				longDesc = "Category " + category + ": " + " | ".join(itemDescList)
			else:
				longDesc = "Category " + category + ": No Description"

			logger.error("***Mithun***Script DM_JOBCALC** shortDesc = " + str(shortDesc))
			logger.error("***Mithun***Script DM_JOBCALC** longDesc = " + str(longDesc))
			jobcontrLinesSet = mbo.getMboSet("DM_JOBCALCONTRLINE")  # this will get all lines with  DM_NEWLINETYPE='JOBCALC', which means this will get all the job calcuated lines from contract .
			whereClause = "DM_CATEGORY = '" + category + "' and " + str(totsum) + " between DM_MINVALUE and DM_MAXVALUE"   # this will check for each category total sum falls between min , max in  contract lines 
			jobcontrLinesSet.setWhere(whereClause)
			jobcontrLinesSet.reset()
			jobcontrLinesSet.setOrderBy("DM_MINVALUE ASC")

			logger.error("***Mithun***Script DM_JOBCALC**where=" + jobcontrLinesSet.getCompleteWhere())
			logger.error("***Mithun***Script DM_JOBCALC**where count=" + str(jobcontrLinesSet.count()))

			jobcontrLinesMbo = jobcontrLinesSet.getMbo(0)   # that one line falls under one mbo .

			if jobcontrLinesMbo is not None:
				addJCLMbo = wpserviceSet.add()
				logger.error("***Mithun*** Added JCL Line for Category = " + category)
				addJCLMbo.setValue("LINETYPE", jobcontrLinesMbo.getString("LINETYPE"))
				addJCLMbo.setValue("ITEMNUM", jobcontrLinesMbo.getString("ITEMNUM"))
				addJCLMbo.setValue("DESCRIPTION", shortDesc[:249], 11)
				addJCLMbo.setValue("DESCRIPTION_LONGDESCRIPTION", longDesc[:1999], 11)
				addJCLMbo.setValue("SITEID", mbo.getString("SITEID"))
				addJCLMbo.setValue("ITEMQTY", 1)
				addJCLMbo.setValue("UNITCOST", jobcontrLinesMbo.getDouble("UNITCOST"))
				addJCLMbo.setValue("DM_NEWLINETYPE", "JOBCALC")
				addJCLMbo.setValue("DM_BTYPE", "CM", 11)
				addJCLMbo.setValue("DM_TYPE", "M")
				addJCLMbo.setValue("DM_CONTREFLINEID", jobcontrLinesMbo.getLong("CONTRACTLINEID"))
				addJCLMbo.setValue("DM_CATEGORY", category)
				addJCLMbo.setValue("DM_ACCEPTQTY", 0)
				addJCLMbo.setValue("DM_APPRQTY", 0)
				addJCLMbo.setValue("DM_CALCAMT", jobcontrLinesMbo.getDouble("UNITCOST"))
				addJCLMbo.setValue("DM_ISCALCLINE", 1)

				# Set matching material line cost to 0
				for i in range(0, cmLinesSet.count()):
					cmlineMbo = cmLinesSet.getMbo(i)
					if cmlineMbo.getString("DM_CATEGORY").lower()==category.lower():
						cmlineMbo.setValue("UNITCOST", 0, 2)

		logger.error("***Mithun***Script DM_JOBCALC** after loop")

	except Exception, e:
		logger.error("***Mithun***Script DM_JOBCALC** EXCEPTION=" + str(e))

	finally:
		logger.error("***Mithun***Script DM_JOBCALC** FINALLY START ***")
		if rs is not None:
			rs.close()
		if stmt is not None:
			stmt.close()
		if con is not None:
			con.close()
		logger.error("***Mithun***Script DM_JOBCALC** FINALLY END ***")

	mbo.getThisMboSet().save()

else:
	service.error("dm_wocont", "statuschk")

logger.error("***Mithun***Script DM_JOBCALC** END ***")