###############################################
#script:DM_ADV_REASSIGNWF
#Createdby:nk
#Creation Date:17-May-26
#scope: Reassign workflow from dashboard
###############################################

from psdi.mbo import MboConstants
from psdi.server import MXServer
from psdi.util import MXApplicationException
from psdi.common.context import UIContext

mxServer = MXServer.getMXServer()
userInfo = mbo.getUserInfo()
currentDate = mxServer.getDate()

def refreshDashboardTables():

    context = UIContext.getCurrentContext()

    if context is None:
        return

    wcs = context.getWebClientSession()

    if wcs is None:
        return

    tableIds = [
        "results_showlist_2",
        "results_showlist"
    ]

    for tableId in tableIds:

        tableBean = wcs.getDataBean(tableId)

        if tableBean is not None:

            # Reload saved database records
            tableBean.getMboSet().reset()

            # Refresh displayed table
            tableBean.refreshTable()
            

def getNextSeq(conn, seqName):
    pstmt = None
    rs = None

    try:
        sql = "SELECT " + seqName + ".NEXTVAL FROM dual"

        pstmt = conn.prepareStatement(sql)
        rs = pstmt.executeQuery()

        if rs.next():
            return rs.getLong(1)

        return None

    finally:
        if rs is not None:
            rs.close()

        if pstmt is not None:
            pstmt.close()
            
def validateDesigner(personId):
    userSet = mxserver.getMboSet("MAXUSER", mbo.getUserInfo())

    try:
        personSafe = personId.replace("'", "''")

        userSet.setWhere(
            "PERSONID = '%s' AND USERID IN "
            "(SELECT USERID FROM GROUPUSER "
            "WHERE GROUPNAME = 'SG_ADV_003')" % personSafe
        )

        userSet.reset()

        if userSet.isEmpty():
            service.error(
                "scriptval",
                "scriptvalidationerror",
                [
                    "Currently design is in progress for Work Order " + wonum +
                    ". Reassignment is allowed only to a Designer. "
                    "Selected person: " + personId
                ]
            )

    finally:
        userSet.close()    
        


def checkAssignmentLimit(designer):
    MAX_WO = 3
    ACTIVE_STATUSES = ("DES_ASSIGNED","INPROGRESS","DES_QC_WAPPR","HOLD")
    site = mbo.getString("SITEID")

    woSet = None

    try:

        woSet = mxServer.getMboSet("WORKORDER",userInfo)
        designerSQL = designer.replace("'", "''")
        siteSQL = site.replace("'", "''")

        whereClause = (
            "OWNER = '%s' "
            "AND SITEID = '%s' "
            "AND WORKTYPE = 'ADV' "
            "AND ISTASK = 0 "
            "AND STATUS IN ("
            "'DES_ASSIGNED',"
            "'INPROGRESS',"
            "'DES_QC_WAPPR',"
            "'HOLD')"
        ) % (designerSQL, siteSQL)

        woSet.setWhere(whereClause)
        woSet.reset()

        activeCount = woSet.count()
        if activeCount >= MAX_WO:

            woDetails = []

            wo = woSet.moveFirst()

            while wo is not None:
                wonum = wo.getString("WONUM")
                status = wo.getString("STATUS")
                statusDesc = wo.getString("UXSYNONYMDOMAIN.DESCRIPTION")

                if not statusDesc:
                    statusDesc = status

                # Color indicators
                if status == "DES_ASSIGNED":
                    indicator = u"\U0001F534" 
                elif status == "INPROGRESS":
                    indicator = u"\U0001F7E0" 
                elif status == "DES_QC_WAPPR":
                    indicator = u"\U0001F7E1"  
                else:
                    indicator = u"\u25cf"
                
                woDetails.append(indicator + " " + wonum + " - " + statusDesc)
                #woDetails.append(wonum + " - " + statusDesc)

                wo = woSet.moveNext()

            errorMessage = (
                "Designer " + designer +
                " already has " +
                str(activeCount) +
                " active Work Orders.\n\n"
                "Maximum allowed: " +
                str(MAX_WO) + ".\n\n"
                "You cannot assign another Work Order "
                "until an existing Work Order "
                "is released from the active workload.\n\n"
                "Active Work Orders:\n" +
                "\n".join(woDetails)
            )

            service.error(
                "scriptval",
                "scriptvalidationerror",
                [errorMessage]
            )

    finally:

        if woSet is not None:
            woSet.close()
        

flags = MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION
NOACCESS = MboConstants.NOACCESSCHECK
mxserver = MXServer.getMXServer()
currentDate = mxserver.getDate()

appName = "DM_PLUSGWO_ADV"
currentOwner = mbo.getString("OWNER")
newPerson = mbo.getString("DM_ADV_ASSIGNEE")
wonum = mbo.getString("wonum")
status = mbo.getString("STATUS")

ownerid = mbo.getUniqueIDValue()
designerStatuses = ("DES_ASSIGNED","INPROGRESS","HOLD")
isDesignerStatus = status in designerStatuses

# ============================================================
# VALIDATION 1 - SAME OWNER
# ============================================================
if newPerson and currentOwner:
    if (isDesignerStatus and newPerson.upper() == currentOwner.upper()):
        message=["The selected person is already assigned as the designer for Work Order. Please select a different Designer."]
        service.error("scriptval","scriptvalidationerror",message)


# ============================================================
# VALIDATION 2 - DESIGNER ELIGIBILITY AND LIMIT
# ============================================================
if newPerson and isDesignerStatus:
    validateDesigner(newPerson)
    checkAssignmentLimit(newPerson)    

# ============================================================
# VALIDATION 3 - DESIGN QC CANNOT BE REASSIGNED TO SAME DESIGNER
# ============================================================
if newPerson and status == "DES_QC_WAPPR":
    if currentOwner and newPerson.upper() == currentOwner.upper():

        errorMessage = (
            "Work Order " + wonum +
            " is pending Design Quality Check. "
            "The workflow cannot be reassigned to the "
            "same person assigned as Designer (" +
            currentOwner + "). "
            "Please select a different person."
        )

        service.error(
            "scriptval",
            "scriptvalidationerror",
            [errorMessage]
        )    
    
# ============================================================
# REASSIGN WORKFLOW
# ========================================================    
if newPerson:
    ownerid = mbo.getUniqueIDValue()
    # Get active workflow assignment
    wfset = mbo.getMboSet(
        "$ACTIVEWFASSIGN",
        "WFASSIGNMENT",
        "ownertable='WORKORDER' and ownerid=%s and assignstatus='ACTIVE'" % ownerid
    )
    
    if not wfset.isEmpty():
        oldwf = wfset.getMbo(0)
        desc = oldwf.getString("DESCRIPTION")
        currentUser = mbo.getUserInfo().getPersonId()
        #newdesc = desc + " | Reassigned to you by : " + currentUser
        newdesc = "Workorder-" + wonum + " | Reassigned to you by : " + currentUser
        
        # # Mark all active assignment as forwarded
        i = 0
        while wfset.getMbo(i) is not None:
            oldwf1 = wfset.getMbo(i)
            oldwf1.setValue("ASSIGNSTATUS", "FORWARDED", MboConstants.NOACCESSCHECK)
            i += 1
        
        
        # Create new active assignment
        newSet = mbo.getMboSet("$NEWWFASSIGN", "WFASSIGNMENT", "1=2")
        newwf = newSet.add()
        
        newwf.setValue("DESCRIPTION", newdesc,NOACCESS)
        newwf.setValue("APP", appName, flags)
        newwf.setValue("ASSIGNCODE", newPerson, NOACCESS)
        newwf.setValue("WFID", oldwf.getString("WFID"), NOACCESS)
        newwf.setValue("NODEID", oldwf.getString("NODEID"), NOACCESS)
        newwf.setValue("TIMELIMIT", oldwf.getString("TIMELIMIT"), NOACCESS)
        newwf.setValue("PRIORITY", oldwf.getString("PRIORITY"), NOACCESS)
        newwf.setValue("ORIGPERSON", oldwf.getString("ORIGPERSON"), NOACCESS)
        newwf.setValue("ROLEID", oldwf.getString("ROLEID"), flags)
        newwf.setValue("PROCESSNAME", oldwf.getString("PROCESSNAME"), NOACCESS)
        newwf.setValue("PROCESSREV", oldwf.getString("PROCESSREV"), NOACCESS)
        newwf.setValue("OWNERTABLE", oldwf.getString("OWNERTABLE"), NOACCESS)
        newwf.setValue("OWNERID", oldwf.getString("OWNERID"), NOACCESS)
        newwf.setValue("TEMPLATEID", oldwf.getString("TEMPLATEID"), NOACCESS)
        newwf.setValue("EMAILNOTIFICATION", oldwf.getString("EMAILNOTIFICATION"), NOACCESS)
        newwf.setValue("CONDITION", oldwf.getString("CONDITION"), NOACCESS)
        newwf.setValue("CONDITIONCLASS", oldwf.getString("CONDITIONCLASS"), NOACCESS)
        newwf.setValue("LANGCODE", oldwf.getString("LANGCODE"), NOACCESS)
        newwf.setValue("ESCROLE", oldwf.getString("ESCROLE"), NOACCESS)
        newwf.setValue("CALENDARBASED", oldwf.getString("CALENDARBASED"), NOACCESS)
        newwf.setValue("HASLD", oldwf.getString("HASLD"), NOACCESS)
        newwf.setValue("GROUPNUM", oldwf.getString("GROUPNUM"), NOACCESS)
        newwf.setValue("SEPARATEGROUPS", oldwf.getString("SEPARATEGROUPS"), NOACCESS)
        newwf.setValue("ASSIGN_01", oldwf.getString("ASSIGN_01"), flags)
        newwf.setValue("ASSIGN_02", oldwf.getString("ASSIGN_02"), flags)
        newwf.setValue("ASSIGN_03", oldwf.getString("ASSIGN_03"), flags)
        newwf.setValue("ASSIGN_04", oldwf.getString("ASSIGN_04"), flags)
        newwf.setValue("ASSIGN_05", oldwf.getString("ASSIGN_05"), flags)
        
        newwf.setValue("ASSIGNSTATUS", "ACTIVE", NOACCESS)
        newwf.setValue("STARTDATE", currentDate, NOACCESS)
        newwf.setValue("DUEDATE", currentDate, NOACCESS)
        #newwf.setValue("ASSIGNID", mbo.getUniqueIDValue(), 11)
        #newwf.setValue("WFASSIGNMENTID", mbo.getUniqueIDValue(), 11)
        
        
        # ====================================================
        # Get new IDs 
        # ====================================================
        conn = None
        pstmt = None
        connectionKey = mxserver.getSystemUserInfo().getConnectionKey()
        try:

            conn = mxserver.getDBManager().getConnection(connectionKey)
            newAssignID = getNextSeq(conn,"WFASSIGNMENTSEQ")
            newWFAssignmentID = getNextSeq(conn,"WFASSIGNMENTUSEQ")

        finally:

            if conn is not None:
                mxserver.getDBManager().freeConnection(connectionKey)


        # ====================================================
        # Ensure sequence values were generated
        # ====================================================

        if newAssignID is None or \
           newWFAssignmentID is None:

            service.error(
                "dmadv",
                "sequenceerror"
            )
        newwf.setValue("ASSIGNID", newAssignID, 11)
        newwf.setValue("WFASSIGNMENTID", newWFAssignmentID, 11)
        
        
        wfset.save()    
        newSet.save()
             
        
        # insert workflow transaction history
        trset = mbo.getMboSet("$WFTRANS", "WFTRANSACTION", "1=2")
        tr = trset.add()
        
        # Workflow Reassignment Memo
        userMemo = mbo.getString("DM_ADV_MEMO").strip()
        reassignTo = mbo.getString("DM_ADV_ASSIGNEE")
        reassignBy = mbo.getUserInfo().getUserName()
        
        if userMemo:
            workflowMemo = userMemo
        else:
            workflowMemo = "Reassigned to %s by %s" % (reassignTo,reassignBy)
        
        tr.setValue("WFID", oldwf.getLong("WFID"), 11)
        tr.setValue("ASSIGNID", oldwf.getLong("ASSIGNID"), 11)
        tr.setValue("NODEID", oldwf.getLong("NODEID"), 11)
        tr.setValue("TRANSTYPE", "WFFORWARDED", 11)
        tr.setValue("TRANSDATE", MXServer.getMXServer().getDate(), 11)
        tr.setValue("MEMO", workflowMemo, 11)
        tr.setValue("NODETYPE", "TASK", 11)
        tr.setValue("PROCESSREV", oldwf.getInt("PROCESSREV"), 11)
        tr.setValue("PROCESSNAME", oldwf.getString("PROCESSNAME"), 11)
        tr.setValue("PERSONID", mbo.getUserInfo().getPersonId(), 11)
        tr.setValue("OWNERTABLE", "WORKORDER", 11)
        tr.setValue("OWNERID", mbo.getUniqueIDValue(), 11)
        
        trset.save()
        mbo.setValueNull("DM_ADV_MEMO", 11)
        
    # Update work order ownership
    if isDesignerStatus:
        woSet = mbo.getMboSet("$UPDWO", "WORKORDER", "workorderid=%s" % ownerid)
        wo = woSet.getMbo(0)
        if wo is not None:
            wo.setValue("OWNER", newPerson, 11)
            wo.setValue("DM_ADV_ASSIGN", currentDate, 11)
            wo.setValueNull("OWNERGROUP", 11)
            if wo.getString("STATUS") == "WASSIGN":
                wo.changeStatus("DES_ASSIGNED", MXServer.getMXServer().getDate(), "Reassign", 11)
        woSet.save()
        
    refreshDashboardTables()    
        
    service.closeDialog()