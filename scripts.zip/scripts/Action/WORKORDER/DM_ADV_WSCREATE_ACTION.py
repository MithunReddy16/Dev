##############################################
#script:DM_ADV_WSLINE
#Createdby:NK
#Creation Date:20-04-2026
#scope: Add workshop team
###############################################
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

myLogger = MXLoggerFactory.getLogger("maximo.custom")
myLogger.debug("****This is DM_ADV_WSCREATE_ACTION****")

session = service.webclientsession()
mainBean = session.getDataBean("mainrecord")
requestMbo = mainBean.getMbo()

wsDatabean = session.getDataBean("dm_adv_wsteam_tb")
requestLineMboSet = requestMbo.getMboSet("DM_ADV_WS")

if wsDatabean is not None:
    myLogger.debug("****This is DM_ADV_WSCREATE - 1****")
    wsSet = wsDatabean.getMboSet()

    selectedRecords = wsSet.getSelection()
    iterator = selectedRecords.iterator()

    # create new line for each selected person
    while iterator.hasNext():
        myLogger.debug("****This is DM_ADV_WSCREATE - 2****")
        wsMbo = iterator.next()
        requestLineMbo = requestLineMboSet.add()
        requestLineMbo.setValue("PERSONID", wsMbo.getString("PERSONID"))
        requestLineMbo.setValue("TEAMTYPE",'WS')

    requestLineMboSet.save()
    service.closeDialog()
    mainBean.SAVE()