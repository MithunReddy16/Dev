###############################################
#script:DM_TR_REGWORK
#Createdby:NK
#Creation Date:18/06/26
#scope: Create Registration workorder for TR
###############################################

from psdi.mbo import MboConstants
from psdi.server import MXServer

mxServer = MXServer.getMXServer()
userInfo = mbo.getUserInfo()
wfService = mxServer.lookup("WORKFLOW")

NOACCESS = MboConstants.NOACCESSCHECK
flags = MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION

assetnum = mbo.getString("ASSETNUM")
siteid = mbo.getString("SITEID")
orgid = mbo.getString("ORGID")
mainJP = mbo.getString("DM_ASSETGROUP")
mainDept = mbo.getString("DM_MAINTDEPT")

chkSet = None
woSet = None
newWOSet = None

try:
    chkSet = mbo.getMboSet(
        "$CHK_REG_WO",
        "WORKORDER",
        "assetnum='%s' and siteid='%s' "
        "and worktype='REG' "
        "and status not in ('CAN','CLOSE')" % (assetnum, siteid)
    )
    chkSet.reset()

    if chkSet.isEmpty():

        woSet = mxServer.getMboSet("WORKORDER", userInfo)

        # Parent WO
        wo = woSet.add()
        wo.setValue("SITEID", siteid, NOACCESS)
        wo.setValue("ORGID", orgid, NOACCESS)
        wo.setValue("ASSETNUM", assetnum, NOACCESS)
        wo.setValue("WORKTYPE", "REG", NOACCESS)
        wo.setValue("DM_TRPRIORITY", "1", NOACCESS)
        wo.setValue("AMCREW", "RECPT", NOACCESS)
        wo.setValue("JPNUM", mainJP, NOACCESS)
        wo.setValue("DM_MAINTDEPT", mainDept, NOACCESS)
        wo.setValue(
            "DESCRIPTION",
            "Asset %s - vehicle registration expiry date reached" % assetnum,NOACCESS)

        woSet.save()
        parentWo = wo.getString("WONUM")

        
        # Send email from parent WO
        newWOSet = mbo.getMboSet(
            "$NEWREGWO",
            "WORKORDER",
            "wonum='%s' and siteid='%s'" % (parentWo, siteid)
        )
        newWOSet.reset()
        newWO = newWOSet.getMbo(0)
        if newWO is not None:
            commSet = newWO.getMboSet("COMMLOG")
            comm = commSet.add()
            comm.setValue("TEMPLATEID", "DM_TR_REG", NOACCESS)
            comm.sendMessage()
            commSet.save()
            
        newWOSet.save()    
        newWOSet.close()

finally:
    if chkSet:
        chkSet.close()
    if newWOSet:
        newWOSet.close()
    if woSet:
        woSet.close()