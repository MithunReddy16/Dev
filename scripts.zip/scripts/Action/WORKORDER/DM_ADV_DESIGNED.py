###############################################
#script:DM_ADV_DESIGNED
#Createdby:nk
#Creation Date:16-04-26
#scope: Requester delay
###############################################

from psdi.server import MXServer
from psdi.mbo import MboConstants

if mbo is not None and mbo.getString("STATUS") == "REQWAPPR":
    mbo.changeStatus("DESIGNED",MXServer.getMXServer().getDate(),"Auto-closed: requester did not respond within 3 days")
    mbo.getThisMboSet().save()
    
     # Stop active workflow instance
    ownerid = mbo.getUniqueIDValue()
    wfset = mbo.getMboSet(
        "$STOPWF",
        "WFINSTANCE",
        "ownertable='WORKORDER' and ownerid=%s and active=1" % ownerid
    )

    wf = wfset.moveFirst()
    while wf:
        try:
            wf.stopWorkflow("Auto stopped by escalation - no response from requester")
        except:
            # fallback if method not available
            wf.setValue("ACTIVE", 0)
        wf = wfset.moveNext()

    wfset.save()