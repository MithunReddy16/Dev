#script:DM_WOASTSTATUSSCRIPT
#Createdby:Ram
#Creation Date:29-AUG-23
#scope: through workflow,script changes the asset status to out of service if the workorder status is assigned otherwise asset status wil be operating
#Modifiedby: NK,14-Aug-25, Change - added changestatus method and memo


from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.mbo import MboSet
from psdi.util.logging import MXLoggerFactory

myLogger = MXLoggerFactory.getLogger("maximo.script")
myLogger.debug("****This is DM_WOASTSTATUSSCRIPT****")

assetnum = mbo.getString("ASSETNUM")
wostatus = mbo.getString("status")
wonum = mbo.getString("WONUM")
pc = mbo.getString("DM_VENDCONTRACT")
pc_empty = (pc is None) or (str(pc).strip() == "")
memo = "Auto-set via PM workflow by WO"+wonum

if assetnum:
    assetSet = None
    assetSet = MXServer.getMXServer().getMboSet("ASSET", mbo.getUserInfo())
    assetSet.setWhere("assetnum= '"+assetnum+"'")
    assetSet.reset()
    assetMbo = assetSet.moveFirst()
    if (assetMbo):
        current_status= assetMbo.getString("Status")
        myLogger.debug("****DM_WOASTSTATUSSCRIPT-0****"+current_status)
        myLogger.debug("****DM_WOASTSTATUSSCRIPT-wostatus:"+wostatus)
        myLogger.debug("****DM_WOASTSTATUSSCRIPT-pc:"+pc)
        # if (wostatus=='ASSIGNED' and pc_empty) or (pc is not None):
        if (wostatus=='ASSIGNED'):
            myLogger.debug("****DM_WOASTSTATUSSCRIPT-1****"+wostatus)
            if current_status != 'OOS':
                myLogger.debug("****DM_WOASTSTATUSSCRIPT-2****"+current_status)
                assetMbo.changeStatus("OOS",MXServer.getMXServer().getDate(),memo,MboConstants.NOACCESSCHECK)
                # asset.setValue("status","OOS",MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK)
                assetSet.save()
        else:
            if current_status not in  ('OPERATING','DECOMMISSIONED'):
                myLogger.debug("****DM_WOASTSTATUSSCRIPT-3****"+current_status)
                #asset.setValue("status","OPERATING",MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK)
                assetMbo.changeStatus("OPERATING",MXServer.getMXServer().getDate(),memo,MboConstants.NOACCESSCHECK)
                assetSet.save()
               
            elif current_status =='DECOMMISSIONED':
                myLogger.debug("****DM_WOASTSTATUSSCRIPT-3****"+current_status)
                #asset.setValue("status","OPERATING",MboConstants.NOVALIDATION | MboConstants.NOACCESSCHECK)
                assetMbo.changeStatus("MREF_DRAFT",MXServer.getMXServer().getDate(),memo,MboConstants.NOACCESSCHECK)
                assetSet.save()