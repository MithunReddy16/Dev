# Created by: Ram
# Date: 03-Jul-25
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

# Initialize Logger
logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("*** Script DM_CREATEPR START ***")

try:
    # Confirm context
    logger.error("*** MBO Object: " + mbo.getName())
    logger.error("*** Running as User: " + mbo.getUserInfo().getUserName())

    # Get related WPService lines
    wpSet = mbo.getMboSet("WPSERVICE")
    servicesByVendor = {}

    for i in range(wpSet.count()):
        wp = wpSet.getMbo(i)
        if wp.getString("LINETYPE") == "SERVICE" and wp.getString("VENDOR") and not wp.getString("PR"):
            vendor = wp.getString("VENDOR")
           # service.error("563","PRrrrrrrrrrr")
            logger.error("*** Found service line for vendor: " + vendor + " - " + wp.getString("DESCRIPTION"))

            if vendor not in servicesByVendor:
                servicesByVendor[vendor] = []
            servicesByVendor[vendor].append(wp)

    # Loop through each vendor group to create PRs
    for vendor in servicesByVendor:
        wpList = servicesByVendor[vendor]
        prSet = mbo.getMboSet("$PR", "PR", "")
        pr = prSet.add()

        pr.setValue("VENDOR", vendor)
        pr.setValue("DM_AUTOCREATED", True)
        pr.setValue("DM_SOURCE", "WO")
        pr.setValue("DM_SOURCE", mbo.getString('WONUM'))
        
        pr.setValue("DESCRIPTION", "Auto PR for vendor " + vendor + " and WO " + mbo.getString("WONUM"))

        prLineSet = pr.getMboSet("PRLINE")

        for wpMbo in wpList:
            prLine = prLineSet.add()
            prLine.setValue("LINETYPE", "SERVICE")
            prLine.setValue("DESCRIPTION", wpMbo.getString("DESCRIPTION"))
            prLine.setValue("ORDERQTY", wpMbo.getDouble("DM_ACCEPTQTY"))
            prLine.setValue("UNITCOST", wpMbo.getDouble("UNITCOST"))
            prLine.setValue("COMMODITY", wpMbo.getString("DM_COMMODITY"))
            prLine.setValue("COMMODITYGROUP", wpMbo.getString("DM_COMMODITYGROUP"))
            prLine.setValue("WONUM", mbo.getString("WONUM"))

            # Link PR and PR Line to wpservice
            wpMbo.setValue("PR", pr.getString("PRNUM"), MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
            wpMbo.setValue("PRLINENUM", prLine.getInt("PRLINENUM"), MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)

        # Try to approve PR
        try:
            logger.error("*** Attempting PR APPR for vendor: " + vendor)
            pr.changeStatus("APPR", MXServer.getMXServer().getDate(), "From Script DM_CREATEPR", 2)
            logger.error("*** PR approved for vendor: " + vendor)
        except Exception as e:
            logger.error("*** Failed to approve PR for vendor " + vendor + ": " + str(e))

    # Save everything (this is CRITICAL in Escalation context)
    try:
        mbo.getThisMboSet().save()
        logger.error("*** Changes saved successfully")
    except Exception as e:
        logger.error("*** Save failed: " + str(e))

except Exception as ex:
    logger.error("*** General Exception in DM_CREATEPR: " + str(ex))

logger.error("*** Script DM_CREATEPR END ***")