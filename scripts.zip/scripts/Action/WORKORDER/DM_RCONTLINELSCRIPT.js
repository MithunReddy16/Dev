//script:DM_RCONTLINELSCRIPT
//Createdby:Ram
//Creation Date:08-APR-25
//scope: in workorder gm application ,based on the route which is coming from pm via contracts,script will copy the contract lines  to workorder boq tab

load("nashorn:mozilla_compat.js");
importPackage(java.util);
importPackage(Packages.psdi.server);
importPackage(Packages.psdi.mbo);
importPackage(Packages.psdi.util.logging);
importPackage(Packages.psdi.app.contract.purch);
importPackage(Packages.psdi.app.contract.software);
importPackage(Packages.psdi.security);

var logger = MXLoggerFactory.getLogger("maximo.script.dm");
var section = mbo.getString("dm_maintdept");


//service.error("dm","genericerror",[""+section+""])    
if (mbo.getName() == "WORKORDER" && section) {


    var valueSet = mbo.getMboSet("$value", "DM_ORGHIERARCHY", "parent1id = '" + section + "' OR unitid = '" + section + "'");

    if (valueSet !== null && !valueSet.isEmpty()) {
        for (var i = 0; i < valueSet.count(); i++) {
            var maxvalue = valueSet.getMbo(i).getString("abbriviation");
            var unitid = valueSet.getMbo(i).getString("unitid");

            if (maxvalue == "GMD" && unitid == section) {
                // service.error("dm","genericerror",[""+section+""])    
                var route = mbo.getString("route")
                var contractnum = mbo.getString("dm_vendcontract")
                var pmnum = mbo.getString("pmnum")


                logger.info("Route: " + route + ", Contract: " + contractnum);

                if (pmnum !== null && contractnum !== null && route !== null) {
                    //service.error("dm","genericerror",[""+ contSet.count()+""])    
                    // var whereClause = "dm_route='" + route + "'";
                    //    logger.info("Where Clause: " + whereClause);

                    var contSet = mbo.getMboSet("DM_ROUTECONTRACTS")
                    //  contSet.setWhere(whereClause);
                    contSet.reset();
                    //service.error("dm","genericerror",[""+ contSet.count()+""])    
                    logger.info("Matching CONTRACTLINE records: " + contSet.count());
                    if (contSet.count() > 0) {
                        numberOfContractLines = contSet.count()
                        for (var j = 0; j < numberOfContractLines; j++) {
                            var contractLineMbo = contSet.getMbo(j);


                            logger.error("Processing line " + (j + 1) + ": " + contractLineMbo.getString("LINETYPE") + " | " + contractLineMbo.getString("ITEMNUM"));

                            logger.info("Processing line " + (j + 1) + ": " + contractLineMbo.getString("LINETYPE") + " | " + contractLineMbo.getString("ITEMNUM"));

                            if ((contractLineMbo.getString("LINETYPE") == "SERVICE" || contractLineMbo.getString("LINETYPE") == "STDSERVICE") && contractLineMbo.getString("DM_BTYPE") =="PM"  ) {
                                var wpServiceSet = mbo.getMboSet("WPSERVICE");

                                //service.error("dm","genericerror",[""+section+""])    
                                logger.error("***ASH***Sript DM_RCONTLINELSCRIPT**wpServiceMbo before add")
                                wpServiceMbo = wpServiceSet.add();
                                logger.error("***ASH***Sript DM_RCONTLINELSCRIPT**wpServiceMbo itemnum=" + contractLineMbo.getString("ITEMNUM"))
                                wpServiceMbo.setValue("LINETYPE", contractLineMbo.getString("LINETYPE"), 2)
                                wpServiceMbo.setValue("ITEMNUM", contractLineMbo.getString("ITEMNUM"), 2)
                                wpServiceMbo.setValue("DESCRIPTION", contractLineMbo.getString("DESCRIPTION"), 2)
                                //wpServiceMbo.setValue("ITEMQTY",contractLineMbo.getString("ORDERQTY"),2)
                                wpServiceMbo.setValue("ITEMQTY", "1", 2)
                                wpServiceMbo.setValue("WONUM", mbo.getString("WONUM"), 2)
                                wpServiceMbo.setValue("SITEID", mbo.getString("SITEID"), 2)
                                wpServiceMbo.setValue("DM_CONTREFLINEID", contractLineMbo.getLong("CONTRACTLINEID"), 2)
                                wpServiceMbo.setValue("DIRECTREQ", "1", 2)
                                wpServiceMbo.setValue("ITEMSETID", contractLineMbo.getString("ITEMSETID"), 2)
                                wpServiceMbo.setValue("UNITCOST", contractLineMbo.getDouble("UNITCOST"), 2)
                                //wpServiceMbo.setValue("INSPECTIONREQUIRED",contractLineMbo.getInt("INSPECTIONREQUIRED"),2)
                                wpServiceMbo.setValue("DM_APPRQTY", "0", 2)
                                wpServiceMbo.setValue("DM_ACCEPTQTY", "0", 2)

                                //The below lines added by Ashok on 16-Sep-24
                                wpServiceMbo.setValue("DM_NEWLINETYPE", contractLineMbo.getString("DM_NEWLINETYPE"), 2)
                                wpServiceMbo.setValue("DM_CATEGORY", contractLineMbo.getString("DM_CATEGORY"), 2)
                                wpServiceMbo.setValue("DM_BTYPE", contractLineMbo.getString("DM_BTYPE"), 2)
                                wpServiceMbo.setValue("DM_TYPE", contractLineMbo.getString("DM_TYPE"), 2)
                                logger.info("WPSERVICE added for item: " + contractLineMbo.getString("itemnum"));
                            }
                        }
                    }
                } else {
                    logger.info("Contract number or route is null. Skipping execution.");
                }
            }
        }
    }
}