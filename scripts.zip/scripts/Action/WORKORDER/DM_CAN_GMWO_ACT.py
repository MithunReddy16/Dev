#------------------------------------------------------------------------
#Script Name :DM_CAN_GMWO_ACT
#Launch Point Type: Action
#Description :Cancel GM Work Order
#Comment     :Used in Work Order Tracking (GM)(DM) applications
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          30-07-2026         Initiate version.

#------------------------------------------------------------------------
from psdi.server import MXServer 
from psdi.mbo import MboConstants

mxServer=MXServer.getMXServer()
#change work order status to Cancel
mbo.changeStatus("CAN", mxServer.getDate(), "The Work Order Cancelled by: "+mbo.getUserInfo().getPersonId())

WFService = MXServer.getMXServer().lookup("WORKFLOW")
# get active wfinstance related to the current workorder
woWFInstanceSet = WFService.getActiveInstances(mbo)
woWFInstance =woWFInstanceSet.moveFirst()
if woWFInstance:
    #Stop the workflow
    woWFInstance.stopWorkflow("The Work Order Cancelled by: "+mbo.getUserInfo().getPersonId())
    woWFInstanceSet.save()
#save and refech the workorder    
service.webclientsession().getDataBean("mainrecord").SAVE()