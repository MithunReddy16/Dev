####################################
#script:DM_ADV_SETVALUES
#created by :NK
#purpose: Set Values in WO 
#Date:16-Mar-26
####################################

from psdi.mbo import MboConstants


userInfo = mbo.getUserInfo()
userid = userInfo.getUserName()
personId = userid

personSet = None
try:
    personSet = mbo.getMboSet("$PERSON", "PERSON", "personid='%s'" % userid)
    person = personSet.moveFirst()
    if person:
        if not person.isNull("PERSONID"):
            personId = person.getString("PERSONID")

    if launchPoint == "DM_ADV_PRINTBY":
        mbo.setValue("DM_ADV_PRINTBY", personId,
                     MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)

    elif launchPoint == "DM_ADV_PRINTQCBY":
        mbo.setValue("DM_ADV_PQUAL", personId,
                     MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)
    
    elif launchPoint == "DM_ADV_WQUAL":
        mbo.setValue("DM_ADV_WQUAL", personId,
                     MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)

finally:
    if personSet:
        personSet.close()