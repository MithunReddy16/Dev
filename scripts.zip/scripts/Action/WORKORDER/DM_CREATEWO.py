#------------------------------------------------------------------------

#Script Name :DM_CREATEWO
#Description :script to Create Follo-Up WO from GM WO application
#Comment     :Used in GM WO application
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
# Samer Al Fakih      SWORD_salfakih@dm.ae     1.0          01-JAN-2026         Initiate version.

#------------------------------------------------------------------------

from psdi.mbo import MboConstants
from java.util import HashMap
# Initialize variables
zoneId = None
serviceType = None

# Get basic values
location = mbo.getString("LOCATION")
serviceId = mbo.getString("DM_SERVICEID")
workType = mbo.getString("WORKTYPE")

# -----------------------------
# Get Zone from Location
# -----------------------------
if location:
    locSet = mbo.getMboSet(
        "TEMP_LOCATIONS",
        "LOCATIONS",
        "LOCATION='{}'".format(location)
    )
    locMbo = locSet.moveFirst()
    if locMbo:
        zoneId = locMbo.getString("DM_ZONES")
# -----------------------------
# Get Service Type
# -----------------------------
if serviceId:
    serviceSet = mbo.getMboSet(
        "TEMP_DM_SERVICECATALOG",
        "DM_SERVICECATALOG",
        "SERVICEID='{}'".format(serviceId)
    )
    serviceMbo = serviceSet.moveFirst()
    if serviceMbo:
        serviceType = serviceMbo.getString("TYPE")

#-------------------------------------------------------
# Create Follow-Up Work Order
#-------------------------------------------------------
woSet = mbo.getMboServer().getMboSet("WORKORDER", mbo.getUserInfo())
wo = mbo.createWorkorder(woSet, None, False)

wo.setValue("DM_MAINTDEPT", mbo.getString("DM_MAINTDEPT"), MboConstants.NOACCESSCHECK)
wo.setValue("WOPRIORITY", mbo.getString("WOPRIORITY"), MboConstants.NOACCESSCHECK)
wo.setValue("DM_SERVICEID", mbo.getString("DM_SERVICEID"), MboConstants.NOACCESSCHECK)
wo.setValue("TARGSTARTDATE", mbo.getString("TARGSTARTDATE"), MboConstants.NOACCESSCHECK)
wo.setValue("TARGCOMPDATE", mbo.getString("TARGCOMPDATE"), MboConstants.NOACCESSCHECK)

#-------------------------------------------------------
# Contractor Follow-Up WO
#-------------------------------------------------------
if launchPoint == "DM_CREATEWO_CONT":

    wo.setValue("DM_INHOUSE", 0, MboConstants.NOACCESSCHECK)

    if not mbo.isNull("LOCATION"):
        zone = mbo.getString("WO_LOCATION.DM_ZONES")

        zoneSet = mbo.getMboSet(
            "$ZONEMAP",
            "ALNDOMAIN",
            "DOMAINID='DM_ZONEMAPPING' AND VALUE='%s'" % zone
        )
        zoneMbo = zoneSet.getMbo(0)

        if zoneMbo:
            contNum = zoneMbo.getString("DESCRIPTION")

            contSet = mbo.getMboSet(
                "$CONTRACT",
                "PURCHVIEW",
                "CONTRACTNUM='%s' AND STATUS='APPR'" % contNum
            )
            contMbo = contSet.getMbo(0)

            if contMbo:
                vendor = contMbo.getString("VENDOR")
                wo.setValue("VENDOR", vendor, MboConstants.NOACCESSCHECK)
                wo.setValue("DM_VENDCONTRACT", contNum, MboConstants.NOACCESSCHECK)

#-------------------------------------------------------
# In-House Follow-Up WO
#------------------------------------------------`
elif launchPoint == "DM_CREATEWO_INH":
    wo.setValue("DM_INHOUSE", 1, MboConstants.NOACCESSCHECK)
    
ctx = HashMap()
ctx.put("mbo", mbo)
ctx.put("launchPoint", "DM_APPLY_OWNER_WO")
service.invokeScript("DM_APPLY_OWNER", ctx)

#-------------------------------------------------------
# Save and notify user
#-------------------------------------------------------
woSet.save()

wcs = service.webclientsession()
params = [wo.getString("WONUM")]
wcs.showMessageBox("dm", "dm_createwo", params)