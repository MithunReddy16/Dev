from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory

woWhere ='''
status in ('COMP','CLOSE')
and woclass in ('WORKORDER','ACTIVITY') and pmnum is not null  and istask = 0 and siteid = 'DM' 
and not exists (select 1 from poline where refwo = workorder.wonum and siteid=workorder.siteid)
and wonum in (select wonum from wpservice) and dm_maintdept ='1996' 
'''

woMboSet =MXServer.getMXServer().getMboSet("WORKORDER", mbo.getUserInfo())
#woMboSet = mbo.getMboSet("WOUHHgjdfbjdbf3","WORKORDER",woWhere)
woMboSet.setWhere(woWhere)
woMboSet.reset()
woCount = woMboSet.count()
i =0
woMbo = woMboSet.moveFirst()
while woMbo:
    if not woMbo.isNull("DM_VENDCONTRACT") and not woMbo.isNull("VENDOR"):
	where = ("CONTRACTNUM=:DM_VENDCONTRACT  and status ='APPR'" )
	purcviewMbo = woMbo.getMboSet("$PURCHVIEW", "PURCHVIEW", where).getMbo(0)
	if purcviewMbo:
	    wpItemSet = woMbo.getMboSet("$WPITEM","WPITEM","wonum=:wonum and siteid=:siteid and DM_CONTREFLINEID is not null " )
	    wpItemSet.reset()
	    wpItemMbo = wpItemSet.getMbo(0)
	    poCreated = False
	    if wpItemMbo:
	        if  wpItemMbo.getBoolean("DM_APPROVED"):
				if True:
					poHeaderMbo = purcviewMbo.createPOHeader("DM")
					if poHeaderMbo.isNull("ponum") :
						ponumAk = poHeaderMbo.getMboValue("PONUM")
						ponumAk.autoKey()
						ponum = poHeaderMbo.getString("PONUM")
						poHeaderMbo.setValue("PONUM", ponum)
					
				releasePOLineSetRemote = poHeaderMbo.getMboSet("POLINE")
				#createRelInputRemote = releasePOLineSetRemote.add()
				#createRelInputRemote.setValue("WONUM", woMbo.getString("WONUM"))
				purchviewLineMboSet = purcviewMbo.getMboSet("Phhxcosaoso","CONTRACTLINE","itemnum='"+wpItemMbo.getString("itemnum")+"' and CONTRACTNUM=:CONTRACTNUM")
				purchviewLineMboSet.reset()
				purchviewLineMbo = purchviewLineMboSet.getMbo(0)
				if purchviewLineMbo:
					itemqty = wpItemMbo.getDouble("itemqty")
					wpItemMbo.setValue("DM_APPRQTY", itemqty, 2)
					wpItemMbo.setValue("DM_ACCEPTQTY", itemqty, 2)
					contractLineRemote = purchviewLineMbo
				#releasePOLineRemote = releasePOLineSetRemote.add()
					#contractLineRemote.copyPurchContractLine(releasePOLineRemote, createRelInputRemote)
					releasePOLineRemote = poHeaderMbo.getMboSet("POLINE").add()
					releasePOLineRemote.setValue("CONTRACTREFID", purcviewMbo.getLong("CONTRACTID"), 66)
					releasePOLineRemote.setValue("LINETYPE", "STDSERVICE", MboConstants.NOACCESSCHECK)
					releasePOLineRemote.setValue("ITEMNUM", wpItemMbo.getString("ITEMNUM"), MboConstants.NOACCESSCHECK)
					releasePOLineRemote.setValue("DESCRIPTION", wpItemMbo.getString("DESCRIPTION"), MboConstants.NOACCESSCHECK)
					#releasePOLineRemote.setValue("DM_NEWLINETYPE", wpItemMbo.getString("DM_NEWLINETYPE"), MboConstants.NOACCESSCHECK)
					releasePOLineRemote.setValue("ORDERQTY", wpItemMbo.getDouble("itemqty"), MboConstants.NOACCESSCHECK)
					releasePOLineRemote.setValue("UNITCOST", wpItemMbo.getDouble("UNITCOST"), MboConstants.NOACCESSCHECK)
					releasePOLineRemote.setValue("DM_WPITEMID", wpItemMbo.getLong("WPITEMID"))
					releasePOLineRemote.setValue("WONUM", woMbo.getString("WONUM"))
					#service.error("description",releasePOLineRemote.getString("description"))
					releasePOLineSetRemote.save()
					poHeaderMbo.changeStatus("APPR", MXServer.getMXServer().getDate(), "From Script DM_CRTRELPO", 2)
					releasePOLineSetRemote.save()
					releasePOLineSetRemote.cleanup
					wpItemSet.save()
					wpItemSet.cleanup()
	woMbo = woMboSet.moveNext()
	i = i+1
	if i >= woCount:
	    break;
	

woMboSet.save()
woMboSet.cleanup()