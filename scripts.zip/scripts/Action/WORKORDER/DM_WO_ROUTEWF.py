# Import the required UI context class
from psdi.common.context import UIContext
from psdi.mbo import SqlFormat
from psdi.server import MXServer

#get most recent completed assignment
def getMboAssignments(wombo, personid):
  sqf = SqlFormat(wombo, "ownertable=:1 and wfassignment.ownerid=:2 and ASSIGNSTATUS ='COMPLETE' order by ASSIGNID DESC FETCH FIRST 1 ROW ONLY")
  sqf.setObject(1, "WFASSIGNMENT", "OWNERTABLE", "WORKORDER")
  sqf.setLong(2, wombo.getUniqueIDValue())
  sqf.setObject(3, "WFASSIGNMENT", "ASSIGNCODE", personid)
  assignSet = wombo.getMboSet("$CURMBOASGN", "WFASSIGNMENT", sqf.format())
  assignSet.reset()
  return assignSet

#Get the current WebClientSession and Application instance
webClientSession = UIContext.getCurrentContext().getWebClientSession()
currentApp = webClientSession.getCurrentApp()

#Access the underlying results bean and MboSet of the List tab
resultsBean = currentApp.getResultsBean()
mboSet = resultsBean.getMboSet()
userInfo = mboSet.getUserInfo()
personid = userInfo.getPersonId()
# Step 3: Fetch the Vector containing only the selected Mbo records
selectedRecords = mboSet.getSelection()
currentMemo="Incorrect service report - end-user signature is missing"
#Loop through the selected records
wfSrv = MXServer.getMXServer().lookup('WORKFLOW')
if not selectedRecords.isEmpty():
    for i in range(selectedRecords.size()):
        wonum = selectedRecords.get(i).getString("wonum")
        woMboSet = MXServer.getMXServer().getMboSet("WORKORDER",mboSet.getUserInfo())
        woMboSet.setWhere("wonum ='"+wonum+"' and siteid ='DM'")
        woMboSet.reset()
        woMbo = woMboSet.getMbo(0)
        if not woMbo:
            continue
        wfactiveInstanceSet =wfSrv.getActiveInstances(woMbo)
        #stop the current wf process
        wfactiveInstanceSet.getMbo(0).stopWorkflow(currentMemo)
        wfactiveInstanceSet.save()
       
        woMbo.changeStatus("REWORK",MXServer.getMXServer().getDate(),currentMemo,2)
        woMboSet.save()
        
        #get last completed assignment 
        wfAsSet = getMboAssignments(woMbo, personid)
        if not wfAsSet.isEmpty():           
            assign = wfAsSet.getMbo(0)
            if assign:
                #get all recent assignments
                allAssignmnetSet = assign.getMboSet("All_RECENT_WFASSIGNMENTS","wfassignment","wfid=:wfid and ownerid=:ownerid and OWNERTABLE='WORKORDER' and nodeid=:nodeid")
                allAssignmnetSet.reset()
                assignmnet = allAssignmnetSet.moveFirst()
                nodeid = assignmnet.getInt("nodeid")
                #re-activate the assignments
                while assignmnet:
                    assignmnet.setValue("ASSIGNSTATUS","ACTIVE",11)
                    assignmnet = allAssignmnetSet.moveNext()
                
                allAssignmnetSet.save() 
                #Re-Activate the wf instance.
                instanceSet = assign.getMboSet("GET_RECENT_WFINSTANCE","WFINSTANCE","wfid=:wfid")
                instanceSet.reset()
                instanceSet.getMbo(0).setValue("active",1,11)
                instanceSet.save()
                # Re-activate CallStack and update the node id             
                callStackSet = assign.getMboSet("GET_RECENT_CALLSTACK","WFCALLSTACK","wfid=:wfid and PROCESSNAME !='DM_WGMCMZC' ")
                callStackSet.reset()
                callStack = callStackSet.moveFirst()
                while callStack:
                    callStack.setValue("ACTIVE",1,11)
                    #update the nodeid
                    if callStack.getString("PROCESSNAME") == assign.getString("PROCESSNAME"):
                        callStack.setValue("nodeid",nodeid)
                    callStack = callStackSet.moveNext()
                callStackSet.save()
    mboSet.save()

            

else:
    # Optional handling if no records were explicitly ticked
    pass