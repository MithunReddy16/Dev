##############################################
#script:DM_ADV_WSLINE
#Createdby:NK
#Creation Date:20-04-2026
#scope: Add workshop team
###############################################

service.log_debug("######################################## Start:" + scriptName+" ######################")
session = service.webclientsession()
mainBean = session.getDataBean("mainrecord")
requestMbo = mainBean.getMbo()

wsDatabean = session.getDataBean("dm_adv_wsteam1_tb")
requestLineMboSet = requestMbo.getMboSet("DM_ADV_WS")

if wsDatabean is not None:
    wsSet = wsDatabean.getMboSet()

    selectedRecords = wsSet.getSelection()
    iterator = selectedRecords.iterator()

    # create new line for each selected person
    while iterator.hasNext():
        wsMbo = iterator.next()
        requestLineMbo = requestLineMboSet.add()
        requestLineMbo.setValue("PERSONID", wsMbo.getString("PERSONID"))
        requestLineMbo.setValue("TEAMTYPE",'INSTALL')

    requestLineMboSet.save()
    service.closeDialog()
    mainBean.SAVE()
    service.log_debug("######################################## end:" + scriptName+" ######################")