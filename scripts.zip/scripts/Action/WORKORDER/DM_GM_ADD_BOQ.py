from java.util import HashMap

ctx = HashMap()
ctx.put("mbo", mbo)
service.invokeScript("DM_RCONTLINELSCRIPT", ctx)