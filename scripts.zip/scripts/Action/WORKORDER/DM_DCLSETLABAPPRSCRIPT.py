from psdi.server import MXServer
from psdi.mbo import MboConstants

if launchPoint == 'DM_DCLSETLABAPPR':
    #service.error("dm","genercierror",["test"])
        mbo.changeStatus("REASSIGNED", MXServer.getMXServer().getDate(), '', MboConstants.NOACCESSCHECK)
        
    
        labtransSet = mbo.getMboSet("LABTRANS")
        
        if labtransSet is not None and not labtransSet.isEmpty():
            labmbo = labtransSet.moveFirst()
            while labmbo:
                labmbo.setValue("GENAPPRSERVRECEIPT", 0, MboConstants.NOACCESSCHECK)
                labmbo = labtransSet.moveNext()
        
        
        #mbo.getThisMboSet().save()
if launchPoint == 'DM_DCLDESETLABAPPR':
    #service.error("dm","genercierror",["test"])
        mbo.changeStatus("ASSIGNED", MXServer.getMXServer().getDate(), '', MboConstants.NOACCESSCHECK)
        
    
        labtransSet = mbo.getMboSet("LABTRANS")
        
        if labtransSet is not None and not labtransSet.isEmpty():
            labmbo = labtransSet.moveFirst()
            while labmbo:
                labmbo.setValue("GENAPPRSERVRECEIPT", 0, MboConstants.NOACCESSCHECK)
                labmbo = labtransSet.moveNext()
        
        
            
if launchPoint == "DM_DCLSETDISC":
    
    mbo.changeStatus("PENDING", MXServer.getMXServer().getDate(), '', MboConstants.NOACCESSCHECK)
    #service.error("dm","genercierror",["test"])
    labtransSet = mbo.getMboSet("LABTRANS")
    
    
    if labtransSet is not None and not labtransSet.isEmpty():
        
        labmbo = labtransSet.moveFirst()
        while labmbo:
            labmbo.setValue("GENAPPRSERVRECEIPT", 1, MboConstants.NOACCESSCHECK)
            labmbo = labtransSet.moveNext()
            assetmboSet = mbo.getMboSet("ASSET")
    
            if assetmboSet is not None and not assetmboSet.isEmpty():
                assetmbo=assetmboSet.getMbo(0)            
                #service.error("dm","genercierror",["test"])
                assetmbo.changeStatus("DECOMMISSIONED", MXServer.getMXServer().getDate(), '', MboConstants.NOACCESSCHECK)
        
    
        #assetmboSet.save()