# Created by: ram
# Date: 17-Jun-25

from psdi.util.logging import MXLoggerFactory
from psdi.server import MXServer
from psdi.mbo import MboConstants

# Initialize logger
logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***Script DM_CREATETRPO START***")

# Fetch all WPService lines
wpserviceSet = mbo.getMboSet("DM_SHOWPLANCSERVICE")

for i in range(wpserviceSet.count()):
    wpserviceMbo = wpserviceSet.getMbo(i)

    dm_vendcontract = wpserviceMbo.getString("DM_VENDCONTRACT")
    dm_vendor = wpserviceMbo.getString("VENDOR")
    logger.error("***Script DM_CREATETRPO**DM_VENDCONTRACT=" + dm_vendcontract)
    logger.error("***Script DM_CREATETRPO**VENDOR=" + dm_vendor)

    if len(dm_vendcontract) > 0 and len(dm_vendor) > 0 and wpserviceMbo.getString("LINETYPE") == "STDSERVICE" and not wpserviceMbo.getString("PR"):
        logger.error("***Script DM_CREATETRPO**inside if")
        #service.error("erwe","pooooooooooo")
        purcviewMbo = mbo.getMboSet(
            "$PURCHVIEW",
            "PURCHVIEW",
            "CONTRACTNUM='" + dm_vendcontract + "' and revisionnum=(SELECT MAX(revisionnum) FROM PURCHVIEW WHERE CONTRACTNUM='" + dm_vendcontract + "' and status='APPR') and status='APPR' and CREATEREL=1"
        ).getMbo(0)

        logger.error("***Script DM_CREATETRPO**purcviewMbo=" + str(purcviewMbo))

        if purcviewMbo is not None:
            wpItemSet = mbo.getMboSet(
                "$WPITEM",
                "WPITEM",
                "wonum='" + mbo.getString("WONUM") + "' and siteid='" + mbo.getString("SITEID") + "' AND PR IS NULL"
            )
            logger.error("***Script DM_CREATETRPO**wpItemSet where=" + wpItemSet.getCompleteWhere())

            if wpItemSet.count() > 0:
                
                poHeaderMbo = purcviewMbo.createPOHeader("DM")
                logger.error("***Script DM_CREATETRPO**poHeaderMbo.DESCRIPTION=" + poHeaderMbo.getString("DESCRIPTION"))

                ponumAk = poHeaderMbo.getMboValue("PONUM")
                ponumAk.autoKey()
                ponum = poHeaderMbo.getString("PONUM")
                poHeaderMbo.setValue("PONUM", ponum)
                logger.error("***Script DM_CREATETRPO**ponum=" + ponum)

                releasePOLineSetRemote = poHeaderMbo.getMboSet("POLINE")
                createRelInputRemote = purcviewMbo.getMboSet("CREATERELINPUT").add()
                createRelInputRemote.setValue("WONUM", mbo.getString("WONUM"))

                purchviewLineMboSet = purcviewMbo.getMboSet(
                "$CONTRACTLINE",
                "CONTRACTLINE",
                "CONTRACTNUM = '" + dm_vendcontract + "' AND REVISIONNUM = " + str(purcviewMbo.getInt("REVISIONNUM")) +
                " AND LINESTATUS = 'APPR' AND LINETYPE = 'STDSERVICE' AND CONTRACTLINEID IN (" +
                    "SELECT DM_CONTREFLINEID FROM WPITEM WHERE WONUM = '" + mbo.getString("WONUM") + 
                    "' AND SITEID = '" + mbo.getString("SITEID") + "' AND PR IS NULL" +
                ")"
                )

                logger.error("***Script DM_CREATETRPO**purchviewLineMboSet where=" + purchviewLineMboSet.getCompleteWhere())
                logger.error("***Script DM_CREATETRPO**purchviewLineMboSet count=" + str(purchviewLineMboSet.count()))

                for j in range(purchviewLineMboSet.count()):
                    
                    purchviewLineMbo = purchviewLineMboSet.getMbo(j)

                    wpItemMboSet = purchviewLineMbo.getMboSet(
                        "$WPITEM",
                        "WPITEM",
                        "wonum = '" + mbo.getString("WONUM") + 
                        "' AND siteid = '" + mbo.getString("SITEID") + 
                        "' AND DM_VENDCONTRACT IS NOT NULL AND DM_VENDCONTRACT = '" + purchviewLineMbo.getString("CONTRACTNUM") + 
                        "' AND PR IS NULL"
                    )

                    wpItemMbo = wpItemMboSet.moveFirst()

                    while wpItemMbo:
                        
                        releasePOLineRemote = releasePOLineSetRemote.add()
                        purchviewLineMbo.copyPurchContractLine(releasePOLineRemote, createRelInputRemote)
                        releasePOLineRemote.setValue("CONTRACTREFID", 0, 11)
                        releasePOLineRemote.setValue("CONTRACTREFID", purcviewMbo.getLong("CONTRACTID"), 66)
                        releasePOLineRemote.setValue("ORDERQTY", wpItemMbo.getDouble("DM_ACCEPTQTY"))
                        releasePOLineRemote.setValue("UNITCOST", wpItemMbo.getDouble("UNITCOST"))
                        releasePOLineRemote.setValue("DM_WPITEMID", wpItemMbo.getLong("WPITEMID"))

                        wpItemMbo.setValue("PR", "0000", MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                        wpItemMbo.setValue("PRLINENUM", 1, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)

                        logger.error("***Script DM_CREATETRPO**Set dummy PR and PRLINENUM for WPITEMID=" + str(wpItemMbo.getLong("WPITEMID")))
                        wpItemMbo = wpItemMboSet.moveNext()

                try:
                   
                    poHeaderMbo.changeStatus("APPR", MXServer.getMXServer().getDate(), "From Script DM_CREATETRPO", 2)
                    logger.error("***Script DM_CREATETRPO**After PO APPR")
                except Exception as e:
                    logger.error("***Script DM_CREATETRPO**Failed to approve PO: " + str(e))
            else:
                errorgroup = "dm_wocont"
                errorkey = "nocontractlinesqty"
        else:
            errorgroup = "dm_wocont"
            errorkey = "contrelnotenable"

# Save changes
try:
    #service.error("8765","532")
    logger.error("***Script DM_CREATETRPO**woset before save")
    mbo.getThisMboSet().save()
    logger.error("***Script DM_CREATETRPO**woset after save")
except Exception as e:
    logger.error("***Script DM_CREATETRPO**Save failed: " + str(e))

logger.error("***Script DM_CREATETRPO END***")