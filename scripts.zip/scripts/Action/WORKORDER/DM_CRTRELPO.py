# DM_CRTRELPO
# Created by: Mithun/Ashok
# Date: 13-Aug-2024
# Updated: 19-Apr-2025 by Amir (Ignore contract revision while checking)
# Updated: 13-Nov-2025 by Samer (Remove the partial approval logic)


from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.custom")
logger.info("******START Script DM_CRTRELPO")


mbo.getThisMboSet().save()

if mbo.toBeSaved() and 1==2:
	errorgroup = "dm_wocont"
	errorkey = "savewo"
elif mbo.getString("STATUS") in ["WAPPR", "WSCH"]:
	errorgroup = "dm_wocont"
	errorkey = "approvewo"
elif mbo.getString("DM_VENDCONTRACT") and mbo.getString("VENDOR"):
	where = ("CONTRACTNUM=:DM_VENDCONTRACT and revisionnum=(SELECT MAX(revisionnum) "
		"FROM PURCHVIEW WHERE CONTRACTNUM=:DM_VENDCONTRACT and orgid=:orgid and status='APPR') "
		"and orgid=:orgid and status='APPR' and CREATEREL=1" )
	purcviewMbo = mbo.getMboSet("$PURCHVIEW", "PURCHVIEW", where).getMbo(0)
	if purcviewMbo:
		wpItemSet = mbo.getMboSet("$WPITEM","WPITEM","wonum='" + mbo.getString("WONUM") + "' and siteid='" + mbo.getString("SITEID") +"' and DM_CONTREFLINEID is not null " )			 
		if wpItemSet.count() > 0 and 1==2:
			poHeaderMbo = purcviewMbo.createPOHeader("DM")
			ponumAk = poHeaderMbo.getMboValue("PONUM")
			ponumAk.autoKey()
			ponum = poHeaderMbo.getString("PONUM")
			poHeaderMbo.setValue("PONUM", ponum)
			releasePOLineSetRemote = poHeaderMbo.getMboSet("POLINE")
			createRelInputRemote = purcviewMbo.getMboSet("CREATERELINPUT").add()
			createRelInputRemote.setValue("WONUM", mbo.getString("WONUM"))
			purchviewLineMboSet = purcviewMbo.getMboSet("CONTRACTLINE")
			for i in range(purchviewLineMboSet.count()):
				purchviewLineMbo = purchviewLineMboSet.getMbo(i)
				wpItemMboSet = purchviewLineMbo.getMboSet("$WPITEM","WPITEM","wonum='" + mbo.getString("WONUM") + "' and siteid='" + mbo.getString("SITEID") + "' and DM_CONTREFLINEID is not null and DM_CONTREFLINEID='" + str(purchviewLineMbo.getLong("CONTRACTLINEID")) + "'" )
				wpItemMbo = wpItemMboSet.moveFirst()
				while wpItemMbo:
					if  wpItemMbo.getDouble("DM_APPROVED"):
						itemqty = wpItemMbo.getDouble("itemqty")
						wpItemMbo.setValue("DM_APPRQTY", itemqty, 2)
						wpItemMbo.setValue("DM_ACCEPTQTY", itemqty, 2)
					contractLineRemote = purchviewLineMbo
					releasePOLineRemote = releasePOLineSetRemote.add()
					contractLineRemote.copyPurchContractLine(releasePOLineRemote, createRelInputRemote)
					releasePOLineRemote.setValue("CONTRACTREFID", purcviewMbo.getLong("CONTRACTID"), 66)
					releasePOLineRemote.setValue("ITEMNUM", wpItemMbo.getString("ITEMNUM"), MboConstants.NOACCESSCHECK)
					releasePOLineRemote.setValue("DESCRIPTION", wpItemMbo.getString("DESCRIPTION"), MboConstants.NOACCESSCHECK)
					#releasePOLineRemote.setValue("DM_NEWLINETYPE", wpItemMbo.getString("DM_NEWLINETYPE"), MboConstants.NOACCESSCHECK)
					releasePOLineRemote.setValue("ORDERQTY", wpItemMbo.getDouble("DM_APPRQTY"), MboConstants.NOACCESSCHECK)
					releasePOLineRemote.setValue("UNITCOST", wpItemMbo.getDouble("UNITCOST"), MboConstants.NOACCESSCHECK)
					releasePOLineRemote.setValue("DM_WPITEMID", wpItemMbo.getLong("WPITEMID"))
					wpItemMbo = wpItemMboSet.moveNext()
			poHeaderMbo.changeStatus("APPR", MXServer.getMXServer().getDate(), "From Script DM_CRTRELPO", 2)
			#mbo.changeStatus("COMP", MXServer.getMXServer().getDate(), "Work Order Completed", 2)
		else:  
			errorgroup = "dm_wocont"
			errorkey = "nocontractlinesqty"
	else:
		errorgroup = "dm_wocont"
		errorkey = "contrelnotenable"
else:
	errorgroup = "dm_wocont"
	errorkey = "invalidcontract"

mbo.getThisMboSet().save()
logger.info("******END Script DM_CRTRELPO")