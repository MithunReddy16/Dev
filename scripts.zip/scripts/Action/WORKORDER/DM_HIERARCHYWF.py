from psdi.server import MXServer
from psdi.mbo import MboSet

woid=mbo.getInt("workorderid")

#wfmbo =mbo.getMboSet('$TEMPWF','WFINSTANCE',"ownerid='"+str(woid)+"' and active=1").getMbo(0)

#if wfmbo is not None:
    

mxs = MXServer.getMXServer()
wfsub = mxs.lookup('WORKFLOW')
    
requestSet= mbo.getMboSet('SHOWCHILDREN')
for x in range (requestSet.count()):
    requestMbo = requestSet.getMbo(x)
    wfsub.initiateWorkflow('DM_WOTMAIN',requestMbo)
#   wfsub.initiateWorkflow('DM_WOSTCM',requestMbo)