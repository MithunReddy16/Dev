#DM_GENMR

from psdi.mbo import MboConstants
from psdi.server import MXServer
from psdi.webclient.system.controller import SessionContext, Utility, WebClientEvent
from psdi.util.logging import MXLoggerFactory


def setError(Msg):
		#global errorkey,errorgroup,params
		#errorkey='scriptvalidationerror'
		#errorgroup='scriptval'
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)
        
if mbo.getBoolean('HISTORYFLAG') or mbo.getString('STATUS') in ('WORKCOMP','COMP', 'WAPPR') :
    setError('Invalid Work Order Status.')
#mrSet = MXServer.getMXServer().getMboSet('MR',mbo.getUserInfo())
mrSet = mbo.getMboSet('MR')

mrSet.setInsertSite(mbo.getString('SITEID'))

mrMbo = mrSet.add()

mrMbo.setValue('WONUM',mbo.getString('WONUM'))

mrMbo.setValue('ASSETNUM',mbo.getString('ASSETNUM'))
mrMbo.setValue('DESCRIPTION','GENERATED FROM WO#' + mbo.getString('WONUM'))
mrMbo.setValue('REQUIREDDATE',MXServer.getMXServer().getDate(),11L)

Type ='MR' if launchPoint =='DM_GENMR' else 'OSP'
mrMbo.setValue('DM_TYPE',Type)

mrMbo.getThisMboSet().save()
#mrSet.save()