#------------------------------------------------------------------------
#STPSCRIPT
#Script Name :DM_WO_PTW_EXT
#Description :Permit to Work Extension Action
#Comment     :Used in STP Work Order WF
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          05-May-2026         Initiate version.
#---------------------------------------------------------------------------------------------

from psdi.server import MXServer

service.closeDialog()
session = service.webclientsession()
session.getDataBean("mainrecord").SAVE()


mxs = MXServer.getMXServer()
wfstart = mxs.lookup('WORKFLOW')
ptwSet=mbo.getMboSet("DM_PERMITWORKISSUED")
ptw=ptwSet.moveFirst()
if ptw:
    wfstart.initiateWorkflow('DM_PTWEXT',ptw)