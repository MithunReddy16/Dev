##############################################
#script:DM_ADV_CHKATTACH
#Createdby:NK
#Creation Date:19-05-2026
#scope: Adv - Designer attachments mandatory
###############################################

# Validate attachments before routing WO to Approval


def checkAttachment(docType):
    docSet = None
    try:
        docSet = mbo.getMboSet(
            "$CHK_ATTACH",
            "DOCLINKS",
            "ownertable = 'WORKORDER' "
            "and ownerid = :workorderid "
            "and doctype = '%s'" % docType
        )
        docSet.reset()

        if docSet.isEmpty():
            service.error(
                "scriptval",
                "scriptvalidationerror",
                ["Attachment is required under %s folder." % docType]
            )

    finally:
        if docSet is not None:
            docSet.close()


if launchPoint == "DM_ADV_CHKATTACH":
    checkAttachment("DesignFile")

elif launchPoint == "DM_ADV_CHKATTACH1":
    checkAttachment("PrintFile")