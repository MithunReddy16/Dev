###################################################
#script:DM_ADV_ASSIGNWO
#Createdby:NK
#Creation Date:16-06-2026
#scope: Assign workorder to designer from dashboard
###################################################

from psdi.mbo import MboConstants
from psdi.server import MXServer
from java.util import Date
from java.text import SimpleDateFormat
from psdi.util import MXApplicationException

mxServer = MXServer.getMXServer()
userInfo = mbo.getUserInfo()
currentDate = mxServer.getDate()
flags = MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION | MboConstants.NOACTION

from psdi.common.context import UIContext

# --------------------------------------------------
# Create Work Log (comments) for Designer Assignment
# --------------------------------------------------
def createWorklog(wo):
    loggedUser = userInfo.getUserName()
    userMemo = mbo.getString("DM_ADV_MEMO").strip()
    if userMemo:
        worklogComments = userMemo
    else:
        worklogComments = "Assigned to you by %s" % loggedUser
    
    worklogSet = wo.getMboSet("WORKLOG")
    worklog = worklogSet.add()
    worklog.setValue("LOGTYPE","CLIENTNOTE",MboConstants.NOACCESSCHECK)
    worklog.setValue("DESCRIPTION",worklogComments,MboConstants.NOACCESSCHECK)
    
def refreshDashboardTables():

    context = UIContext.getCurrentContext()

    if context is None:
        return

    wcs = context.getWebClientSession()

    if wcs is None:
        return

    tableIds = [
        "results_showlist_2",
        "results_showlist"
    ]

    for tableId in tableIds:

        tableBean = wcs.getDataBean(tableId)

        if tableBean is not None:

            # Reload saved database records
            tableBean.getMboSet().reset()

            # Refresh displayed table
            tableBean.refreshTable()
            
            
            

MAX_WO = 3
ACTIVE_STATUSES = ("DES_ASSIGNED","INPROGRESS","DES_QC_WAPPR","HOLD")

def checkAssignmentLimit(designer):

    site = mbo.getString("SITEID")

    woSet = None

    try:

        woSet = mxServer.getMboSet("WORKORDER",userInfo)
        designerSQL = designer.replace("'", "''")
        siteSQL = site.replace("'", "''")

        whereClause = (
            "OWNER = '%s' "
            "AND SITEID = '%s' "
            "AND WORKTYPE = 'ADV' "
            "AND ISTASK = 0 "
            "AND STATUS IN ("
            "'DES_ASSIGNED',"
            "'INPROGRESS',"
            "'DES_QC_WAPPR',"
            "'HOLD')"
        ) % (designerSQL, siteSQL)

        woSet.setWhere(whereClause)
        woSet.reset()

        activeCount = woSet.count()
        if activeCount >= MAX_WO:

            woDetails = []

            wo = woSet.moveFirst()

            while wo is not None:
                wonum = wo.getString("WONUM")
                status = wo.getString("STATUS")
                statusDesc = wo.getString("UXSYNONYMDOMAIN.DESCRIPTION")

                if not statusDesc:
                    statusDesc = status

                # Color indicators
                if status == "DES_ASSIGNED":
                    indicator = u"\U0001F534" 
                elif status == "INPROGRESS":
                    indicator = u"\U0001F7E0" 
                elif status == "DES_QC_WAPPR":
                    indicator = u"\U0001F7E1"  
                else:
                    indicator = u"\u25cf"
                
                woDetails.append(indicator + " " + wonum + " - " + statusDesc)
                #woDetails.append(wonum + " - " + statusDesc)

                wo = woSet.moveNext()

            errorMessage = (
                "Designer " + designer +
                " already has " +
                str(activeCount) +
                " active Work Orders.\n\n"
                "Maximum allowed: " +
                str(MAX_WO) + ".\n\n"
                "You cannot assign another Work Order "
                "until an existing Work Order "
                "is released from the active workload.\n\n"
                "Active Work Orders:\n" +
                "\n".join(woDetails)
            )

            service.error(
                "scriptval",
                "scriptvalidationerror",
                [errorMessage]
            )

    finally:

        if woSet is not None:
            woSet.close()


newPerson = mbo.getString("DM_ADV_ASSIGNEE")
wonum = mbo.getString("WONUM")
ownerid = mbo.getLong("WORKORDERID")
newdesc = "Workorder-%s-DES_ASSIGNED-Assigned to you " % wonum

if newPerson and mbo.getString("STATUS") == "WASSIGN":
    checkAssignmentLimit(newPerson)
    
    # Stop active workflow instance for this WO
    wfInstanceSet = mbo.getMboSet(
        "$STOPWF",
        "WFINSTANCE",
        "processname='DM_ADVWO' and ownertable='WORKORDER' and ownerid=:workorderid and active=1"
    )
    wfInstanceSet.reset()

    wfInstance = wfInstanceSet.moveFirst()
    while wfInstance:
        wfInstance.stopWorkflow("Reassigned from Assignment Dashboard")
        wfInstance = wfInstanceSet.moveNext()

    wfInstanceSet.save()
    wfInstanceSet.close()

    # Update WO
    woSet = mxServer.getMboSet("WORKORDER", userInfo)
    woSet.setWhere("workorderid=%s" % ownerid)
    woSet.reset()

    wo = woSet.getMbo(0)

    if wo:
        wo.setValue("OWNER", newPerson, flags)
        wo.setValueNull("OWNERGROUP", flags)
        wo.setValue("DM_ADV_ASSIGN", currentDate, flags)
        wo.setValue("WOL1", "1", flags)

        #woSet.save()
        wo.changeStatus("DES_ASSIGNED", currentDate, "Assigned to designer",flags)
        createWorklog(wo)
        woSet.save()
        
        # Restart workflow
        wfService = mxServer.lookup("WORKFLOW")
        wfService.initiateWorkflow("DM_ADVWO", wo)

        woSet.save()

    woSet.close()
    
    refreshDashboardTables()
    
    service.closeDialog()