#------------------------------------------------------------------------
#STPSCRIPT
#Script Name :DM_WO_UPTWOACT
#Description :script to Update Work Activities related to PTW
#Comment     :Used in STP Work Order /
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          20-MAY-2026         Initiate version.
#---------------------------------------------------------------------------------------------
session=service.webclientsession()
mainBean = session.getDataBean("mainrecord") 
woMbo = mainBean.getMbo()
alnDatabean = session.getDataBean("dm_alndomaintable")   
if alnDatabean is not None:
    alnDomainSet=alnDatabean.getMboSet()
    selectedRecords=alnDomainSet.getSelection()
    iterator=selectedRecords.iterator()
    i = 0

    while (iterator.hasNext()):
        alnDomainMbo=iterator.next()
        alnDesc = alnDomainMbo.getString("description")
        if i == 0:
            woactValue = alnDesc 
        else:
            woactValue = woactValue+ ",\n"+ alnDesc
            
        i=i+1
   
    woMbo.setValue("WOEQ10",woactValue)
    
    service.closeDialog()
    mainBean.SAVE()
    wcs = service.webclientsession()