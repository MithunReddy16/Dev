#------------------------------------------------------------------------
#STPSCRIPT
#Script Name :DM_CREATE_PTW
#Description :Create Permit to Work Action
#Comment     :Used in STP Work Order WF
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          05-May-2026         Initiate version.
#--------------------------------------------------------------------------------------------


mbo.createMultiplePermitWorks(None)