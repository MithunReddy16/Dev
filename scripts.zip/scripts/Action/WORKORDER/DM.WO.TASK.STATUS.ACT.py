ActivitySet = mbo.getMboSet('SHOWTASKS')

Status = 'PA'
if launchPoint == 'WO.ALL.FA.ACT':
    Status='FA'
elif launchPoint == 'WO.ALL.NA.ACT':
    Status='NA'
ActivityMbo = ActivitySet.moveFirst()
while ActivityMbo:
    ActivityMbo.setValue('DM_TASKSTATUS',Status)
    ActivityMbo = ActivitySet.moveNext()