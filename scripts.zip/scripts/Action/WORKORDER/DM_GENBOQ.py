#------------------------------------------------------------------------

#Script Name :DM_GENBOQ
#Description :Generate BOQ Lines
#Comment     :Used in GM WO Application
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
# Samer Al Fakih      SWORD_salfakih@dm.ae     1.0          14-MAY-2026         Initiate version.

#------------------------------------------------------------------------

from psdi.mbo import MboConstants
from psdi.server import MXServer

session = service.webclientsession()
main_bean = session.getDataBean("mainrecord")
CIVIL_THRESHOLD = float(MXServer.getMXServer().getProperty("dm.wo.boq.civil_threshold"))
EL_THRESHOLD = float(MXServer.getMXServer().getProperty("dm.wo.boq.elec_threshold"))

#---------------------------------------------------------
# Work Order context
#---------------------------------------------------------
woMbo = mbo.getOwner()
siteId = woMbo.getString("SITEID")
woNum = woMbo.getString("WONUM")
contractNum = woMbo.getString("DM_VENDCONTRACT")

CIVIL_CATEGORIES = ["PL", "MA", "CP", "PT"]

#---------------------------------------------------------
# BOQ set
#---------------------------------------------------------

if mbo.isModified():
    service.error("dm_wocount", "savewobeforegenboq")

boqSet = mbo.getMboSet("DM_BOQ$","DM_BOQ","siteid='{}' and wonum='{}'".format(siteId, woNum))
wpServiceSet = woMbo.getMboSet("WPSERVICE")
boqGroups = {}
nonGroupedLines = []
electricLines = []

#---------------------------------------------------------
# STEP 1: Classify BOQ lines
#---------------------------------------------------------
boqMbo = boqSet.moveFirst()
while boqMbo:
    boqMbo.setValue("ABOVECATEGORYLIMIT", 0)
    category = boqMbo.getString("DM_CATEGORY")
    cmType = boqMbo.getString("DM_CMTYPE")
    bType=boqMbo.getString("DM_BTYPE")

    if bType =='PS' or cmType != "CMBOQ":
        nonGroupedLines.append(boqMbo)

    elif category == "EL":
        electricLines.append(boqMbo)

    elif category in CIVIL_CATEGORIES:
        if category not in boqGroups:
            boqGroups[category] = {"lines": [], "totalCost": 0.0}

        boqGroups[category]["lines"].append(boqMbo)
        boqGroups[category]["totalCost"] += boqMbo.getDouble("LINECOST")
    else: 
        nonGroupedLines.append(boqMbo)
    boqMbo = boqSet.moveNext()

#---------------------------------------------------------
# STEP 2: NON‑CMBOQ → direct copy
#---------------------------------------------------------
for boqMbo in nonGroupedLines:

    wpMbo = wpServiceSet.add()
    wpMbo.setValue("WONUM", woNum, MboConstants.NOACCESSCHECK)
    wpMbo.setValue("DM_CONTREFLINEID", boqMbo.getString("DM_CONTREFLINEID"))
    wpMbo.setValue("DM_VENDCONTRACT", contractNum, MboConstants.NOVALIDATION)
    wpMbo.setValue("ITEMNUM", boqMbo.getString("ITEMNUM"),MboConstants.NOACCESSCHECK)
    wpMbo.setValue("DESCRIPTION", boqMbo.getString("DESCRIPTION"), 11l)
    wpMbo.setValue("DM_CATEGORY", boqMbo.getString("DM_CATEGORY"))
    wpMbo.setValue("DM_BTYPE", boqMbo.getString("DM_BTYPE"))
    wpMbo.setValue("DM_TYPE", boqMbo.getString("DM_TYPE"))
    wpMbo.setValue("DM_CMTYPE", boqMbo.getString("DM_CMTYPE"))
    wpMbo.setValue("UNITCOST", boqMbo.getDouble("UNITCOST"))
    wpMbo.setValue("ITEMQTY", boqMbo.getDouble("ITEMQTY"))
    wpMbo.setValue("WPM1", boqMbo.getString("REMARKS"))

#---------------------------------------------------------
# STEP 3: ELECTRIC (EL) LOGIC – PER LINE
#---------------------------------------------------------
for boqMbo in electricLines:


    lineCost = boqMbo.getDouble("LINECOST")
    unitCost = boqMbo.getDouble("UNITCOST")
    qty = boqMbo.getDouble("ITEMQTY")

    cmjcMbo = None
    searchCost = None
    finalQty = None

    #-- Step 2
    if lineCost <= EL_THRESHOLD:
        searchCost = lineCost
        finalQty = 1

    #-- Step 3
    elif lineCost > EL_THRESHOLD and unitCost <= EL_THRESHOLD:
        searchCost = unitCost
        finalQty = qty

    #-- Step 6 fallback
    if searchCost is not None:

        cmjcSet = woMbo.getMboSet(
            "EL_CMJC",
            "CONTRACTLINE",
            "contractnum='{}' AND linestatus='APPR' "
            "AND dm_category='EL' AND dm_cmtype='CMJC' "
            "AND {} BETWEEN dm_minvalue AND dm_maxvalue".format(
                contractNum, searchCost)
        )
        if cmjcSet and not cmjcSet.isEmpty():
            cmjcMbo = cmjcSet.moveFirst()

    if cmjcMbo:
        wpMbo = wpServiceSet.add()
        wpMbo.setValue("WONUM", woNum, MboConstants.NOACCESSCHECK)
        wpMbo.setValue("DM_CONTREFLINEID", cmjcMbo.getString("CONTRACTLINEID"))
        wpMbo.setValue("DM_VENDCONTRACT", contractNum,MboConstants.NOVALIDATION)
        wpMbo.setValue("ITEMNUM", cmjcMbo.getString("ITEMNUM") ,MboConstants.NOACCESSCHECK)
        wpMbo.setValue("DESCRIPTION", cmjcMbo.getString("DESCRIPTION"))
        wpMbo.setValue("DM_CATEGORY", "EL")
        wpMbo.setValue("DM_BTYPE", cmjcMbo.getString("DM_BTYPE"))
        wpMbo.setValue("DM_TYPE", cmjcMbo.getString("DM_TYPE"))
        wpMbo.setValue("DM_CMTYPE", "CMJC")
        wpMbo.setValue("UNITCOST", cmjcMbo.getDouble("UNITCOST"))
        wpMbo.setValue("ITEMQTY", finalQty)

    else:
        wpMbo = wpServiceSet.add()
        wpMbo.setValue("WONUM", woNum, MboConstants.NOACCESSCHECK)
        wpMbo.setValue("DM_CONTREFLINEID", boqMbo.getString("DM_CONTREFLINEID"))
        wpMbo.setValue("DM_VENDCONTRACT", contractNum,MboConstants.NOVALIDATION)
        wpMbo.setValue("ITEMNUM", boqMbo.getString("ITEMNUM") ,MboConstants.NOACCESSCHECK)
        wpMbo.setValue("DESCRIPTION", boqMbo.getString("DESCRIPTION"), 11l)
        wpMbo.setValue("DM_CATEGORY", boqMbo.getString("DM_CATEGORY"))
        wpMbo.setValue("DM_BTYPE", boqMbo.getString("DM_BTYPE"))
        wpMbo.setValue("DM_TYPE", boqMbo.getString("DM_TYPE"))
        wpMbo.setValue("DM_CMTYPE", boqMbo.getString("DM_CMTYPE"))
        wpMbo.setValue("UNITCOST", boqMbo.getDouble("UNITCOST"))
        wpMbo.setValue("ITEMQTY", qty)
        boqMbo.setValue("ABOVECATEGORYLIMIT", 1)
        wpMbo.setValue("WPM1", boqMbo.getString("REMARKS"))

#---------------------------------------------------------
# STEP 4: CIVIL CATEGORIES (unchanged grouping logic)
#---------------------------------------------------------
for category in boqGroups:

    totalCost = boqGroups[category]["totalCost"]
    boqLines = boqGroups[category]["lines"]

    cmjcMbo = None

    if totalCost <= CIVIL_THRESHOLD:

        cmjcSet = woMbo.getMboSet(
            "CIVIL_CMJC",
            "CONTRACTLINE",
            "contractnum='{}' AND linestatus='APPR' "
            "AND dm_category='{}' AND dm_cmtype='CMJC' "
            "AND {} BETWEEN dm_minvalue AND dm_maxvalue".format(
                contractNum, category, totalCost)
        )

        if cmjcSet and not cmjcSet.isEmpty():
            cmjcMbo = cmjcSet.moveFirst()

    if cmjcMbo:
        wpMbo = wpServiceSet.add()
        wpMbo.setValue("WONUM", woNum, MboConstants.NOACCESSCHECK)
        wpMbo.setValue("DM_CONTREFLINEID", cmjcMbo.getString("CONTRACTLINEID"))
        wpMbo.setValue("DM_VENDCONTRACT", contractNum,MboConstants.NOVALIDATION)
        wpMbo.setValue("ITEMNUM", cmjcMbo.getString("ITEMNUM") ,MboConstants.NOACCESSCHECK)
        wpMbo.setValue("DESCRIPTION", cmjcMbo.getString("DESCRIPTION"))
        wpMbo.setValue("DM_CATEGORY", category)
        wpMbo.setValue("DM_BTYPE", cmjcMbo.getString("DM_BTYPE"))
        wpMbo.setValue("DM_TYPE", cmjcMbo.getString("DM_TYPE"))
        wpMbo.setValue("DM_CMTYPE", "CMJC")
        wpMbo.setValue("UNITCOST", cmjcMbo.getDouble("UNITCOST"))
        wpMbo.setValue("ITEMQTY", 1)


    else:
        for boqMbo in boqLines:
            wpMbo = wpServiceSet.add()
            wpMbo.setValue("WONUM", woNum, MboConstants.NOACCESSCHECK)
            wpMbo.setValue("DM_CONTREFLINEID", boqMbo.getString("DM_CONTREFLINEID"))
            wpMbo.setValue("DM_VENDCONTRACT", contractNum,MboConstants.NOVALIDATION)
            wpMbo.setValue("ITEMNUM", boqMbo.getString("ITEMNUM") ,MboConstants.NOACCESSCHECK)
            wpMbo.setValue("DESCRIPTION", boqMbo.getString("DESCRIPTION"))
            wpMbo.setValue("DM_CATEGORY", boqMbo.getString("DM_CATEGORY"))
            wpMbo.setValue("DM_BTYPE", boqMbo.getString("DM_BTYPE"))
            wpMbo.setValue("DM_TYPE", boqMbo.getString("DM_TYPE"))
            wpMbo.setValue("DM_CMTYPE", boqMbo.getString("DM_CMTYPE"))
            wpMbo.setValue("UNITCOST", boqMbo.getDouble("UNITCOST"))
            wpMbo.setValue("ITEMQTY", boqMbo.getDouble("ITEMQTY"))
            boqMbo.setValue("ABOVECATEGORYLIMIT", 1)
            wpMbo.setValue("WPM1", boqMbo.getString("REMARKS"))

main_bean.SAVE()