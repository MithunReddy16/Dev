#-----------------------------------------------------
#Createdby:ram
#date:25-Aug-26
#---------------------------------------------------

from psdi.mbo import MboConstants
from psdi.server import MXServer

woSet = mbo.getMboServer().getMboSet("WORKORDER", mbo.getUserInfo())
wo = mbo.createWorkorder(woSet, None, False)
mbo.changeStatus("WOCREATED", MXServer.getMXServer().getDate(),"Follow up CM work order created")
wo.setValue("WORKTYPE", 'CM', mbo.NOACCESSCHECK)
#wo.setValue("PRIORITY", 4, mbo.NOACCESSCHECK)

wo.setValue("DM_MAINTDEPT", mbo.getString("DM_MAINTDEPT"), mbo.NOACCESSCHECK)
wo.setValue("ASSETNUM", mbo.getString("ASSETNUM"), mbo.NOACCESSCHECK)
wo.setValue("DM_BUNIT", mbo.getString("DM_BUNIT"), mbo.NOACCESSCHECK)
wo.setValue("DM_INHOUSE", mbo.getString("DM_INHOUSE"), mbo.NOACCESSCHECK)
wo.setValue("DM_VENDCONTRACT", mbo.getString("DM_VENDCONTRACT"), mbo.NOACCESSCHECK)
wo.setValue("DM_QRVENDOR", mbo.getString("DM_QRVENDOR"), mbo.NOACCESSCHECK)
wo.setValue("PERSONGROUP", mbo.getString("PERSONGROUP"), mbo.NOACCESSCHECK)
wo.setValue("AMCREW", mbo.getString("AMCREW"), mbo.NOACCESSCHECK)
wo.setValue("SUPERVISOR", mbo.getString("SUPERVISOR"), mbo.NOACCESSCHECK)
woSet.save()