from psdi.mbo import MboConstants 
from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.custom")

logger.info("========== START CREATE FOLLOW-UP WO SCRIPT ==========")

questionMboSet = mbo.getMboSet("DM_INSPQUESTION") 
logger.info("Inspection questions count: " + str(questionMboSet.count()))

questionMbo = questionMboSet.moveFirst()

logger.info("Inspection questions retrieved")

while questionMbo:

    
    logger.info("Processing inspection question: " + questionMbo.getString("INSPQUESTIONNUM"))
    
    woSet = mbo.getMboServer().getMboSet("WORKORDER", mbo.getUserInfo())
    logger.info("WORKORDER MboSet initialized")
    
    wo = mbo.createWorkorder(woSet, None, False)
    logger.info("Work Order creation initiated")
    
    wo.setValue(
        "DESCRIPTION",
        "Followup Work Order for Inspection Point: " + questionMbo.getString("SEQUENCE")
    )
    wo.setValue("WORKTYPE", "FIND", MboConstants.NOACCESSCHECK)
    wo.setValue(
        "DM_INSPFINDINGTYPE",
        questionMbo.getString("DM_INSPFINDINGTYPE"),
        MboConstants.NOACCESSCHECK
    )
    wo.setValue("DM_LOCATION", mbo.getString("DM_LOCATION"))
    wo.setValue("ASSETNUM", mbo.getString("ASSETNUM"))
    wo.setValue("WOLO4", questionMbo.getString("INSPQUESTIONID"))
    
    logger.info("Work Order attributes populated")
    
    inspectionResultSet = mbo.getMboSet("INSPECTIONRESULT")
    inspectionResult = inspectionResultSet.getMbo(0)

    if inspectionResult:
        resultNum = inspectionResult.getString("RESULTNUM")
    
        logger.info("Inspection Result Number: " + resultNum)
    
        # Temporary relationship from question to INSPFIELDRESULT
        resultSet = questionMbo.getMboSet(
            "$TEMP_INSPFIELDRESULT",
            "INSPFIELDRESULT",
            "RESULTNUM = '{}' AND INSPQUESTIONNUM = '{}'".format(
                resultNum,
                questionMbo.getString("INSPQUESTIONNUM")
            )
        )

    logger.info("Matching field result count: " + str(resultSet.count()))
    logger.info("Inspection question results count: " + str(resultSet.count()))
    
    urgencyValue = None
    remarks = None
    
    for i in range(resultSet.count()):
    
        currentResult = resultSet.getMbo(i)
        logger.info("Result Number: " + currentResult.getString("RESULTNUM"))
        if currentResult.getString("INSPQUESTIONNUM") == questionMbo.getString("INSPQUESTIONNUM"):
    
            responseFieldNum = currentResult.getString("INSPFIELDNUM")
            logger.info("Text field: " + currentResult.getString("INSPFIELDNUM"))
            logger.info("Text resp: " + currentResult.getString("TXTRESPONSE"))
            if responseFieldNum:
    
                fieldSet = mbo.getMboSet(
                    "$CHECK_FIELD_" + str(i),
                    "INSPFIELD",
                    "INSPFIELDNUM = '{}'".format(responseFieldNum)
                )
    
                if fieldSet.count() > 0:
    
                    field = fieldSet.getMbo(0)
    
                    if field.getString("DOMAINID") == "DM_URGENCY":
                        logger.info("Text urg field: " + currentResult.getString("INSPFIELDNUM"))
                        logger.info("Text urg resp: " + currentResult.getString("TXTRESPONSE"))
                        urgencyValue = currentResult.getString("TXTRESPONSE")
    
                    if field.getString("FIELDTYPE") == "TR":
                        logger.info("Text tr field: " + currentResult.getString("INSPFIELDNUM"))
                        logger.info("Text tr resp: " + currentResult.getString("TXTRESPONSE"))
                        remarks = currentResult.getString("TXTRESPONSE")
    
            if urgencyValue:
                wo.setValue("WOPRIORITY", urgencyValue)
    
            if remarks:
                wo.setValue("DESCRIPTION_LONGDESCRIPTION", remarks)
    
    logger.info("Inspection response processing completed")
    logger.info("Saving Work Order")
    
    woSet.save()
    
    logger.info("Work Order saved successfully: " + wo.getString("WONUM"))
    
    questionMbo = questionMboSet.moveNext()
    
    
logger.info("========== END CREATE FOLLOW-UP WO SCRIPT ==========")