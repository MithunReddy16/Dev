##############################################
#script:DM_ADV_WODOCLINK
#Createdby:NK
#Creation Date:22-12-2025
#scope: Copy doclinks to workorder
###############################################

from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory

mxServer = MXServer.getMXServer()
userInfo = mbo.getUserInfo()
flags = MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION

logger = MXLoggerFactory.getLogger("maximo.custom")
logger.debug("*******DM_ADV_WODOCLINK - START**********")

if mbo is not None:
    logger.debug("*******DM_ADV_WODOCLINK - Condition-1**********")
    ticketid = mbo.getString("DM_ADV_REQ")
    linenum = mbo.getInt("DM_ADV_LINENUM")
    siteid = mbo.getString("SITEID")
    
    def copy_doclinks(srcMbo, woMbo):
        logger.debug("*******DM_ADV_WODOCLINK - Condition-2**********")
        srcDocs = srcMbo.getMboSet("DOCLINKS")
        if srcDocs is not None:
            logger.debug("*******DM_ADV_WODOCLINK - Condition-3**********")
            logger.info("DM_ADV_WODOCLINK srcDocs.count=" + str(srcDocs.count()))
            tgtDocs = woMbo.getMboSet("DOCLINKS")
        
            src = srcDocs.moveFirst()
            while src is not None:
                logger.debug("*******DM_ADV_WODOCLINK - Condition-4**********")
                docinfoid = src.getLong("DOCINFOID")
        
                chk = woMbo.getMboSet(
                    "$DOCCHK",
                    "DOCLINKS",
                    "ownertable='WORKORDER' and ownerid=:workorderid and document='%s'"
                    % src.getString("DOCUMENT").replace("'", "''")
                )
        
                try:
                    if chk.isEmpty():
                        logger.debug("*******DM_ADV_WODOCLINK - Condition-5**********")
                        newDoc = tgtDocs.add()
                        logger.debug("*******DM_ADV_WODOCLINK - Condition-5.1**********")
                        newDoc.setValue("DOCINFOID", docinfoid, flags)
                        if not src.isNull("DOCUMENT"):
                            newDoc.setValue("DOCUMENT", src.getString("DOCUMENT"), flags)
        
                        if not src.isNull("DOCTYPE"):
                            newDoc.setValue("DOCTYPE", src.getString("DOCTYPE"), flags)
        
                        if not src.isNull("URLTYPE"):
                            newDoc.setValue("URLTYPE", src.getString("URLTYPE"), flags)
        
                        if not src.isNull("URLNAME"):
                            newDoc.setValue("URLNAME", src.getString("URLNAME"), flags)
        
                        if not src.isNull("NEWURLNAME"):
                            newDoc.setValue("NEWURLNAME", src.getString("NEWURLNAME"), flags)
        
                        if not src.isNull("DESCRIPTION"):
                            newDoc.setValue("DESCRIPTION", src.getString("DESCRIPTION"), flags)
                   
                    tgtDocs.save()    
                    
                finally:
                    chk.close()
        
                src = srcDocs.moveNext()
        
    # Get matching advertisement child line
    advSet = mxServer.getMboSet("DM_ADV_SR", userInfo)
    
    try:
        advSet.setWhere(
            "DM_ADV_TICKETID='%s' and DM_ADV_LINENUM=%s"
            % (ticketid, str(linenum))
        )
        advSet.reset()

        if not advSet.isEmpty():
            logger.debug("*******DM_ADV_WODOCLINK - Condition-6**********")
            advLine = advSet.getMbo(0)
    
            copy_doclinks(advLine, mbo)
            mbo.setValue("DM_ADV_ETR", "1", flags)
            logger.debug("*******DM_ADV_WODOCLINK - END**********")
    
    finally:
        advSet.close()
        mbo.getThisMboSet().save()