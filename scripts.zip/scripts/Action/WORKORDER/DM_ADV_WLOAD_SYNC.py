from psdi.server import MXServer
from psdi.mbo import MboConstants
from java.util import Date

mx = MXServer.getMXServer()
userInfo = mx.getSystemUserInfo()

woSet = None
summarySet = None

FLAGS = MboConstants.NOACCESSCHECK
now = Date()

ACTIVE_STATUSES = (
    "DES_ASSIGNED",
    "INPROGRESS",
    "DES_QC_WAPPR",
    "HOLD"
)


def emptyCounts():
    return {
        "active": 0,
        "inprogress": 0,
        "qc": 0,
        "requesterpending": 0,
        "delayed": 0
    }

def updateSummary(summary, counts):
    summary.setValue("TOTALACTIVE",counts["active"],FLAGS)
    summary.setValue("TOTALPROGRESS",counts["inprogress"],FLAGS)
    summary.setValue("TOTALQC",counts["qc"],FLAGS)
    summary.setValue("TOTALASSIGNED",counts["requesterpending"],FLAGS)
    summary.setValue("TOTALDELAYED",counts["delayed"],FLAGS)


try:

    # ---------------------------------------------
    # 1. Retrieve Active ADV Work Orders
    # ---------------------------------------------

    woSet = mx.getMboSet("WORKORDER",userInfo)

    woSet.setWhere(
        "worktype = 'ADV' "
        "AND istask = 0 "
        "AND owner IS NOT NULL "
        "AND status IN ("
        "'DES_ASSIGNED',"
        "'INPROGRESS',"
        "'DES_QC_WAPPR',"
        "'HOLD')"
    )

    woSet.reset()

    designers = {}

    wo = woSet.moveFirst()

    # ---------------------------------------------
    # 2. Calculate Designer Workload
    # ---------------------------------------------

    while wo is not None:

        designer = wo.getString("OWNER")
        status = wo.getString("STATUS")
        expectedFinish = wo.getDate("DM_ADV_DT7")

        if designer not in designers:
            designers[designer] = emptyCounts()

        d = designers[designer]

        d["active"] += 1

        if status in ("DES_ASSIGNED","INPROGRESS"):
            d["inprogress"] += 1

        elif status == "DES_QC_WAPPR":
            d["qc"] += 1

        elif status == "HOLD":
            d["requesterpending"] += 1

        if expectedFinish is not None:

            if expectedFinish.before(now):
                d["delayed"] += 1

        wo = woSet.moveNext()


    summarySet = mx.getMboSet("DM_ADV_WLOAD",userInfo)

    summarySet.reset()

    summary = summarySet.moveFirst()

    # ---------------------------------------------
    # 4. Update Existing Designer Records
    # ---------------------------------------------

    while summary is not None:

        designer = summary.getString("DESIGNERID")

        if designer in designers:

            counts = designers.pop(designer)

        else:
            counts = emptyCounts()

        updateSummary(summary, counts)

        summary = summarySet.moveNext()

    # ---------------------------------------------
    # 5. Insert New Designer Records
    # ---------------------------------------------

    for designer in designers:

        counts = designers[designer]

        summary = summarySet.add()

        summary.setValue("DESIGNERID",designer,FLAGS)
        summary.setValue("DESIGNERNAME",designer,FLAGS)

        updateSummary(summary, counts)

    # ---------------------------------------------
    # 6. Save Designer Workload Summary
    # ---------------------------------------------

    summarySet.save()

finally:

    if summarySet is not None:
        summarySet.close()

    if woSet is not None:
        woSet.close()