#Script Name :DM_COPYCONTLINETOBOQ
#Description :Copy Contract Line to BOQ
#Comment     :Used in GM WO Application
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
# Samer Al Fakih      SWORD_salfakih@dm.ae     1.0          13-MAY-2026         Initiate version.

#------------------------------------------------------------------------

from psdi.mbo import MboConstants


session = service.webclientsession()
main_bean = session.getDataBean("mainrecord")
databean = session.getDataBean("dm_cpycontlinetoboq_grid2_1_1_contlines_table")
woMbo = main_bean.getMbo()

if databean is not None:

    flag = 0

    contractLineSet = databean.getMboSet()
    selectedRecords = contractLineSet.getSelection()
    status = woMbo.getString("STATUS")

    if status in ["WAPPR", "REWORK", "WSCH", "ZERETURNED", "INPRG"]:

        boqSet = woMbo.getMboSet("DM_BOQ")

        if selectedRecords.size() > 0:

            iterator = selectedRecords.iterator()

            while iterator.hasNext():

                contractLineMbo = iterator.next()

                boqMbo = boqSet.add()
                boqMbo.setValue("ITEMNUM", contractLineMbo.getString("ITEMNUM"), MboConstants.NOACCESSCHECK)
                boqMbo.setValue("DESCRIPTION", contractLineMbo.getString("DESCRIPTION"), MboConstants.NOACCESSCHECK)
                boqMbo.setValue("ITEMQTY", 1, MboConstants.NOACCESSCHECK)  # confirm field name
                boqMbo.setValue("WONUM", woMbo.getString("WONUM"), MboConstants.NOACCESSCHECK)
                boqMbo.setValue("SITEID", woMbo.getString("SITEID"), MboConstants.NOACCESSCHECK)
                boqMbo.setValue("DM_CONTREFLINEID",
                                contractLineMbo.getLong("CONTRACTLINEID"),
                                MboConstants.NOACCESSCHECK)
                boqMbo.setValue("UNITCOST",
                                contractLineMbo.getDouble("UNITCOST"),
                                MboConstants.NOACCESSCHECK)
                boqMbo.setValue("DM_CATEGORY",
                                contractLineMbo.getString("DM_CATEGORY"),
                                MboConstants.NOACCESSCHECK)
                boqMbo.setValue("DM_BTYPE",
                                contractLineMbo.getString("DM_BTYPE"),
                                MboConstants.NOACCESSCHECK)
                boqMbo.setValue("DM_TYPE",
                                contractLineMbo.getString("DM_TYPE"),
                                MboConstants.NOACCESSCHECK)
                boqMbo.setValue("DM_CMTYPE",
                                contractLineMbo.getString("DM_CMTYPE"),
                                MboConstants.NOACCESSCHECK)
                
        woMbo.getThisMboSet().save()
        service.closeDialog()