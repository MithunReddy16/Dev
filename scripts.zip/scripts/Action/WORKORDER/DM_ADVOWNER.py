###############################################
#script:DM_ADVOWNER
#Createdby:nk
#Creation Date:17/12/25
#scope: Take Ownership
###############################################


from psdi.mbo import MboConstants
from psdi.server import MXServer
from java.util import Date
from java.text import SimpleDateFormat

#Adv Rel-1 change
def checkAssignmentLimit():
    MAX_WO = 3
    activeStatuses = ["DES_ASSIGNED","INPROGRESS","DES_QC_WAPPR"]
    user = mbo.getUserInfo().getUserName()
    site = mbo.getString("SITEID")
    
    if mbo.getString("STATUS") == "WASSIGN":
        woSet = MXServer.getMXServer().getMboSet("WORKORDER", mbo.getUserInfo())
        try:
            woSet.setWhere(
                "OWNER = '" + user.replace("'", "''") + "' "
                "AND SITEID = '" + site.replace("'", "''") + "' "
                "AND STATUS IN ('DES_ASSIGNED', 'INPROGRESS', 'DES_QC_WAPPR') "
                "AND ISTASK = 0"
            )
    
            woSet.reset()
            activeCount = woSet.count()
            if activeCount >= MAX_WO:
                woDetails = []
    
                wo = woSet.moveFirst()
                while wo is not None:
                    wonum = wo.getString("WONUM")
                    status = wo.getString("STATUS")
                    statusDesc = wo.getString("UXSYNONYMDOMAIN.DESCRIPTION")
                    if status == "DES_ASSIGNED":
                        indicator = u"\U0001F534" 
                    elif status == "INPROGRESS":
                        indicator = u"\U0001F7E0" 
                    elif status == "DES_QC_WAPPR":
                        indicator = u"\U0001F7E1"  
                    else:
                        indicator = u"\u25cf"
                    
                    woDetails.append(indicator + " " + wonum + " - " + statusDesc)
                    #woDetails.append(wonum + " - " + statusDesc)
    
                    wo = woSet.moveNext()
    
                # Prepare error message
                errorMessage = (
                    "You already have " +
                    str(activeCount) +
                    " active Work Orders. "
                    "You cannot pick another Work Order "
                    "until Design Quality Check is completed "
                    "for an existing Work Order.\n\n"
                    "Your Active Work Orders:\n" +
                    "\n".join(woDetails)
                )
    
                service.error("scriptval","scriptvalidationerror",[errorMessage])
                
        finally:
            woSet.close()
        
    
user = mbo.getUserInfo().getUserName()
mxServer = MXServer.getMXServer()
userInfo = mbo.getUserInfo()
wonum= mbo.getString("wonum")
personid = userInfo.getPersonId()
currentDate = mxServer.getDate()

# Validate maximum 3 active Work Orders
checkAssignmentLimit()

 # Assign Designer
mbo.setValue("OWNER", user, MboConstants.NOACCESSCHECK)
mbo.setValue("DM_ADV_ASSIGN", currentDate, MboConstants.NOACCESSCHECK)
mbo.setValueNull("OWNERGROUP", MboConstants.NOACCESSCHECK)
#mbo.getThisMboSet().save()