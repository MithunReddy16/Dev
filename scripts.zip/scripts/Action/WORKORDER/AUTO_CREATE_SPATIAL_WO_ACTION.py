'''Sample Script
Automatically run Auto Create Spatial when action ACWOACTIONLP is run. '''

woNum = mbo.getString("WONUM")
print "Auto Creating Spatial WO"
print "WONUM:"+woNum
print "SITEID: "+mbo.getString("SITEID")
success = mbo.autoCreateSpatial(True)
if (success):
    print "WO Spatial successfully created"
else:
    print "WO Spatial creation failed"