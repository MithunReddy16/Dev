#------------------------------------------------------------------------
#Script Name : DM_ZMWOLIMITSCRIPT
#Description :set the max limit for current approval which is zone manager/section manager/department director to workorder field based on who approved the wo.
#Comment     :Used in GM Work Order Workflow
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
# Ram Nalla           rnalla.v@dm.gov.ae       1.0          23-Dec-2025         Initiate version.
# Samer Al Fakih      SWORD_salfakih@dm.ae     2.0          16-FEB-2026         Add logic for level 1 and restructure the script

#------------------------------------------------------------------------

from psdi.mbo import MboConstants
from psdi.server import MXServer

mxserver = MXServer.getMXServer()

# ---------------------------------------------------
# Get basic values
# ---------------------------------------------------
currentUser = mbo.getUserInfo().getPersonId()
vendor      = mbo.getString("VENDOR")
location    = mbo.getString("LOCATION")
serviceId   = mbo.getString("DM_SERVICEID")
workType    = mbo.getString("WORKTYPE")
ownerGroup  = mbo.getString("OWNERGROUP")

# Responsibility Matrix defined for CP
# Apply same logic for MD
if workType == "MD":
    workType = "CP"

# ---------------------------------------------------
# Determine Approval Level based on Launch Point
# ---------------------------------------------------
levelMap = {
    "DM_ZEWOLIMIT": 1,
    "DM_ZMWOLIMIT": 2,
    "DM_SMWOLIMIT": 3,
    "DM_DDWOLIMIT": 4
}

if launchPoint in levelMap:

    level = levelMap[launchPoint]

    # ---------------------------------------------------
    # Get DM_RESPMANAGER MboSet
    # ---------------------------------------------------
    respSet = mxserver.getMboSet("DM_RESPMANAGER", mbo.getUserInfo())

    # ---------------------------------------------------
    # Build WHERE clause based on level
    # ---------------------------------------------------
    if level == 1:
        where = (
            "APPROVALLEVEL = 1 "
            "AND DM_MAINTDEPT = :DM_MAINTDEPT "
            "AND WORKTYPE = '{0}' "
            "AND RESPONSIBLEGROUP = '{1}'"
        ).format(workType, ownerGroup)
    else:
        where = (
            "WORKTYPE = '{0}' "
            "AND APPROVALLEVEL = {1} "
            "AND VENDOR = '{2}'"
        ).format(workType, level, vendor)

    # ---------------------------------------------------
    # Execute Query
    # ---------------------------------------------------
    respSet.setWhere(where)
    respSet.reset()

    record = respSet.getMbo(0)

    # ---------------------------------------------------
    # Set Values if Record Found
    # ---------------------------------------------------
    if record:
        maxLimit = record.getDouble("MAXLIMIT")

        mbo.setValue("WOEQ5", maxLimit, MboConstants.NOACCESSCHECK)
        mbo.setValue("WOLO10", level, MboConstants.NOACCESSCHECK)