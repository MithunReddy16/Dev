#------------------------------------------------------------------------
#STPSCRIPT
#Script Name :DM_WOPTW_ACKNOW
#Description :script to acknowlede that all precausions in PTW have been understood.
#Comment     :Used in STP Work Order /
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          20-MAY-2026         Initiate version.
#--------------------------------------------------------------------------------------------

from psdi.server import MXServer

mbo.setValue("PLUSGPERMITWORK.CONFSPACEAUTH",mbo.getUserInfo().getPersonId(),11l)
mbo.setValue("PLUSGPERMITWORK.SITECHECKEDDATE",MXServer.getMXServer().getDate(),11l)