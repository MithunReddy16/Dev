/*
Script: DM_DELJCLINE
Created By: Ashok
Date: 01-Oct-2024
Req: Delete the calculated Lines in the Plans Tab

*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)



//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_COPYCONTLINE**START***")
if(mbo.getString("STATUS")=="WAPPR" || mbo.getString("STATUS")=="WSCH" || mbo.getString("STATUS")=="ZERETURNED")
{
	//wpMaterialSet=mbo.getMboSet("WPMATERIAL");
	//wpServiceSet=mbo.getMboSet("WPSERVICE");
	logger.error("***ASH***Sript DM_COPYCONTLINE**START***")
	wpItemSet1=mbo.getMboSet("DM_CONTWPMATERIAL1");
	
	calcLineSet=mbo.getMboSet("DM_CALCLINES");
	for(i=0;(calcLineMbo=calcLineSet.getMbo(i))!=null;i++)
	{
		if(calcLineMbo.getString("DM_BTYPE").equalsIgnoreCase("CM"))
		{
			for(j=0;(wpItemMbo1=wpItemSet1.getMbo(j))!=null;j++)
			{
				
				if(wpItemMbo1.getString("DM_CATEGORY").equalsIgnoreCase(calcLineMbo.getString("DM_CATEGORY")))
				{
					wpItemMbo1.setValue("UNITCOST",wpItemMbo1.getMboSet("DM_CONTRACTLINE").getMbo(0).getDouble("UNITCOST"),2);
				}
			}
		}
	}
	
	
	mbo.getMboSet("DM_CALCLINES").deleteAll();
	mbo.getThisMboSet().save();
}
else
{
	service.error("dm_wocont","statuschk")
}