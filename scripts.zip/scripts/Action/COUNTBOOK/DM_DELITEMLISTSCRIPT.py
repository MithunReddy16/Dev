from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory


logger = MXLoggerFactory.getLogger("maximo.script")

if app == "DM_COUNTBOOK":
    
    countBookSelSet = mbo.getMboSet("COUNTBOOKSELTYPE")
    countBookLineSet = mbo.getMboSet("COUNTBOOKALLITM")
    
    try:
    
        if countBookSelSet is None:
            logger.error("Failed to retrieve COUNTBOOKSELTYPE MboSet.")
        else:
           
            logger.debug("COUNTBOOKSELTYPE records to be deleted: " + str(countBookSelSet.count()))
    
            
            if countBookSelSet.count() > 0:
                countBookSelSet.deleteAll(MboConstants.NOACCESSCHECK)
                logger.debug("Deleted all records from COUNTBOOKSELTYPE.")
               
                countBookSelSet.save()
                logger.debug("Changes saved for COUNTBOOKSELTYPE.")
    
        
        if countBookLineSet is None:
            logger.error("Failed to retrieve COUNTBOOKLINE MboSet.")
        else:
            
            logger.debug("COUNTBOOKLINE records to be deleted: " + str(countBookLineSet.count()))
    
            
            if countBookLineSet.count() > 0:
                countBookLineSet.deleteAll(MboConstants.NOACCESSCHECK)
                logger.debug("Deleted all records from COUNTBOOKLINE.")
                countBookLineSet.save()
               
                logger.debug("Changes saved for COUNTBOOKLINE.")
    
    except Exception as e:
        logger.error("An error occurred while deleting records: " + str(e))