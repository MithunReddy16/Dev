# lines Modified by Mithun 
from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory
from psdi.app.inventory import InvBalancesRemote

logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("******Mithun Script execution started for DM_CBPHYSCOUNTCOPY Count Book.*******")

if app == "DM_COUNTBOOK":
	logger.debug("**copyphysicalcount***")
	if launchPoint =='DM_CBPHYSCOUNTCOPY':
		logger.debug("**copyphysicalcount1***")
		#current_status=mbo.getString("STATUS")
		logger.debug("**copyphysicalcount2***")
		#if current_status == "HACAPPR":
		logger.debug("**copyphysicalcount3***")
		currentuser = mbo.getUserInfo().getPersonId()
		today = MXServer.getMXServer().getDate()
		countBookLineSet = mbo.getMboSet("COUNTBOOKALLITM3")
		logger.debug("******countBookLineSet *******"+str(countBookLineSet.count()))
		if countBookLineSet:
			#countBookLineSet.setWhere("match=1")
			logger.debug("******copyphysicalcount *******4")
			#countBookLineSet.reset()
			logger.debug("******copyphysicalcount *******5"+str(countBookLineSet.count()))
			line = countBookLineSet.moveFirst()
			while line:
				#if line.getBoolean('RECON'):  # added by Mithun to pass only reconcile lines 
					round2count = line.getDouble("DM_ROUND2PHYSCNT")
					itemnum = line.getString("ITEMNUM")
					logger.debug("******Finalcount started looping*******"+str(round2count))
					if round2count is not None and not line.isNull("DM_ROUND2PHYSCNT"):
						logger.debug("******Finalcount is not null1*******")
						
						#invSet=line.getMboSet("DM_INVBALANCES")
						invSet=MXServer.getMXServer().getMboSet("INVBALANCES",MXServer.getMXServer().getSystemUserInfo())
						
						lotnum=line.getString("LOTNUM")								
						Where = " LOCATION='{}' AND  ITEMNUM='{}' AND BINNUM='{}' AND SITEID='{}' AND STAGINGBIN =0 ".format(line.getString("COUNTBOOK.STOREROOM"),line.getString("ITEMNUM"),line.getString("BINNUM"),line.getString("SITEID"))
						if lotnum != None and lotnum !="":
							
							Where = Where + " AND lotnum='"+lotnum+"' "
						else:
							Where = Where + " AND lotnum is null  "
							

						invSet.setWhere(Where)
						invSet.reset()
						#where =" itemnum="+line.getString("ITEMNUM")+" and location=:countbook.storeroom and binnum=:binnum  and lotnum=:lotnum and  siteid=:siteid"
						#invSet=line.getMboSet("$DM_INVBALANCES","INVBALANCES","where ")
						logger.debug("******DM_INVBALANCES where = " + str(invSet.getUserWhere()))
						logger.debug("***** DM_INVBALANCES relationship debug START ----")

						logger.debug("****COUNTBOOKLINE values -> ITEMNUM=" + line.getString("ITEMNUM") +", SITEID=" + line.getString("SITEID") +", LOCATION=" + line.getString("countbook.storeroom") +
							", BINNUM=" + line.getString("BINNUM") +", LOTNUM=" + line.getString("LOTNUM"))
						logger.debug("******Invset *******"+str(invSet.count()))
						invBalMbo = None
						if invSet is not None:
							invBalMbo = invSet.getMbo(0)

						if invBalMbo is None:
							logger.debug("****No INVBALANCES found for ITEMNUM=" + itemnum + " (DM_INVBALANCES relationship returned 0 rows)")
						else:
							invTrans=invBalMbo.adjustPhysicalCount(round2count, today)
							if invTrans:
							    if not mbo.isNull("GLCREDITACCOUNT"):
							        invTrans.setValue("GLCREDITACCT",mbo.getString("GLCREDITACCOUNT"))
							    if not mbo.isNull("GLDEBITACCOUNT"):
							        invTrans.setValue("GLDEBITACCT",mbo.getString("GLDEBITACCOUNT"))
							logger.debug("*****Updated INVBALANCES for ITEMNUM=" + itemnum)
						#invBalMbo.adjustPhysicalCount(round2count,today)
						
						invSet.save()
						invSet.close()
						logger.debug("******Finalcount is not null2*******")

					line = countBookLineSet.moveNext()
			#mbo.getThisMboSet().save()
	session=service.webclientsession()
	mainBean = session.getDataBean("mainrecord")
	mainBean.SAVE()