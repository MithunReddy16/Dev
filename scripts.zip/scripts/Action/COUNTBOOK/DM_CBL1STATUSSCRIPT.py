# lines Modified by Mithun .
from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory


logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("******Mithun Script execution started for Count Book.*******")
logger.info("Script execution started for Count Book.")

if app == "DM_COUNTBOOK":
    
    if launchPoint =='DM_CBL1STATUS':
        
        if mbo is not None:
            current_status = mbo.getString("STATUS")
            
        
            if current_status == "WAPPR":
                
                    mbo.changeStatus("ROUND1", MXServer.getMXServer().getDate(), '', MboConstants.NOACCESSCHECK)
    
            mbo.getThisMboSet().save()
    if launchPoint =='DM_CBL3STATUS':
        if mbo is not None:
            current_status = mbo.getString("STATUS")
            if current_status == "ROUND1":
                mbo.changeStatus("ROUND2", MXServer.getMXServer().getDate(), '', MboConstants.NOACCESSCHECK)
                mbo.getThisMboSet().save()
    if launchPoint == 'DM_CBL2STATUS':
        logger.debug("******Finalcount started*******")
    
        if mbo is not None:
            current_status = mbo.getString("STATUS")
            logger.debug("******Finalcount started*******"+str(current_status))
            if current_status == "ROUND2":
                # Change status to FICO               
                mbo.changeStatus("FICO", MXServer.getMXServer().getDate(), '', MboConstants.NOACCESSCHECK)
                """
                currentuser = mbo.getUserInfo().getPersonId()
                today = MXServer.getMXServer().getDate()
                countBookLineSet = mbo.getMboSet("COUNTBOOKALLITM")
                if countBookLineSet:
                    countBookLineSet.setWhere("match=1")
                    logger.debug("******Finalcount started*******4")
                    #countBookLineSet.reset()
                    logger.debug("******Finalcount started*******5"+str(countBookLineSet.count()))
                    line = countBookLineSet.moveFirst()
                    while line:
                        if line.getBoolean('match'):
                            initialCount = line.getDouble("DM_INITIALPHYSCNT")
                            itemnum = line.getString("ITEMNUM")
                            logger.debug("******Finalcount started looping*******")
                            if initialCount is not None:
                                #logger.debug('Updating item {} with initial count {}'.format(itemnum, initialCount))
                                line.setValue("PHYSCNT", initialCount, MboConstants.NOACCESSCHECK)
                                line.setValue("PHYSCNTBY", currentuser, MboConstants.NOACCESSCHECK)
                                line.setValue("PHYSCNTDATE", today, MboConstants.NOACCESSCHECK)
    
                        line = countBookLineSet.moveNext()
                """
                mbo.getThisMboSet().save()