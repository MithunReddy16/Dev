# Modified by Mithun 
from psdi.mbo import MboConstants
from java.util import Date
from java.text import SimpleDateFormat
from psdi.util.logging import MXLoggerFactory

def setError(Msg):
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)

logger = MXLoggerFactory.getLogger("maximo.script")

if app == "DM_COUNTBOOK":

	startDate = mbo.getDate("DM_STARTDATE")
	endDate = mbo.getDate("DM_ENDDATE")
	store = mbo.getString("STOREROOM")
	itemType = mbo.getString("SELECTIONTYPE")
	status = mbo.getString("STATUS")
	if (not  mbo.getString("DM_COUNTTYPE")=="Periodic"):
		setError("Count type must be periodic")
	if (not startDate or not endDate ) and mbo.getString("DM_COUNTTYPE")=="Periodic":
		setError("List Start date and End date is Mandatory for Periodic Count Type.")
	
	if (not status == "WAPPR"):
		setError("Status must be WAPPR")
	if (not itemType == "ITEM"):
		setError("Line Type must be ITEM")
		
	dateFormat = SimpleDateFormat("dd-MM-yyyy")
	
	if startDate: 
		formattedStartDate = dateFormat.format(startDate)
	if endDate:
		formattedEndDate = dateFormat.format(endDate)
	
	if itemType == "ITEM" and status == "WAPPR":
		matRecSet = mbo.getMboSet("$matrectrans", "MATRECTRANS")
	
		if matRecSet is None:
			logger.error("Failed to retrieve MATRECTRANS MboSet.")
		else:
			#matRecSet.setWhere("fromstoreloc = '{}' AND actualdate BETWEEN TO_DATE('{}', 'dd-MM-yyyy') AND TO_DATE('{}', 'dd-MM-yyyy')"
				#.format(store, formattedStartDate, formattedEndDate))
			whereClause = "fromstoreloc = '" + store + "'"  + " AND actualdate BETWEEN TO_DATE('" + formattedStartDate + "', 'dd-MM-yyyy')" + " AND TO_DATE('" + formattedEndDate + "', 'dd-MM-yyyy')"
			matRecSet.setWhere(whereClause)
			matRecSet.reset()
			#matRecSet.reset()
	
			selectedItemsSet = mbo.getMboSet("COUNTBOOKSELTYPE")
			countBookLineSet = mbo.getMboSet("COUNTBOOKALLITM")
	
			if selectedItemsSet and countBookLineSet:
				selectedItemsSet.reset()
				countBookLineSet.reset()
	
				addedItems = set()
	
				if selectedItemsSet.count() == 0 and countBookLineSet.count() == 0:
					if matRecSet.count() > 0:
						for i in range(matRecSet.count()):
							matRecMbo = matRecSet.getMbo(i)
							actualDate = matRecMbo.getDate("ACTUALDATE")
							mritemNum = matRecMbo.getString("ITEMNUM")
	
							if mritemNum not in addedItems and matRecMbo.getString("LINETYPE") == "ITEM" :
								addedItems.add(mritemNum)
	
								if startDate <= actualDate <= endDate:
									itemSet = mbo.getMboSet("$ITEM", "ITEM")
									itemSet.setWhere("ITEMNUM = '{}'".format(mritemNum))
									itemSet.reset()
									rotating = 0
									if itemSet.count() > 0:
										itemMbo = itemSet.getMbo(0)
										if itemMbo.getBoolean("ROTATING"):
											rotating = 1
	
									newItem = selectedItemsSet.add()
									newItem.setValue("SELECTIONITM", mritemNum,2l)
									'''
									newItem.setValue("SELECTIONITM", mritemNum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
									newLineItem = countBookLineSet.add()
									newLineItem.setValue("ITEMNUM", mritemNum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
									newLineItem.setValue("COUNTBOOKNUM", mbo.getString("COUNTBOOKNUM"), MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
									newLineItem.setValue("ROTATING", rotating, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
									'''
	
					else:
						logger.debug("No records found in MATRECTRANS for the specified criteria.")
				else:
					logger.debug("Records already exist in COUNTBOOKSELTYPE or COUNTBOOKLINE. No new records will be added.")
		
		matUseSet = mbo.getMboSet("$matuserec", "MATUSETRANS")
	
		if matUseSet is None:
			logger.error("Failed to retrieve MATUSETRANS MboSet.")
		else:
			matUseSet.setWhere(
				"STORELOC = '{}' AND actualdate BETWEEN TO_DATE('{}', 'dd-MM-yyyy') AND TO_DATE('{}', 'dd-MM-yyyy')"
				.format(store, formattedStartDate, formattedEndDate))
			matUseSet.reset()
	
			selectedItemsSet = mbo.getMboSet("COUNTBOOKSELTYPE")
			countBookLineSet = mbo.getMboSet("COUNTBOOKALLITM")
	
			if selectedItemsSet and countBookLineSet:
				selectedItemsSet.reset()
				countBookLineSet.reset()
	
				addedItems = set()
	
				if selectedItemsSet.count() == 0 and countBookLineSet.count() == 0:
					if matUseSet.count() > 0:
						for i in range(matUseSet.count()):
							matUseMbo = matUseSet.getMbo(i)
							actualDate = matUseMbo.getDate("ACTUALDATE")
							muitemNum = matUseMbo.getString("ITEMNUM")
	
							if muitemNum not in addedItems  and matUseMbo.getString("LINETYPE") == "ITEM" :
								addedItems.add(muitemNum)
	
								if startDate <= actualDate <= endDate:
									itemSet = mbo.getMboSet("$ITEM", "ITEM")
									itemSet.setWhere("ITEMNUM = '{}'".format(muitemNum))
									itemSet.reset()
									rotating = 0
									if itemSet.count() > 0:
										itemMbo = itemSet.getMbo(0)
										if itemMbo.getBoolean("ROTATING"):
											rotating = 1
	
									newItem = selectedItemsSet.add()
									newItem.setValue("SELECTIONITM", muitemNum,2l)
									'''
									newItem.setValue("SELECTIONITM", muitemNum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
									newLineItem = countBookLineSet.add()
									newLineItem.setValue("ITEMNUM", muitemNum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
									newLineItem.setValue("COUNTBOOKNUM", mbo.getString("COUNTBOOKNUM"), MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
									newLineItem.setValue("ROTATING", rotating, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
									'''
	
					else:
						logger.debug("No records found in MATUSETRANS for the specified criteria.")
				else:
					logger.debug("Records already exist in COUNTBOOKSELTYPE or COUNTBOOKLINE. No new records will be added.")
	else:
		logger.debug("Item type is not ITEM or status is not WAPPR. No action will be taken.")