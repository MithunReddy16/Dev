#-----------------------------------------------------------------------------------------
#
# @author Amir
#-----------------------------------------------------------------------------------------

from psdi.server import MXServer
from psdi.mbo import MboConstants
#from datetime import datetime
from java.text import SimpleDateFormat
from java.util import Date
from java.lang import String
from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.custom")
logger.debug("==================== DM_CBHACNOTIFICATION: START  =================================")


# --------------------------
# Helpers
# --------------------------
def clean(s):
	if s is None:
		return ""
	s = str(s)
	# Replace problematic characters
	s = s.replace(u'\u2013', '-').replace(u'\u2014', '-')
	s = s.replace(u'\u2018', "'").replace(u'\u2019', "'")
	s = s.replace(u'\u201c', '"').replace(u'\u201d', '"')
	s = s.replace(u'\u2026', '...')
	return "".join([ch for ch in s if ord(ch) < 128])

def escape_csv(value):
	if value is None:
		return ""
	v = clean(value)
	v = v.replace('"', '""')
	if ("," in v) or ('"' in v) or ("\n" in v):
		return '"' + v + '"'
	return v

def removeNonAscii(s): 
	return "".join(i for i in s if ord(i) < 128)
 
def buildRowData(mbo, fields):
	rowData = []
	for field in fields:
		val = '' if  mbo.isNull(field) else mbo.getString(field)
		val = removeNonAscii(val)
		val = val.replace(",", "")
		rowData.append(val)
	
	#service.error("A",str(rowData))
	
	#"CURBAL","DM_ROUND2PHYSCNT","INVENTORY.INVCOST.AVGCOST"
	calcValue = str(round(mbo.getFloat("CURBAL") *  mbo.getFloat("INVENTORY.INVCOST.AVGCOST"),2))
	calcValue = removeNonAscii(calcValue)
	calcValue = calcValue.replace(",", "")
	
	rowData.append(calcValue)
	
	calcValue = str(round(mbo.getFloat("DM_ROUND2PHYSCNT") *  mbo.getFloat("INVENTORY.INVCOST.AVGCOST"),2))
	calcValue = calcValue.replace(",", "")
	rowData.append(calcValue)
	
	#service.error("A",str(rowData))
	#service.error("A",",".join(rowData))
	return rowData
	
def buildCSV(mboSet, fields, fieldtitles):
	rows = [",".join([escape_csv(h) for h in fieldtitles])]
	mbo = mboSet.moveFirst()
	while mbo:
		
		rows.append(",".join(buildRowData(mbo, fields)))
		mbo = mboSet.moveNext()
	return "\n".join(rows).encode('utf-8')


	
def get_dt_string():

	now = Date()
	return SimpleDateFormat("dd-MM-yyyy_HH-mm-ss").format(now)




PPLmboSet = MXServer.getMXServer().getMboSet("PERSONGROUPTEAM", MXServer.getMXServer().getSystemUserInfo())
PPLmboSet.setFlag(MboConstants.DISCARDABLE, True)
PPLmboSet.setWhere("PERSONGROUP='DM_CBHOC'") 
PPLmboSet.reset()
SendTo = []
PPLmbo = PPLmboSet.moveFirst()
while PPLmbo:
	Email = PPLmbo.getMboSet('RESPPARTYGROUP_PERSONS').getMbo(0).getString('PRIMARYEMAIL')
	if Email:
	   SendTo.append(Email) 
	PPLmbo = PPLmboSet.moveNext()
SendTo.append("SWORD_AANWAR@DM.AE")	 

LineSet = mbo.getMboSet("COUNTBOOKALLITM3")

listOfFields = ["ITEMNUM","ITEM.DESCRIPTION","BINNUM","LOTNUM", "CURBAL","DM_ROUND2PHYSCNT","INVENTORY.INVCOST.AVGCOST"]
listOfHeadernames = ["Item","Description","Bin","Lot", "System Balance","Count Balance","Averge Cost" , "System Cost", "New Cost"]

csvContent = buildCSV(LineSet, listOfFields,listOfHeadernames)

LineSet.close()


filename = "CB_" + mbo.getString("COUNTBOOKNUM") + "_" +mbo.getString("STOREROOM")+".csv"
attachmentName = String(filename, "UTF-8")

hostName = MXServer.getMXServer().getProperty('mxe.hostname')
sendFrom ="maxadmin@maximo.dm.ae"
system = "TEST"
if "masprd" in hostName:
	sendFrom ="maximo@dm.ae"
	system = "PRODUCTION"
#DM_CBHANOT
mailBody = "Dear/s,</br> Please Find attached Count Book Information.</br>"
mailBody = mailBody + "</br> Count book {} , Description: {}.</br>".format(mbo.getString("COUNTBOOKNUM"),mbo.getString("description"))
mailBody = mailBody +   " " + "\r\n"
mailBody = mailBody + "\r\n"





mailBody = mailBody +  "<br>"	

mailBody = mailBody +   " " + "\r\n"
mailBody = mailBody +   " " + "\r\n"
mailBody = mailBody +   "=========================================================================================================================\r\n"
mailBody = mailBody +  "<br>"

mailBody = mailBody +   "Please Note - This is Auto Generated email from - Maximo {} System\r\n".format(system)
mailBody = mailBody +  "<br>"

mailBody = mailBody +   "=========================================================================================================================\r\n"
mailBody = mailBody +   "</BODY></HTML>"+ "\r\n"


logger.debug("==================== DM_CBHACNOTIFICATION: MAIL BODY===" + mailBody)
MXServer.getMXServer().sendEMail(SendTo, sendFrom,"Count Book Complelation Notification",mailBody, csvContent, attachmentName)

logger.debug("==================== DM_CBHACNOTIFICATION: Ended  =================================")