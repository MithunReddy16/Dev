# lines Modified by Mithun 
from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory
from psdi.app.inventory import InvBalancesRemote

logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("******Mithun Script execution started for DM_RECONCILE Count Book.*******")

if app == "DM_COUNTBOOK":
    if launchPoint =='DM_REC':
        logger.debug("******Mithun Script  for DM_RECONCILE *******1")
        round2Set= mbo.getMboSet("COUNTBOOKALLITM3")
        logger.debug("******Mithun Script  for DM_RECONCILE *******1.1")
        currentMbo=round2Set.moveFirst()
        while currentMbo :
            asset_num = currentMbo.getString("ASSETNUM")
            if asset_num is None or asset_num=='' :
                logger.debug("******Mithun Script  for DM_RECONCILE *******1.3")
                currentMbo.setValue("RECON",1)
            currentMbo=round2Set.moveNext()
        #round2Set.save()
        
    if launchPoint =="DM_UNREC":
        round3Set= mbo.getMboSet("COUNTBOOKALLITM3")
        currentMbo2=round3Set.moveFirst()
        while currentMbo2 :
            asset_num = currentMbo2.getString("ASSETNUM")
            if asset_num == "":
                currentMbo2.setValue("RECON",0)
            currentMbo2=round3Set.moveNext()
        #round3Set.save()
    #mbo.getThisMboSet().save()