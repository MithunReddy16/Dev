## Lines modified by Mithun
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.script")

if app == "DM_COUNTBOOK":
    
    if not mbo.getString("SELECTIONTYPE"):
        mbo.setValue("selectiontype", 'ITEM', 2L)
    
    def setError(Msg):
        params = [Msg]
        service.error('scriptval', 'scriptvalidationerror', params)
    
    LineSet = mbo.getMboSet('DM_COUNTBOOKLINE')
    LineSelection = LineSet.getSelection()
    
    if not LineSelection.size() > 0:
        setError('Please select at least one line.')
    
    elif mbo.getString('STATUS') in ('APPR', 'CAN', 'COMP'):
        setError('Lines cannot be added.')
    
    else:
        
        for selectedMbo in LineSelection:
            selectedItemsSet = mbo.getMboSet("COUNTBOOKSELTYPE")
            countBookLineSet = mbo.getMboSet("COUNTBOOKALLITM")
    
            itemSet = mbo.getMboSet("$ITEM", "ITEM")
            selectitem = selectedMbo.getString("ITEMNUM")
            selectbin = selectedMbo.getString("INVBALANCES.binnum")
            itemSet.setWhere("ITEMNUM = '{}'".format(selectitem))
            itemSet.reset()
    
            rotating = 0
            if itemSet.count() > 0:
                itemMbo = itemSet.getMbo(0)
                if itemMbo.getBoolean("ROTATING"):
                    rotating = 1
    
            selectedItemsSet.setWhere("SELECTIONITM = '{}'".format(selectitem))
            selectedItemsSet.reset()
            
            if selectedItemsSet.count() == 0:
                newItem = selectedItemsSet.add()
                newItem.setValue("SELECTIONITM", selectitem, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                newItem.setValue("selectiontype", 'ITEM', 2L)
                newItem.setValue("SELECTIONBIN",selectbin , 2L)
                
                selectedItemsSet.save(MboConstants.NOVALIDATION)
    
            countBookLineSet.setWhere("ITEMNUM = '{}' AND COUNTBOOKNUM = '{}'".format(selectitem, mbo.getString("COUNTBOOKNUM")))
            countBookLineSet.reset()
            
            if countBookLineSet.count() == 0:
                newLineItem = countBookLineSet.add()
                newLineItem.setValue("ITEMNUM", selectitem, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                newLineItem.setValue("COUNTBOOKNUM", mbo.getString("COUNTBOOKNUM"), MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                newLineItem.setValue("ROTATING", rotating, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                newLineItem.setValue("binnum", selectbin, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                if mbo.getString('STATUS')=="ROUND2" :
                    newLineItem.setValue("DM_ISROUND2LINE",1)
                countBookLineSet.save(MboConstants.NOVALIDATION)
                
    
            logger.debug("COUNTBOOKSELTYPE and COUNTBOOKLINE records have been saved successfully.")
    
    service.closeDialog()