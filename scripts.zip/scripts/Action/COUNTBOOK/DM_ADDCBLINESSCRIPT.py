from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.script")

if app == "DM_COUNTBOOK":
    logger.debug("*****START DM_ADDCBLINESSCRIPT******")
    if not mbo.getString("SELECTIONTYPE"):
        mbo.setValue("selectiontype", 'ITEM', 2L)

    def setError(Msg):
        params = [Msg]
        service.error('scriptval', 'scriptvalidationerror', params)

    LineSet = mbo.getMboSet('DM_CBLINE')
    LineSelection = LineSet.getSelection()
    logger.debug("***** DM_ADDCBLINESSCRIPT1******")
    if not LineSelection.size() > 0:
        setError('Please select at least one line.')

    elif mbo.getString('STATUS') in ('CAN', 'COMP'):
        setError('Lines cannot be added.')

    else:
        countBookLineSet = mbo.getMboSet("COUNTBOOKALLITM")
        logger.debug("***** DM_ADDCBLINESSCRIPT2******")
        countbooknum = mbo.getString("COUNTBOOKNUM")
        store = mbo.getString("STOREROOM")
        logger.debug("***** DM_ADDCBLINESSCRIPT3******")
        for selectedMbo in LineSelection:
            itemnum = selectedMbo.getString("ITEMNUM")
            binnum = selectedMbo.getString("INVBALANCES.binnum")

            if not itemnum or not binnum:
                continue

           
            logger.debug("***** DM_ADDCBLINESSCRIPT4******")
            itemset = selectedMbo.getMboSet("ITEM")
            itemset.setWhere("ITEMNUM = '{}'".format(itemnum))
            itemset.reset()
            itemmbo = itemset.moveFirst()
            rotating = itemmbo.getBoolean("ROTATING") if itemmbo else False
            
                # Get CURBAL from invbalances relationship
            curbal = 0
            inv_where = "BINNUM IN ('{}') AND LOCATION = '{}' ".format(binnum, store)
            invmbo = selectedMbo.getMboSet("$INVBAL", "INVBALANCES", inv_where).getMbo(0)
            if invmbo:
			    curbal = invmbo.getDouble("CURBAL") 
			    
            logger.debug("***** DM_ADDCBLINESSCRIPT5******")
            if rotating:
                    # Query matching assets
                    asset_where = "LOCATION = '{}' AND BINNUM = '{}' AND ITEMNUM = '{}'".format(store, binnum, itemnum)
                    assetset = mbo.getMboSet("$ASSETSET", "ASSET", asset_where)
                    logger.debug("***** DM_ADDCBLINESSCRIPT6******")
                    assetmbo = assetset.moveFirst()
                    while assetmbo:
                        assetnum = assetmbo.getString("ASSETNUM")
                        service.error("dm","genericerror",[""+str(binnum)+str(curbal)+""])
                        newline = countBookLineSet.addAtEnd()
                        newline.setValue("COUNTBOOKNUM", countbooknum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                        newline.setValue("BINNUM", binnum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                        newline.setValue("ITEMNUM", itemnum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                        newline.setValue("ROTATING", 1, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                        newline.setValue("ASSETNUM", assetnum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                        newline.setValue("CURBAL", 1, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                        assetmbo = assetset.moveNext()
            else:
                    # For non-rotating items
                    newline = countBookLineSet.addAtEnd()
                    newline.setValue("COUNTBOOKNUM", countbooknum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                    newline.setValue("BINNUM", binnum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                    newline.setValue("ITEMNUM", itemnum, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                    newline.setValue("ROTATING", 0, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                    newline.setValue("CURBAL", curbal, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)

        logger.debug("COUNTBOOKSELTYPE and COUNTBOOKLINE records have been saved successfully.")

    service.closeDialog()