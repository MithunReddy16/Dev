# =============================================================
# SCRIPT   : DM_DLROUND2LINES
# OBJECT   : COUNTBOOK 
# AUTHOR   : Mithun
# =============================================================

from psdi.util.logging import MXLoggerFactory
from psdi.server import MXServer
from psdi.mbo import MboConstants
from java.text import SimpleDateFormat
from java.util import Date
from java.lang import String
from psdi.util.logging import MXLoggerFactory
from java.io import File, FileOutputStream
from  psdi.common.context import UIContext
from psdi.webclient.system.controller import SessionContext, Utility, WebClientEvent
from psdi.webclient.system.session import WebClientSession
from psdi.webclient.system import controller as wsController
logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("**** DM_DLROUND2LINES debug Started ***1")

def setError(Msg):
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)

# --------------------------
# Helpers
# --------------------------
def clean(s):
	if s is None:
		return ""
	s = str(s)
	# Replace problematic characters
	s = s.replace(u'\u2013', '-').replace(u'\u2014', '-')
	s = s.replace(u'\u2018', "'").replace(u'\u2019', "'")
	s = s.replace(u'\u201c', '"').replace(u'\u201d', '"')
	s = s.replace(u'\u2026', '...')
	return "".join([ch for ch in s if ord(ch) < 128])

def escape_csv(value):
	if value is None:
		return ""
	v = clean(value)
	v = v.replace('"', '""')
	if ("," in v) or ('"' in v) or ("\n" in v):
		return '"' + v + '"'
	return v

def removeNonAscii(s): 
	return "".join(i for i in s if ord(i) < 128)
 
def buildRowData(mbo, fields):
	rowData = []
	for field in fields:
		val = '' if  mbo.isNull(field) else mbo.getString(field)
		val = removeNonAscii(val)
		val = val.replace(",", "")
		rowData.append(val)
	
	#service.error("A",str(rowData))
	'''
	#"CURBAL","DM_ROUND2PHYSCNT","INVENTORY.INVCOST.AVGCOST"
	calcValue = str(round(mbo.getFloat("CURBAL") *  mbo.getFloat("INVENTORY.INVCOST.AVGCOST"),2))
	calcValue = removeNonAscii(calcValue)
	calcValue = calcValue.replace(",", "")
	
	rowData.append(calcValue)
	
	calcValue = str(round(mbo.getFloat("DM_ROUND2PHYSCNT") *  mbo.getFloat("INVENTORY.INVCOST.AVGCOST"),2))
	calcValue = calcValue.replace(",", "")
	rowData.append(calcValue)
	'''
	#service.error("A",str(rowData))
	#service.error("A",",".join(rowData))
	return rowData
	
def buildCSV(mboSet, fields, fieldtitles):
	rows = [",".join([escape_csv(h) for h in fieldtitles])]
	mbo = mboSet.moveFirst()
	while mbo:
		
		rows.append(",".join(buildRowData(mbo, fields)))
		mbo = mboSet.moveNext()
	return "\n".join(rows).encode('utf-8')






# Code start here 

status=mbo.getString("STATUS")
if status not in ["ROUND2"]  :
    setError("Round 2 lines can download only in Round2 status.")

LineSet = mbo.getMboSet("COUNTBOOKALLITM3")

listOfFields = ["COUNTBOOKNUM","SITEID","ITEMNUM","ITEM.DESCRIPTION","BINNUM","LOTNUM","ASSETNUM","CONDITIONCODE","DM_ROUND2PHYSCNT"]

listOfHeadernames = ["COUNTBOOKNUM","SITEID","A_ITEM","B_DESCRIPTION","C_BIN","D_LOT","E_ASSET","F_CONDITION","G_COUNT"]

csvContent = buildCSV(LineSet, listOfFields,listOfHeadernames)

LineSet.close()


filename = "CB_" + mbo.getString("COUNTBOOKNUM") + "_" +mbo.getString("STOREROOM")+"_R2.csv"
attachmentName = String(filename, "UTF-8")


outputDir = File("/output/maximo/migration")
if not outputDir.exists():
    outputDir.mkdirs()
    
outputFile = File(outputDir, filename)
fos = None
try:
    fos = FileOutputStream(outputFile)
    fos.write(csvContent)        # write the bytes
    fos.flush()
    logger.debug("*********File written: " + outputFile.getAbsolutePath())
except:
    logger.error("***********Failed to write CSV file: " + filename)
    raise
finally:
    if fos is not None:
        fos.close()   

uiContext = UIContext.getCurrentContext()
if uiContext != None:
	wcs = uiContext.getWebClientSession()
#session = service.getWebClientSession()
clientSession = service.webclientsession()
baseURL = clientSession.getMaximoBaseURL()
#baseURL = wcs.getMaximoBaseURL()
#baseURL = MXServer.getMXServer().getProperty("mxe.hostname")
logger.debug("*********"+str(baseURL ))
downloadURL = baseURL + "/maximo/migration/" + filename
logger.debug("*******Download URL: " + downloadURL)
#clientSession = service.webclientsession()
#clientSession.openURL(downloadURL)
service.openURL(downloadURL,True)
#service.openURL("https://google.com",True)




logger.debug("==================== DM_DLROUND2LINES: Ended  =================================")