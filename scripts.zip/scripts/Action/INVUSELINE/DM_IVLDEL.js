/*
Script: DM_IVLDEL
Created By: Ashok
Date: 21-Dec-2024
Req: Delete the INVUSE LIne from Pick List application and update the pending qty accordingly
*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)


logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_IVLDEL**START***")
logger.error("***ASH***Sript DM_IVLDEL**mbo="+mbo);
//logger.error("***ASH***Sript DM_IVLDEL**ownerapp="+mbo.getOwner().getApp());
logger.error("***ASH***Sript DM_IVLDEL**app="+app);
invReserveMbo=mbo.getMboSet("INVRESERVE").getMbo(0);
if(mbo.getOwner()!=null && mbo.getOwner().getOwner()!=null &&  mbo.getOwner().getOwner().getString("DM_STATUS").equalsIgnoreCase("ENTERED"))
{
	if(invReserveMbo!=null)
	{
		newpendqty=invReserveMbo.getDouble("PENDINGQTY")-mbo.getDouble("QUANTITY");
		mbo.delete(2);
		invReserveMbo.setValue("PENDINGQTY",newpendqty,2)
	}
}
else
{
	errorgroup="dm_picklist"
	errorkey="notvalidstatus"
}