/*
Script: DM_PLCREATEIVDIAG
Created By: Ashok
Date: 10-Dec-2024
Req: Create the Inventory Usage records for the provided storeroom and From Date and To Date
For those set, create inventory usage records that follows: 
	For items that only has balance in hand  
	Inventory usages grouped by WONUM ( MRNUM if not WONUM) 
	If item current balance is not sufficient to cover all reservation for the same due date,  start with reservation that has HARD reservation type, then based on request date  order. 
	Pick inventory bin that has oldest stock: 
		

Solution Approach:
1. IVR will be created against WO-STORE-RESERVATIONTYPE
2. Lines are Created Against the same criteria which has enough balances
3. IF the Current Inventory Balance is not Sufficient including the Open IVR Transcation qty, then the IVR will not create 
for eg, IF requestqty <= (Total Inventory Balance Qty - Total Open IVRLInes Qty) then IVR is created ELSE Not Created
4. Reserve Lines are copied to INVUSELINE and set the FROM BIN as per the DM_BALANCEDATE in ASC
5. By Default the BIN is selected as per the balance date, irrespective of balance exists. During the INVUSE Completion the user has to change the bin or split the line accordingly.

var workorderMap = new HashMap();
workorderMap.put(workorderId, wo);
var mboRemote = workorderMap.get(workorderId);

workorderMap.put(workorderId, wo);
*/

load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(java.time)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)



//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_PLCREATEIVDIAG**START***")
logger.error("***ASH***Sript DM_PLCREATEIVDIAG**mbo="+mbo)
logger.error("***ASH***Sript DM_PLCREATEIVDIAG**Owner mbo="+mbo.getOwner())
session=service.webclientsession()
databean=session.getDataBean("DM_PLDIAG_grid2_1_1_contlines_table")


function addInvUseLineFromInvReserveCutom(invuseLineSet)
{
    logger.error("***ASH***addInvUseLineFromInvReserveCutom**START***")
    invuseLineMbo = invuseLineSet.addAtEnd()
	logger.error("***ASH***addInvUseLineFromInvReserveCutom*****1"+invRes.getString("MRNUM"))
    //if (invRes.getString("tostoreloc")!=null  || (invRes.getString("ponum")!=null && invRes.getString("polinenum")!=null))
	if (!invRes.isNull("TOSTORELOC") ||  (!invRes.isNull("PONUM") && !invRes.isNull("POLINENUM")))
    {
		logger.error("***ASH***addInvUseLineFromInvReserveCutom*****1.1")
        invuseLineMbo.setValue("usetype", "TRANSFER", 2);
    }
    else
    {
		logger.error("***ASH***addInvUseLineFromInvReserveCutom*****1.2")
        invuseLineMbo.setValue("usetype", "ISSUE", 2);
    }

    invuseLineMbo.setValue("itemnum", invRes.getString("itemnum"), 2);
    invuseLineMbo.setValue("itemsetid", invRes.getString("itemsetid"), 2);
    invuseLineMbo.setValue("fromconditioncode", invRes.getString("conditioncode"), 2);
    invuseLineMbo.setValue("siteid", invRes.getString("STORELOCSITEID"), 2);
    invuseLineMbo.setValue("tositeid", invRes.getString("siteid"), 2);
    invuseLineMbo.setValue("fromstoreloc", invRes.getString("location"), 2);
    requestnum = invRes.getString("requestnum");
    siteid = invRes.getString("STORELOCSITEID");
    if (!invRes.isNull("glaccount"))
        {invuseLineMbo.setValue("gldebitacct", invRes.getString("glaccount"), 11);}

    invuseLineMbo.setValue("requestnum", invRes.getString("requestnum"), 11);
    if (!invRes.isNull("displaytaskid")) {
    invuseLineMbo.setValue("wonum", invRes.getString("displaywonum"), 11);
    invuseLineMbo.setValue("taskid", invRes.getString("displaytaskid"), 2);
    invuseLineMbo.setValue("refwo", invRes.getString("wonum"), 2);
    } else {
    invuseLineMbo.setValue("wonum", invRes.getString("wonum"), 2);
    } 
    issuetolabor = invRes.getString("issueto");

    if (issuetolabor != null && issuetolabor!="") {
    labor = invRes.getMboSet("$LABOR", "LABOR", "laborcode=:issueto and orgid=:orgid").getMbo(0);
    if (labor != null && !labor.isNull("personid"))
        invuseLineMbo.setValue("issueto", labor.getString("personid"), 2); 
    }
    
    if (invRes.getString("assetnum").equals("") && (invuseLineMbo.getString("assetnum") == null || invuseLineMbo.getString("assetnum").equals(""))) {
    invuseLineMbo.setValue("location", invRes.getString("oplocation"), 2);
    } else {
    invuseLineMbo.setValue("location", invRes.getString("oplocation"), 11);
    } 
    if (invuseLineMbo.getString("assetnum") == null || invuseLineMbo.getString("assetnum") == "")
        {invuseLineMbo.setValue("assetnum", invRes.getString("assetnum"), 2); }
    
    invuseLineMbo.setValue("mrnum", invRes.getString("mrnum"), 2);
    invuseLineMbo.setValue("mrlinenum", invRes.getString("mrlinenum"), 2);
    
    
    logger.error("***ASH***addInvUseLineFromInvReserveCutom*****8")
    invuseLineMbo.setValue("tostoreloc", invRes.getString("tostoreloc"), 11);
    if (invRes.getString("tostoreloc")!="")
    {
        ToLoc =invRes.getMboSet("TOLOCATIONS").getMbo(0);
        if (ToLoc)
        {
            invuseLineMbo.setValue("glcreditacct", ToLoc.getString("controlacc"), 11);
        }
    }
    invuseLineMbo.setValue("ponum", invRes.getString("ponum"), 2);
    invuseLineMbo.setValue("polinenum", invRes.getString("polinenum"), 2);
    //service.error("A","B");
    invuseLineMbo.setValue("porevisionnum", invRes.getString("porevisionnum"), 2);
    invuseLineMbo.setValue("tositeid", invRes.getString("siteid"), 2);
    if (invuseLineMbo.getString("ponum")!="") {
    poline = invuseLineMbo.getMboSet("POLINE").getMbo(0);
    if (poline != null)
        {invuseLineMbo.setValue("inspectionrequired", poline.getString("inspectionrequired"), 2);}
    }
    logger.error("***ASH***Sript DM_PLCREATEIVDIAG**before return invuseLineMbo****** ")
    return invuseLineMbo
}
if (launchPoint == 'DM_PLCREATEIVDIAG_TR')
{
    databean=session.getDataBean("DM_PLDIAG_grid2_1_1_contlines_table_TR")
}

logger.error("***ASH***Sript DM_PLCREATEIVDIAG**databean="+databean)
if(mbo.getOwner().getString("DM_STATUS").equalsIgnoreCase("ENTERED"))
{   
	if(databean!=null)
	{
		invReserveSet=databean.getMboSet();
		logger.error("***ASH***Sript DM_PLCREATEIVDIAG**invReserveSet selectedRecords where  ="+invReserveSet.getCompleteWhere())
		selectedRecords=invReserveSet.getSelection()
		logger.error("***ASH***Sript DM_PLCREATEIVDIAG**invReserveSet selectedRecords size ="+selectedRecords.size())
		selectedInvreserverids="";
		if (selectedRecords.size()>0)
		{
			iterator=selectedRecords.iterator()
			
			while (iterator.hasNext())
			{
				invReserveMbo=iterator.next()
				selectedInvreserverids+="'"+invReserveMbo.getInt("INVRESERVEID")+"',";
			}
			if(selectedInvreserverids.length()>0)
			{
				selectedInvreserverids=selectedInvreserverids.substring(0, selectedInvreserverids.length() - 1);
			}
			logger.error("***ASH***Sript DM_PLCREATEIVDIAG**invReserveSet final selectedInvreserverids ="+selectedInvreserverids)
			
			// The below logic is to create the IVR
			
			try
			{
				dbShortcut= new DBShortcut()
				dbShortcut2= new DBShortcut()
				dbShortcut3= new DBShortcut()
				invUseMbo=null;
				resultSet2=null;
				resultSet1=null;
				resultSet3=null;
				dbShortcut.connect(mbo.getThisMboSet().getUserInfo().getConnectionKey())
				dbShortcut2.connect(mbo.getThisMboSet().getUserInfo().getConnectionKey())
				dbShortcut3.connect(mbo.getThisMboSet().getUserInfo().getConnectionKey())
				invUseSet=mbo.getOwner().getMboSet("DM_INVUSE");
				query1="SELECT location,womrnum,siteid,rectype,min(requireddate) FROM "
										+" (SELECT location,wonum womrnum,siteid,'WO' rectype,requireddate FROM invreserve WHERE  wonum IS NOT NULL and location='"+mbo.getString("DM_STOREROOM")+"'"
										//+"	and "+invReserveSet.getCompleteWhere() 
										+" and invreserveid in ("+selectedInvreserverids+")"
										+" UNION  "
										+" SELECT location,mrnum womrnum,siteid,'MR' rectype,requireddate FROM invreserve WHERE wonum IS NULL AND mrnum IS NOT NULL and location='"+mbo.getString("DM_STOREROOM")+"'"
										//+" and "+invReserveSet.getCompleteWhere() 
										+" and invreserveid in ("+selectedInvreserverids+")"
										+"UNION  "
										+" SELECT location,ponum womrnum,siteid,'PO' rectype,requireddate FROM invreserve WHERE wonum IS NULL AND ponum IS NOT NULL and location='"+mbo.getString("DM_STOREROOM")+"'"
										+" and invreserveid in ("+selectedInvreserverids+")"
										+" ) group by location,womrnum,siteid,rectype ORDER BY min(requireddate) asc";
				sqfQuery=new SqlFormat(query1)
				//sqfQuery.setObject(1,"ASSET","SITEID","BEDFORD")
				logger.error("***ASH***Sript DM_PLCREATEIVDIAG**query1="+query1);
				resultSet1=dbShortcut.executeQuery(sqfQuery.format())
				//logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet1="+resultSet1);
				//invUseSet=mbo.getThisMboSet();
				
				while( resultSet1.next())
				{
					//logger.error("***ASH***Sript DM_PLCREATEIVDIAG**inside while 1"); 
					canDM_PLCREATEIVDIAG=0;
					isIVRCreated=0;
					invUseNum=null;
					invUseMbo=null;
					query2="";
					if(resultSet1.getString("rectype").equalsIgnoreCase("WO"))
					{
						
						
					//logger.error("***ASH***Sript DM_PLCREATEIVDIAG** upd restype="+restype); 
					query2="select requestnum,itemnum,RESERVEDQTY, pendingqty,remnqty,requesteddate,binnum,totalbal,totopeninvuseqty,requireddate from (select requestnum,itemnum,RESERVEDQTY, pendingqty,(RESERVEDQTY-pendingqty-stagedqty-shippedqty) remnqty,requesteddate,binnum,requireddate,"
							+" coalesce((select sum(curbal) from invbalances ib where ib.location=ir.location and ib.siteid=ir.siteid and ib.itemnum=ir.itemnum AND ((SELECT il.USEBY FROM invlot il WHERE il.lotnum=ib.lotnum AND il.itemnum=ib.itemnum AND il.location=ib.location AND il.siteid=ib.siteid AND il.itemsetid=ib.itemsetid) IS NULL OR (SELECT il.USEBY FROM invlot il WHERE il.lotnum=ib.lotnum AND il.itemnum=ib.itemnum AND il.location=ib.location AND il.siteid=ib.siteid AND il.itemsetid=ib.itemsetid)>SYSDATE)),0) totalbal,"
							+" coalesce((select sum(invuseline.QUANTITY) from invuseline  where invuseline.USETYPE='ISSUE' and invuseline.itemnum=ir.itemnum and invuseline.fromstoreloc=ir.location and "
							+" invuseline.invusenum in ( select invusenum from invuse where siteid=ir.siteid and status in ( select value from synonymdomain where "
							+" domainid = 'INVUSESTATUS' and maxvalue = 'ENTERED'))),0) totopeninvuseqty"
							+" from invreserve ir where wonum='"+resultSet1.getString("womrnum")+"' and location='"+resultSet1.getString("location")+"'"
							//+" and "+invReserveSet.getCompleteWhere()+" 
							+" and invreserveid in ("+selectedInvreserverids+") ) where remnqty>0 and (remnqty<=(totalbal-totopeninvuseqty) or (totalbal-totopeninvuseqty)>0) order by requireddate asc";
					
					}
					else if(resultSet1.getString("rectype").equalsIgnoreCase("MR"))
					{
						query2="select requestnum,itemnum,RESERVEDQTY, pendingqty,remnqty,requesteddate,binnum,totalbal,totopeninvuseqty,requireddate from (select requestnum,itemnum,RESERVEDQTY, pendingqty,(RESERVEDQTY-pendingqty-stagedqty-shippedqty) remnqty,requesteddate,binnum,requireddate,"
							+" coalesce((select sum(curbal) from invbalances ib where ib.location=ir.location and ib.siteid=ir.siteid and ib.itemnum=ir.itemnum AND ((SELECT il.USEBY FROM invlot il WHERE il.lotnum=ib.lotnum AND il.itemnum=ib.itemnum AND il.location=ib.location AND il.siteid=ib.siteid AND il.itemsetid=ib.itemsetid) IS NULL OR (SELECT il.USEBY FROM invlot il WHERE il.lotnum=ib.lotnum AND il.itemnum=ib.itemnum AND il.location=ib.location AND il.siteid=ib.siteid AND il.itemsetid=ib.itemsetid)>SYSDATE)),0) totalbal,"
							+" coalesce((select sum(invuseline.QUANTITY) from invuseline  where invuseline.USETYPE='ISSUE' and invuseline.itemnum=ir.itemnum and invuseline.fromstoreloc=ir.location and "
							+" invuseline.invusenum in ( select invusenum from invuse where siteid=ir.siteid and status in ( select value from synonymdomain where "
							+" domainid = 'INVUSESTATUS' and maxvalue = 'ENTERED'))),0) totopeninvuseqty"
							+" from invreserve ir where MRNUM='"+resultSet1.getString("womrnum")+"' and location='"+resultSet1.getString("location")+"'"
							//+" and "+invReserveSet.getCompleteWhere()
							+" and invreserveid in ("+selectedInvreserverids+")  ) where remnqty>0 and (remnqty<=(totalbal-totopeninvuseqty) or (totalbal-totopeninvuseqty)>0) order by requireddate asc";
					
					}
					else if(resultSet1.getString("rectype").equalsIgnoreCase("PO"))
					{
						query2="select requestnum,itemnum,RESERVEDQTY, pendingqty,remnqty,requesteddate,binnum,totalbal,totopeninvuseqty,requireddate from (select requestnum,itemnum,RESERVEDQTY, pendingqty,(RESERVEDQTY-pendingqty-stagedqty-shippedqty) remnqty,requesteddate,binnum,requireddate,"
							+" coalesce((select sum(curbal) from invbalances ib where ib.location=ir.location and ib.siteid=ir.siteid and ib.itemnum=ir.itemnum AND ((SELECT il.USEBY FROM invlot il WHERE il.lotnum=ib.lotnum AND il.itemnum=ib.itemnum AND il.location=ib.location AND il.siteid=ib.siteid AND il.itemsetid=ib.itemsetid) IS NULL OR (SELECT il.USEBY FROM invlot il WHERE il.lotnum=ib.lotnum AND il.itemnum=ib.itemnum AND il.location=ib.location AND il.siteid=ib.siteid AND il.itemsetid=ib.itemsetid)>SYSDATE)),0) totalbal,"
							+" coalesce((select sum(invuseline.QUANTITY) from invuseline  where invuseline.USETYPE='TRANSFER' and invuseline.itemnum=ir.itemnum and invuseline.fromstoreloc=ir.location and "
							+" invuseline.invusenum in ( select invusenum from invuse where siteid=ir.siteid and status in ( select value from synonymdomain where "
							+" domainid = 'INVUSESTATUS' and maxvalue = 'ENTERED'))),0) totopeninvuseqty"
							+" from invreserve ir where PONUM='"+resultSet1.getString("womrnum")+"' and location='"+resultSet1.getString("location")+"'"
							//+" and "+invReserveSet.getCompleteWhere()
							+" and invreserveid in ("+selectedInvreserverids+")  ) where remnqty>0 and (remnqty<=(totalbal-totopeninvuseqty) or (totalbal-totopeninvuseqty)>0) order by requireddate asc";
					
					}
					logger.error("***ASH***Sript DM_PLCREATEIVDIAG**query2="+query2); 
					sqfQuery2= new SqlFormat(query2)
					
					resultSet2=dbShortcut2.executeQuery(sqfQuery2.format())
					//logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet2="+resultSet2); 
					i=0;
					while( resultSet2.next())
					{
						
						i++;
						logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet2 i="+i);
					
						
						//if(resultSet2.getDouble("remnqty")<=resultSet2.getDouble("totalbal"))
						if(resultSet2.getDouble("remnqty")>0 && resultSet2.getDouble("totalbal")>0)
						{
							canDM_PLCREATEIVDIAG=1;
							
						}
						logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet2 canDM_PLCREATEIVDIAG="+canDM_PLCREATEIVDIAG);
						if(canDM_PLCREATEIVDIAG==1)
						{
							
							if(isIVRCreated==0)
							{
								//logger.error("***ASH***Sript DM_PLCREATEIVDIAG**isIVRCreated="+isIVRCreated); 
								
					
								invUseMbo=invUseSet.add();
								invUseNum=invUseMbo.getString("INVUSENUM");
								logger.error("***ASH***Sript DM_PLCREATEIVDIAG**IVR Created invusenum="+invUseNum);
								invUseMbo.setValue("FROMSTORELOC",resultSet1.getString("location"),2);
								if(resultSet1.getString("rectype").equalsIgnoreCase("WO") || resultSet1.getString("rectype").equalsIgnoreCase("MR"))
								{
									invUseMbo.setValue("USETYPE","ISSUE",2);
								}
								else if(resultSet1.getString("rectype").equalsIgnoreCase("PO"))
								{
									invUseMbo.setValue("USETYPE","TRANSFER",2);
								}
								invUseMbo.setValue("DM_PICKLISTNUM",mbo.getString("DM_PICKLISTNUM"),2);
								invUseMbo.setValue("DESCRIPTION","Created for "+resultSet1.getString("rectype")+" - "+resultSet1.getString("womrnum")+" by Pick List "+mbo.getString("DM_PICKLISTNUM"),2);
								isIVRCreated=1;
								
								//Create the IVR Header and return invUseNum value
								
							}
							if(invUseNum!=null)
							{
								//logger.error("***ASH***Sript DM_PLCREATEIVDIAG**invUseNum="+invUseNum); 
								// add reserved lines to INVUSE
								if(invUseMbo!=null)
								{
									curbalQty=resultSet2.getDouble("totalbal")-resultSet2.getDouble("totopeninvuseqty");
									//if(resultSet2.getDouble("remnqty")<=resultSet2.getDouble("totalbal"))
									if(resultSet2.getDouble("remnqty")>0 && resultSet2.getDouble("totalbal")>0)
									{
										invReserveSet=invUseMbo.getMboSet("INVRESERVE");
										invReserveSet.setWhere("requestnum='"+resultSet2.getString("requestnum")+"'")
										//logger.error("***ASH***Sript DM_PLCREATEIVDIAG**IVR Created invReserveSet where="+invReserveSet.getCompleteWhere());
										invReserveSet.reset();
										//logger.error("***ASH***Sript DM_PLCREATEIVDIAG**IVR Created invReserveSet reset() where="+invReserveSet.getCompleteWhere());
										invuseLineSet=invUseMbo.getMboSet("INVUSELINE")
										// The below code to add multiple lines against the Bin
										if(resultSet1.getString("rectype").equalsIgnoreCase("WO") || resultSet1.getString("rectype").equalsIgnoreCase("MR"))
										{
											query3="SELECT openinvusebinbal,itemnum,location,binnum,curbal,lastrecvdate,(curbal-COALESCE(openinvusebinbal,0)) remninvbal,lotnum,expirydate FROM ( "
													+" SELECT "
													+" (SELECT sum(ivl.quantity) FROM invuseline ivl WHERE ivl.USETYPE ='ISSUE' AND ivl.LINETYPE ='ITEM'  AND ivl.fromstoreloc=i.LOCATION AND ivl.ITEMNUM =i.itemnum  "
													+" AND EXISTS (SELECT 1 FROM INVUSE i2 WHERE i2.status='ENTERED' AND ivl.INVUSENUM=i2.invusenum AND ivl.SITEID=i2.siteid AND ivl.FROMSTORELOC=i2.FROMSTORELOC) "
													+" AND ((ivl.frombin IS NOT NULL AND i.binnum IS NOT NULL and ivl.frombin=i.BINNUM) OR (ivl.frombin IS NULL AND i.binnum IS null))) openinvusebinbal, "
													+" i.itemnum,i.location,i.BINNUM,i.CURBAL,i.DM_BALANCEDATE lastrecvdate, lotnum, "
													+" (SELECT il.USEBY FROM invlot il WHERE il.lotnum=i.lotnum AND il.itemnum=i.itemnum AND il.location=i.location AND il.siteid=i.siteid AND il.itemsetid=i.itemsetid) expirydate"
													+" FROM INVBALANCES i WHERE LOCATION='"+resultSet1.getString("location")+"' AND ITEMNUM='"+resultSet2.getString("itemnum")+"'  AND STAGINGBIN =0 AND CURBAL >0 "
													+" ORDER BY DM_BALANCEDATE ASC) where (curbal-COALESCE(openinvusebinbal,0)) >0 AND (EXPIRYDATE IS NULL OR EXPIRYDATE>SYSDATE) ORDER BY EXPIRYDATE asc";
										}
										else if (resultSet1.getString("rectype").equalsIgnoreCase("PO"))
										{
											query3="SELECT openinvusebinbal,itemnum,location,binnum,curbal,lastrecvdate,(curbal-COALESCE(openinvusebinbal,0)) remninvbal,lotnum,expirydate FROM ( "
													+" SELECT "
													+" (SELECT sum(ivl.quantity) FROM invuseline ivl WHERE ivl.USETYPE ='TRANSFER' AND ivl.LINETYPE ='ITEM'  AND ivl.fromstoreloc=i.LOCATION AND ivl.ITEMNUM =i.itemnum  "
													+" AND EXISTS (SELECT 1 FROM INVUSE i2 WHERE i2.status='ENTERED' AND ivl.INVUSENUM=i2.invusenum AND ivl.SITEID=i2.siteid AND ivl.FROMSTORELOC=i2.FROMSTORELOC) "
													+" AND ((ivl.frombin IS NOT NULL AND i.binnum IS NOT NULL and ivl.frombin=i.BINNUM) OR (ivl.frombin IS NULL AND i.binnum IS null))) openinvusebinbal, "
													+" i.itemnum,i.location,i.BINNUM,i.CURBAL,i.DM_BALANCEDATE lastrecvdate, lotnum, "
													+" (SELECT il.USEBY FROM invlot il WHERE il.lotnum=i.lotnum AND il.itemnum=i.itemnum AND il.location=i.location AND il.siteid=i.siteid AND il.itemsetid=i.itemsetid) expirydate"
													+" FROM INVBALANCES i WHERE LOCATION='"+resultSet1.getString("location")+"' AND ITEMNUM='"+resultSet2.getString("itemnum")+"'  AND STAGINGBIN =0 AND CURBAL >0 "
													+" ORDER BY DM_BALANCEDATE ASC) where (curbal-COALESCE(openinvusebinbal,0)) >0 AND (EXPIRYDATE IS NULL OR EXPIRYDATE>SYSDATE) ORDER BY EXPIRYDATE asc";
										}	
										logger.error("***ASH***Sript DM_PLCREATEIVDIAG**query3="+query3); 
										sqfQuery3= new SqlFormat(query3)
										
										resultSet3=dbShortcut3.executeQuery(sqfQuery3.format())
										//logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet2="+resultSet2); 
										loopBreakFlag=0;
										remnqty=resultSet2.getDouble("remnqty");
										remlineqty=remnqty;
										while( resultSet3.next() && loopBreakFlag==0)
										{
											invReserveMbo1=invReserveSet.getMbo(0);
											itemMbo=invReserveMbo1.getMboSet("ITEM").getMbo(0);
											isRotating= itemMbo.getInt("ROTATING");
											logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet3 isRotating="+isRotating); 
											rs3binnum=resultSet3.getString("binnum");
											logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet3 rs3binnum="+rs3binnum); 
											rs3lotnum=resultSet3.getString("lotnum");
											logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet3 rs3lotnum="+rs3lotnum); 
											if(isRotating==0)
											{
												logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet3 while loop "); 
                                                //Amir
												//invuseLineMbo=invuseLineSet.addInvUseLineFromInvReserve(invReserveSet.getMbo(0));
                                                invRes = invReserveSet.getMbo(0)
                                                
                                                invuseLineMbo = addInvUseLineFromInvReserveCutom(invuseLineSet);
                                                //
												remninvbal=resultSet3.getDouble("remninvbal")
												logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet3 remninvbal="+remninvbal); 
												logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet3 binnum="+resultSet3.getString("binnum")); 
												if(remlineqty<=remninvbal)
												{
													logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet3 remlineqty<=remninvbal=True"); 
													invuseLineMbo.setValue("QUANTITY",remlineqty,2)
													if(rs3binnum!=null && rs3binnum.length()>0)
													{
														invuseLineMbo.setValue("frombin",rs3binnum,2);
													}
													else
													{
														invuseLineMbo.setValueNull("frombin",2);
													}
													if(rs3lotnum!=null && rs3lotnum.length()>0)
													{
														invuseLineMbo.setValue("FROMLOT",rs3lotnum,2);
													}
														
													loopBreakFlag=1;
												}
												else
												{
													logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet3 remlineqty<=remninvbal=false"); 
													invuseLineMbo.setValue("QUANTITY",remninvbal,2)
													if(rs3binnum!=null && rs3binnum.length()>0)
													{
														invuseLineMbo.setValue("frombin",rs3binnum,2);
													}
													else
													{
														invuseLineMbo.setValueNull("frombin",2);
													}
													if(rs3lotnum!=null && rs3lotnum.length()>0)
													{
														invuseLineMbo.setValue("FROMLOT",rs3lotnum,2);
													}
													remlineqty=remlineqty-remninvbal
												}
											}
											else
											{
												remninvbal=resultSet3.getDouble("remninvbal")
												if(remlineqty<=remninvbal)
												{
													logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet3 rot remlineqty<=remninvbal=true"); 
													for(k=0;k<remlineqty;k++)
													{
														logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet3 rot  remlineqty<=remninvbal=true k="+k); 

                                                        //Amir
                                                        //invuseLineMbo=invuseLineSet.addInvUseLineFromInvReserve(invReserveSet.getMbo(0));
                                                        invRes = invReserveSet.getMbo(0)
                                                        
                                                        invuseLineMbo = addInvUseLineFromInvReserveCutom(invuseLineSet);
                                                        //
														logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet3 rot  remlineqty<=remninvbal=true afdter addline"); 
														invuseLineMbo.setValue("QUANTITY",'1',2)
														logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet3 rot  remlineqty<=remninvbal=true afdter qty"); 
														//invuseLineMbo.setValue("frombin",resultSet3.getString("binnum"),2);
														if(rs3binnum!=null && rs3binnum.length()>0)
														{
															invuseLineMbo.setValue("frombin",rs3binnum,2);
														}
														else
														{
															invuseLineMbo.setValueNull("frombin",2);
														}
														if(rs3lotnum!=null && rs3lotnum.length()>0)
														{
															invuseLineMbo.setValue("FROMLOT",rs3lotnum,2);
														}
														loopBreakFlag=1;
													}
													logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet3 rot  remlineqty<=remninvbal=true end for loop"); 
												}
												else
												{
													logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet3 rot  remlineqty<=remninvbal=false"); 
													for(k=0;k<remninvbal;k++)
													{
														logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet3 rot  remlineqty<=remninvbal=false k="+k); 
														//Amir
                                                        //invuseLineMbo=invuseLineSet.addInvUseLineFromInvReserve(invReserveSet.getMbo(0));
                                                        invRes = invReserveSet.getMbo(0)
                                                        
                                                        invuseLineMbo = addInvUseLineFromInvReserveCutom(invuseLineSet);
                                                        //

														invuseLineMbo.setValue("QUANTITY",'1',2)
														//invuseLineMbo.setValue("frombin",resultSet3.getString("binnum"),2);
														if(rs3binnum!=null && rs3binnum.length()>0)
														{
															invuseLineMbo.setValue("frombin",rs3binnum,2);
														}
														else
														{
															invuseLineMbo.setValueNull("frombin",2);
														}
														if(rs3lotnum!=null && rs3lotnum.length()>0)
														{
															invuseLineMbo.setValue("FROMLOT",rs3lotnum,2);
														}
														remlineqty=remlineqty-1;
														
														
													}
													logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet rot 3 remlineqty<=remninvbal=false end for loop"); 	
												}													
											}
										}
										logger.error("***ASH***Sript DM_PLCREATEIVDIAG**resultSet3 while loop END "); 
										resultSet3.close();
									}
								}
							}
							
							
						}
					}
					resultSet2.close();
					if(canDM_PLCREATEIVDIAG==1)
					{
						invUseSet.save();
					}
					//save the IVR 
				}
				resultSet1.close();
				mbo.getOwner().getThisMboSet().save();
				service.closeDialog();
			}
			catch(e)
			{
				logger.error("***ASH***Sript DM_PLCREATEIVDIAG**EXCEPTION="+e);
				//logger.error("***ASH***Sript DM_PLCREATEIVDIAG**EXCEPTION="+e.printStackTrace());
				if(invUseMbo!=null)
				{
					logger.error("***ASH***Sript DM_PLCREATEIVDIAG**EXCEPTION="+invUseMbo.getString("invusenum")+" is deleted");
					invUseMbo.delete(2);
					
				}
				
				service.error("DM","genericerror",[e])
				
			}
			finally
			{
				if(resultSet3!=null)
				{
					resultSet3.close();
				}
				if(resultSet2!=null)
				{
					resultSet2.close();
				}
				if(resultSet1!=null)
				{
					resultSet1.close();
				}
				dbShortcut.close();
				dbShortcut2.close();
				dbShortcut3.close();
			}
			
			
			
		}
		
	}
}
else
{
	errorgroup="dm_picklist"
	errorkey="notvalidstatus"
}