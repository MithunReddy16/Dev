/*
Script: DM_PLINRESILTER
Created By: Ashok
Date: 19-Nov-2024
Req: Create Inventory Usage Lines from Pick LIst


*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(java.time)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)



//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_PLINRESILTER**START***")
logger.error("***ASH***Sript DM_PLINRESILTER**mbo="+mbo)
//logger.error("***ASH***Sript DM_PLINRESILTER**Owner mbo="+mbo.getOwner())
session=service.webclientsession()

databean=session.getDataBean("DM_PLDIAG_grid2_1_1_contlines_table")
if(launchPoint  == 'DM_PLINRESILTER_TR')
{
    databean=session.getDataBean("DM_PLDIAG_grid2_1_1_contlines_table_TR")

}

databean1=session.getDataBean("DM_PLDIAGLIST_grid2_1_1_contlines_table")
logger.error("***ASH***Sript DM_PLINRESILTER**databean="+databean)
if(databean!=null)
{
	//woMbo=mbo.getOwner();
	
	logger.error("***ASH***Sript DM_PLINRESILTER**DM_PICKLISTNUM="+mbo.getString("DM_PICKLISTNUM"))
	//invReserveSet=mbo.getMboSet("DM_CONTRACTLINES")
	//date_column BETWEEN TO_DATE('2024-12-01', 'YYYY-MM-DD') AND TO_DATE('2024-12-31', 'YYYY-MM-DD')
	invReserveSet=databean.getMboSet();
	//fromDate = mbo.getDate("DM_FROMDATE").toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	//toDate = mbo.getDate("DM_TODATE").toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	whereClause=" 1=1 ";
	storeloc=mbo.getString("DM_STOREROOM");
	siteid=mbo.getString("siteid");
	fromDate = mbo.getDate("DM_FROMDATE");
	toDate = mbo.getDate("DM_TODATE");
	if(storeloc!=null)
	{
		whereClause+=" and location='"+storeloc+"'"
	}
	if(siteid!=null)
	{
		whereClause+=" and siteid='"+siteid+"'"
	}
	if(fromDate!=null)
	{
		fromDate = mbo.getDate("DM_FROMDATE").toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
		whereClause+=" and TRUNC(requireddate)>=TO_DATE('"+fromDate.getYear()+"-"+fromDate.getMonthValue()+"-"+fromDate.getDayOfMonth()+"', 'YYYY-MM-DD')"
	}
	if(toDate!=null)
	{
		toDate = mbo.getDate("DM_TODATE").toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		whereClause+=" and TRUNC(requireddate)<=TO_DATE('"+toDate.getYear()+"-"+toDate.getMonthValue()+"-"+toDate.getDayOfMonth()+"', 'YYYY-MM-DD')"
	}
	
	
	//logger.error("***ASH***Sript DM_PLINRESILTER**invReserveSet selectedRecords localDate.getYear() ="+localDate.getYear())
	//select * from invreserve  where (to_date(requireddate, 'YYYY-MM-DD') between TO_DATE('124-11-25', 'YYYY-MM-DD') and TO_DATE('124-12-18', 'YYYY-MM-DD')) nd (location= 'M02'  and siteid= 'DM'  and  (reservedqty - pendingqty - stagedqty - shippedqty) > 0). See the log file for more details about the error.
	//invReserveSet.setWhere("TRUNC(requireddate) between TO_DATE('"+fromDate.getYear()+"-"+fromDate.getMonthValue()+"-"+fromDate.getDayOfMonth()+"', 'YYYY-MM-DD') and TO_DATE('"+toDate.getYear()+"-"+toDate.getMonthValue()+"-"+toDate.getDayOfMonth()+"', 'YYYY-MM-DD')");
	//invReserveSet.setWhere("requireddate between "+mbo.getDate("DM_FROMDATE")+" and "+mbo.getDate("DM_TODATE"));
	invReserveSet.setWhere(whereClause);
	invReserveSet.reset();
	logger.error("***ASH***Sript DM_PLINRESILTER**invReserveSet selectedRecords where  ="+invReserveSet.getCompleteWhere())
	selectedRecords=invReserveSet.getSelection()
	logger.error("***ASH***Sript DM_PLINRESILTER**invReserveSet selectedRecords size ="+selectedRecords.size())
	
	
}
else if(databean1!=null)
{
	//woMbo=mbo.getOwner();
	
	logger.error("***ASH***Sript DM_PLINRESILTER**DM_PICKLISTNUM="+mbo.getString("DM_PICKLISTNUM"))
	//invReserveSet=mbo.getMboSet("DM_CONTRACTLINES")
	//date_column BETWEEN TO_DATE('2024-12-01', 'YYYY-MM-DD') AND TO_DATE('2024-12-31', 'YYYY-MM-DD')
	whereClause=" 1=1 ";
	invReserveSet=databean1.getMboSet();
	storeloc=mbo.getString("DM_STOREROOM");
	siteid=mbo.getString("siteid");
	fromDate = mbo.getDate("DM_FROMDATE");
	toDate = mbo.getDate("DM_TODATE");
	if(storeloc!=null)
	{
		whereClause+=" and location='"+storeloc+"'"
	}
	if(siteid!=null)
	{
		whereClause+=" and siteid='"+siteid+"'"
	}
	if(fromDate!=null)
	{
		fromDate = mbo.getDate("DM_FROMDATE").toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
		whereClause+=" and TRUNC(requireddate)>=TO_DATE('"+fromDate.getYear()+"-"+fromDate.getMonthValue()+"-"+fromDate.getDayOfMonth()+"', 'YYYY-MM-DD')"
	}
	if(toDate!=null)
	{
		toDate = mbo.getDate("DM_TODATE").toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		whereClause+=" and TRUNC(requireddate)<=TO_DATE('"+toDate.getYear()+"-"+toDate.getMonthValue()+"-"+toDate.getDayOfMonth()+"', 'YYYY-MM-DD')"
	}
	//logger.error("***ASH***Sript DM_PLINRESILTER**invReserveSet selectedRecords localDate.getYear() ="+localDate.getYear())
	//select * from invreserve  where (to_date(requireddate, 'YYYY-MM-DD') between TO_DATE('124-11-25', 'YYYY-MM-DD') and TO_DATE('124-12-18', 'YYYY-MM-DD')) nd (location= 'M02'  and siteid= 'DM'  and  (reservedqty - pendingqty - stagedqty - shippedqty) > 0). See the log file for more details about the error.
	//invReserveSet.setWhere("TRUNC(requireddate) between TO_DATE('"+fromDate.getYear()+"-"+fromDate.getMonthValue()+"-"+fromDate.getDayOfMonth()+"', 'YYYY-MM-DD') and TO_DATE('"+toDate.getYear()+"-"+toDate.getMonthValue()+"-"+toDate.getDayOfMonth()+"', 'YYYY-MM-DD')");
	invReserveSet.setWhere(whereClause);
	//invReserveSet.setWhere("requireddate between "+mbo.getDate("DM_FROMDATE")+" and "+mbo.getDate("DM_TODATE"));
	invReserveSet.reset();
	logger.error("***ASH***Sript DM_PLINRESILTER**invReserveSet selectedRecords where  ="+invReserveSet.getCompleteWhere())
	selectedRecords=invReserveSet.getSelection()
	logger.error("***ASH***Sript DM_PLINRESILTER**invReserveSet selectedRecords size ="+selectedRecords.size())
	
		
}
else {
	
	logger.error("***ASH***Sript DM_PLINRESILTER**databean is null ")
}
//service.closeDialog();
logger.error("***ASH***Sript DM_PLINRESILTER**END***")