/*
Script: dm_selpolines
Created By: ram
Date: 19-Nov-2025
Req: Create Inventory Usage Lines from Pick LIst


*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(java.time)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)

var logger = MXLoggerFactory.getLogger("maximo.dm")
logger.debug("***RA*** Script POLINE ** START ***")

session = service.webclientsession()
databean = session.getDataBean("copypolinebean")

if (databean != null) {
    var invReserveSet = databean.getMboSet()
    var whereClause = "1=1" // Start with a default that returns all
    
    var fromDate = mbo.getDate("DM_FROMDATE")
    var toDate = mbo.getDate("DM_TODATE")
   // service.error("debug3456", "FromDate: "+fromDate);
    // Build date filtering if either date exists

   if (fromDate != null || toDate != null) {
whereClause = "poline.refwo IN (SELECT wostatus.wonum from  workorder,wostatus WHERE workorder.wonum=wostatus.wonum and wostatus.status='COMP'";
if (fromDate != null) {
    var fromDateStr = new java.text.SimpleDateFormat("dd-MMM-yy").format(fromDate).toUpperCase();
    whereClause += " AND TRUNC(wostatus.changedate) >= TO_DATE('" + fromDateStr + "', 'DD-MON-YY')";
}
if (toDate != null) {
    var toDateStr = new java.text.SimpleDateFormat("dd-MMM-yy").format(toDate).toUpperCase();
    whereClause += " AND TRUNC(wostatus.changedate) <= TO_DATE('" + toDateStr + "', 'DD-MON-YY')";
}
whereClause += ")";
    
    logger.debug("***RA*** Final WHERE clause: " + whereClause)
    invReserveSet.setWhere(whereClause)
    invReserveSet.reset()
     // App=session.getCurrentApp()
    //App.SAVE()
    
    databean.fireDataChangedEvent()
   databean.refreshTable(); 
    var resultCount = invReserveSet.count()
    logger.debug("***RA*** Resulting records after WHERE: " + resultCount)
    
    } 


//    service.error("debug3456", "FromDate: "+resultCount);
}