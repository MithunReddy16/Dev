/*
Script: DM_CREATEPLIU
Created By: Ashok
Date: 19-Nov-2024
Req: Create Inventory Usage Lines from Pick LIst


*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)



//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_CREATEPLIU**START***")
logger.error("***ASH***Sript DM_CREATEPLIU**mbo="+mbo)
//logger.error("***ASH***Sript DM_CREATEPLIU**Owner mbo="+mbo.getOwner())
session=service.webclientsession()
databean=session.getDataBean("DM_CRTIUFROMRES_grid2_1_1_contlines_table")
logger.error("***ASH***Sript DM_CREATEPLIU**databean="+databean)
if(databean!=null)
{
	//woMbo=mbo.getOwner();
	
	logger.error("***ASH***Sript DM_CREATEPLIU**DM_PICKLISTNUM="+mbo.getString("DM_PICKLISTNUM"))
	//invReserveSet=mbo.getMboSet("DM_CONTRACTLINES")
	invReserveSet=databean.getMboSet();
	selectedRecords=invReserveSet.getSelection()
	logger.error("***ASH***Sript DM_CREATEPLIU**invReserveSet selectedRecords size ="+selectedRecords.size())
	
	if (selectedRecords.size()>0)
	{
		iterator=selectedRecords.iterator()
		invUseSet=mbo.getMboSet("DM_INVUSE");
		invUseMbo=invUseSet.add();
		invUseNum=invUseMbo.getString("INVUSENUM");
		logger.error("***ASH***Sript DM_CREATEPLIU**IVR Created invusenum="+invUseNum);
		invUseMbo.setValue("FROMSTORELOC",mbo.getString("DM_STOREROOM"),2);
		invUseMbo.setValue("USETYPE","MIXED",2);
		invUseMbo.setValue("DESCRIPTION","Created from Pick List  "+mbo.getString("DM_PICKLISTNUM")+" Reservation ",2);
		invUseMbo.setValue("DM_PICKLISTNUM",mbo.getString("DM_PICKLISTNUM"),2);
		invuseLineSet=invUseMbo.getMboSet("INVUSELINE");
		while (iterator.hasNext())
		{
			invReserveMbo=iterator.next()
			
			invuseLineMbo=invuseLineSet.addInvUseLineFromInvReserve(invReserveMbo);		
			
		}
	}
	else
	{
		logger.error("***ASH***Sript DM_CREATEPLIU**selectedRecords size is 0")
	}

	
}
else
{
	logger.error("***ASH***Sript DM_CREATEPLIU**databean is null ")
}
service.closeDialog();
logger.error("***ASH***Sript DM_CREATEPLIU**END***")