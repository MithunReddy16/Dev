/*
Script: DM_PLCREATEIVR
Created By: Ashok
Date: 10-Dec-2024
Req: Create the Inventory Usage records for the provided storeroom and From Date and To Date
For those set, create inventory usage records that follows: 
	For items that only has balance in hand  
	Inventory usages grouped by WONUM ( MRNUM if not WONUM) 
	If item current balance is not sufficient to cover all reservation for the same due date,  start with reservation that has HARD reservation type, then based on request date  order. 
	Pick inventory bin that has oldest stock: 
		

Solution Approach:
1. IVR will be created against WO-STORE-RESERVATIONTYPE
2. Lines are Created Against the same criteria which has enough balances
3. IF the Current Inventory Balance is not Sufficient including the Open IVR Transcation qty, then the IVR will not create 
for eg, IF requestqty <= (Total Inventory Balance Qty - Total Open IVRLInes Qty) then IVR is created ELSE Not Created
4. Reserve Lines are copied to INVUSELINE and set the FROM BIN as per the DM_BALANCEDATE in ASC
5. By Default the BIN is selected as per the balance date, irrespective of balance exists. During the INVUSE Completion the user has to change the bin or split the line accordingly.

var workorderMap = new HashMap();
workorderMap.put(workorderId, wo);
var mboRemote = workorderMap.get(workorderId);

workorderMap.put(workorderId, wo);



*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)

//from psdi.mbo import DBShortcut,SqlFormat


//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_PLCREATEIVR**START***")
 //workorderMap = new HashMap();
 
if(mbo.getString("DM_STATUS").equalsIgnoreCase("ENTERED"))
{
	 
	try
	{
		dbShortcut= new DBShortcut()
		dbShortcut2= new DBShortcut()
		invUseMbo=null;
		resultSet2=null;
		resultSet1=null;
		dbShortcut.connect(mbo.getThisMboSet().getUserInfo().getConnectionKey())
		dbShortcut2.connect(mbo.getThisMboSet().getUserInfo().getConnectionKey())
		invUseSet=mbo.getMboSet("DM_INVUSE");
		query1="SELECT location,womrnum,siteid,rectype FROM "
								+" (SELECT location,wonum womrnum,siteid,'WO' rectype FROM invreserve WHERE  wonum IS NOT NULL and location='"+mbo.getString("DM_STOREROOM")+"' and requireddate between trunc((select dm_fromdate from dm_picklist where dm_picklistnum='"+mbo.getString("DM_PICKLISTNUM")+"')) and trunc((select dm_todate+1 from dm_picklist where dm_picklistnum='"+mbo.getString("DM_PICKLISTNUM")+"'))" 
								+" UNION  "
								+" SELECT location,mrnum womrnum,siteid,'MR' rectype FROM invreserve WHERE wonum IS NULL AND mrnum IS NOT NULL and location='"+mbo.getString("DM_STOREROOM")+"' and requireddate between trunc((select dm_fromdate from dm_picklist where dm_picklistnum='"+mbo.getString("DM_PICKLISTNUM")+"')) and trunc((select dm_todate+1 from dm_picklist where dm_picklistnum='"+mbo.getString("DM_PICKLISTNUM")+"'))" 
								+" ) group by location,womrnum,siteid,rectype";
		sqfQuery=new SqlFormat(query1)
		//sqfQuery.setObject(1,"ASSET","SITEID","BEDFORD")
		logger.error("***ASH***Sript DM_PLCREATEIVR**query1="+query1);
		resultSet1=dbShortcut.executeQuery(sqfQuery.format())
		//logger.error("***ASH***Sript DM_PLCREATEIVR**resultSet1="+resultSet1);
		//invUseSet=mbo.getThisMboSet();
		
		while( resultSet1.next())
		{
			//logger.error("***ASH***Sript DM_PLCREATEIVR**inside while 1"); 
			canDM_PLCREATEIVR=0;
			isIVRCreated=0;
			invUseNum=null;
			invUseMbo=null;
			query2="";
			if(resultSet1.getString("rectype").equalsIgnoreCase("WO"))
			{
				
				
			//logger.error("***ASH***Sript DM_PLCREATEIVR** upd restype="+restype); 
			query2="select requestnum,itemnum,RESERVEDQTY, pendingqty,remnqty,requesteddate,binnum,totalbal,totopeninvuseqty from (select requestnum,itemnum,RESERVEDQTY, pendingqty,(RESERVEDQTY-pendingqty-stagedqty-shippedqty) remnqty,requesteddate,binnum,"
					+" coalesce((select sum(curbal) from invbalances ib where ib.location=ir.location and ib.siteid=ir.siteid and ib.itemnum=ir.itemnum ),0) totalbal,"
					+" coalesce((select sum(invuseline.QUANTITY) from invuseline  where invuseline.USETYPE='ISSUE' and invuseline.itemnum=ir.itemnum and invuseline.fromstoreloc=ir.location and "
					+" invuseline.invusenum in ( select invusenum from invuse where siteid=ir.siteid and status in ( select value from synonymdomain where "
					+" domainid = 'INVUSESTATUS' and maxvalue = 'ENTERED'))),0) totopeninvuseqty"
					+" from invreserve ir where wonum='"+resultSet1.getString("womrnum")+"' and location='"+resultSet1.getString("location")+"' and requireddate between trunc((select dm_fromdate from dm_picklist where dm_picklistnum='"+mbo.getString("DM_PICKLISTNUM")+"')) and trunc((select dm_todate+1 from dm_picklist where dm_picklistnum='"+mbo.getString("DM_PICKLISTNUM")+"'))  ) where remnqty>0 and remnqty<=(totalbal-totopeninvuseqty) order by requesteddate asc";
			
			}
			else if(resultSet1.getString("rectype").equalsIgnoreCase("MR"))
			{
				query2="select requestnum,itemnum,RESERVEDQTY, pendingqty,remnqty,requesteddate,binnum,totalbal,totopeninvuseqty from (select requestnum,itemnum,RESERVEDQTY, pendingqty,(RESERVEDQTY-pendingqty-stagedqty-shippedqty) remnqty,requesteddate,binnum,"
					+" coalesce((select sum(curbal) from invbalances ib where ib.location=ir.location and ib.siteid=ir.siteid and ib.itemnum=ir.itemnum ),0) totalbal,"
					+" coalesce((select sum(invuseline.QUANTITY) from invuseline  where invuseline.USETYPE='ISSUE' and invuseline.itemnum=ir.itemnum and invuseline.fromstoreloc=ir.location and "
					+" invuseline.invusenum in ( select invusenum from invuse where siteid=ir.siteid and status in ( select value from synonymdomain where "
					+" domainid = 'INVUSESTATUS' and maxvalue = 'ENTERED'))),0) totopeninvuseqty"
					+" from invreserve ir where MRNUM='"+resultSet1.getString("womrnum")+"' and location='"+resultSet1.getString("location")+"' and requireddate between trunc((select dm_fromdate from dm_picklist where dm_picklistnum='"+mbo.getString("DM_PICKLISTNUM")+"')) and trunc((select dm_todate+1 from dm_picklist where dm_picklistnum='"+mbo.getString("DM_PICKLISTNUM")+"'))  ) where remnqty>0 and remnqty<=(totalbal-totopeninvuseqty) order by requesteddate asc";
			
			}
			logger.error("***ASH***Sript DM_PLCREATEIVR**query2="+query2); 
			sqfQuery2= new SqlFormat(query2)
			
			resultSet2=dbShortcut2.executeQuery(sqfQuery2.format())
			//logger.error("***ASH***Sript DM_PLCREATEIVR**resultSet2="+resultSet2); 
			i=0;
			while( resultSet2.next())
			{
				//logger.error("***ASH***Sript DM_PLCREATEIVR** beforeLine i="+i); 
				i++;
				//logger.error("***ASH***Sript DM_PLCREATEIVR**Line i="+i); 
				//logger.error("***ASH***Sript DM_PLCREATEIVR**requestnum="+resultSet2.getString("requestnum")); 
				//logger.error("***ASH***Sript DM_PLCREATEIVR**itemnum="+resultSet2.getString("itemnum")); 
				//logger.error("***ASH***Sript DM_PLCREATEIVR**remnqty="+resultSet2.getString("remnqty")); 
				//logger.error("***ASH***Sript DM_PLCREATEIVR**totalbal="+resultSet2.getString("totalbal")); 
				
				
				if(resultSet2.getDouble("remnqty")<=resultSet2.getDouble("totalbal"))
				{
					canDM_PLCREATEIVR=1;
					//logger.error("***ASH***Sript DM_PLCREATEIVR**canDM_PLCREATEIVR="+canDM_PLCREATEIVR); 
					//resultSet2.next()
				}
				if(canDM_PLCREATEIVR==1)
				{
					
					if(isIVRCreated==0)
					{
						//logger.error("***ASH***Sript DM_PLCREATEIVR**isIVRCreated="+isIVRCreated); 
						
			
						invUseMbo=invUseSet.add();
						invUseNum=invUseMbo.getString("INVUSENUM");
						logger.error("***ASH***Sript DM_PLCREATEIVR**IVR Created invusenum="+invUseNum);
						invUseMbo.setValue("FROMSTORELOC",resultSet1.getString("location"),2);
						invUseMbo.setValue("USETYPE","MIXED",2);
						invUseMbo.setValue("DM_PICKLISTNUM",mbo.getString("DM_PICKLISTNUM"),2);
						invUseMbo.setValue("DESCRIPTION","Created for "+resultSet1.getString("rectype")+" - "+resultSet1.getString("womrnum")+" by Pick List "+mbo.getString("DM_PICKLISTNUM"),2);
						isIVRCreated=1;
						
						//Create the IVR Header and return invUseNum value
						
					}
					if(invUseNum!=null)
					{
						//logger.error("***ASH***Sript DM_PLCREATEIVR**invUseNum="+invUseNum); 
						// add reserved lines to INVUSE
						if(invUseMbo!=null)
						{
							if(resultSet2.getDouble("remnqty")<=resultSet2.getDouble("totalbal"))
							{
								invReserveSet=invUseMbo.getMboSet("INVRESERVE");
								invReserveSet.setWhere("requestnum='"+resultSet2.getString("requestnum")+"'")
								//logger.error("***ASH***Sript DM_PLCREATEIVR**IVR Created invReserveSet where="+invReserveSet.getCompleteWhere());
								invReserveSet.reset();
								//logger.error("***ASH***Sript DM_PLCREATEIVR**IVR Created invReserveSet reset() where="+invReserveSet.getCompleteWhere());
								invuseLineSet=invUseMbo.getMboSet("INVUSELINE")
								//logger.error("***ASH***Sript DM_PLCREATEIVR** before addInvUseLineFromInvReserve");
								invuseLineMbo=invuseLineSet.addInvUseLineFromInvReserve(invReserveSet.getMbo(0));
								//logger.error("***ASH***Sript DM_PLCREATEIVR** after addInvUseLineFromInvReserve");
								//logger.error("***ASH***Sript DM_PLCREATEIVR**IVR Created invuseLinenum="+invuseLineMbo.getString("invuseLinenum"));
								//logger.error("***ASH***Sript DM_PLCREATEIVR**IVR Created invuseLineITEMnum="+invuseLineMbo.getString("ITEMNUM"));
								//logger.error("***ASH***Sript DM_PLCREATEIVR**IVR Created invuseLine QTY="+invuseLineMbo.getString("QUANTITY"));
								/*
								if(invuseLineMbo.getString("QUANTITY")<=0)
								{
									//invuseLineMbo.setValue("QUANTITY",resultSet2.getDouble("remnqty"),2);
								}
								invbalSet=invuseLineMbo.getMboSet("DM_INVBALANCES");
								invbalSet.setOrderBy("DM_BALANCEDATE ASC");
								
								invbalMbo=invbalSet.getMbo(0);
								
								if(invbalMbo!=null)
								{
									
									if(invbalMbo.getString("BINNUM")==null)
									{
										invuseLineMbo.setValue("FROMBIN","",11)
									}
									else
									{
										invuseLineMbo.setValue("FROMBIN",invbalMbo.getString("BINNUM"),11)
									}
								}
								*/
							}
						}
					}
					
					
				}
			}
			resultSet2.close();
			if(canDM_PLCREATEIVR==1)
			{
				invUseSet.save();
			}
			//save the IVR 
		}
		resultSet1.close();
		mbo.getThisMboSet().save();
	}
	catch(e)
	{
		logger.error("***ASH***Sript DM_PLCREATEIVR**EXCEPTION="+e);
		//logger.error("***ASH***Sript DM_PLCREATEIVR**EXCEPTION="+e.printStackTrace());
		if(invUseMbo!=null)
		{
			logger.error("***ASH***Sript DM_PLCREATEIVR**EXCEPTION="+invUseMbo.getString("invusenum")+" is deleted");
			invUseMbo.delete(2);
			
		}
	}
	finally
	{
		if(resultSet2!=null)
		{
			resultSet2.close();
		}
		if(resultSet1!=null)
		{
			resultSet1.close();
		}
		dbShortcut.close();
		dbShortcut2.close();
	}
}
else
{
	errorgroup="dm_picklist"
	errorkey="notvalidstatus"
}
//logger.error("***ASH***Sript DM_PLCREATEIVR**END***")