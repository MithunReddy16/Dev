/*
Script: DM_STATUS2CAN
Created By: Ashok
Date: 11-Dec-2024
Req: Change Status to Staged

*/

load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_PICKLIST.STATUSCHANGE**START***")



if(mbo.getString("DM_STATUS").equalsIgnoreCase("ENTERED") || mbo.getString("DM_STATUS").equalsIgnoreCase("STAGED"))
{
	mbo.setValue("DM_STATUS","CAN",2)
}
else
{
	errorgroup="dm_picklist"
	errorkey="notvalidstatus"
}