# -------------------------------------------------------------
# Script: DM_STATUS2STG
# Modified by Mithun
# -------------------------------------------------------------

from psdi.util.logging import MXLoggerFactory


logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("***Mithun***Script DM_PICKLIST.STATUSCHANGE**START***")

dm_status = mbo.getString("DM_STATUS")

def setError(Msg):
    params = [Msg]
    service.error('scriptval', 'scriptvalidationerror', params)





def validateGLAccountError(glcode,invusenum,lineNum):
	'''
    coaSet = mbo.getMboSet("$coa", "CHARTOFACCOUNTS", "glaccount='" + glcode + "' AND active=1")
	if coaSet.isEmpty():
		coaSet.close()
		setError('GL Account is not valid')
    '''
    
    
	if glcode == None or glcode ==""  or  '?' in glcode:
		setError('GL Account is not valid in IU ' + invusenum+ ', line#' + lineNum)

if dm_status is not None and dm_status.lower() == "entered":
    logger.debug("***MithunDM_PICKLIST.STATUSCHANGE****")

    invUseLineSet = mbo.getMboSet("DM_CHKROTITEMSVAL")
    invUseLineSet_po = mbo.getMboSet("DM_CHKROTITEMSVAL_TR")
    invuseLineSetRot= mbo.getMboSet("DM_INVUSEROTATINGITEMS")
    logger.debug("***MithunDM_PICKLIST.STATUSCHANGE****"+str(invuseLineSetRot.count()))
    if invUseLineSet is not None and invUseLineSet.count() > 0:
        errorgroup = "dm_picklist"
        errorkey = "emptylocrotast"

    elif invUseLineSet_po is not None and invUseLineSet_po.count() > 0:
        errorgroup = "dm_picklist"
        errorkey = "emptyrotast"
    elif invuseLineSetRot is not None and invuseLineSetRot.count()>0 :
        logger.debug("***MithunDM_PICKLIST.STATUSCHANGE rot 1****")
        invRotLine = invuseLineSetRot.moveFirst()
        logger.debug("***MithunDM_PICKLIST.STATUSCHANGE rot 2****")
        while invRotLine :
            rotAssetMbo=invRotLine.getMboSet("ROTATINGASSET").getMbo(0)
            if rotAssetMbo is not None :
                assettag=str(rotAssetMbo.getString("DM_ASSET_TAG"))
                logger.debug("***MithunDM_PICKLIST.STATUSCHANGE rotbefore 3****"+assettag)
                if assettag is None or assettag=='' :
                    invuse=invRotLine.getString("INVUSENUM")
                    itemnum=invRotLine.getString("ITEMNUM")
                    logger.debug("***MithunDM_PICKLIST.STATUSCHANGE rot 3****"+itemnum)
                    setError("DM Asset tag is missing for Rotating "+itemnum+", Please remove Invuse "+invuse+" and create with new Picklist with status of WASSETTAG.")
                    
            invRotLine=invuseLineSetRot.moveNext()        
    ## Below lines modified by Mithun 
    allInvUseLineSet = mbo.getMboSet("DM_ALLINVUSELINE")
    if allInvUseLineSet is None or allInvUseLineSet.count() <= 0:
        errorgroup = "dm_picklist"
        errorkey = "genivdoc"
    
    else:
		for i in range(allInvUseLineSet.count()):
			invuseLine = allInvUseLineSet.getMbo(i)
			lineNum = str(invuseLine.getInt("INVUSELINENUM"))

			debitGL = invuseLine.getString("GLDEBITACCT")
			if debitGL:
				validateGLAccountError(debitGL,invuseLine.getString("INVUSENUM"),lineNum)

			creditGL = invuseLine.getString("GLCREDITACCT")
			if creditGL:
				validateGLAccountError(creditGL,invuseLine.getString("INVUSENUM"),lineNum)

		mbo.setValue("DM_STATUS", "STAGED", 2)

else:
    errorgroup = "dm_picklist"
    errorkey = "notvalidstatus"