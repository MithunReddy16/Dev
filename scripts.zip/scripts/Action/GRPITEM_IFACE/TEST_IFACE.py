from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.custom")
logger.debug("TEST_IFACE- AMIR")
mbo.setFieldFlag ( "DM_IFACESTATUS" , MboConstants.NOSETVALUE | MboConstants.NOOVERWRITE , False)
mbo.setValue('DM_IFACESTATUS','Amir')