#service.error('A',mbo.getString('ASSETNUM'))
from com.ibm.tivoli.maximo.script import ScriptService




userInput = service.yncuserinput()

if userInput == ScriptService.YNC_NULL:
    service.yncerror('dm_custom', 'userinput',["Are you sure you want to remove the asset from the list"])
elif userInput == ScriptService.YNC_YES:
    mbo.setValue('EXCLUDED',True)
    session = service.webclientsession()
    App=session.getCurrentApp()
    #App.SAVE()
    
    App.getAppBean().fireDataChangedEvent()
    #App.getDataBean("dm_disposalline_table_ex").refreshTable()
    #App.getDataBean("dm_disposalline_table").refreshTable()
    App.getAppBean().save()