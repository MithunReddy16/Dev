session=service.webclientsession()
databean=session.getDataBean("reason_table")
if databean: 
    reasonSet=databean.getMboSet()

    reasonList=[]
    selectedRecords=reasonSet.getSelection()
    if selectedRecords:
        iterator=selectedRecords.iterator()
        
        while iterator.hasNext():
            reasonMbo=iterator.next()
            reasonList.append(reasonMbo.getString("value"))
        #service.error('A',",".join(reasonList))
        DisposalLine = reasonMbo.getOwner()
        JustMboValue = DisposalLine.getMboValue('JUSTIFICATION')
        if not JustMboValue.isReadOnly():
            DisposalLine.setValue("JUSTIFICATION",", ".join(reasonList),11L)
        else:
            service.error('scriptval','scriptvalidationerror',['Field is read only'])
    service.closeDialog()