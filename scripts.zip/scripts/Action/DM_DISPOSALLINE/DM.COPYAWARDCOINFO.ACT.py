###################################################
# Script = DM.COPYAWARDCOINFO.ACT
# Description = Used to copy awarded company information across all lines
# Author : Amir Anwar
# Version 0 - 25 May 2024 - Intial Version
#################################################

def setError(Msg):
		#global errorkey,errorgroup,params
		#errorkey='scriptvalidationerror'
		#errorgroup='scriptval'
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)


Disposal = mbo.getOwner()
if Disposal:
    if Disposal.getString('Status') in ('AMD-APPR','WRET','WAUCCO'):
        DispsoalLineSet = Disposal.getMboSet('DM_DISPOSALLINE')
        DisposalLine = DispsoalLineSet.moveFirst()
        while DisposalLine:
            if DisposalLine.getInt('DISPOSALLINENUM') == mbo.getInt('DISPOSALLINENUM'):
                DisposalLine = DispsoalLineSet.moveNext()    
                continue
            DisposalLine.setValue('AWARDCOMPANY',mbo.getString('AWARDCOMPANY'))
            DisposalLine.setValue('AWARDCOADDRESS',mbo.getString('AWARDCOADDRESS'))
            DisposalLine.setValue('AWARDCOCONTACT',mbo.getString('AWARDCOCONTACT'))
            DisposalLine.setValue('AWARDCOEMAIL',mbo.getString('AWARDCOEMAIL'))
            DisposalLine.setValue('AWARDCOPHONE',mbo.getString('AWARDCOPHONE'))
            DisposalLine.setValue('AWARDPRODATE',mbo.getString('AWARDPRODATE'))
            DisposalLine.setValue('DELIVERYMETHOD',mbo.getString('DELIVERYMETHOD'))
            DisposalLine = DispsoalLineSet.moveNext()
    else:
        setError('Not a Valid Status')