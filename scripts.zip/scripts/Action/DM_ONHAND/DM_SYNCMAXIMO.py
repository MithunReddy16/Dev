# =============================================================
# SCRIPT  : DM_SYNC_MAXIMO_ONHAND
# OBJECT  : DM_ONHAND
# LAUNCH  : Action Launch Point
# AUTHOR  : Mithun Kumar
# =============================================================

from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("******Mithun Script execution started for DM_OHDELETE *******")

def setError(Msg):
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)

def toFloat(val, fieldName):
    try:
        return float(str(val).strip())
    except (ValueError, TypeError):
        logger.debug("WARNING: Could not parse " + fieldName + " value=" + str(val) + " | Defaulting to 0.0")
        return 0.0

def safeStr(val):
    if val is None:
        return ""
    return str(val).strip()


# main function 
def syncMaximoOnhand():

    onhandnum = mbo.getString("ONHANDNUM")
    storeroom = mbo.getString("STOREROOM")
    userInfo  = mbo.getUserInfo()
    logger.debug("I****** Sync Maximo Onhand Started *******")
    logger.debug("***** ONHANDNUM=" + str(onhandnum) + " | STOREROOM=" + str(storeroom))

    if not storeroom:
        setError("ERROR: STOREROOM is empty.")        

    if not  mbo.getBoolean("SYNCGRP")  :
        setError("Sync Data From GRP first, then Sync Maximo Data.")
    if  mbo.getBoolean("SYNCMAXIMO")  :
        setError("Already Maximo Inventory Data is Synced.")
        
    invBalSet = None
    ohLinesSet = None

    try:
        invBalSet = MXServer.getMXServer().getMboSet("INVBALANCES", userInfo)
        invBalSet.setWhere("LOCATION='" + storeroom + "'")
        invBalSet.reset()
        logger.debug("********** INVBALANCES fetched for STOREROOM=" + storeroom)
        
        ohLinesSet = MXServer.getMXServer().getMboSet("DM_ONHANDLINES", userInfo)
        ohLinesSet.setWhere("STOREROOM='" + storeroom + "' AND ONHANDNUM='" + onhandnum + "'")
        ohLinesSet.reset()

        existingMap = {}
        ohLineMbo = ohLinesSet.moveFirst()
        while ohLineMbo is not None:
            ex_item = safeStr(ohLineMbo.getString("ITEMNUM"))
            ex_bin  = safeStr(ohLineMbo.getString("GRPBINNUM"))
            ex_lot  = safeStr(ohLineMbo.getString("GRPLOTNUM"))

            key = ex_item + "|" + ex_bin + "|" + ex_lot
            existingMap[key] = ohLineMbo

            logger.debug("DEBUG: Existing line loaded | KEY=" + key)
            ohLineMbo = ohLinesSet.moveNext()

        logger.debug("*********** Total existing DM_ONHANDLINES rows=" + str(len(existingMap)))


        insertCount = 0
        updateCount = 0

        invRow = invBalSet.moveFirst()
        while invRow is not None:

            mx_item= safeStr(invRow.getString("ITEMNUM"))
            mx_bin = safeStr(invRow.getString("BINNUM"))
            mx_lot= safeStr(invRow.getString("LOTNUM"))
            mx_bal= toFloat(invRow.getString("CURBAL"), "CURBAL")

            matchKey = mx_item + "|" + mx_bin + "|" + mx_lot

            logger.debug("*********** Processing INVBALANCES | KEY=" + matchKey + " | CURBAL=" + str(mx_bal))

            if matchKey in existingMap:
                existingLine = existingMap[matchKey]
                existingLine.setValue("MAXIMOBINNUM", mx_bin, MboConstants.NOACCESSCHECK)
                existingLine.setValue("MAXIMOLOTNUM", mx_lot, MboConstants.NOACCESSCHECK)
                existingLine.setValue("MAXIMOBAL",    mx_bal, MboConstants.NOACCESSCHECK)

                updateCount += 1
                logger.debug("********UPDATE | KEY=" + matchKey + " | MAXIMOBAL=" + str(mx_bal))

            else:

                newLine = ohLinesSet.add()
                newLine.setValue("ONHANDNUM",  onhandnum, MboConstants.NOACCESSCHECK)
                newLine.setValue("STOREROOM", storeroom, MboConstants.NOACCESSCHECK)
                newLine.setValue("ITEMNUM",  mx_item,   MboConstants.NOACCESSCHECK)
                newLine.setValue("MAXIMOBINNUM", mx_bin, MboConstants.NOACCESSCHECK)
                newLine.setValue("MAXIMOLOTNUM", mx_lot, MboConstants.NOACCESSCHECK)
                newLine.setValue("MAXIMOBAL",  mx_bal, MboConstants.NOACCESSCHECK)
                newLine.setValue("RESULT", "ONLY MAXIMO", MboConstants.NOACCESSCHECK)

                insertCount += 1
                logger.debug("*********INSERT | KEY=" + matchKey + " | MAXIMOBAL=" + str(mx_bal))

            invRow = invBalSet.moveNext()

        mbo.setValue("SYNCMAXIMO",1)
        ohLinesSet.save()
        mbo.getThisMboSet().save()
        #mbo.getThisMboSet().reset()
        logger.debug("INFO: ===== Sync Complete | INSERTS=" + str(insertCount) + " | UPDATES=" + str(updateCount) + " =====")

    finally:

        if invBalSet is not None:
            try:
                invBalSet.close()
            except Exception as ce:
                logger.debug("******WARNING: Could not close invBalSet | " + str(ce))

        if ohLinesSet is not None:
            try:
                ohLinesSet.close()
            except Exception as ce:
                logger.debug("*******WARNING: Could not close ohLinesSet | " + str(ce))


# Code start here 
try:
    syncMaximoOnhand()
except Exception as e:
    logger.debug("ERROR: Sync failed | " + str(e))
    raise