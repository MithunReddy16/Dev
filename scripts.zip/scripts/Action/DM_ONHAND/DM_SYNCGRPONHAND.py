# =============================================================================
# Script: DM_SYNCGRPONHAND
# Object: DM_ONHAND
# Author : Mithun 

# =============================================================================

from psdi.server import MXServer
from psdi.mbo import MboConstants
from java.io import ByteArrayInputStream, StringReader, BufferedReader, InputStreamReader
from java.net import URL, HttpURLConnection
from java.lang import String, StringBuilder
from javax.xml.parsers import SAXParserFactory
from org.xml.sax.helpers import DefaultHandler
from org.xml.sax import InputSource
from psdi.mbo import SqlFormat
from psdi.util.logging import MXLoggerFactory
from psdi.util import MXFormat
from psdi.util import MXApplicationException
import time

logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("******Mithun Script execution started for DM_SYNCGRPONHAND *******")
session=service.webclientsession()
mainBean = session.getDataBean("mainrecord") 

def setError(Msg):
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)


if mbo.getBoolean("SYNCGRP")  :
    setError("Already GRP Data Synced.")
    
 
ENDPOINT_NAME = "EP_DMGRP_ONHAND"
BATCH_SIZE = 500  
LOG_PREFIX = "DM_SYNCGRPDATA"

mainMbo = mbo
storeroom = mainMbo.getString("STOREROOM")
siteid = mainMbo.getString("SITEID")
storeroom=mainMbo.getString("STOREROOM")
onhandnum = mainMbo.getString("ONHANDNUM")  

if not storeroom:
    setError('Please select storeroom.')

logger.debug(LOG_PREFIX + ": *************Starting sync for storeroom=" + storeroom)
startTime = time.time()


# request payload 

soapRequest = (
    '<?xml version="1.0" encoding="UTF-8"?>'
    '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" '
    'xmlns:grp="http://grp.scm.eReqInt.dsg.gov.ae">'
    '<soapenv:Header/>'
    '<soapenv:Body>'
    '<grp:getOnhandByPage>'
    '<grp:pOrganizationCode>' + storeroom + '</grp:pOrganizationCode>'
    '<grp:lowerBound>1</grp:lowerBound>'
    '<grp:higherBound>10000000</grp:higherBound>'
    '</grp:getOnhandByPage>'
    '</soapenv:Body>'
    '</soapenv:Envelope>'
)


def callSoapService(endpointName, soapPayload):

    epUrl = "https://devapigw-vip.dm.ae/ws/SDG-GRP-DMReqInterface/1.0"

    service.log_info(LOG_PREFIX + ": Calling URL=" + epUrl)
    url = URL(epUrl)
    conn = url.openConnection()
    conn.setRequestMethod("POST")
    conn.setRequestProperty("Content-Type", "text/xml;charset=UTF-8")
    conn.setRequestProperty("x-Gateway-APIKey", "c2036d4a-e480-491e-8b07-7a830c98ee0d")
    conn.setDoOutput(True)
    conn.setConnectTimeout(30000)
    conn.setReadTimeout(300000)   
    os = conn.getOutputStream()
    os.write(String(soapPayload).getBytes("UTF-8"))
    os.flush()
    os.close()

    # Check response code
    responseCode = conn.getResponseCode()
    logger.debug(LOG_PREFIX + ": HTTP Response Code=" + str(responseCode))

    if responseCode != 200:
        errStream = conn.getErrorStream()
        if errStream:
            errReader = BufferedReader(InputStreamReader(errStream, "UTF-8"))
            errMsg = StringBuilder()
            line = errReader.readLine()
            while line:
                errMsg.append(line)
                line = errReader.readLine()
            errReader.close()
            service.log_error(LOG_PREFIX + ": Error response=" + errMsg.toString()[:500])
        raise Exception("SOAP call failed with HTTP " + str(responseCode))

    # Read response as string
    reader = BufferedReader(InputStreamReader(conn.getInputStream(), "UTF-8"))
    response = StringBuilder()
    line = reader.readLine()
    while line:
        response.append(line)
        line = reader.readLine()
    reader.close()
    conn.disconnect()

    return response.toString()


responseStr = callSoapService(ENDPOINT_NAME, soapRequest)
logger.debug(LOG_PREFIX + ": Response received, length=" + str(len(responseStr)))


class OnhandSAXHandler(DefaultHandler):

    def __init__(self):
        DefaultHandler.__init__(self)
        self.records = []           
        self.currentRecord = None
        self.currentTag = ""
        self.currentText = StringBuilder()
        self.inRecord = False

    def startElement(self, uri, localName, qName, attrs):
        
        tag = qName
        if ":" in tag:
            tag = tag.split(":")[1]

        if tag == "OnhandByPageInfo":
            self.inRecord = True
            self.currentRecord = {}
        elif self.inRecord:
            self.currentTag = tag
            self.currentText = StringBuilder()

    def characters(self, ch, start, length):
        if self.inRecord and self.currentTag:
            self.currentText.append(String(ch, start, length))

    def endElement(self, uri, localName, qName):
        tag = qName
        if ":" in tag:
            tag = tag.split(":")[1]

        if tag == "OnhandByPageInfo" and self.currentRecord is not None:
            self.records.append(self.currentRecord)
            self.currentRecord = None
            self.inRecord = False
        elif self.inRecord and self.currentTag:
            value = self.currentText.toString().strip()
            self.currentRecord[self.currentTag] = value
            self.currentTag = ""


# Parse the response
saxHandler = OnhandSAXHandler()
saxFactory = SAXParserFactory.newInstance()
saxFactory.setNamespaceAware(False)  # Simpler parsing without NS
saxParser = saxFactory.newSAXParser()
inputSource = InputSource(StringReader(responseStr))
saxParser.parse(inputSource, saxHandler)

records = saxHandler.records
totalRecords = len(records)
logger.debug(LOG_PREFIX + ": Parsed " + str(totalRecords) + " records from response")


linesSet = mainMbo.getMboSet("DM_ONHANDLINES")  
'''
existingCount = linesSet.count()
if existingCount > 0:
    logger.debug(LOG_PREFIX + ": Deleting " + str(existingCount) + " existing lines")
    linesSet.deleteAll()
    mainMbo.getThisMboSet().save()
    '''


insertCount = 0
errorCount = 0

for i in range(totalRecords):
    rec = records[i]

    try:
        newLine = linesSet.add(MboConstants.NOACCESSCHECK)        
        itemnum = rec.get("item", "")
        grpSubinv = rec.get("subinventoryCode", "")
        onhand = rec.get("onhand", "0")
        uom = rec.get("primaryUnitOfMeasure", "")
        locater = rec.get("locater", "")
        lotNumber = rec.get("lotNumber", "")
        expirationDate = rec.get("expirationDate", "")

        if locater in ( "--" ):
            locater = ""
        elif locater:
            segments = locater.split("-")
            if len(segments) == 3:
                first_segment = segments[0]
                if len(first_segment) >= 2:
                    new_first = first_segment[0]   
                    new_second = first_segment[1:] 
                    locater = new_first + "-" + new_second + "-" + segments[1] + "-" + segments[2]

        if lotNumber in ("", "nil", "null", "true"):
            lotNumber = ""

        if expirationDate in ("", "nil", "null", "true"):
            expirationDate = ""
        
        newLine.setValue("ONHANDNUM", onhandnum, MboConstants.NOACCESSCHECK)
        newLine.setValue("ITEMNUM", itemnum, MboConstants.NOACCESSCHECK)
        newLine.setValue("GRPSUBINVENTORY", grpSubinv, MboConstants.NOACCESSCHECK)
        newLine.setValue("SITEID", siteid, MboConstants.NOACCESSCHECK)    
        newLine.setValue("STOREROOM", storeroom, MboConstants.NOACCESSCHECK)
        newLine.setValue("GRPBAL", float(onhand), MboConstants.NOACCESSCHECK)
        newLine.setValue("RESULT", "ONLY GRP", MboConstants.NOACCESSCHECK)
        if locater:
            newLine.setValue("GRPBINNUM", locater, MboConstants.NOACCESSCHECK)

        if lotNumber:
            newLine.setValue("GRPLOTNUM", lotNumber, MboConstants.NOACCESSCHECK)

        if expirationDate:                        
            dateVal = MXFormat.stringToDate(expirationDate)
            newLine.setValue("GRPLOTEXPIR", dateVal, MboConstants.NOACCESSCHECK)
            #newLine.setValue("GRPLOTEXPIR", expirationDate, MboConstants.NOACCESSCHECK)

        insertCount += 1

    except Exception, e:
        errorCount += 1
        service.log_error("***** Error on record " + str(i) + ": " + str(e))


mainMbo.setValue("SYNCGRP",1)
mainBean.SAVE()

#mainMbo.getThisMboSet().save()
#mainMbo.getThisMboSet().reset()

elapsed = round(time.time() - startTime, 2)
logger.debug(    LOG_PREFIX + ": **********COMPLETE - "+ str(insertCount) + " inserted, "+ str(errorCount) + " errors, " + str(elapsed) + " seconds")