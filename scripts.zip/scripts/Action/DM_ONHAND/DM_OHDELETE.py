# lines Modified by Mithun 
from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory
from psdi.app.inventory import InvBalancesRemote
from com.ibm.tivoli.maximo.script import ScriptService

logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("******Mithun Script execution started for DM_OHDELETE *******")

if app == "DM_ONHAND":
    if launchPoint =='DM_OHDELETE':
        userInput = service.yncuserinput()
        if userInput == ScriptService.YNC_NULL:
            service.yncerror('dm_custom', 'userinput',["Are you sure you want to delete Synced Lines ?"])
        elif userInput == ScriptService.YNC_YES:
            onhandLinesSet= mbo.getMboSet("DM_ONHANDLINES")
            lineMbo=onhandLinesSet.moveFirst()
            if  lineMbo :
                onhandLinesSet.deleteAll()
                mbo.setValue("SYNCGRP",0)
                mbo.setValue("SYNCMAXIMO",0)
                onhandLinesSet.save()