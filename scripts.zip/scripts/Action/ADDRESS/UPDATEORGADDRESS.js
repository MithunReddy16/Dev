/*
#-----------------------------------------------------------------------------------------
# Script Name : DMUPDATESTOREGRPID
# Description : Update Store GRP ID
#
# Event              : Action Script 
# Author             : Pramod Kumar
# Version            : 1.0
# Date               : 10-Oct-2025
#-----------------------------------------------------------------------------------------
*/

load("nashorn:mozilla_compat.js");
importPackage(Packages.psdi.util.logging);
importPackage(Packages.psdi.server);
importPackage(Packages.psdi.mbo);
var mxServer = MXServer.getMXServer();	
HashMap = Java.type('java.util.HashMap');

//service.error("", "launchPoint22:\n"+launchPoint);
 
var library = new HashMap();

var extApiMboSet = MXServer.getMXServer().getMboSet("DM_EXT_API_DETAIL", mbo.getUserInfo());
	extApiMboSet.setWhere("OPERATION='"+launchPoint+"'" );
	extApiMboSet.reset();
	
	if (extApiMboSet.count() > 0) {
		extApiMbo = extApiMboSet.getMbo(0);
	
		library.put("mbo",extApiMbo)
		library.put("SourceObject","ORGANIZATION")
		service.invokeScript("DMADHOCAPICALL",library)
		
	}