from psdi.server import MXServer

userChoice = service.yncuserinput()
if (userChoice == service.YNC_NULL):
    service.yncerror("system", "maxCache")
elif (userChoice == service.YNC_YES):
	mxserver = MXServer.getMXServer()
	cacheNames = mxserver.getMaximoCacheNames()

	mxserver.reloadMaximoCache("MAXPROP", True )
	mxserver.reloadMaximoCache("MAXIMODD", True )
	mxserver.reloadMaximoCache("MAXIMOMLDD", True )
	mxserver.reloadMaximoCache("MAXMESSAGECACHE", True )
	mxserver.reloadMaximoCache("MAXVARS", True )
	
	cacheNames.remove("ADMINMODE")
	cacheNames.remove("MAXPROP")
	cacheNames.remove("MAXIMODD")
	cacheNames.remove("MAXIMOMLDD")
	cacheNames.remove("MAXMESSAGECACHE")
	cacheNames.remove("MAXVARS")

	i = cacheNames.iterator()
	while (i.hasNext()):
		cacheName = i.next()
		mxserver.reloadMaximoCache(cacheName, True )