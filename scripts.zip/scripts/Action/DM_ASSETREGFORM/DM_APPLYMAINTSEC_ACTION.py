#------------------------------------------------------------------------

#Script Name :DM_APPLYMAINTSEC_ACTION
#Description :script to update maintenance section field for all the assets in the form lines.
#Comment     :Used in Aseet Register Form Application
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          20-Sept-2025         Initiate version.

#------------------------------------------------------------------------

#check if the maintenance section is null in the header
if not mbo.isNull("MAINTSECTION"):
    session=service.webclientsession()
    mainBean = session.getDataBean("mainrecord") 
    maintSec = mbo.getString("MAINTSECTION")
    #get the assets
    assetMboSet = mbo.getMboSet("ASSETFORM")
    assetMbo = assetMboSet.moveFirst()
    while assetMbo:
        #update the maintenance section for each asset
        assetMbo.setValue("DM_MAINTSEC",maintSec)
        assetMbo = assetMboSet.moveNext()
    #save the assets and refresh the screen
    assetMboSet.save()    
    mainBean.SAVE()