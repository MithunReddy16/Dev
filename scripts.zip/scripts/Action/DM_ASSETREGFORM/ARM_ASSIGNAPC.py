# Author Mithun

service.log_debug("***********Start:" + scriptName+"**************** ")

from psdi.mbo import SqlFormat
from psdi.server import MXServer

def getMboAssignments(mbo, personid):
  sqf = SqlFormat(mbo, "ownertable=:1 and wfassignment.ownerid=:2 and assigncode=:3 and assignstatus='ACTIVE'")
  sqf.setObject(1, "WFASSIGNMENT", "OWNERTABLE", mbo.getName())
  sqf.setLong(2, mbo.getUniqueIDValue())
  sqf.setObject(3, "WFASSIGNMENT", "ASSIGNCODE", personid)
  assignSet = mbo.getMboSet("$CURMBOASGN", "WFASSIGNMENT", sqf.format())
  assignSet.reset()
  return assignSet


  

def setError(Msg):
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)

service.log_debug("***********Start:" + scriptName+"**************** ")

logperson=mbo.getUserInfo().getPersonId()
if logperson :
    if mbo.isNull("APCOWNER") :
        mbo.setValue("APCOWNER",logperson)

        session = service.webclientsession()
        appBean=session.getCurrentApp().getAppBean()
        appBean.save()
        """"
        appBean.refreshTable()
        appBean.fireDataChangedEvent()
        #App=session.getCurrentApp()
        #mainBean = session.getDataBean("mainrecord")
        #mainBean.save()
        #mainBean.fireDataChangedEvent()
        #App.getAppBean().fireDataChangedEvent()
        wfSrv = MXServer.getMXServer().lookup('WORKFLOW')
        wfAsSet = getMboAssignments(mbo, mbo.getUserInfo().getPersonId())
        if not wfAsSet.isEmpty():
          wfAs = wfAsSet.getMbo(0)
          wfSrv.completeAssignment(wfAs, "Approved by script", True)
        #mainBean = session.getDataBean("mainrecord")
        #mainBean.save()
        appBean=session.getCurrentApp().getAppBean()
        appBean.save()
        appBean.refreshTable()
        #appBean.fireDataChangedEvent()
        
        #mainBean.fireDataChangedEvent()