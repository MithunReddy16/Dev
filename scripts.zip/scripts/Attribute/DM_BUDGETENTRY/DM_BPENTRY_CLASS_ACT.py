#------------------------------------------------------------------------

#Script Name :DM_BPENTRY_CLASS_ACT
#Description :Budget Entry Category/Classification Average Cost Action
#Comment     :Used in Budget Plan Application.  
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-Jan-2026         Initiate version.

#------------------------------------------------------------------------

# Calculate the asset average cost based on category
def calculateAvg(classid):
    # get all assets which have same category
    
    assetByCateSet = mbo.getMboSet("DM_ASSET_DM_MINORCATEGORY_SS","ASSET","SITEID='DM' and CLASSSTRUCTUREID ='"+classid+"' and dm_department=:department")
    assetByCateSet.reset()
    assetCount = assetByCateSet.count()
    mbo.setValue("assetcount",assetCount)
    assetByCateMbo = assetByCateSet.moveFirst()
    costList=[]
    while assetByCateMbo: 
        if not assetByCateMbo.isNull("DM_COST") and assetByCateMbo.getDouble("DM_COST") > 0:
            costList.append(assetByCateMbo.getDouble("DM_COST"))
        assetByCateMbo = assetByCateSet.moveNext()
        
    if len(costList) == 0:
        return 0
    else:
        return iterative_average(costList)    

# formula the asset average cost based on category
def iterative_average(valuesList):
    def calculate_average(lst):
        return sum(lst) / len(lst)
    
    valuesList = sorted(valuesList)
    average1 = calculate_average(valuesList)
    
    while True:
        # Exclude the lowest and highest valuesList
        valuesList = valuesList[1:-1]
        if len(valuesList) <2:
            return average1
        average2 = calculate_average(valuesList)
        # Compare the two averages
        if abs(average1 - average2) / average1 < 0.3:
            return average1
          # Update average1 for the next iteration
        average1 = average2
        
    
#####----Main ------------------
if  launchPoint =="DM_BPENTRY_CLASS_ACT":
    if not mbo.isNull("CLASSSTRUCTUREID"):
        if not mbo.isNull("CLASSSTRUCTURE.DM_CENTRALDEPT.DESCRIPTION"):
            centDept = mbo.getString("CLASSSTRUCTURE.DM_CENTRALDEPT.DESCRIPTION")
            mbo.setValue("CENTRALDEPT",centDept)
        else:
            mbo.setValueNull("CENTRALDEPT")
            
        avgCost = calculateAvg(mbo.getString("CLASSSTRUCTUREID")) 
        mbo.setValue("AVERAGECOST",avgCost)
    else:
        mbo.setValueNull("CENTRALDEPT")
        mbo.setValueNull("AVERAGECOST")