if mbo.getString("REQUESTTYPE") == "NEW":
    mbo.setValueNull("ASSETNUM")
    mbo.setValueNull("QUANTITY")
    
elif mbo.getString("REQUESTTYPE") == "REPLACEMENT":  
    mbo.setValueNull("CLASSSTRUCTUREID")
    mbo.setValue("QUANTITY",1,11l)
    mbo.setFieldFlag("QUANTITY",7l,True)