#------------------------------------------------------------------------

#Script Name :DM_BUDGETENTRY_ESTIMATEDCOST
#Description :Calculate estimated all budget line cost script.
#Comment     :Used in Budget Plan Application.  muti launch points
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-Jan-2026         Initiate version.

#------------------------------------------------------------------------


unitCost = mbo.getDouble("ESTIMATEDUNITCOST")
maintCost = mbo.getDouble("MAINTENANCEUNITCOST")
optCost = mbo.getDouble("OPERATINGUNITCOST")

# current budget year
qty = mbo.getDouble("QUANTITY")
mbo.setValue("ESTIMATEDCOST",unitCost*qty)
mbo.setValue("EXPMAINTCOST",maintCost*qty)
mbo.setValue("EXPOPERCOST",optCost*qty)
# next year
qty = mbo.getDouble("QTYNEXTYEAR")
mbo.setValue("ESTIMATEDCOST1Y",unitCost*qty)
mbo.setValue("EXPMAINTCOST1Y",maintCost*qty)
mbo.setValue("EXPOPERCOST1Y",optCost*qty)
# next 2 years
qty = mbo.getDouble("QTYNEXT2YEAR")
mbo.setValue("ESTIMATEDCOST2Y",unitCost*qty)
mbo.setValue("EXPMAINTCOST2Y",maintCost*qty)
mbo.setValue("EXPOPERCOST2Y",optCost*qty)