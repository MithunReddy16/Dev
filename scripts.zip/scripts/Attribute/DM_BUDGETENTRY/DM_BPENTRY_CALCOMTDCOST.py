qty = mbo.getDouble("COMMITTEDQTY")
unitCost = mbo.getDouble("COMMITTEDUNITCOST")
mbo.setValue("COMMITTEDCOST",unitCost*qty)

abvQty = mbo.getDouble("ABVCEILINGQTY")
mbo.setValue("ABVCEILINGAMOUNT",unitCost*abvQty)