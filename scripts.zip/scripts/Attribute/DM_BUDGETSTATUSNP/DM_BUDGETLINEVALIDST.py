#DM_BUDGETLINEVALIDST
from psdi.mbo import SqlFormat
from psdi.server import MXServer

###1
#sqlf = SqlFormat(MXServer.getMXServer().getSystemUserInfo(),"domainid = 'DM_BUDGETLINEST' and value in ('CAN') ");
#listMboSet = mbo.getMboSet("$alndomain", "ALNDOMAIN", sqlf.format());

###2
relationObject = "ALNDOMAIN";
CustomWhere = "domainid = 'DM_BUDGETLINEST' "

BudgetLineMbo = mbo.getOwner()
BudgetLineStatus = BudgetLineMbo.getString('STATUS')
BudgetMbo = BudgetLineMbo.getOwner()
BudgetStatus = BudgetMbo.getString('STATUS')

if BudgetLineStatus == 'DRAFT' :
	CustomWhere += " and value ='CAN' "
elif BudgetLineStatus == 'PENDING' :
	
	CustomWhere += " and value  in ('CAN' "
	if not BudgetLineMbo.getBoolean('DM_CENTRAL'):
		CustomWhere += ",'D-APPR')"
	else:
		CustomWhere += ",'REVIEWED')"
	
elif BudgetLineStatus == 'REVIEWED' :
	CustomWhere += " and value  in ('CAN' "
	if BudgetStatus == 'PENDING':
		CustomWhere += ",'PENDING'"
		if not BudgetLineMbo.getBoolean('DM_CENTRAL'):
			CustomWhere += ",'D-APPR')"
		else:
			CustomWhere += ")"
	elif BudgetStatus == 'REVIEWED':
		CustomWhere += ",'D-APPR') "


elif BudgetLineStatus == 'D-APPR' :	
	if BudgetStatus == 'PENDING':
		CustomWhere += " and value  in ('CAN' ,'PENDING')"
	elif BudgetStatus =='REVIEWED':
		if BudgetLineMbo.getBoolean('DM_CENTRAL'):
			CustomWhere += "and value  in  ('CAN') "
		else:
			CustomWhere += "and 1=2 "
	
	elif BudgetStatus =='D-APPR':
		CustomWhere += " and value  in ('CAN' ,'APPR')"
	
listWhere = CustomWhere




###3
#domainid='DM_BUDGETLINEST'

srcKeys = ["value"]
targetKeys = ["status"]
relationWhere = "domainid = 'DM_BUDGETLINEST' and value =:status";