if mbo.isNull("MAINACTIVITY"):
    mbo.setFieldFlag("SUBACTIVITY",7l,True)