if mbo.isNull("MAINACTIVITY"):
    mbo.setValueNull("SUBACTIVITY")
    mbo.setFieldFlag("SUBACTIVITY",7l,True)
    mbo.setValueNull("assetnum")
    mbo.setFieldFlag("assetnum",7l,True)
else:
    mbo.setFieldFlag("SUBACTIVITY",7l,False)
    mbo.setValueNull("SUBACTIVITY")
    mbo.setFieldFlag("assetnum",7l,False)
    mbo.setValueNull("assetnum")