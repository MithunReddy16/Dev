# check if the investment plan for the department has been created before start creating Opportunities.
from java.util import Calendar
from psdi.util import MXApplicationException

investPlanSet = mbo.getMboSet("DM_INVESTPLAN")

if investPlanSet.count() == 0:
    service.error("dm_invst","dm_noinvstplan",[mbo.getString("YEAR")])


# Get current year
currentYear = Calendar.getInstance().get(Calendar.YEAR)
# Get value entered in field
yearValue = mbo.getInt("YEAR")
# Validation
if yearValue < currentYear:
    service.error("dm_invst","dm_invalidyear")