#DM.FLD.DISPOSALLINE.CALPRICE

appl = mbo.getThisMboSet().getParentApp()
DisposalMbo = mbo.getOwner()
if appl =='DM_DISPOSAL' and DisposalMbo.getString('DISPOSALTYPE').upper() == 'AUCTION':
	if not mbo.isNull('ASSETNUM'):
		AssetMbo = mbo.getMboSet('ASSET').moveFirst()
		if AssetMbo:
			NBV = 0.0 if AssetMbo.isNull('DM_CURNTVAL') else AssetMbo.getFloat('DM_CURNTVAL')
			CurrentCost = 0.0 if AssetMbo.isNull('DM_COST') else AssetMbo.getFloat('DM_COST')
			if NBV == 0.00 or NBV < CurrentCost * 0.1 :
				mbo.setValue('CALPRICE', CurrentCost * 0.1, 11L)
			else:
				mbo.setValue('CALPRICE', NBV,11L)