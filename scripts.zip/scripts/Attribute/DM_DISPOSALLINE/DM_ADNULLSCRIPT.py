from psdi.mbo import MboConstants

if mbo.getString("decision")  in ('Refurbishment','Upgrade'):
    
      mbo.setValueNull("DISPOSALMETHOD", MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)