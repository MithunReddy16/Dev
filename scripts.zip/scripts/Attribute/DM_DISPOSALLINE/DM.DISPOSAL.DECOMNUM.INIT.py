AppName=  mbo.getThisMboSet().getParentApp()
#mbovalue.setValue('REFSOURCELINES.DISPOSALNUM')

if AppName =='DM_DISPOSAL':
    mbovalue.setValue(mbo.getString('REFSOURCELINES.DISPOSALNUM'),11L)