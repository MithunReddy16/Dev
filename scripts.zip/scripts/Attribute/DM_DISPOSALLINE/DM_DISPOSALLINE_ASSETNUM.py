##############################################
# Script = DM_DISPOSALLINE_ASSETNUM
# Description : Valide Asset number on Disposal Line, Get valid asset list and Set description field
# Author Amir
# Version 1 - GoLive Date
# Version 2 - Fixes getassetlist change where condition
##############################################
from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.mbo import MboSet
from psdi.mbo import Mbo

owner = mbo.getOwner()
Dstatus=owner.getString("Status")
Dsiteid= mbo.getString("Siteid")
Dorgid= mbo.getString("Orgid")
Dasset= mbo.getString("Assetnum")
Ddept=owner.getString("dm_department")

# check if the current user belong to Assets and Property Management Department /DEP 
orgSet = mbo.getMboSet("DM_DM_ORGHIERARCHY_ZZ","DM_ORGHIERARCHY","UNITID ='"+Ddept+"' and ABBRIVIATION= 'APM' ")
orgSet.reset()
isAPM = False
if orgSet.getMbo(0):
    isAPM = True


def setError(Msg):
    params=[Msg]
    service.error('scriptval','scriptvalidationerror',params)



if launchPoint == 'DISPOSAL_ASSETNUM':    
    if owner.getString('INTERNALTYPE') == 'Decommission':
         #listWhere = " SITEID=:SITEID  and dm_department='"+Ddept+"' AND STATUS NOT IN (SELECT VALUE FROM synonymdomain WHERE DOMAINID='LOCASSETSTATUS' AND MAXVALUE  = 'DECOMMISSIONED') AND STATUS NOT LIKE 'RF%'  and  assetnum not in (select a.assetnum from DM_DISPOSALLINE a,DM_DISPOSAL b where a.disposalnum=b.disposalnum and a.assetnum is not null and b.status not in ('CAN')) and assetnum in (select assetnum from asset where DM_ASSET_TAG is not null) "
        relationObject = "ASSET"
        #--Start 07-08-2025 Modified to optimize the query and improve the performance. 
        #--09-11-2025 add new field maintainer to consider in the condition.
        #listWhere = " SITEID=:SITEID  and DM_MAINTSEC IN (SELECT UNITID FROM dm_orghierarchy WHERE UNITID='"+Ddept+"' OR PARENT1ID ='"+Ddept+"') AND STATUS NOT IN (SELECT VALUE FROM synonymdomain WHERE DOMAINID='LOCASSETSTATUS' AND MAXVALUE  = 'DECOMMISSIONED') AND STATUS NOT LIKE 'RF%'  and  assetnum not in (select a.assetnum from DM_DISPOSALLINE a,DM_DISPOSAL b where a.disposalnum=b.disposalnum and a.assetnum is not null and b.status not in ('CAN')) and assetnum in (select assetnum from asset where DM_ASSET_TAG is not null) "
        # if the user is APM user so the user can see all asset
        if isAPM: 
            if Ddept =="55555":
                listWhere = " SITEID=:SITEID  AND STATUS NOT IN (SELECT VALUE FROM synonymdomain WHERE DOMAINID='LOCASSETSTATUS' AND MAXVALUE  = 'DECOMMISSIONED') AND STATUS NOT LIKE 'RF%'  and  assetnum not in (select a.assetnum from DM_DISPOSALLINE a,DM_DISPOSAL b where a.EXCLUDED=0 and a.disposalnum=b.disposalnum and a.assetnum is not null and b.status not in ('CAN'))"
            else:
                listWhere = " SITEID=:SITEID  AND STATUS NOT IN (SELECT VALUE FROM synonymdomain WHERE DOMAINID='LOCASSETSTATUS' AND MAXVALUE  = 'DECOMMISSIONED') AND STATUS NOT LIKE 'RF%'  and  assetnum not in (select a.assetnum from DM_DISPOSALLINE a,DM_DISPOSAL b where a.EXCLUDED=0 and a.disposalnum=b.disposalnum and a.assetnum is not null and b.status not in ('CAN')) and DM_GRPNUM is not null "
        else:  
            #if the maintainer is the same department.
            if owner.getBoolean("ISLOCALMAINTAINER"):
                listWhere = " SITEID=:SITEID  and DM_MAINTDEPT ='"+Ddept+"' AND STATUS NOT IN (SELECT VALUE FROM synonymdomain WHERE DOMAINID='LOCASSETSTATUS' AND MAXVALUE  = 'DECOMMISSIONED') AND STATUS NOT LIKE 'RF%'  and  assetnum not in (select a.assetnum from DM_DISPOSALLINE a,DM_DISPOSAL b where a.EXCLUDED=0 and a.disposalnum=b.disposalnum and a.assetnum is not null and b.status not in ('CAN')) and DM_GRPNUM is not null"
            #if the maintainter is different department.
            else:
                maintDept = owner.getString("MAINTAINERDEPT")
                opSection = owner.getString("dm_section")
                listWhere = " SITEID=:SITEID and dm_department='"+Ddept+"'  and DM_MAINTDEPT ='"+maintDept+"' AND STATUS NOT IN (SELECT VALUE FROM synonymdomain WHERE DOMAINID='LOCASSETSTATUS' AND MAXVALUE  = 'DECOMMISSIONED') AND STATUS NOT LIKE 'RF%'  and  assetnum not in (select a.assetnum from DM_DISPOSALLINE a,DM_DISPOSAL b where a.EXCLUDED=0 and a.disposalnum=b.disposalnum and a.assetnum is not null and b.status not in ('CAN')) and DM_GRPNUM is not null "

        #--End the change.
        relationWhere  = listWhere + " AND ASSETNUM=:ASSETNUM"
    
    else:
        relationObject = "ASSET"
        listWhere =  " SITEID=:SITEID AND STATUS NOT IN (SELECT VALUE FROM synonymdomain WHERE DOMAINID='LOCASSETSTATUS' AND MAXVALUE  = 'DECOMMISSIONED') "
        relationWhere  = listWhere + " AND ASSETNUM=:ASSETNUM" 
    
if  launchPoint == 'DISPOSAL_ASSETNUM2':
    if owner.getString('INTERNALTYPE') == 'Decommission' and not mbo.isNull('ASSETNUM'):
             Assetwhere = "assetnum in (select assetnum from asset where  STATUS NOT IN (SELECT VALUE FROM synonymdomain WHERE DOMAINID='LOCASSETSTATUS' AND MAXVALUE  = 'DECOMMISSIONED') AND STATUS NOT LIKE 'RF%' and assetnum not in (select a.assetnum from DM_DISPOSALLINE a,DM_DISPOSAL b where a.disposalnum=b.disposalnum and a.assetnum is not null and b.status not in ('CAN')) and assetnum='"+Dasset+"' and  siteid='"+Dsiteid+"' and  orgid='"+Dorgid+"')";
             AssetDatSet = mbo.getMboSet("$DM_DISASSET$","Asset",Assetwhere)
             if(AssetDatSet.isEmpty()):
                 setError("Please Enter the Valid Asset")
                 
if  launchPoint == 'FLD.ASSETNUM.ACT':
    if mbovalue.isNull():
        mbo.setValueNull('Description')
    else:
        mbo.setValue('Description',mbo.getString('ASSET.DESCRIPTION'),11L)

if launchPoint =="DM_DISPOSALLINE_ASSETNUM_ACT":
    assetMbo = mbo.getMboSet("asset").getMbo(0)
    remValue = assetMbo.getDouble("DM_REMAINUSEFULLIFE")
    costValue = assetMbo.getDouble("DM_COST")
    if costValue >= 30000 or (costValue > 15000 and remValue > 0):
        mbo.setValue("APC","YES")