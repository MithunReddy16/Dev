#DM_CUSTOM_GENERATE_LINENUM

#Variables
### LineNumName

#if mbo.isNew() and mbo.isNull(LineNumName):
#	thisSet = mbo.getThisMboSet()
#	newLineNum = thisSet.max(LineNumName) + 1
#	mbo.setValue(LineNumName,newLineNum)
	
#DM_GENERATE_BUDGETLINENUM

if mbo.isNew() and mbo.isNull('DISPOSALLINENUM'):
	thisSet = mbo.getThisMboSet()
	newLineNum = thisSet.max('DISPOSALLINENUM') + 1
	mbo.setValue('DISPOSALLINENUM',newLineNum)