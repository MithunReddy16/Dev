# the validation runs in main tab only to use import application action. 
session = service.webclientsession();
decomApp = session.getCurrentApp()
if not decomApp.onListTab():
    if not mbovalue.isNull():
        service.error('scriptval','scriptvalidationerror',['Please select value from lookup'])