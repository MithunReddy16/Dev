if mbo.getThisMboSet().getParentApp() =="DM_DISPOSAL":
    if mbo.getBoolean('bulk'):
        mbovalue.setReadOnly(True)