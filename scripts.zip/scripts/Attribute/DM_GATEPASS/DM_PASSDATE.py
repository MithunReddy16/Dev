from psdi.mbo import MboConstants
from java.util import Date
from java.text import SimpleDateFormat

current_date = Date()
formatter = SimpleDateFormat("yyyy-MM-dd")
current_date_str = formatter.format(current_date)
current_date_only = formatter.parse(current_date_str)

pass_date = mbo.getDate("PASSDATE")

if pass_date:
    pass_date_str = formatter.format(pass_date)
    pass_date_only = formatter.parse(pass_date_str)

    if pass_date_only.before(current_date_only):
        error_group = "dm_gatepass"
        error_key = "dm_passdate"
        service.error(error_group, error_key)