from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.security import UserInfo

currentUser = user
groupUserSet = mbo.getMboServer().getMboSet("GROUPUSER", mbo.getUserInfo())
groupUserSet.setWhere("userid = '{}' AND groupname = 'MAXADMIN'".format(currentUser))
groupUserSet.reset()

maximo = MXServer.getMXServer()
currentUser = maximo.getUserInfo(user) 
persond = currentUser.getPersonId()  
personMbo = mbo.getMboSet('$person', 'person', "personid = '" + persond + "'").getMbo(0)
persondept = personMbo.getString("DM_Department")
personSec = personMbo.getString("DM_SECTION")

orgHirMbo = mbo.getMboSet('$DM_ORGHIERARCHY', 'DM_ORGHIERARCHY', "UNITID = '" + persondept + "'").getMbo(0)
abbriviation = orgHirMbo.getString("ABBRIVIATION")

if launchPoint == 'DM_JPMAINTSEC' or launchPoint == 'DM_PMMAINTSEC':
    if abbriviation == 'STP' and groupUserSet.count() == 0:
        domainid="DM_ORGPMSERVDEPT"
        listWhere="unitid = '" + personSec + "'"
    elif abbriviation != 'STP' and groupUserSet.count() == 0:
        domainid="DM_ORGPMSERVDEPT"
        listWhere="(unitid = '" + persondept + "' or unitid in (select unitid from DM_ORGHIERARCHY where parent1id = '" + persondept + "'))"
      
    elif groupUserSet.count() > 0:
        domainid="DM_ORGPMSERVDEPT"
        listWhere="unittype != 'SECTOR'"
        
if launchPoint == 'DM_SRMAINTSEC':
    if abbriviation == 'STP' and groupUserSet.count() == 0:
        domainid="DM_ORGHIERARCHY"
        listWhere="unitid = '" + personSec + "'"
    elif abbriviation != 'STP' and groupUserSet.count() == 0:
        domainid="DM_ORGHIERARCHY"
        ##listWhere="(unitid = '" + persondept + "' or unitid in (select unitid from DM_ORGHIERARCHY where parent1id = '" + persondept + "'))"
        listWhere="(unitid in (select unitid from DM_ORGHIERARCHY where parent1id = '" + persondept + "'))"
    elif groupUserSet.count() > 0:
        domainid="DM_ORGHIERARCHY"
        listWhere="unittype = 'SECTION'"