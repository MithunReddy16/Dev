from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.security import UserInfo

ThisSet = mbo.getThisMboSet()  
appl = ThisSet.getParentApp()

currentUser = user
groupUserSet = mbo.getMboServer().getMboSet("GROUPUSER", mbo.getUserInfo())
groupUserSet.setWhere("userid = '{}' AND groupname = 'MAXADMIN'".format(currentUser))
groupUserSet.reset()
    
maximo = MXServer.getMXServer()
currentUser = maximo.getUserInfo(user)
persond = currentUser.getPersonId() 
personMbo = mbo.getMboSet('$person', 'person', "personid = '" + persond + "'").getMbo(0)
persondept = personMbo.getString("DM_Department")
personSec = personMbo.getString("DM_SECTION")
    
orgHirMbo = mbo.getMboSet('$DM_ORGHIERARCHY', 'DM_ORGHIERARCHY', "UNITID = '" + persondept + "'").getMbo(0)
abbriviation = orgHirMbo.getString("ABBRIVIATION")

if (appl and appl =='DM_PLUSGPM'):
    if abbriviation == 'STP' and groupUserSet.count() == 0:
        domainid="DM_PMCREW"
        listWhere = " DM_SECTION = '" + personSec + "'"
    elif abbriviation == 'TAS' and groupUserSet.count() == 0:
        domainid="DM_PMCREW"
        listWhere = " AMCREW = 'RECPT' and orgid = 'DMORG' "
    # Below if added by Mithun 
    elif abbriviation  in ('SRN') and groupUserSet.count() == 0:
        #service.error("rgr","agr")
        if persondept=='15763':
            domainid = "DM_AMCREW1"
            listWhere = " dm_bunit = :dm_bunit AND dm_department = :dm_maintdept "  
            service.log_debug("*********listWhere1: " + listWhere)
    elif abbriviation  in ('SRN') and groupUserSet.count() == 0:
        #service.error("rgr","agr")
        relationObject = "DM_PMCREW"
        listWhere = (
            "(:dm_vendor IS NOT NULL AND vendor = :dm_vendor "
            "AND dm_bunit = :dm_bunit "
            "AND dm_department = :dm_maintdept) "
            "OR "
            "(:dm_vendor IS NULL "
             "AND dm_bunit = :dm_bunit "
            "AND dm_department = :dm_maintdept)"
        )
        service.log("listWhere: " + listWhere)
          
    elif groupUserSet.count() > 0:
        domainid="DM_PMCREW"
        listWhere="1=1"
    else:
        domainid = 'DM_AMCREW'
elif (appl and appl =='DM_PLUSGJP') or (appl and appl =='DM_PLUSGSR') or (appl and appl =='DM_CREATESR'):
    if abbriviation == 'STP' and groupUserSet.count() == 0:
        domainid="DM_PMCREW"
        listWhere = " DM_SECTION = '" + personSec + "'"
    elif abbriviation !='STP' and groupUserSet.count() == 0:
        domainid="DM_PMCREW"
        listWhere = " DM_DEPARTMENT = '" + persondept + "'"
    elif groupUserSet.count() > 0:
        domainid="DM_PMCREW"
        listWhere="1=1"
        
else:
    domainid = 'DM_AMCREW'