##############################################
#script:DM_ADV_EVENTDATE
#Createdby:NK
#Creation Date:023-03-2026
##############################################

from java.util import Date
from psdi.util import MXApplicationException
from psdi.server import MXServer

eventDate = mbo.getDate("DM_ADV_EVENTDATE")
currentDate = MXServer.getMXServer().getDate()

if (eventDate != None):
    if eventDate < currentDate:
        service.error("dm","genericerror",["Event Date cannot be in the past"])