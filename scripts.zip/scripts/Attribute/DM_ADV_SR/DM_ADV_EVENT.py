##############################################
#script:DM_ADV_EVENT
#Createdby:NK
#Creation Date:02-03-2026
#scope: Create SR -event

from psdi.mbo import MboConstants

if not mbo.getBoolean("DM_ADV_EVNT"):
    mbo.setValue("DM_ADV_EVENTDESC", "", MboConstants.NOACCESSCHECK)
    mbo.setValueNull("DM_ADV_EVENTDATE", MboConstants.NOACCESSCHECK)