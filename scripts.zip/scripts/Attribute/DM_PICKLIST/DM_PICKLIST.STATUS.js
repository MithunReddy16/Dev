/*
Script: DM_PICKLIST.STATUS
Created By: Ashok
Date: 11-Dec-2024
Req: To Track the Change Status History

*/

load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)
importPackage(Packages.psdi.app.inventory.virtual)


//from psdi.mbo import DBShortcut,SqlFormat


//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_PICKLIST.STATUS**START***")

if(mbo.getString("DM_STATUS").equalsIgnoreCase("STAGED"))
{
	logger.error("***ASH***Sript DM_PICKLIST.STATUS**changing Status to STAGED")
	invUseSet=mbo.getMboSet("DM_INVUSE");
	invUseMbo=null;
	for(i=0;(invUseMbo=invUseSet.getMbo(i))!=null;i++)
	{
		if(invUseMbo.getString("STATUS").equalsIgnoreCase("CANCELLED") || invUseMbo.getString("STATUS").equalsIgnoreCase("STAGED"))
		{
		}
		else
		{
			logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - i="+i)
			invuseLineMbo=invUseMbo.getMboSet("INVUSELINE").getMbo(0);
			womrnum="";
			logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - invusenum="+invUseMbo.getString("invusenum"))
			logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - invuseLineMbo.invusenum="+invuseLineMbo.getString("invusenum"))
			if(invuseLineMbo!=null)
			{
				womrnum="WO"+invuseLineMbo.getString("REFWO");
				if(womrnum.length()<=3)
				{
					womrnum="MR"+invuseLineMbo.getString("mrnum")
				}
				if(womrnum.length()<=3)
				{
					womrnum="PO"+invuseLineMbo.getString("ponum")
				}
			}
			logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - womrnum="+womrnum)
			binnum="PL"+invUseMbo.getString("DM_PICKLISTNUM")+"-IU"+invUseMbo.getString("INVUSENUM")+"-"+womrnum;
			logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - stg binnum="+binnum)
			splitUseLineSet = invUseMbo.getMboSet("SPLITUSELINE");
			
			if(!splitUseLineSet.setSplitUseLineSet().isEmpty())
			{
				logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - before autosplit")
				splitUseLineSet.autoSplitRecordSet();
				logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - before Validatesplit()")
				splitUseLineSet.validateSplitLines();
				logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - before splitUseLineSet.isEmpty()="+splitUseLineSet.isEmpty())
				if (!splitUseLineSet.isEmpty()) {
					logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - before addInvUseLineSplitRecords()")
					splitUseLineSet.addInvUseLineSplitRecords();
					logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - after addInvUseLineSplitRecords()")
				}
				logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - before changestatus")
				invUseMbo.changeStatus("STAGED", MXServer.getMXServer().getDate(), "", "1", binnum, false, 2)
				logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - after changestatus")
			}
			else
			{
				logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - before changestatus no split")
				invUseMbo.changeStatus("STAGED", MXServer.getMXServer().getDate(), "", "1", binnum, false, 2)
				logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - after changestatus no split")
			}
			invUseSet.save(2)
		}
	}
}
else if(mbo.getString("DM_STATUS").equalsIgnoreCase("CAN"))
{
    invUseSet=mbo.getMboSet("DM_INVUSE");
	invUseSet.setWhere("status!='CANCELLED'")
	invUseSet.reset();
	invUseMbo=null;
	setCnt=invUseSet.count();
	for(i=0;i<setCnt;i++)
	{
		logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - before changestatus CAN")
		
		invUseMbo=invUseSet.getMbo(i);
		logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - invUseMbo="+invUseMbo);
		if(invUseMbo!=null)
	    {
			
			invUseSet1=mbo.getMboSet("$INVUSE","INVUSE","invusenum='"+invUseMbo.getString("INVUSENUM")+"' and DM_PICKLISTNUM='"+invUseMbo.getString("DM_PICKLISTNUM")+"' and status not in ('CANCELLED','COMPLETE')")
			invUseMbo1=invUseSet1.getMbo(0)
			logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - invUseMbo1="+invUseMbo1);
			if(invUseMbo1!=null)
			{
				logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - invUsenum="+invUseMbo1.getString("INVUSENUM"));
				invUseMbo1.changeStatus("CANCELLED",	 MXServer.getMXServer().getDate(), "Canceled from Pick List "+mbo.getString("DM_PICKLISTNUM"), 2)
			}
			
			//invUseMbo.changeStatus("CANCELLED",	 MXServer.getMXServer().getDate(), "Canceled from Pick List "+mbo.getString("DM_PICKLISTNUM"), 2)
			logger.error("***ASH***Sript DM_PICKLIST.STATUS**inside for loop - after changestatus CAN")
			//invUseMbo.getThisMboSet().save(2);
			invUseSet1.save(2)
		}
	}
}

logger.error("***ASH***Sript DM_PICKLIST.STATUS**History Add")
pickListHistMbo=mbo.getMboSet("DM_PICKLISTSTATUSHIST").add();

pickListHistMbo.setValue("DM_PICKLISTNUM",mbo.getString("DM_PICKLISTNUM"),2)
pickListHistMbo.setValue("DM_STATUS",mbo.getString("DM_STATUS"),2)
pickListHistMbo.setValue("SITEID",mbo.getString("SITEID"),2)

if(!mbo.toBeAdded())
{
	mbo.getThisMboSet().save(2)
}


logger.error("***ASH***Sript DM_PICKLIST.STATUS**History Add Complete")
logger.error("***ASH***Sript DM_PICKLIST.STATUS**END***")