#DM_ITEM_CLASSIFICATION

def setError(Msg):
		#global errorkey,errorgroup,params
		#errorkey='scriptvalidationerror'
		#errorgroup='scriptval'
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)
        
if mbo.getBoolean('ROTATING'):
    
    if not mbo.isNew():
        setError('Classification Can not be changed for Rotating Item')
    #if mbo.getString('CLASSSTRUCTURE.HIERARCHYPATH')[:6] != 'ASSETS' or mbo.getString('CLASSSTRUCTURE.CLASSIFICATIONID') =='ASSETS':
    #    setError('Invalid Classification')
    if mbo.isNull('CLASSSTRUCTUREID'):
        mbo.setValueNull('ITEMNUM',11L)
    else:
        mbo.setValue('ITEMNUM',mbo.getString('CLASSSTRUCTURE.CLASSIFICATIONID'),11L)

#elif mbo.getString('CLASSSTRUCTURE.HIERARCHYPATH')[:6] == 'ASSETS':
#    setError('Invalid Classification')