#DM_ITEM_ROTATING
Rotating = mbo.getBoolean('ROTATING')
if Rotating:
    mbo.setValueNull('ITEMNUM')
    mbo.setFieldFlag('ITEMNUM',7L,True)
    mbo.setValueNull('HIERARCHYPATH')
    mbo.setValueNull('CLASSSTRUCTUREID')
else:
    mbo.setValueNull('ITEMNUM')
    mbo.setFieldFlag('ITEMNUM',7L,False)
    mbo.setValueNull('HIERARCHYPATH')
    mbo.setValueNull('CLASSSTRUCTUREID')