load('nashorn:mozilla_compat.js');


importClass(java.util.Calendar);
importClass (java.util.Date);
importClass(java.text.SimpleDateFormat);
importClass(java.lang.Integer);



if( !mbo.isNull("DM_JCCMONTH")){
    dm_month = mbo.getMboSet("dm_month").getMbo(0).getString("maxvalue");
    calendar = Calendar.getInstance();
    currentMonth =calendar.get(Calendar.MONTH);
    if ( (Integer.parseInt(dm_month))> currentMonth+1){
        service.error("dm_jcc","dm_invalidmonth");
    }
    else{
       currentYear = calendar.get(Calendar.YEAR);
       dm_month = mbo.getMboSet("dm_month").getMbo(0).getInt("maxvalue")
       
        // --- Set Start Date ---
        //calendar.set(Calendar.YEAR, currentYear);
        //calendar.set(Calendar.MONTH, (Integer.parseInt(dm_month))-1);
        //calendar.set(Calendar.DAY_OF_MONTH, 1);
        //startDate = calendar.getTime();
        //mbo.setValue("DM_FROMDATE",startDate);
        // --- Set End/Invoicedate Date ---
        calendar.set(Calendar.MONTH, dm_month-1)
        lastDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        calendar.set(Calendar.DAY_OF_MONTH, lastDay);
        endDate = calendar.getTime();
         mbo.setValue("invoicedate",endDate);
        // Format dates as dd-MM-yyyy
       //sdf = new SimpleDateFormat("dd-MM-yyyy");
        //start = sdf.format(startDate); 
    }
    
    
}