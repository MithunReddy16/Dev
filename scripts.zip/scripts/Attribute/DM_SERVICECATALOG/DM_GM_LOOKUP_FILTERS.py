#---------------------------------------------------------------------------------------------
#Script Name : DM_GM_LOOKUP_FILTERS
#Description : Filter attribute lookup values in the General Maintenance applications.
#
#Author/Modifiedby       Email                Version      Date               Comment
#---------------------------------------------------------------------------------------------
#Muhammad Darwish        MDARWISH.V@dm.ae      1.0          2026-10-12         Filter multiple attribute lookups.
#---------------------------------------------------------------------------------------------

from psdi.server import MXServer

app = mbo.getThisMboSet().getParentApp()
isGM = app and app.upper() in ("DM_PLUSGSR_GM", "DM_PLUSGWO_GM")

# Service Type lookup - SR, WO
if launchPoint == "DM_GM_SERVICETYPES":
    where = "DOMAINID = 'DM_SERVICETYPES'"
    if isGM:
        where += " AND VALUE IN ('CIVIL','ELEC','MECH','AD-HOC')"
    listMboSet = MXServer.getMXServer().getMboSet("ALNDOMAIN", mbo.getUserInfo())
    listMboSet.setWhere(where)
    listMboSet.setOrderBy("VALUE")
    listMboSet.reset()

# Status lookup - SR
elif launchPoint == "DM_GM_STATUSFILTER":
    statuses = "NEW,QUEUED,ASSIGNED,IHACCEPTED,INPROG,PENDING,ADHPROP,TRWAPPR,ZMWAPPR,RETURNED,CTRETURNED,IHRETURNED,TRRETURNED,ZMRETURNED,RESOLVED,CLOSED,REJECTED,CANCELLED".split(",")
    where = "DOMAINID = 'SRSTATUS'"
    order = "VALUE"
    if isGM:
        where += " AND VALUE IN (%s)" % ",".join("'%s'" % s for s in statuses)
        order = "CASE VALUE %s ELSE 99 END, VALUE" % " ".join("WHEN '%s' THEN %d" % (s, i) for i, s in enumerate(statuses, 1))
    listMboSet = MXServer.getMXServer().getMboSet("SYNONYMDOMAIN", mbo.getUserInfo())
    listMboSet.setWhere(where)
    listMboSet.setOrderBy(order)
    listMboSet.reset()

# Vendor (Contractor) lookup - SR, WO
elif launchPoint in ("DM_GM_CONFILTER", "DM_GM_WOCONFILTER"):
    where = "1=1"
    if isGM:
        where = "COMPANY IN ('EMDAD','43729','1391')"
    listMboSet = MXServer.getMXServer().getMboSet("COMPANIES", mbo.getUserInfo())
    listMboSet.setWhere(where)
    listMboSet.setOrderBy("COMPANY")
    listMboSet.reset()
    srcKeys = ["COMPANY"]
    targetKeys = ["VENDOR"]

# Work Type lookup - WO
elif launchPoint == "DM_GM_WOTYPEFILTER":
    where = "1=1"
    if isGM:
        where = "WORKTYPE IN ('CM','AS','PM','CP','MD')"
    listMboSet = MXServer.getMXServer().getMboSet("WORKTYPE", mbo.getUserInfo())
    listMboSet.setWhere(where)
    listMboSet.setOrderBy("CASE WORKTYPE WHEN 'CM' THEN 1 WHEN 'AS' THEN 2 WHEN 'PM' THEN 3 WHEN 'CP' THEN 4 WHEN 'MD' THEN 5 ELSE 99 END, WORKTYPE")
    listMboSet.reset()
    srcKeys = ["WORKTYPE"]
    targetKeys = ["WORKTYPE"]

# Status lookup - WO
elif launchPoint == "DM_GM_WOSTATUSFILTER":
    statuses = (
        "WAPPR,PENDING,ZEWAPPR,ZMWAPPR,SMWAPPR,APPR,INPRG,WINSP,ZEWINSP,ZMWINSP,SMWINSP,COMP,CANREQUEST,CLOSE,"
        "CDDWAPPR,CDDRETURNED,APCTAPPR,APCTRETURNED,APCTWAPPR,COM1RETURNED,COM2RETURNED,COMITE1APPR,COMITE2APPR,"
        "COMWAPPR,QUOTREV,REWORK,SEWINSP,SMRETURNED,ZERETURNED,ZMRETURNED,CAN"
    ).split(",")
    where = "DOMAINID = 'WOSTATUS'"
    order = "VALUE"
    if isGM:
        where += " AND VALUE IN (%s)" % ",".join("'%s'" % s for s in statuses)
        order = "CASE VALUE %s ELSE 99 END, VALUE" % " ".join("WHEN '%s' THEN %d" % (s, i) for i, s in enumerate(statuses, 1))
    listMboSet = MXServer.getMXServer().getMboSet("SYNONYMDOMAIN", mbo.getUserInfo())
    listMboSet.setWhere(where)
    listMboSet.setOrderBy(order)
    listMboSet.reset()