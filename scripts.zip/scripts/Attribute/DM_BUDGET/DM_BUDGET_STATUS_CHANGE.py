#DM_BUDGET_STATUS_CHANGE

from psdi.server import MXServer
from  psdi.common.context import UIContext
from psdi.webclient.system.controller import SessionContext, Utility, WebClientEvent


mxServer = MXServer.getMXServer()
from psdi.util.logging import MXLoggerFactory
myLogger = MXLoggerFactory.getLogger("maximo.custom")


#app = service.webclientsession().getCurrentApp()
#BudgetSet = app.getResultsBean().getMboSet()
#isTableSelect = app.getResultsBean().getTableStateFlags().isFlagSet(ResultsBean.TABLE_SUBSELECT_ON)


def setError(Msg):
		#global errorkey,errorgroup,params
		#errorkey='scriptvalidationerror'
		#errorgroup='scriptval'
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)


## Budget Line Status Change ACTION
if launchPoint == 'CHNGLINEST':
	
	if mbo.isNull('STATUS'):
		setError('Please select a valid status.')
		
		
	NewStatus = mbo.getString('STATUS')
	if NewStatus == 'APPR' and (mbo.isNull('APPRQTY') or mbo.getFloat('APPRQTY') == 0):
		setError("Approved quantity can not be empty or 0.")
        
	BudgetLineMbo = mbo.getOwner()
	if NewStatus == 'APPR' and (BudgetLineMbo.getString('NEED') !='New Asset' and mbo.getFloat('APPRQTY') > 1):
		setError("Approved quantity Must be 1.")
	
	BudgetLineMbo.setValue('STATUSDATE',mxServer.getDate())
	
	BudgetLineMbo.setValue('STATUS',NewStatus,11L)
	BudgetLineMbo.setValue('APPRQTY',mbo.getFloat('APPRQTY'))
	
	StatusHistorySet = BudgetLineMbo.getMboSet('DM_BUDGETLINESTHIST')
	
	StatusHistorySet.setInsertOrg(BudgetLineMbo.getString('ORGID'))
	StatusHistorySet.setInsertSite(BudgetLineMbo.getString('SITEID'))
	
	StatusHistoryMbo = StatusHistorySet.addAtEnd()
	
	StatusHistoryMbo.setValue('ORGID',BudgetLineMbo.getString('ORGID'))	
	StatusHistoryMbo.setValue('SITEID',BudgetLineMbo.getString('SITEID'))
	StatusHistoryMbo.setValue('BUDGETNUM',BudgetLineMbo.getString('BUDGETNUM'))
	StatusHistoryMbo.setValue('BUDGETLINENUM',BudgetLineMbo.getInt('BUDGETLINENUM'))
	StatusHistoryMbo.setValue('MEMO',mbo.getString('MEMO'))
	StatusHistoryMbo.setValue('STATUSDATE',BudgetLineMbo.getDate('STATUSDATE'))
	StatusHistoryMbo.setValue('STATUS',BudgetLineMbo.getString('STATUS'))
	
	
	service.closeDialog()
	
## Budget Line(S) Status Change Check
if launchPoint == 'CHGLINESTAC_M':
	
	LineSet = mbo.getMboSet('DM_BUDGETLINE')
	LineSelection = LineSet.getSelection()
	
	
	if not LineSelection.size() > 0:
		setError('Please select at least one line.')
	
	
	uiContext = UIContext.getCurrentContext()
	if uiContext != None:
		wcs = uiContext.getWebClientSession()
		Utility().sendEvent(WebClientEvent("changelinestatus_m", wcs.getCurrentPageId(), None, SessionContext(wcs)))
	#service.launchDialog('changelinestatus_m')
	

## Budget Line(S) Status Change ACTION

if launchPoint == 'CHGLINESTAC_MA':
	
	BudgetMbo = mbo.getOwner()
	LineSet = BudgetMbo.getMboSet('DM_BUDGETLINE')
	#LineSelection = LineSet.getSelection()
	#setError(str(LineSelection.size()))	
	
	if mbo.isNull('STATUS'):
		setError('Please select status.')
		
		
	NewStatus = mbo.getString('STATUS')
	NewStatusMemo = mbo.getString('Memo')
	
	BudgetLineMbo = LineSet.moveFirst()
	while (BudgetLineMbo):
		if BudgetLineMbo.isSelected():
			myLogger.debug("Line " + str(BudgetLineMbo.getInt('BUDGETLINENUM')) + " Is Selected")
			OldStatus = BudgetLineMbo.getString('STATUS')
			if OldStatus != NewStatus:
				
				if OldStatus == 'DRAFT' or OldStatus == 'REVIEWED' or OldStatus == 'PENDING':
					BudgetLineMbo.setValue('STATUSDATE',mxServer.getDate())
	
					BudgetLineMbo.setValue('STATUS',NewStatus,11L)
					BudgetLineMbo.setValue('APPRQTY',BudgetLineMbo.getFloat('QUANTITY'))
					
					StatusHistorySet = BudgetLineMbo.getMboSet('DM_BUDGETLINESTHIST')
					
					StatusHistorySet.setInsertOrg(BudgetLineMbo.getString('ORGID'))
					StatusHistorySet.setInsertSite(BudgetLineMbo.getString('SITEID'))
	
					StatusHistoryMbo = StatusHistorySet.addAtEnd()
					
					StatusHistoryMbo.setValue('ORGID',BudgetLineMbo.getString('ORGID'))	
					StatusHistoryMbo.setValue('SITEID',BudgetLineMbo.getString('SITEID'))
					StatusHistoryMbo.setValue('BUDGETNUM',BudgetLineMbo.getString('BUDGETNUM'))
					StatusHistoryMbo.setValue('BUDGETLINENUM',BudgetLineMbo.getInt('BUDGETLINENUM'))
					StatusHistoryMbo.setValue('MEMO',mbo.getString('MEMO'))
					StatusHistoryMbo.setValue('STATUSDATE',BudgetLineMbo.getDate('STATUSDATE'))
					StatusHistoryMbo.setValue('STATUS',BudgetLineMbo.getString('STATUS'))
	
		BudgetLineMbo = LineSet.moveNext()
		
		
	service.closeDialog()
## Budget Line Status Field
if launchPoint == 'BUDGETLINESTATUS.STATUS':
	
	BudgetMbo = mbo
	
	StatusHistorySet = BudgetMbo.getMboSet('DM_BUDGETLINESTHIST')
	
	StatusHistorySet.setInsertOrg(BudgetMbo.getString('ORGID'))
	StatusHistorySet.setInsertSite(BudgetMbo.getString('SITEID'))
	
	StatusHistoryMbo = StatusHistorySet.addAtEnd()
	
	
	
	StatusHistoryMbo.setValue('ORGID',BudgetMbo.getString('ORGID'))	
	StatusHistoryMbo.setValue('SITEID',BudgetMbo.getString('SITEID'))
	StatusHistoryMbo.setValue('BUDGETNUM',BudgetMbo.getString('BUDGETNUM'))
	StatusHistoryMbo.setValue('BUDGETLINENUM',BudgetMbo.getInt('BUDGETLINENUM'))
	
	StatusHistoryMbo.setValue('STATUSDATE',BudgetMbo.getDate('STATUSDATE'))
	StatusHistoryMbo.setValue('STATUS',BudgetMbo.getString('STATUS'))


# Budget (HEADER) Status Field
if launchPoint == 'BUDGETSTATUS.STATUS':
	
	BudgetMbo = mbo
	
	StatusHistorySet = BudgetMbo.getMboSet('DM_BUDGETSTHIST')
	StatusHistoryMbo = StatusHistorySet.addAtEnd()
	
	StatusHistoryMbo.setValue('ORGID',BudgetMbo.getString('ORGID'))	
	StatusHistoryMbo.setValue('SITEID',BudgetMbo.getString('SITEID'))
	StatusHistoryMbo.setValue('BUDGETNUM',BudgetMbo.getString('BUDGETNUM'))	
	StatusHistoryMbo.setValue('STATUSDATE',BudgetMbo.getDate('STATUSDATE'))
	StatusHistoryMbo.setValue('STATUS',BudgetMbo.getString('STATUS'))
	
## Buget Line Status Auto CHANGE from WF
if launchPoint == 'BUD_LSWF':
	
	BudgetMbo = mbo
	
	NewStatus = BudgetMbo.getString('STATUS')
	NewStatusDate = mbo.getString('STATUSDATE')
	
	## TODO
	## I think we need to test for different department in one budget to see
	## if all dep lines will be changed to draft or only person's department
	
	
	if NewStatus == 'PENDING' or NewStatus == 'DRAFT':
		LineSet = BudgetMbo.getMboSet('DM_BUDGETLINE')	
		BudgetLineMbo = LineSet.moveFirst()
		while (BudgetLineMbo):			
			OldLineStatus = BudgetLineMbo.getString('STATUS')
			if OldLineStatus != NewStatus:					
				if OldLineStatus == 'DRAFT' or ( OldLineStatus == 'REVIEWED' and not BudgetLineMbo.isNull('DM_CENTRALDEPARTMENT')) or OldLineStatus == 'PENDING':
					BudgetLineMbo.setValue('STATUSDATE',NewStatusDate)	
					BudgetLineMbo.setValue('STATUS',NewStatus,11L)					
					StatusHistorySet = BudgetLineMbo.getMboSet('DM_BUDGETLINESTHIST')					
					StatusHistorySet.setInsertOrg(BudgetLineMbo.getString('ORGID'))
					StatusHistorySet.setInsertSite(BudgetLineMbo.getString('SITEID'))	
					StatusHistoryMbo = StatusHistorySet.addAtEnd()					
					StatusHistoryMbo.setValue('ORGID',BudgetLineMbo.getString('ORGID'))	
					StatusHistoryMbo.setValue('SITEID',BudgetLineMbo.getString('SITEID'))
					StatusHistoryMbo.setValue('BUDGETNUM',BudgetLineMbo.getString('BUDGETNUM'))
					StatusHistoryMbo.setValue('BUDGETLINENUM',BudgetLineMbo.getInt('BUDGETLINENUM'))
					
					StatusHistoryMbo.setValue('STATUSDATE',BudgetLineMbo.getDate('STATUSDATE'))
					StatusHistoryMbo.setValue('STATUS',BudgetLineMbo.getString('STATUS'))
		
			BudgetLineMbo = LineSet.moveNext()
			
	elif NewStatus == 'REVIEWED':
		LineSet = BudgetMbo.getMboSet('DM_BUDGETLINE')	
		BudgetLineMbo = LineSet.moveFirst()
		while (BudgetLineMbo):			
			OldLineStatus = BudgetLineMbo.getString('STATUS')
			if OldLineStatus != NewStatus:					
				if (OldLineStatus == 'DRAFT' or OldLineStatus == 'PENDING'):
					NewLineStatus = NewStatus
					if BudgetLineMbo.isNull('DM_CENTRALDEPARTMENT'):
						NewLineStatus = 'D-APPR'
					BudgetLineMbo.setValue('STATUSDATE',NewStatusDate)	
					BudgetLineMbo.setValue('STATUS',NewLineStatus,11L)
					StatusHistorySet = BudgetLineMbo.getMboSet('DM_BUDGETLINESTHIST')					
					StatusHistorySet.setInsertOrg(BudgetLineMbo.getString('ORGID'))
					StatusHistorySet.setInsertSite(BudgetLineMbo.getString('SITEID'))	
					StatusHistoryMbo = StatusHistorySet.addAtEnd()					
					StatusHistoryMbo.setValue('ORGID',BudgetLineMbo.getString('ORGID'))	
					StatusHistoryMbo.setValue('SITEID',BudgetLineMbo.getString('SITEID'))
					StatusHistoryMbo.setValue('BUDGETNUM',BudgetLineMbo.getString('BUDGETNUM'))
					StatusHistoryMbo.setValue('BUDGETLINENUM',BudgetLineMbo.getInt('BUDGETLINENUM'))
					
					StatusHistoryMbo.setValue('STATUSDATE',BudgetLineMbo.getDate('STATUSDATE'))
					StatusHistoryMbo.setValue('STATUS',BudgetLineMbo.getString('STATUS'))
		
			BudgetLineMbo = LineSet.moveNext()
	
	elif NewStatus == 'D-APPR':
		LineSet = BudgetMbo.getMboSet('DM_BUDGETLINE')	
		BudgetLineMbo = LineSet.moveFirst()
		while (BudgetLineMbo):			
			OldLineStatus = BudgetLineMbo.getString('STATUS')	
			if (OldLineStatus == 'DRAFT' or OldLineStatus == 'PENDING'):
				NewLineStatus = NewStatus
				BudgetLineMbo.setValue('STATUSDATE',NewStatusDate)	
				BudgetLineMbo.setValue('STATUS',NewLineStatus,11L)
				StatusHistorySet = BudgetLineMbo.getMboSet('DM_BUDGETLINESTHIST')					
				StatusHistorySet.setInsertOrg(BudgetLineMbo.getString('ORGID'))
				StatusHistorySet.setInsertSite(BudgetLineMbo.getString('SITEID'))	
				StatusHistoryMbo = StatusHistorySet.addAtEnd()					
				StatusHistoryMbo.setValue('ORGID',BudgetLineMbo.getString('ORGID'))	
				StatusHistoryMbo.setValue('SITEID',BudgetLineMbo.getString('SITEID'))
				StatusHistoryMbo.setValue('BUDGETNUM',BudgetLineMbo.getString('BUDGETNUM'))
				StatusHistoryMbo.setValue('BUDGETLINENUM',BudgetLineMbo.getInt('BUDGETLINENUM'))
				
				StatusHistoryMbo.setValue('STATUSDATE',BudgetLineMbo.getDate('STATUSDATE'))
				StatusHistoryMbo.setValue('STATUS',BudgetLineMbo.getString('STATUS'))
		
			BudgetLineMbo = LineSet.moveNext()
			
	elif NewStatus == 'APPR':
		LineSet = BudgetMbo.getMboSet('DM_BUDGETLINE')	
		BudgetLineMbo = LineSet.moveFirst()
		while (BudgetLineMbo):			
			OldLineStatus = BudgetLineMbo.getString('STATUS')
			if OldLineStatus != NewStatus:					
				if OldLineStatus == 'D-APPR':
					BudgetLineMbo.setValue('STATUSDATE',NewStatusDate)	
					BudgetLineMbo.setValue('STATUS',NewStatus,11L)
					BudgetLineMbo.setValue('APPRQTY',BudgetLineMbo.getFloat('QUANTITY'))
					StatusHistorySet = BudgetLineMbo.getMboSet('DM_BUDGETLINESTHIST')					
					StatusHistorySet.setInsertOrg(BudgetLineMbo.getString('ORGID'))
					StatusHistorySet.setInsertSite(BudgetLineMbo.getString('SITEID'))	
					StatusHistoryMbo = StatusHistorySet.addAtEnd()					
					StatusHistoryMbo.setValue('ORGID',BudgetLineMbo.getString('ORGID'))	
					StatusHistoryMbo.setValue('SITEID',BudgetLineMbo.getString('SITEID'))
					StatusHistoryMbo.setValue('BUDGETNUM',BudgetLineMbo.getString('BUDGETNUM'))
					StatusHistoryMbo.setValue('BUDGETLINENUM',BudgetLineMbo.getInt('BUDGETLINENUM'))
					
					StatusHistoryMbo.setValue('STATUSDATE',BudgetLineMbo.getDate('STATUSDATE'))
					StatusHistoryMbo.setValue('STATUS',BudgetLineMbo.getString('STATUS'))
                    
		
			BudgetLineMbo = LineSet.moveNext()