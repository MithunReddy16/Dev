#DM_BUDGET.YEAR
from	java.util	import	Calendar

def setError(Msg):

		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)

Cal = Calendar.getInstance()
CurrentYear = Cal.get(Calendar.YEAR)

try:
    Year = int(mbo.getString('Year'))
    if Year < CurrentYear:
        setError('Not a valid year')
except:
    setError('Not a valid year.')
if launchPoint =="CAPYEAR" and not mbo.isNull("YEAR"):
    thismboset=mbo.getThisMboSet()
    xx=0
    for i in range (thismboset.count()):
        if(mbo.getString('YEAR')==thismboset.getMbo(i).getString('YEAR')):
            xx=xx+1
    if (xx>1):
        setError('Year Already Exists')