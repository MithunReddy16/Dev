from psdi.mbo import MboConstants
from psdi.server import MXServer

maintDept = mbo.getString("DM_MAINTDEPT")
asset = mbo.getString("ASSETNUM")

if (maintDept is None or maintDept == ''):
    if (asset is not None or asset != ''):
        assetSet = mbo.getMboSet("ASSET")
        assetMaintSec = assetSet.getMbo(0).getString("DM_MAINTSEC")
        assetMaintDept = assetSet.getMbo(0).getString("DM_MAINTDEPT")
        if (assetMaintSec is not None or assetMaintSec != ''):
            mbo.setValue("DM_MAINTDEPT",assetMaintSec)
            mbo.setValue("DM_MAINTSEC",assetMaintDept)