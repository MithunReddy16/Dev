#script:DM_PMASSETLISTSCRIPT

#Createdby:Ram
#Creation Date:18-DEC-24
#scope: script is to restrict the lookup on different fields in different applications,and it triggers based on user action.
#list of fields-supervisor in wo,pm and crew in pm,owner group and person group and crew work group in pm,lead in pm,crew in jp and wo and pm applications
#and based on maintenance department different lookup will apply for the asset field.

if launchPoint== "DM_PMASSETLIST":
    maintDept = mbo.getString("DM_MAINTDEPT")
    if (maintDept is None or maintDept == ''):
        domainid="DM_PMASSETS"
        #listwhere="dm_department=:dm_maintdept"
    else:
         domainid="DM_PMASSET"

if launchPoint== "DM_PMJP":
    domainid="DM_PMJP"
    
if launchPoint== "DM_WOSUP":
    domainid="DM_WOSUP"

if launchPoint== "DM_WOJP":
    domainid="DM_WOJP"
'''
if launchPoint== "DM_WOCREW":
    domainid="DM_WOCREW"

if launchPoint== "DM_JPCREW":
    domainid="DM_JPCREW"
'''    
if launchPoint== "DM_PMLEAD":
    domainid="DM_PMLEAD"
    
if launchPoint== "DM_PMSUP":
    domainid="DM_PMLEAD"    
if launchPoint== "DM_PMOWNER":
    domainid="DM_PMLEAD"
if launchPoint== "DM_PMOG":
    domainid="DM_JPPG"
if launchPoint== "DM_PMCG":
    domainid="DM_PMCG"    
if launchPoint== "DM_PMPG":
    domainid="DM_JPPG"
    
if launchPoint== "DM_PMCREW": # below if modified by Mithun 
    #domainid="DM_JPCREW"
    relationObject = "AMCREW"
    relationWhere = "AMCREW = :AMCREW"
    if  mbo.getString('dm_bunit') == 'FIUNIT'  :
        listWhere =  " dm_bunit = :dm_bunit AND dm_department = :dm_maintdept  and AMCREWTYPE=:DM_CREWTYPE  "    
    else :
        listWhere =   " crewworkgroup in (SELECT persongroup FROM persongroupteam where resppartygroup in(SELECT personid FROM person where  dm_department=:dm_maintdept))  "