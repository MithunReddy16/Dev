#Author: Ram
#Remarks: Setting the contract details to null if the process is in house
#Date: 31-Jul-2026

inHouse = mbo.getInt("DM_INHOUSE")
bunit = mbo.getString("DM_BUNIT")


if launchPoint =='DM_SRINHOUSE':
    if(inHouse == 1):
        mbo.setValueNull("VENDOR")
        mbo.setValueNull("DM_VENDCONTRACT")
    
if launchPoint =='DM_WOINH' and app=='DM_PLUSGWO_SRWN':
    if(inHouse == 1):
         mbo.setValueNull("DM_QRVENDOR")
         mbo.setValueNull("VENDOR")
         mbo.setValueNull("DM_VENDCONTRACT")
    elif(inHouse == 0) and bunit:
            mbo.setValueNull("amcrew")
         
if launchPoint =='DM_PMINH':
    if(inHouse == 1):
        mbo.setValueNull("DM_VENDCONTRACT")
        mbo.setValueNull("DM_VENDOR")
    elif(inHouse == 0) and bunit:
        mbo.setValueNull("amcrew")
'''
if launchPoint =='DM_SRWWO':
    ptwreq = mbo.getString("dm_ptwreq")
    if(inHouse == 1):
        mbo.setValueNull("DM_VENDCONTRACT")
        mbo.setValueNull("DM_VENDOR")
    elif(inHouse == 0):
        mbo.setValueNull("amcrew")
        mbo.setValueNull("DM_VENDCONTRACT")
        mbo.setValueNull("VENDOR")
        mbo.setValueNull("DM_QRVENDOR")
    if ptwreq==0:
        mbo.setValueNull("DM_PTWNO")
        mbo.setValueNull("DM_PTWISSUEDATE")
        mbo.setValueNull("DM_PTWEXPDATE")
        
        '''