#date:08-Oct-26
#createby:ram

routeSet = mbo.getMboSet("ROUTES")

if not routeSet.isEmpty():
    route = routeSet.getMbo(0)

    if route:
        mbo.setValue("DM_INSPTYPE", route.getString("DM_INSPTYPE"))
        mbo.setValue("dm_floc", route.getString("dm_floc"))