sentDate = mbo.getDate("SENTDATE")
deliveredDate = mbo.getDate("DELIVERDATE")

if (deliveredDate != None and sentDate != None and deliveredDate < sentDate):
    service.error("dm_accdeliverdt","deliverdt")
    
if(deliveredDate == None or deliveredDate ==''):
    mbo.setValueNull("PENALTY")
    mbo.setValue("PENALTYPERCENT",0)
    mbo.setValue("OUTDAYS",0)