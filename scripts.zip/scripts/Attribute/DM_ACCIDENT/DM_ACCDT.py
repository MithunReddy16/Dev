from psdi.server import MXServer

currentDate = MXServer.getMXServer().getDate()
accidentDate = mbo.getDate("ACCIDENTDATE")

if accidentDate is None:
    mbo.setValueNull("SENTDATE")
    mbo.setValueNull("PROMISEDDATE")
    mbo.setValueNull("DELIVERDATE")
else:
    if accidentDate > currentDate:
        service.error("dm_invalidaccdate", "accdate")