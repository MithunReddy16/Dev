if mbo.getString('REPAIRTYPE') == 'External Repair':
    listWhere = " type ='G' and DM_GARAGETYPE ='E' "
elif mbo.getString('REPAIRTYPE') == 'Internal Repair':
    listWhere = " type ='G' and DM_GARAGETYPE ='I' "
elif mbo.getString('REPAIRTYPE') == 'Cancellation':
    listWhere = " type ='G' "