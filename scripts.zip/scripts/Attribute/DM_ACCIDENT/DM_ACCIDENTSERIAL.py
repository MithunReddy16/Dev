#DM_ACCIDENTSERIAL

from java.util import Calendar
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory
myLogger = MXLoggerFactory.getLogger("maximo.custom")


def serialNumber(serialValue,paramLen):
	length = len(serialValue)
	while length<paramLen and length>0:
		serialValue = '0' + serialValue
		length = len(serialValue)
	return serialValue

if mbo.isNew():
    calendar = Calendar.getInstance();
    calendar.setTime(mbo.getDate('ACCIDENTDATE'))
    AccidentYear = calendar.get(Calendar.YEAR)

    AccidentSet = mbo.getMboSet("$SERIALCLASS_Accident","DM_ACCIDENT"," SERIAL in (select max(SERIAL) from DM_ACCIDENT where  EXTRACT(YEAR FROM  ACCIDENTDATE)='"+str(AccidentYear)+"') and EXTRACT(YEAR FROM  ACCIDENTDATE)='"+str(AccidentYear)  + "'")
    

    myLogger.debug("AccidentYear=="+str(AccidentYear))
    maxSerial = 0
    NewAccSerial = ''
    if AccidentSet is not None and not AccidentSet.isEmpty():
        maxSerial = AccidentSet.getMbo(0).getInt('SERIAL')
    if maxSerial==0:
        NewAccSerial ='00001'
    else:
        if maxSerial >= 99999:
            NewAccSerial = str(maxSerial + 1)
        else:
            NewAccSerial = serialNumber(str(maxSerial + 1),5) 

    if NewAccSerial !='':       

        NewAccidentNum=str(AccidentYear)+ NewAccSerial
        mbo.setValue('SERIAL',maxSerial + 1 ,11L);
        mbo.setValue('ACCIDENTNUM',NewAccidentNum,MboConstants.NOVALIDATION)