from psdi.server import MXServer

if not mbo.isNew():
    StatusHistorySet = mbo.getMboSet('DM_ACCIDENTSTATUS')
    StatusHistoryMbo = StatusHistorySet.addAtEnd()
    StatusHistoryMbo.setValue('ACCIDENTNUM',mbo.getString('ACCIDENTNUM'))	
    StatusHistoryMbo.setValue('REVISIONNUM',mbo.getString('REVISIONNUM'))
    StatusHistoryMbo.setValue('STATUS',mbo.getString('STATUS'))