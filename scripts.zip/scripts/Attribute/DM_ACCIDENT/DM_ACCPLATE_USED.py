from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory
from java.lang import String
import jarray

logger = MXLoggerFactory.getLogger("maximo.script.PLATENUM_WARNING")

platenum = mbo.getString("PLATENUM")

if platenum:
    whereClause = "PLATENUM = '{}' AND STATUS IN ('DRAFT', 'ON WORKORDER')".format(platenum)
    accidentSet = mbo.getMboSet("DM_ACCIDENT", "DM_ACCIDENT", whereClause)

    if not accidentSet.isEmpty():
        args = jarray.array([platenum], String)
        service.setWarning("dm_accident","dm_plate_used", args)

    accidentSet.close()