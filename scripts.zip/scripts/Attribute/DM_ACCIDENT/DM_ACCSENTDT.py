accidentDate = mbo.getDate("ACCIDENTDATE")
sentDate = mbo.getDate("SENTDATE")

if ((sentDate != None) and (sentDate < accidentDate)):
    service.error("dm_accsentaccdt","sentaccdt")
    
if(sentDate == None or sentDate == ''):
    mbo.setValueNull("DELIVERDATE")
    mbo.setValueNull("PROMISEDDATE")