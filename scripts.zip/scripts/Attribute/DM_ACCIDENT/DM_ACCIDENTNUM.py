from java.util import Calendar
from psdi.server import MXServer
from java.text import SimpleDateFormat

accidentDate = mbo.getDate("ACCIDENTDATE")

if accidentDate is not None:
    cal = Calendar.getInstance()
    cal.setTime(accidentDate)
    year_str = SimpleDateFormat("yyyy").format(cal.getTime())

    myMXServer = MXServer.getMXServer()
    userInfo = mbo.getThisMboSet().getUserInfo()
    accidentMboSet = myMXServer.getMboSet("DM_ACCIDENT", userInfo)
    accidentMboSet.setWhere("dm_accidentid in (select max(dm_accidentid) from dm_accident)")
    accidentMboSet.reset()

    Accident = accidentMboSet.getMbo(0)
    if Accident:
        accidentNum = Accident.getString("accidentnum")
        acciNum = accidentNum[4:] if accidentNum and len(accidentNum) > 4 else "0"
    else:
        acciNum = "0"

    try:
        next_num = int(acciNum) + 1
    except ValueError:
        next_num = 1  

    formatted_num = "{:04d}".format(next_num)

    newAccidentNum = year_str + formatted_num
    mbo.setValue("ACCIDENTNUM", newAccidentNum)

else:
    mbo.setValueNull("ACCIDENTNUM")