from java.util import Date
from java.util import Calendar
from psdi.server import MXServer
from java.text import SimpleDateFormat

endDate = mbo.getDate("DELIVERDATE")
startDate = mbo.getDate("PROMISEDDATE")

if (endDate != None) and (startDate != None):
    stcal = Calendar.getInstance()
    stcal.setTime(startDate)

    encal = Calendar.getInstance()
    encal.setTime(endDate)

    calStart=0
    calStart=Calendar.getInstance()
    calStart.setTime(stcal.getTime())
    calFinish=0
    calFinish=Calendar.getInstance()
    calFinish.setTime(encal.getTime())
    cS=None
    eS=None
    diffDays=None

    if calStart.getTime()<calFinish.getTime():
        amount = mbo.getDouble("INSAPRVDAMT")
        if(amount is not None):
            penalty = (3.0/100) * amount
            mbo.setValue("PENALTY", penalty)
    else:
        mbo.setValue("PENALTY", 0.0)