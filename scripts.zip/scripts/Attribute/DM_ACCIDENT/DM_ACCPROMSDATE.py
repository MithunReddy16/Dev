promisedDate = mbo.getDate("PROMISEDDATE")
sentDate = mbo.getDate("SENTDATE")
accidentDate = mbo.getDate("ACCIDENTDATE")

if (promisedDate != None and sentDate != None and promisedDate < sentDate):
    service.error("dm_accpromsentdt","pomsentdt")
    
if (promisedDate != None and accidentDate != None and promisedDate < accidentDate):
    service.error("dm_accpromsaccdt","promsaccdt")
    
if(promisedDate == None or promisedDate == ''):
    mbo.setValueNull("DELIVERDATE")