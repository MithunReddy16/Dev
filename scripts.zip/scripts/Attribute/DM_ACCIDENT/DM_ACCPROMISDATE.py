from java.util import Date, Calendar
from psdi.server import MXServer
from java.text import SimpleDateFormat
from psdi.mbo import MboConstants

lpoDate = mbo.getDate("LPODATE")
woDays = mbo.getInt("WORKINGDAYS")

if lpoDate is not None and woDays != 0:
    stcal = Calendar.getInstance()
    stcal.setTime(lpoDate)
    
    calStart = Calendar.getInstance()
    calStart.setTime(stcal.getTime())
    
    cS = SimpleDateFormat("MM.dd.yyyy").format(calStart.getTime())
    
    myMXServer = MXServer.getMXServer()
    userInfo = mbo.getThisMboSet().getUserInfo()
    
    nwSet = myMXServer.getMboSet("WORKPERIOD", userInfo)
    
    whereClause = "calnum = 'WD' AND orgid = 'DMORG' AND WORKDATE > TO_DATE('" + cS + "', 'MM.dd.yyyy')"
    nwSet.setWhere(whereClause)
    nwSet.setOrderBy("WORKDATE")
    nwSet.reset()
    
    if nwSet.count() >= woDays:
        mbo.setValue("PROMISEDDATE", nwSet.getMbo(woDays - 1).getDate("WORKDATE"))
    else:
        mbo.setValueNull("PROMISEDDATE")
else:
    mbo.setValueNull("PROMISEDDATE")