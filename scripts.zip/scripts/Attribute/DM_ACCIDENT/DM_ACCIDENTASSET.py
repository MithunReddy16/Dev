plateNum = mbo.getString("PLATENUM")

if (plateNum == None or plateNum == ''):
    mbo.setValueNull("ASSETNUM")
    mbo.setValueNull("ASSETTAG")