MrrMbo = mbo

StatusHistorySet = MrrMbo.getMboSet('DM_MRRSTATUS')
StatusHistoryMbo = StatusHistorySet.addAtEnd()

StatusHistoryMbo.setValue('ORGID',MrrMbo.getString('ORGID'))	
StatusHistoryMbo.setValue('SITEID',MrrMbo.getString('SITEID'))
StatusHistoryMbo.setValue('MRRNUM',MrrMbo.getString('MRRNUM'))	
StatusHistoryMbo.setValue('CHANGEDBY',MrrMbo.getUserInfo().getPersonId())
StatusHistoryMbo.setValue('STATUSDATE',MrrMbo.getDate('STATUSDATE'))
StatusHistoryMbo.setValue('STATUS',MrrMbo.getString('STATUS'))