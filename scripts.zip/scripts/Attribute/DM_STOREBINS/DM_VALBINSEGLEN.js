/*
Created By: Ashok
Date: 9-MAY-2024
Req: Validate the bin segments values are exactly same as length

*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")


logger.error("***ASH***Sript DM_VALBINSEGLEN**START***")

seg01  = mbo.getString("BINSEG01")
seg02  = mbo.getString("BINSEG02")
seg03  = mbo.getString("BINSEG03")
seg04  = mbo.getString("BINSEG04")
seg05  = mbo.getString("BINSEG05")
logger.error("***ASH***Sript DM_VALBINSEGLEN**")
if(launchPoint=="SEG01VAL")
{
	logger.error("***ASH***Sript DM_VALBINSEGLEN**1")
	if(seg01.length()!=1)
	{
		logger.error("***ASH***Sript DM_VALBINSEGLEN**1.1")
		service.error("dm_locid","vallen1")
	}
}
else if(launchPoint=="SEG02VAL")
{
	if(seg02.length()!=1)
		service.error("dm_locid","vallen1")
}
else if(launchPoint=="SEG03VAL")
{
	if(seg03.length()!=3)
		service.error("dm_locid","vallen3")
}
else if(launchPoint=="SEG04VAL")
{
	if(seg04.length()!=1)
		service.error("dm_locid","vallen1")
}
else if(launchPoint=="SEG05VAL")
{
	if(seg05.length()!=3)
		service.error("dm_locid","vallen2")
	if(!seg05.matches("\\d+"))
	    service.error("dm_locid","valdigits")
}