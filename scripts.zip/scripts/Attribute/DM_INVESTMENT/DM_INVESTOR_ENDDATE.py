startdate = mbo.getDate("STARTDATE")
enddate = mbo.getDate("ENDDATE")

if(enddate <= startdate):
    service.error("dm_investor_enddate","laterenddate")