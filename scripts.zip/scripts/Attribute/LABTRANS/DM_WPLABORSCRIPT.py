# -------------------------------------------------------
# Author      : ram
# Date        : 2025-05-23
# Script Name : DM_WPLABORSCRIPT
# Description : This script is used in the Retrieve List 
#               launch point of the LABORCODE field in 
#               WPLABOR and LABTRNS. It filters the laborcode lookup 
#               based on the DM_MAINTSEC of the parent 
#               WORKORDER, regardless of whether the 
#               WPLABOR is for a WO or a task (WOTASK).
# -------------------------------------------------------
from psdi.util.logging import MXLoggerFactory
#from psdi.util.MXApplicationException import MXApplicationException

if launchPoint == "DM_WPLABOR":
    taskid = mbo.getString("TASKID")

    # Determine the correct owner
    if taskid:
        wo = mbo.getOwner().getOwner()  # WPTASK > WORKORDER
    else:
        wo = mbo.getOwner()  # WPLABOR > WORKORDER

    if wo is not None:
        maintsec = wo.getString("DM_MAINTSEC")
        #laborcode= mbo.getString("laborcode")
        if maintsec:
            relationObject = "LABOR"
            relationWhere=(
                "laborcode IN ("
                "SELECT laborcode FROM labor WHERE personid IN ("
                "SELECT personid FROM person WHERE (dm_section = '{}' OR dm_department = '{}') "
                "AND status = 'ACTIVE') and laborcode =:laborcode AND status = 'ACTIVE')"
            ).format(maintsec, maintsec)
            listWhere = (
                "laborcode IN ("
                "SELECT laborcode FROM labor WHERE personid IN ("
                "SELECT personid FROM person WHERE (dm_section = '{}' OR dm_department = '{}') "
                "AND status = 'ACTIVE') AND status = 'ACTIVE')"
            ).format(maintsec, maintsec)
            #service.error("dm", "genericerror", ["Invalid laborcode"+relationWhere])
    

if launchPoint=="DM_LABTRANS":     
    
    taskid = mbo.getString("ACTUALSTASKID")
    #laborcode=mbo.getString("laborcode")
    
    
    wo = mbo.getOwner()
   
    
    if wo is not None:
        maintsec = wo.getString("DM_MAINTSEC")
        #laborcode= mbo.getString("laborcode")
        if maintsec:
            relationObject = "LABORCRAFTRATE"
            relationWhere=(
                "laborcode IN ("
                "SELECT laborcode FROM labor WHERE personid IN ("
                "SELECT personid FROM person WHERE (dm_section = '{}' OR dm_department = '{}') "
                "AND status = 'ACTIVE') and laborcode =:laborcode AND status = 'ACTIVE')"
            ).format(maintsec, maintsec)
            listWhere = (
                "laborcode IN ("
                "SELECT laborcode FROM labor WHERE personid IN ("
                "SELECT personid FROM person WHERE (dm_section = '{}' OR dm_department = '{}') "
                "AND status = 'ACTIVE') AND status = 'ACTIVE')"
            ).format(maintsec, maintsec)
        else:
            maintDep = wo.getString("dm_maintdept")
            relationObject = "LABORCRAFTRATE"
            relationWhere=(
                "laborcode IN ("
                "SELECT laborcode FROM labor WHERE personid IN ("
                "SELECT personid FROM person WHERE (dm_department = '{}') "
                "AND status = 'ACTIVE') and laborcode =:laborcode AND status = 'ACTIVE')"
            ).format(maintDep)
            listWhere = (
                "laborcode IN ("
                "SELECT laborcode FROM labor WHERE personid IN ("
                "SELECT personid FROM person WHERE (dm_department = '{}') "
                "AND status = 'ACTIVE') AND status = 'ACTIVE')"
            ).format(maintDep)