appl =mbo.getThisMboSet().getParentApp()

if mbo.isNew() and appl=='DM_TR_PLUSGPO' and interactive :
    mbo.setValueNull('TOSITEID',11L)