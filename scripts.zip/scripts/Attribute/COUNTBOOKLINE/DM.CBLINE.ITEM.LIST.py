#author Mithun
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants
mylogger = MXLoggerFactory.getLogger("maximo.custom.inventory")
mylogger.debug("**DM.CBLINE.ITEM.LIST is START***** ")
cbMbo=mbo.getOwner()
storeroom=cbMbo.getString("STOREROOM")
if cbMbo is not None :
        #domainid="DM_MRRITEMNUM"
        relationObject = "ITEM"
        listWhere=("STATUS IN (select VALUE from synonymdomain where domainid ='ITEMSTATUS' and MAXVALUE IN ('ACTIVE','PLANNING','PENDOBS')) and 
                      "exists (SELECT 1 FROM INVENTORY WHERE ITEMNUM=ITEM.ITEMNUM AND ITEMSETID=ITEM.ITEMSETID AND LOCATION='"+storeroom+"' )  " )
        mylogger.debug("*****DM_MRLINE_ITEM***8.0")
        try :
            relationWhere= "itemnum=:itemnum  and STATUS IN (select VALUE from synonymdomain where domainid ='ITEMSTATUS' and MAXVALUE IN ('ACTIVE','PLANNING','PENDOBS')) and exists (SELECT 1 FROM INVENTORY WHERE ITEMNUM=ITEM.ITEMNUM AND ITEMSETID=ITEM.ITEMSETID AND LOCATION=LOCATION='"+storeroom+"' )"
        except :
            mylogger.debug("******* DM_MRRITEMNUM Error ****")
        mylogger.debug("******* DM_MRRITEMNUM ****"+str(relationWhere))
        srcKeys = ['ITEMNUM']
        targetKeys = ['ITEMNUM']