# ============================================================
# Aythor        :   Mithun 
# Description   :   For rotating assets (ASSETNUM is not null), DM_INITIALPHYSCNT must be 0 or 1.
# ============================================================

from psdi.util.logging import MXLoggerFactory
from psdi.server import MXServer
logger = MXLoggerFactory.getLogger("maximo.script")
asset_num        = mbo.getString("ASSETNUM")
initial_phys_cnt = mbo.getDouble("DM_INITIALPHYSCNT")
if asset_num is not None and asset_num.strip() != "":
    if initial_phys_cnt not in (0.0, 1.0):
        err_msg = ("For rotating asset, Physical Count must be 0 or 1." )
        service.error("scriptval", "scriptvalidationerror", [err_msg])