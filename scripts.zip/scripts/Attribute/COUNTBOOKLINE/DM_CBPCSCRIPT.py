from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.script.override_physcnt")


physCnt = mbo.getDouble("PHYSCNT")


if mbo.getBoolean("rotating"):

    mbo.setValue("PHYSCNT", mbo.getDouble("DM_INITIALPHYSCNT"), 2L)