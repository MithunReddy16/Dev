#modified Mithun
from psdi.util.logging import MXLoggerFactory
logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("**** mrline debug Started ***")
app = mbo.getThisMboSet().getParentApp()
parentMbo= mbo.getOwner()
storeloc=parentMbo.getString("STORELOC")
wonum = mbo.getString("wonum")
mrnum = mbo.getString("mrnum")
item =  mbo.getString("itemnum")


if launchPoint=='MRRLINE.QUANTITY':
    logger.debug("**** MRRLINE.QUANTITY debug Started1.1 ***")
    if parentMbo is not None and parentMbo.getString('STATUS') not in ('DRAFT','RETURN'):
        if parentMbo.getString('STATUS') not in ('DRAFT','RETURN') :
            mbovalue.setReadOnly(True)

if launchPoint=='MRRLINE.QUAVALID':
    if (item is not None and mrnum is not None and app=='DM_MRR' and (wonum is None or wonum =='')):
        logger.debug("*** in mr **")
        matusetransSet=mbo.getMboSet("$matusetrans","MATUSETRANS","issuetype in ('ISSUE','RETURN') and storeloc='"+storeloc+"' and itemnum='"+item+"' and mrnum='"+mrnum+"'")    
        if not matusetransSet.isEmpty() :
            totalQty=matusetransSet.sum("QUANTITY")
            totalQty=abs(totalQty)
            enterQty=mbo.getDouble("QUANTITY")
            if enterQty>totalQty :
                message=["Quantity should less than"+str(totalQty)]
                service.error("scriptval","scriptvalidationerror",message)

    elif (item is not None and wonum is not None and app=='DM_MRR' and (mrnum is None or mrnum =='')):
        logger.debug("**** mrline WO Started ***")
        matusetransSet=mbo.getMboSet("$matusetrans","MATUSETRANS","issuetype in ('ISSUE','RETURN') and storeloc='"+storeloc+"' and itemnum='"+item+"' and refwo='"+wonum+"'")
        if not matusetransSet.isEmpty() :
            totalQty=matusetransSet.sum("QUANTITY")
            totalQty=abs(totalQty)
            enterQty=mbo.getDouble("QUANTITY")
            if enterQty>totalQty :
                message=["Quantity should less than"+str(totalQty)]
                service.error("scriptval","scriptvalidationerror",message)

                
if launchPoint=='MRRLINE.MRNUM':
    if item is not None and mrnum is not None and app=='DM_MRR' and (wonum is None or wonum =='') :
        matusetransSet=mbo.getMboSet("$matusetrans","MATUSETRANS","issuetype in ('ISSUE','RETURN') and storeloc='"+storeloc+"' and itemnum='"+item+"' and mrnum='"+mrnum+"'")    
        if not matusetransSet.isEmpty() :
            totalQty=matusetransSet.sum("QUANTITY")
            totalQty=abs(totalQty)
            enterQty=mbo.getDouble("QUANTITY")
            if enterQty>totalQty :
                message=["Quantity should less than"+str(totalQty)]
                service.error("scriptval","scriptvalidationerror",message)
if launchPoint=='MRRLINE.WONUM':
    if item is not None and wonum is not None and app=='DM_MRR' and (mrnum is None or mrnum ==''):
        matusetransSet=mbo.getMboSet("$matusetrans","MATUSETRANS","issuetype in ('ISSUE','RETURN') and storeloc='"+storeloc+"' and itemnum='"+item+"' and refwo='"+wonum+"'")
        if not matusetransSet.isEmpty() :
            totalQty=matusetransSet.sum("QUANTITY")
            totalQty=abs(totalQty)
            enterQty=mbo.getDouble("QUANTITY")
            if enterQty>totalQty :
                message=["Quantity should less than"+str(totalQty)]
                service.error("scriptval","scriptvalidationerror",message)
                service.error("mrr","lessqty",[message])
                
                
if launchPoint=='MRRLINE.MR.ACT':
    if item is not None and mrnum is not None and app=='DM_MRR' and (wonum is None or wonum =='') :
        matusetransSet=mbo.getMboSet("$matusetrans","MATUSETRANS","issuetype in ('ISSUE','RETURN') and storeloc='"+storeloc+"' and itemnum='"+item+"' and mrnum='"+mrnum+"'")    
        if not matusetransSet.isEmpty() :
            unitCost=matusetransSet.getMbo(0).getString("UNITCOST")
            mbo.setValue("UNITCOST",unitCost)
                
                
if launchPoint=='MRRLINE.WO.ACT':
    if item is not None and wonum is not None and app=='DM_MRR' and (mrnum is None or mrnum ==''):
        matusetransSet=mbo.getMboSet("$matusetrans","MATUSETRANS","issuetype in ('ISSUE','RETURN') and storeloc='"+storeloc+"' and itemnum='"+item+"' and refwo='"+wonum+"'")
        if not matusetransSet.isEmpty() :
            unitCost=matusetransSet.getMbo(0).getString("UNITCOST")
            mbo.setValue("UNITCOST",unitCost)