#author Mithun
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants
mylogger = MXLoggerFactory.getLogger("maximo.custom.inventory")
mylogger.debug("**DM_MRRLINEITEM is START***** ")
mrrMbo=mbo.getOwner()
storeloc=mrrMbo.getString("STORELOC")
mylogger.debug("**returntype is ***** "+mrrMbo.getString("RETURNTYPE"))
if mrrMbo is not None :
    if mrrMbo.getString("RETURNTYPE") =="MR":
        domainid="DM_MRRITEMNUM"  #ITEM
        if mbo.isNull("MRNUM") :
            listWhere=("STATUS IN (select VALUE from synonymdomain where domainid ='ITEMSTATUS' and MAXVALUE IN ('ACTIVE','PLANNING','PENDOBS')) and 
                      "exists (SELECT 1 FROM INVENTORY WHERE ITEMNUM=ITEM.ITEMNUM AND ITEMSETID=ITEM.ITEMSETID AND LOCATION='"+storeloc+"' )  " )
                      
        elif not mbo.isNull("MRNUM") :
            listWhere=("SITEID = :SITEID AND STATUS IN (SELECT VALUE FROM synonymdomain WHERE domainid = 'MRSTATUS' AND MAXVALUE = 'APPR') AND
                        "EXISTS ( SELECT 1 FROM MRLINE WHERE MRNUM = :MRNUM AND SITEID = :SITEID and itemnum=item.itemnum  ) AND "
                        "exists (SELECT 1 FROM MATUSETRANS WHERE MRNUM=:WONUM AND SITEID=:SITEID and itemnum=item.itemnum )" )
              
    
    elif mrrMbo.getString("RETURNTYPE") =="WO":
        domainid="DM_MRRITEMNUM"  #ITEM
        #relationObject = "ITEM"
        if mbo.isNull("WONUM") :
            listWhere="STATUS IN (select VALUE from synonymdomain where domainid ='ITEMSTATUS' and MAXVALUE IN ('ACTIVE','PLANNING','PENDOBS')) and 
                      "exists (SELECT 1 FROM INVENTORY WHERE ITEMNUM=ITEM.ITEMNUM AND ITEMSETID=ITEM.ITEMSETID AND LOCATION='"+storeloc+"' )"
        elif not mbo.isNull("WONUM") :
            listWhere="STATUS IN (select VALUE from synonymdomain where domainid ='ITEMSTATUS' and MAXVALUE IN ('ACTIVE','PLANNING','PENDOBS')) and 
                      "exists (SELECT 1 FROM MATUSETRANS WHERE REFWO=:WONUM AND SITEID=:SITEID and itemnum=item.itemnum )"
    
    elif mrrMbo.getString("RETURNTYPE") in ["OnSite","Project"]:    
        #domainid="DM_MRRITEMNUM"
        relationObject = "ITEM"
        listWhere="STATUS IN (select VALUE from synonymdomain where domainid ='ITEMSTATUS' and MAXVALUE IN ('ACTIVE','PLANNING','PENDOBS')) and 
                    "exists (SELECT 1 FROM INVENTORY WHERE ITEMNUM=ITEM.ITEMNUM AND ITEMSETID=ITEM.ITEMSETID AND LOCATION='"+storeloc+"' )"
        mylogger.debug("*****DM_MRLINE_ITEM***8.0")
        try :
            relationWhere= "itemnum=:itemnum  and STATUS IN (select VALUE from synonymdomain where domainid ='ITEMSTATUS' and MAXVALUE IN ('ACTIVE','PLANNING','PENDOBS')) and exists (SELECT 1 FROM INVENTORY WHERE ITEMNUM=ITEM.ITEMNUM AND ITEMSETID=ITEM.ITEMSETID AND LOCATION='"+storeloc+"' )"
        except :
            mylogger.debug("******* DM_MRRITEMNUM Error ****")
        mylogger.debug("******* DM_MRRITEMNUM ****"+str(relationWhere))
        srcKeys = ['ITEMNUM']
        targetKeys = ['ITEMNUM']