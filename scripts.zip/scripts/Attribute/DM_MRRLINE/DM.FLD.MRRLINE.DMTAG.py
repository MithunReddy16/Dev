def setError(Msg):
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)

AssetSet =mbo.getMboSet('ASSET_TAG')
Asset = AssetSet.moveFirst()
if Asset:
    setError('Tag already register, Please select the asset from the Rotating Asset lookup')