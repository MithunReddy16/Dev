#author Mithun
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants
mylogger = MXLoggerFactory.getLogger("maximo.custom.inventory")
mrrMbo=mbo.getOwner()
if mrrMbo is not None :
    if mrrMbo.getString("RETURNTYPE") =="MR":
        domainid="DM_MRRMRNUM"  # MR
        if not mbo.isNull("ITEMNUM") :
            listWhere=("  SITEID = :SITEID AND DM_GRPORG=:STORELOC  AND STATUS IN (SELECT VALUE FROM synonymdomain WHERE domainid = 'MRSTATUS' AND MAXVALUE = 'APPR') AND "
                       "  EXISTS ( SELECT 1 FROM MRLINE WHERE MRNUM = MR.MRNUM AND SITEID = MR.SITEID AND ITEMNUM = :ITEMNUM )  AND "
                       "  EXISTS ( SELECT 1 FROM MATUSETRANS WHERE MRNUM = MR.MRNUM AND SITEID = MR.SITEID AND ITEMNUM = :ITEMNUM) AND WONUM IS NULL " )
        else :
            listWhere=("SITEID = :SITEID AND DM_GRPORG=:STORELOC  AND STATUS IN (SELECT VALUE FROM synonymdomain WHERE domainid = 'MRSTATUS' AND MAXVALUE = 'APPR') AND "
                        " EXISTS ( SELECT 1 FROM MRLINE WHERE MRNUM = MR.MRNUM AND SITEID = MR.SITEID  ) " 
                        " EXISTS ( SELECT 1 FROM MATUSETRANS WHERE MRNUM = MR.MRNUM AND SITEID = MR.SITEID ) AND WONUM IS NULL " )