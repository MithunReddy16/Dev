#Script validates that there are no duplicate rotaing assets in the MRR lines
if not mbovalue.isNull():
    current_assetunm = mbo.getString("ROTASSETNUM")
    current_mrlinenum = mbo.getString("MRRLINENUM")
    mrrLineSet = mbo.getThisMboSet()
    #if (not mrrLineSet.isEmpty()):
    mrrLineMbo = mrrLineSet.moveFirst()
    while mrrLineMbo:
        assetnum = mrrLineMbo.getString("ROTASSETNUM")
        mrlinenum = mrrLineMbo.getString("MRRLINENUM")
        if (current_assetunm==assetnum and mrlinenum!=current_mrlinenum):
            errorgroup="mrr"
            errorkey="assetnum"
        mrrLineMbo = mrrLineSet.moveNext()