from psdi.util.logging import MXLoggerFactory
logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("**** mrline debug Started ***1")

app = mbo.getThisMboSet().getParentApp()
Owner= mbo.getOwner()
storeloc=Owner.getString("STORELOC")
wonum = mbo.getString("wonum")
mrnum = mbo.getString("mrnum")
item =  mbo.getString("itemnum")
wcs = service.webclientsession()
if mbovalue.isNull():
    if launchPoint == 'MRR.ITEMNUM.ACT':
        mbo.setFieldFlag('Quantity',7L,False)
        mbo.setFieldFlag('UNITCOST',7L,False)
        #RotAssetCI=wcs.getControlInstance("DM_MRRLINE_ROTASSET")
        #if RotAssetCI:
        #    RotAssetCI.setVisibility(False)
        mbo.setValueNull('BINNUM',11L)
        mbo.setValue('UNITCOST',0.00)
    elif  launchPoint == 'MRR.ITEMNUM.INIT':
        mbo.setFieldFlag('Quantity',7L,False)
        mbo.setFieldFlag('UNITCOST',7L,False)
        #RotAssetCI=wcs.getControlInstance("DM_MRRLINE_ROTASSET")
        #if RotAssetCI:
        #    RotAssetCI.setVisibility(False)
        
        
else:
    if launchPoint == 'MRR.ITEMNUM.ACT':
        if mbo.getBoolean('ITEM.ROTATING'):
            #RotAssetCI=wcs.getControlInstance("DM_MRRLINE_ROTASSET")
            #if RotAssetCI:
            #    RotAssetCI.setVisibility(True)
            mbo.setValue('QUANTITY','1.00')
            mbo.setValue('UNITCOST','0.00')
            #mbo.setFieldFlag('ROTASSETNUM',128L,True)
            mbo.setFieldFlag('Quantity',7L,True)
            mbo.setFieldFlag('UNITCOST',7L,True)
        else:
            #RotAssetCI=wcs.getControlInstance("DM_MRRLINE_ROTASSET")
            #if RotAssetCI:
            #    RotAssetCI.setVisibility(False)
            #mbo.setFieldFlag('ROTASSETNUM',128L,False)   
            mbo.setFieldFlag('Quantity',7L,False)
            mbo.setFieldFlag('UNITCOST',7L,False)
            #mbo.setValue('UNITCOST',mbo.getString('INVENTORY.INVCOST.AVGCOST'))
        #mbo.setValue('BINNUM',mbo.getString('INVENTORY.BINNUM'),11L)
            """if  app=='DM_MRR' and (mrnum is not None or wonum is not None):
                if wonum is not None :
                    matusetransSet=mbo.getMboSet("$matusetrans","MATUSETRANS","issuetype in ('ISSUE','RETURN') and storeloc='"+storeloc+"' and itemnum='"+item+"' and refwo='"+wonum+"'")
                elif mrnum is not None :
                    matusetransSet=mbo.getMboSet("$matusetrans","MATUSETRANS","issuetype in ('ISSUE','RETURN') and storeloc='"+storeloc+"' and itemnum='"+item+"' and mrnum='"+mrnum+"'")    
                matusetransSet.reset()
                if not matusetransSet.isEmpty() :
                    unitCost=matusetransSet.getMbo(0).getString("UNITCOST")
                    mbo.setValue("UNITCOST",unitCost)"""
        mbo.setValue('BINNUM',mbo.getString('INVENTORY.BINNUM'),11L)
            
            
    elif  launchPoint == 'MRR.ITEMNUM.INIT':
        if mbo.getBoolean('ITEM.ROTATING'):
            RotAssetCI=wcs.getControlInstance("DM_MRRLINE_ROTASSET")
            if RotAssetCI:
                RotAssetCI.setVisibility(True)
            #mbo.setFieldFlag('ROTASSETNUM',128L,True)
            mbo.setFieldFlag('Quantity',7L,True)
            mbo.setFieldFlag('UNITCOST',7L,True)
        else:
            
            RotAssetCI=wcs.getControlInstance("DM_MRRLINE_ROTASSET")
            if RotAssetCI:
                RotAssetCI.setVisibility(False)
            mbo.setFieldFlag('Quantity',7L,False)
            mbo.setFieldFlag('UNITCOST',7L,False)
            mbo.setFieldFlag('ROTASSETNUM',128L,False)
            
            
            
# Below lines Modified by Mithun             
            
if launchPoint=='MRR.ITEMNUM.VAL':
    if  app=='DM_MRR' and (mrnum is not None or wonum is not None):
        if wonum is not None :
            matusetransSet=mbo.getMboSet("$matusetrans","MATUSETRANS","issuetype in ('ISSUE','RETURN') and storeloc='"+storeloc+"' and itemnum='"+item+"' and refwo='"+wonum+"'")
        elif mrnum is not None :
            matusetransSet=mbo.getMboSet("$matusetrans","MATUSETRANS","issuetype in ('ISSUE','RETURN') and storeloc='"+storeloc+"' and itemnum='"+item+"' and mrnum='"+mrnum+"'")    
        matusetransSet.reset()
        if not matusetransSet.isEmpty() :
            
            totalQty=matusetransSet.sum("QUANTITY")
            totalQty=abs(totalQty)
            enterQty=mbo.getDouble("QUANTITY")
            
            if enterQty>totalQty :
            
                message=["Quantity should less than"+str(totalQty)]
                service.error("scriptval","scriptvalidationerror",message)
                service.error("mrr","lessqty",[message])