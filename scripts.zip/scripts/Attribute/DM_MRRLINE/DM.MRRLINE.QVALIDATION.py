def setError(Msg):
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)
		

		
if launchPoint == "MRRLINE.QACCEPT.VAL":
    Field1 = "QACCEPT_NP"
    Field2 = "QREJECT_NP"
else:
    Field1 = "QREJECT_NP"
    Field2 = "QACCEPT_NP"

if not mbovalue.isNull():
    Value1 = mbovalue.getFloat()
    if mbo.isNull(Field2):
        Value2=0.00
    else:
        Value2=mbo.getFloat(Field2)
    
    #setError(str (Value1 + Value2))
    if (Value1 + Value2) > mbo.getFloat('QWINSP'):
        setError('Qauntity Accept and Quantity Rejected exceed Quantity Waiting Inspection')