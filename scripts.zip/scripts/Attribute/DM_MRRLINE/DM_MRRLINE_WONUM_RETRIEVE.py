#author Mithun
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants
mylogger = MXLoggerFactory.getLogger("maximo.custom.inventory")
mrrMbo=mbo.getOwner()
if mrrMbo is not None :
    if mrrMbo.getString("RETURNTYPE") =="WO":
        domainid="DM_MRRWONUM" #WORKORDER
        if not mbo.isNull("ITEMNUM") :
            listWhere=(" SITEID=:SITEID AND STATUS NOT IN (select VALUE from synonymdomain where domainid ='WOSTATUS' and MAXVALUE  IN ('WAPPR','CAN','CLOSE')) AND 
                       " ISTASK=0 AND EXISTS (SELECT 1 FROM MATUSETRANS WHERE REFWO=WORKORDER.WONUM AND SITEID=WORKORDER.SITEID AND ITEMNUM=:ITEMNUM and storeloc=:storeloc) " )
        elif mbo.isNull("ITEMNUM") :
            listWhere=(" SITEID=:SITEID AND STATUS NOT IN (select VALUE from synonymdomain where domainid ='WOSTATUS' and MAXVALUE  IN ('WAPPR','CAN','CLOSE')) and
                       "  ISTASK=0 AND EXISTS (SELECT 1 FROM MATUSETRANS WHERE REFWO=WORKORDER.WONUM AND SITEID=WORKORDER.SITEID and storeloc=:storeloc) " )