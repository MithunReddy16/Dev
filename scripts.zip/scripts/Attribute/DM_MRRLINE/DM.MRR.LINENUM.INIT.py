if mbo.isNew() and mbo.isNull('MRRLINENUM'):
	thisSet = mbo.getThisMboSet()
	newLineNum = thisSet.max('MRRLINENUM') + 1
	mbo.setValue('MRRLINENUM',newLineNum)