#Author Mithun 
#Date  08-10-26


regStatusHisSet=mbo.getMboSet("DM_ASSETREGFORMSTATUS")
regStatusHis=regStatusHisSet.addAtEnd()
regStatusHis.setValue('ORGID',mbo.getString('ORGID'))	
regStatusHis.setValue('SITEID',mbo.getString('SITEID'))
regStatusHis.setValue('FORMNUM',mbo.getString('FORMNUM'))	
regStatusHis.setValue('CHANGEDBY',mbo.getUserInfo().getPersonId())
#regStatusHis.setValue('STATUSDATE',mbo.getDate('STATUSDATE'))
regStatusHis.setValue('STATUS',mbo.getString('STATUS'))