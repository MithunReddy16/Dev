#------------------------------------------------------------------------

#Script Name :DM_ASSETREGFORM_MAINTAINER_ACT
#Description : script to set fields inputmode conditionally.
#Comment     :Used in Aseet Register Form Application
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          20-Sept-2025         Initiate version.

#------------------------------------------------------------------------

from psdi.mbo import MboConstants

service.log_debug("######################################## Start:" + scriptName+" ######################")

if launchPoint == 'DM_MAINTAINERDEPT':
    if mbo.isNull("MAINTAINERDEPT"):
        mbo.setFieldFlag("ASSIGNEE",MboConstants.READONLY,False)
    else:
        mbo.setFieldFlag("ASSIGNEE",MboConstants.READONLY,True)

if launchPoint == 'DM_ASSETREGFORM_ASSIGNEE_ACT':
    if mbo.isNull("ASSIGNEE"):
        mbo.setFieldFlag("MAINTAINERDEPT",MboConstants.READONLY,False)
    else:
        mbo.setFieldFlag("MAINTAINERDEPT",MboConstants.READONLY,True)

service.log_debug("######################################## End:" + scriptName+" ######################")