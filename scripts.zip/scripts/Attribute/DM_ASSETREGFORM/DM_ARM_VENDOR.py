# ------------------------------------------------------------
# Script     : DM_ARM_VENDOR
# Launch pt  : Attribute | DM_ASSETREGFORM.VENDOR | Action
# Author/Date: Mithun / 2026-10-16
# ------------------------------------------------------------
from psdi.mbo import MboConstants

scriptName = 'DM_ASSETREG_VENDOR_ACT'

newVendor = vendor or ''
oldVendor = vendor_previous or ''



service.log_debug('******%s: old VENDOR=%s new VENDOR=%s' % (scriptName, oldVendor, newVendor))


if newVendor != oldVendor and not mbo.isNull('CONTACT'):
    mbo.setValueNull('CONTACT', MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)
    service.log_debug('%s: CONTACT cleared' % scriptName)
else:
    service.log_debug('%s: no change, CONTACT kept' % scriptName)