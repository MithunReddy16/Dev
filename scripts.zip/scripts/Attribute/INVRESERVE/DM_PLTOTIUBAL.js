/*
Script: DM_PLTOTIUBAL
Created By: Ashok
Date: 13-Jan-2025
Req: To Display the Total Open Inventory Usage Balance 
*/

load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(java.time)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)



//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_PLTOTIUBAL**START***")

totopenIUSet=mbo.getMboSet("DM_TOTOPENIUBAL");
if(totopenIUSet!=null)
{
	totopenIUQty=totopenIUSet.sum("QUANTITY");
	logger.error("***ASH***Sript DM_PLTOTIUBAL**totopenIUQty="+totopenIUQty);
	if(totopenIUQty!=null)
	{
		mbo.setValue("DM_OPENIUBAL",totopenIUQty,2);
	}
	else
	{
		mbo.setValue("DM_OPENIUBAL","0",2);
	}
}
else
{
	mbo.setValue("DM_OPENIUBAL","0",2);
}
logger.error("***ASH***Sript DM_PLTOTIUBAL**END***")