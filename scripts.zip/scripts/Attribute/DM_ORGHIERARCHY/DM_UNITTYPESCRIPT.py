from psdi.mbo import MboConstants
from psdi.mbo import Mbo
from java.util import ArrayList
from jarray import array
List=[]
#ArrayList = Java.type("java.util.ArrayList");
if launchPoint == "DM_PARENT1":
         #unittype = mbo.getString('UNITTYPE')
    	    if (mbo.getString('UNITTYPE')=='SECTION'):
				    relationObject = "ALNDOMAIN";
				    relationWhere = "domainid = 'DM_ORGDEPT' and value =:parent1id"
				    listWhere = "domainid = 'DM_ORGDEPT'"
				    srcKeys=["VALUE","DESCRIPTION"]
				    targetKeys=["PARENT1ID","PARENT1NAME"]
				   
				    #listErrorGroup="system"
				    #listErrorKey="notvalid"
				    mbo.setValue("parent1type","DEPARTMENT",MboConstants.NOACCESSCHECK|MboConstants.NOVALIDATION);
				   # service.error("DM","genericerror",["Enter a valid value"])
            elif (mbo.getString('UNITTYPE')=='DEPARTMENT'):
				    relationObject = "ALNDOMAIN";
				    relationWhere = "domainid = 'DM_ORGSECT' and value =:parent1id"
				    listWhere = "domainid = 'DM_ORGSECT'"
				    srcKeys=["VALUE","DESCRIPTION"]
				    targetKeys=["PARENT1ID","PARENT1NAME"]
				    mbo.setValue("parent1type","SECTOR",MboConstants.NOACCESSCHECK|MboConstants.NOVALIDATION);

if launchPoint == "DM_PARENT2":
             
    	    if (mbo.getString('UNITTYPE')=='SECTION'):
				    relationObject = "ALNDOMAIN";
				    relationWhere = "domainid = 'DM_ORGSECT' and value =:parent2id"
				    listWhere = "domainid = 'DM_ORGSECT'"
				    srcKeys=["VALUE","DESCRIPTION"]
				    targetKeys=["PARENT2ID","PARENT2NAME"]
				    mbo.setValue("parent2type","SECTOR",MboConstants.NOACCESSCHECK|MboConstants.NOVALIDATION);
				    
if launchPoint == "DM_UNITTYPE":
            mbo.setValueNull("PARENT1ID",11L)
            mbo.setValueNull("PARENT2ID",11L)
            mbo.setValueNull("PARENT1TYPE",11L)
            mbo.setValueNull("PARENT2TYPE",11L)
            mbo.setValueNull("PARENT1NAME",11L)
            mbo.setValueNull("PARENT2NAME",11L)
         #unittype = mbo.getString('UNITTYPE')
            if (mbo.getString('UNITTYPE')=='SECTOR'):
                        mbo.setValueNull("PARENT1ID",11L)
                        mbo.setValueNull("PARENT2ID",11L)
                        mbo.setValueNull("PARENT1TYPE",11L)
                        mbo.setValueNull("PARENT2TYPE",11L)
    	                mbo.setFieldFlag("PARENT1ID", MboConstants.READONLY, True )
    	                mbo.setFieldFlag("PARENT2ID", MboConstants.READONLY, True )
    	    elif (mbo.getString('UNITTYPE')=='DEPARTMENT'):
    	               mbo.setValueNull("PARENT2ID",11L);
    	               mbo.setFieldFlag("PARENT2ID", MboConstants.READONLY, True )
    	               
    	               mbo.setFieldFlag("PARENT1ID", MboConstants.READONLY, False )
    	    elif (mbo.getString('UNITTYPE') !='SECTOR'):
    	          mbo.setFieldFlag("PARENT1ID", MboConstants.READONLY, False )
    	          mbo.setFieldFlag("PARENT2ID", MboConstants.READONLY, False )
                      #  mbo.setFieldFlag("PARENT1ID", MboConstants.REQUIRED, True)