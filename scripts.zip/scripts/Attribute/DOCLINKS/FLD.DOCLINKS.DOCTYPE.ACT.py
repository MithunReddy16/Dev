#FLD.DOCLINKS.DOCTYPE.ACT

from psdi.mbo import MboConstants
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory

myLogger = MXLoggerFactory.getLogger("maximo.custom")
myLogger.debug("FLD.DOCLINKS.DOCTYPE.ACT===STARTED")

Appl = mbo.getThisMboSet().getParentApp()
myLogger.debug("FLD.DOCLINKS.DOCTYPE.ACT App is-----"+str(Appl))

Relationship = mbo.getThisMboSet().getRelationName()

if Appl=='DM_DISPOSAL':
    if mbo.isNull('docversion'):
        DisposalLine = mbo.getOwner()
        if DisposalLine and DisposalLine.getName()=='DM_DISPOSALLINE':
            Disposal=DisposalLine.getOwner()
            if Disposal:
                if Disposal.getString('DISPOSALTYPE') =='Auction':
                    mbo.setValue("DOCTYPE", "Auction", MboConstants.NOVALIDATION)
                    mbo.setValue("docversion", "0", MboConstants.NOVALIDATION)
                elif Disposal.getString('DISPOSALTYPE') =='Direct Appointment':
                    mbo.setValue("DOCTYPE", "Committee", MboConstants.NOVALIDATION)
                    mbo.setValue("docversion", "0", MboConstants.NOVALIDATION)
                elif Disposal.getString('DISPOSALTYPE') =='Donate':
                    mbo.setValue("DOCTYPE", "Committee", MboConstants.NOVALIDATION)
                    mbo.setValue("docversion", "0", MboConstants.NOVALIDATION)
        elif DisposalLine and DisposalLine.getName()=='DM_DISPOSAL':
            Disposal = DisposalLine
            if Disposal.getString('DISPOSALTYPE') =='Auction':
                    mbo.setValue("DOCTYPE", "Auction", MboConstants.NOVALIDATION)
                    mbo.setValue("docversion", "0", MboConstants.NOVALIDATION)
            elif Disposal.getString('DISPOSALTYPE') =='Direct Appointment':
                mbo.setValue("DOCTYPE", "Committee", MboConstants.NOVALIDATION)
                mbo.setValue("docversion", "0", MboConstants.NOVALIDATION)
            elif Disposal.getString('DISPOSALTYPE') =='Donate':
                mbo.setValue("DOCTYPE", "Committee", MboConstants.NOVALIDATION)
                mbo.setValue("docversion", "0", MboConstants.NOVALIDATION)