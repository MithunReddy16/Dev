# Script: DM_WPServitemscript
# Created By: RAM
# Date: 19-JUN-2025
# use:based on itemnum it will fetch the contractline id from contractline 


from psdi.util.logging import MXLoggerFactory
from psdi.server import MXServer
from psdi.mbo import MboSet 

itemnum = mbo.getString("ITEMNUM")
contractnum = mbo.getString("DM_VENDCONTRACT")
vendor = mbo.getString("VENDOR")

if itemnum and contractnum and vendor:
    
    contractline_where = (
        "itemnum = '{}' AND contractnum = '{}'".format(itemnum, contractnum)
    )

    contractline_set = mbo.getMboSet("$contractline", "CONTRACTLINE", contractline_where)
    contractline = contractline_set.moveFirst()

    found = False
    while contractline:
        contract_set = contractline.getMboSet("CONTRACT")
        contract = contract_set.moveFirst()

        if contract:
            
            if (contract.getString("VENDOR") == vendor and
                contract.getString("STATUS") == "APPR" and
                contract.getString("CONTRACTNUM") == contractnum):
                #service.error("gree","fewfwe")
                contractlineid = contractline.getInt("CONTRACTLINEID")
                mbo.setValue("DM_CONTREFLINEID", contractlineid)
                found = True
                break

        contractline = contractline_set.moveNext()