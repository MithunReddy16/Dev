/*
Script: DM_JC_DISCVALUECALC
Launchpoint: DM_JC_WPM.DM_BTYPE
Desc: Job Calculation, Discount Value Calculation
Created By: Ashok
Date: 23-Sep-2024
Req: In WO Plans, when the Type is changed to CM from NW then the discounted value has to be re-added back to the Unit Cost


*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)

//from psdi.mbo import DBShortcut,SqlFormat


//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_JC_DISCVALUECALC**START***")
if(mbo.getString("DM_BTYPE").equalsIgnoreCase("CM") && mbo.getLong("DM_CONTREFLINEID")!=null)
{
	
	contractLineMbo=mbo.getMboSet("DM_CONTRACTLINE").getMbo(0);
	logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",contractLineMbo="+contractLineMbo)
	if(contractLineMbo!=null)
	{
		logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",contractLineMbo is not null")
		if(contractLineMbo.getString("DM_BTYPE").equalsIgnoreCase("NW"))
		{
			logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",DM_BTYPE TO CM ")
			contUnitCost=0
			if(contractLineMbo.getDouble("UNITCOST")!=null)
			{
				contUnitCost=contractLineMbo.getDouble("UNITCOST");
			}
			logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",contUnitCost="+contUnitCost)
			discpercent=0;
			contractMbo=contractLineMbo.getMboSet("CONTRACT").getMbo(0);
			if(contractMbo!=null)
			{
				if(contractMbo.getDouble("DM_DISCOUNT")!=null)
				{
					discpercent=contractMbo.getDouble("DM_DISCOUNT");
				}
			}
			logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",discpercent="+discpercent)
			//Percentage = (Obtained score x 100) / Total Score
			//3.0225+7%(0.211575) =3.23
			//7*TS(3.0225)/100=
			discountValue=(discpercent*contUnitCost)/100;
			logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",discountValue="+discountValue)
			mbo.setValue("UNITCOST",contUnitCost+discountValue,2);
			logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",UNITCOST="+(contUnitCost+discountValue))
		}
		if(contractLineMbo.getString("DM_BTYPE").equalsIgnoreCase("CM"))
		{
			logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",BTYPE= NW")
			mbo.setValue("UNITCOST",contractLineMbo.getDouble("UNITCOST"),2);
			logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",UNITCOST="+contractLineMbo.getDouble("UNITCOST"))
		}
	}
}
else if(mbo.getString("DM_BTYPE").equalsIgnoreCase("NW") && mbo.getLong("DM_CONTREFLINEID")!=null)
{
	contractLineMbo=mbo.getMboSet("DM_CONTRACTLINE").getMbo(0);
	logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",DM_BTYPE TO NW ")
	
	if(contractLineMbo!=null)
	{
		logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",contractLineMbo="+contractLineMbo)
		if(contractLineMbo.getString("DM_BTYPE").equalsIgnoreCase("NW"))
		{
			logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",BTYPE= NW")
			mbo.setValue("UNITCOST",contractLineMbo.getDouble("UNITCOST"),2);
			logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",UNITCOST="+contractLineMbo.getDouble("UNITCOST"))
		}
		if(contractLineMbo.getString("DM_BTYPE").equalsIgnoreCase("CM"))
		{
			logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",DM_BTYPE TO CM ")
			contUnitCost=0
			if(contractLineMbo.getDouble("UNITCOST")!=null)
			{
				contUnitCost=contractLineMbo.getDouble("UNITCOST");
			}
			logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",contUnitCost="+contUnitCost)
			discpercent=0;
			contractMbo=contractLineMbo.getMboSet("CONTRACT").getMbo(0);
			if(contractMbo!=null)
			{
				if(contractMbo.getDouble("DM_DISCOUNT")!=null)
				{
					discpercent=contractMbo.getDouble("DM_DISCOUNT");
				}
			}
			logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",discpercent="+discpercent)
			//Percentage = (Obtained score x 100) / Total Score
			//3.0225+7%(0.211575) =3.23
			//7*TS(3.0225)/100=
			discountValue=(discpercent*contUnitCost)/100;
			logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",discountValue="+discountValue)
			mbo.setValue("UNITCOST",contUnitCost-discountValue,2);
			logger.error("***ASH***Sript DM_JC_DISCVALUECALC**"+launchPoint+",UNITCOST="+(contUnitCost-discountValue))
		}
	}
}