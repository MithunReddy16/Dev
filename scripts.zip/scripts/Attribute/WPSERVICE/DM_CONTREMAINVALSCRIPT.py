# Script: DM_CONTREMAINVALSCRIPT
# Trigger: Attribute Launch Point on DM_VENDCONTRACT
# Object: WPSERVICE
#createdby:ram
#date:18-Jun-25
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory
logger = MXLoggerFactory.getLogger("maximo.dm")


contract_num = mbo.getString("DM_VENDCONTRACT")
orgid = mbo.getString("ORGID")

if contract_num and orgid:
        # Fetch the contract MBO
        contractSet = mbo.getMboSet("$CONTRACT", "CONTRACT", 
            "contractnum = '{}' AND orgid = '{}' AND status = 'APPR'".format(contract_num, orgid))
        contractMbo = contractSet.getMbo(0)

        if contractMbo:
            total_cost = contractMbo.getDouble("TOTALCOST")
            contract_id = contractMbo.getLong("CONTRACTID")
            #mbo.setValue("DM_CONTVALUE",total_cost,2L)
            # Get all approved POLINEs linked to this contract
            polineSet = contractMbo.getMboSet(
                "$POLINES", 
                "POLINE", 
                "contractrefid = {}".format(contract_id)
            )

            released_cost = 0.0
            for i in range(polineSet.count()):
                polineMbo = polineSet.getMbo(i)
                poMbo = polineMbo.getOwner()  # Get the parent PO

                if poMbo is not None and poMbo.getString("STATUS") == "APPR":
                    qty = polineMbo.getDouble("ORDERQTY")
                    unit_cost = polineMbo.getDouble("UNITCOST")
                    released_cost += qty * unit_cost

            remaining_cost = total_cost - released_cost


            # Set it to your custom field
            mbo.setValue("DM_REMAINVALUE", remaining_cost)
        else:
            mbo.setValue("DM_REMAINVALUE", 0.0)
else:            
    mbo.setValueNull("DM_REMAINVALUE", MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)