#script:DM_TRCONTVENSCRIPT
#createdby:ram
#date:18-Jul-25
#scope:for transport setting the vendor field based on the selected contract
from psdi.mbo import MboConstants
from psdi.util import MXApplicationException
from psdi.util.logging import MXLoggerFactory

logger = service.getLogger("maximo.dm")

logger.debug(">>> Entering script DM_IVCOMP")

if launchPoint=="DM_TRCONTVEN" or launchPoint== "DM_TRCONTITEM":
    
    app = mbo.getThisMboSet().getParentApp()
    if app == 'DM_PLUSTWO':
            contractnum = mbo.getString("dm_vendcontract")
    
            if contractnum:
                # Get matching contract MBO
                contractSet = mbo.getMboSet("$CONTRACT", "CONTRACT", "contractnum = '{}' AND status in (select value from synonymdomain where domainid = 'CONTRACTSTATUS' and maxvalue='APPR')".format(contractnum))
                contractMbo = contractSet.getMbo(0)
            
                if contractMbo:
                    vendor = contractMbo.getString("VENDOR")
                    #service.error("dm","genericerror",[""+vendor+""])
                    mbo.setValue("VENDOR", vendor, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)
                else:
                    mbo.setValueNull("VENDOR", MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)
                    mbo.setValueNull("itemnum", MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)
            else:
                mbo.setValueNull("VENDOR", MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)
                mbo.setValueNull("itemnum", MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)