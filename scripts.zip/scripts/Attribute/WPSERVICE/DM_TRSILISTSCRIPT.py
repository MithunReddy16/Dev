#script:DM_TRSILISTSCRIPT
#Createdby:Ram
#Creation Date:23-Jul-25
#scope: for transport wo,retrive the service items list based on selected contract using the domain
app = mbo.getThisMboSet().getParentApp()



if  app == "DM_PLUSTWO":
        domainid = "DM_SERVITEM"