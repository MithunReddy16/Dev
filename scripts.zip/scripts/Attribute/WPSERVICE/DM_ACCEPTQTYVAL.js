/*
Script: DM_ACCEPTQTYVAL
Created By: Ashok
Date: 15-Aug-2024
Req: Validate the Accept Quantity for below 2 conditions
	1. Check the Accept Qty <=Pending Qty 
	2. Check the Contract Line if the change in Qty is Allowed
*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)

//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_ACCEPTQTYVAL**START***launchpoint="+launchPoint)
if(mbo.getLong("DM_CONTREFLINEID")!=null && mbo.getDouble("DM_ACCEPTQTY")!=null && mbo.getDouble("DM_ACCEPTQTY")>0)
{
	requestQty=mbo.getDouble("ITEMQTY")
	pendqty=mbo.getDouble("DM_PENDINGQTY")
	acceptqty=mbo.getDouble("DM_ACCEPTQTY")
	contlineSet=mbo.getMboSet("$CONTRACTLINE","CONTRACTLINE","CONTRACTLINEID='"+mbo.getLong("DM_CONTREFLINEID")+"' and CHGQTYONUSE=0 and :DM_ACCEPTQTY is not null and :ITEMQTY!=:DM_ACCEPTQTY")
	logger.error("***ASH***Sript DM_ACCEPTQTYVAL**contlineSet where="+contlineSet.getCompleteWhere())
	if(contlineSet.count()>0)
	{
		errorgroup="dm_wocont"
		errorkey="nochangeqty"
	}
	else if(acceptqty>pendqty)
	{
		errorgroup="dm_wocont"
		errorkey="invalidqty"
	}
}