# STP_SCRIPT
if mbo.getBoolean("istask"):
    activity = mbo.getString("DM_WOACT.DESCRIPTION")
    mbo.setValue("description",activity)