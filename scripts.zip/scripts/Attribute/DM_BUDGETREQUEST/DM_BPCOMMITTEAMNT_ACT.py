#------------------------------------------------------------------------

#Script Name :DM_BPALLOCAMOUNT_INIT
#Description :Budget Request Allocated Amount
#Comment     :Used in Budget Plan Application.  
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-Jan-2026         Initiate version.

#------------------------------------------------------------------------
#calculate the total committed budget amount
requestType= mbo.getString("requesttype")
# calculate the allocated and remaining amount for Main Budget Plan
if requestType == "DM":
    budgetDeptSet = mbo.getMboSet("DMBUDGETENTRY")
    budgetDeptSet.reset()
    commitAmount = budgetDeptSet.sum("COMMITTEDCOST")
    mbo.setValue("COMMITTEDBUDGETIU",commitAmount)

if requestType == "DEPARTMENT":
    budgetDeptSet = mbo.getMboSet("DEPBUDGETENTRY")
    budgetDeptSet.reset()
    commitAmount = budgetDeptSet.sum("COMMITTEDCOST")
    mbo.setValue("COMMITTEDBUDGETIU",commitAmount)