#------------------------------------------------------------------------

#Script Name :DM_BPALLOCAMOUNT_INIT
#Description :Budget Request Allocated Amount
#Comment     :Used in Budget Plan Application.  
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-Jan-2026         Initiate version.

#------------------------------------------------------------------------

requestType= mbo.getString("requesttype")
# calculate the allocated and remaining amount for Main Budget Plan
if requestType == "DM":
    budgetDeptSet = mbo.getMboSet("DEPARTMENTREQUEST")
    budgetDeptSet.reset()
    allocatedAmount = budgetDeptSet.sum("BUDGETAMOUNT")
    mbo.setValue("ALLOCATEDAMOUNT",allocatedAmount)
    totalBudget = mbo.getDouble("BUDGETAMOUNT")
    mbo.setValue("REMAININGAMOUNT",totalBudget-allocatedAmount)