#------------------------------------------------------------------------

#Script Name :DM_BPREQUEST_ABOVECIELING_INIT
#Description :Calculate the budget above ceiling amounts
#Comment     :Used in Budget Plan Application.  
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-Jan-2026         Initiate version.

#------------------------------------------------------------------------

requestType= mbo.getString("requesttype")

if requestType=="DEPARTMENT":
    budgetEntryACSet = mbo.getMboSet("DM_BPREQUEST_ABOVECEILING$$","DM_BUDGETENTRY","depbpid=:dm_budgetrequestid and withinceiling=0")
    budgetEntryACSet.reset()
    totalAmountAC = budgetEntryACSet.sum("ESTIMATEDCOST")
    mbo.setValue("ABOVECEILINGAMOUNT",totalAmountAC)
    budgetEntryWCSet = mbo.getMboSet("DM_BPREQUEST_WITHINCEILING$$","DM_BUDGETENTRY","depbpid=:dm_budgetrequestid and withinceiling=1")
    budgetEntryWCSet.reset()
    totalAmountWC = budgetEntryWCSet.sum("ESTIMATEDCOST")
    mbo.setValue("INCEILINGAMOUNT",totalAmountWC)
    
if requestType=="SECTION":
    budgetEntryACSet = mbo.getMboSet("DM_BPREQUEST_ABOVECEILING$$","DM_BUDGETENTRY","SECBPID=:dm_budgetrequestid and withinceiling=0")
    budgetEntryACSet.reset()
    totalAmountAC = budgetEntryACSet.sum("ESTIMATEDCOST")
    mbo.setValue("ABOVECEILINGAMOUNT",totalAmountAC)
    budgetEntryWCSet = mbo.getMboSet("DM_BPREQUEST_WITHINCEILING$$","DM_BUDGETENTRY","SECBPID=:dm_budgetrequestid and withinceiling=1")
    budgetEntryWCSet.reset()
    totalAmountWC = budgetEntryWCSet.sum("ESTIMATEDCOST")
    mbo.setValue("INCEILINGAMOUNT",totalAmountWC)