#------------------------------------------------------------------------

#Script Name :DM_BUDGETREQUEST.INIT
#Description :Budget Plan Init Script
#Comment     :Used in Budget Plan Application.  
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-Jan-2026         Initiate version.

#------------------------------------------------------------------------
from psdi.mbo import MboConstants

if mbo.getString("STATUS") != "DRAFT":
    mbo.setFieldFlag("BUDGETSTARTDATE",MboConstants.READONLY,True)
    mbo.setFieldFlag("YEAROFBUDGET",MboConstants.READONLY,True)
    mbo.setFieldFlag("BUDGETENDDATE",MboConstants.READONLY,True)
    mbo.setFieldFlag("DESCRIPTION",MboConstants.READONLY,True)
else: 
    mbo.setFieldFlag("BUDGETSTARTDATE",MboConstants.READONLY,False)
    mbo.setFieldFlag("YEAROFBUDGET",MboConstants.READONLY,False)
    mbo.setFieldFlag("BUDGETENDDATE",MboConstants.READONLY,False)
    mbo.setFieldFlag("DESCRIPTION",MboConstants.READONLY,False)