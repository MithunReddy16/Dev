/*
Created By: Ashok
Date: 7-MAY-2024
Req: We need to send an email notification to people in DM_DIS10 person group. The notification should the following details :

Disposal Number
Link to disposal
List of assets and their last status.


*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")


logger.error("***ASH***Sript DM_DPNOTIFICATION**START***")
if(mbo.getString("STATUS").equalsIgnoreCase("CLOSED"))
{
	disposalLineSet=mbo.getMboSet("DM_DISPOSALLINE")
	tbheader="<table border=1><tr><td>Line#</td><td>Asset</td><td>Description</td><td>Quantity</td><td>Unit</td><td>Status</td></tr>"
	logger.error("***ASH***Sript DM_DPNOTIFICATION**disposalLineSet.count()="+disposalLineSet.count())
	tbbody="";
	flag=0
	for(i=0;(disposalLineMbo=disposalLineSet.getMbo(i))!=null;i++)
	{
		flag=1;
		tbbody+="<tr><td>"+disposalLineMbo.getString("DISPOSALLINENUM")+"</td><td>"+disposalLineMbo.getString("ASSETNUM")+"</td><td>"+disposalLineMbo.getString("DESCRIPTION")+"</td><td>"+disposalLineMbo.getDouble("QUANTITY")+"</td><td>"+disposalLineMbo.getString("MEASUREUNIT")+"</td><td>"+disposalLineMbo.getString("ASSET.STATUS")+"</td></tr>"
	}
	tbfooter="</table>"
	tbContent=tbheader+""+tbbody+""+tbfooter;
	logger.error("***ASH***Sript DM_DPNOTIFICATION**tbContent="+tbContent)
	if(flag==1)
	{
		mbo.setValue("STATUS_LONGDESCRIPTION",tbContent,11)
		logger.error("***ASH***Sript DM_DPNOTIFICATION**STATUS_LONGDESCRIPTION value set")
	}
	
	clMbo = mbo.createComm()
	clMbo.setValue("TEMPLATEID", "DM_DPCLOSENOTF")
	try{
	  clMbo.sendMessage()
	  logger.error("***ASH***Sript DM_DPNOTIFICATION**mail sent successful")
	}
	catch(exception1)
	{
	  clMbo.setValue("ISSENDFAIL", True, mbo.NOACCESSCHECK)
	  logger.error("***ASH***Sript DM_DPNOTIFICATION**mail sent Failed"+exception1)
	}
	
}