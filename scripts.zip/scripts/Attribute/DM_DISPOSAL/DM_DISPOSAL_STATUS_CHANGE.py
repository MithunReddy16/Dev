#DM_DISPOSAL_STATUS_CHANGE

from psdi.server import MXServer
from  psdi.common.context import UIContext
from psdi.webclient.system.controller import SessionContext, Utility, WebClientEvent

mxServer = MXServer.getMXServer()
from psdi.util.logging import MXLoggerFactory
myLogger = MXLoggerFactory.getLogger("maximo.custom")


#app = service.webclientsession().getCurrentApp()
#DisposalSet = app.getResultsBean().getMboSet()
#isTableSelect = app.getResultsBean().getTableStateFlags().isFlagSet(ResultsBean.TABLE_SUBSELECT_ON)


def setError(Msg):
		#global errorkey,errorgroup,params
		#errorkey='scriptvalidationerror'
		#errorgroup='scriptval'
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)



# Disposal (HEADER) Status Field
if launchPoint == 'DISPOSAL.STATUS':
	
	DisposalMbo = mbo
	
	StatusHistorySet = DisposalMbo.getMboSet(HeaderStatusSet)
	StatusHistoryMbo = StatusHistorySet.addAtEnd()
	
	StatusHistoryMbo.setValue('ORGID',DisposalMbo.getString('ORGID'))	
	StatusHistoryMbo.setValue('SITEID',DisposalMbo.getString('SITEID'))
	StatusHistoryMbo.setValue('DISPOSALNUM',DisposalMbo.getString('DISPOSALNUM'))	
	StatusHistoryMbo.setValue('STATUSDATE',DisposalMbo.getDate('STATUSDATE'))
	StatusHistoryMbo.setValue('STATUS',DisposalMbo.getString('STATUS'))
	
	if DisposalMbo.getString('STATUS') == 'CAN':
		LineSet = DisposalMbo.getMboSet('DM_DISPOSALLINE')	
		DisposalLineMbo = LineSet.moveFirst()
		while (DisposalLineMbo):
			if not DisposalLineMbo.getMboSet('REFSOURCELINES').isEmpty():
				SourceLine= DisposalLineMbo.getMboSet('REFSOURCELINES').getMbo(0)
				SourceLine.setValueNull('REFDISPOSALNUM',11L)
				SourceLine.setValueNull('REFDISPOSALLINENUM',11L)
				SourceLine.setValueNull('REFDISPOSALLINEID',11L)
			
			DisposalLineMbo = LineSet.moveNext()