#------------------------------------------------------------------------

#Script Name :DM_DISPOSAL_ISLOCALMAINTAINER_ACT
#Description :prevent the user changing the value if already the lines have created.
#Comment     :Used in Decommission Request application
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-09-2025         Initiate version.

#------------------------------------------------------------------------

if mbo.getMboSet("DM_DISPOSALLINE").getMbo(0) is not None:
    service.error("dm_disposal","dmfieldcantchange")