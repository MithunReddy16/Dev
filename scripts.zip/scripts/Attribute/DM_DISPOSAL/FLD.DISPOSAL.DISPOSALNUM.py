if mbo.isNew():
    if app=='DM_DECOM':
        mbo.setValue('disposalnum','ADR-' + mbo.getString('disposalnum'),11L)