#------------------------------------------------------------------------

#Script Name :DM_DISPOSAL_ISLOCALMAINTAINER_ACT
#Description :set maintainer department null if value is true. 
#Comment     :Used in Decommission Request application
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-09-2025         Initiate version.

#------------------------------------------------------------------------

#set maintainer department if value is true.
if mbo.getBoolean("ISLOCALMAINTAINER"):
    mbo.setValueNull("MAINTAINERDEPT")