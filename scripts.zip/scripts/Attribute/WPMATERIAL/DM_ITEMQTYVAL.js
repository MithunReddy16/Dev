/*
Script: DM_ITEMQTYVAL
Created By: Ashok
Date: 16-Aug-2024
Req: Validate the Accept Quantity for below 2 conditions
	1. Check if the Contractlineid presents then itemqty should not cross the contract line qty
	2. itemqty is readonly/ error , if the contractline change in Qty (CONTRACTLINE.CHGQTYONUSE) is not Allowed
*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)

//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_ITEMQTYVAL**START***launchpoint="+launchPoint)
if(mbo.getLong("DM_CONTREFLINEID")!=null)
{
	requestQty=mbo.getDouble("ITEMQTY")
	pendqty=mbo.getDouble("DM_PENDINGQTY")
	acceptqty=mbo.getDouble("DM_ACCEPTQTY")
	contlineMbo=mbo.getMboSet("$CONTRACTLINE","CONTRACTLINE","CONTRACTLINEID=:DM_CONTREFLINEID").getMbo(0)
	logger.error("***ASH***Sript DM_ITEMQTYVAL** contlineMbo="+contlineMbo)
	if(contlineMbo!=null)
	{
		if(contlineMbo.getInt("CHGQTYONUSE")) //1 - true
		{
			if(requestQty>contlineMbo.getDouble("ORDERQTY"))
			{
				errorgroup="dm_wocont"
				errorkey="invaliditemqty"
			}
		}
		else //0 
		{
			if(requestQty!=contlineMbo.getDouble("ORDERQTY"))
			{
				errorgroup="dm_wocont"
				errorkey="nochangeqty"
			}
		}
	}
}
logger.error("***ASH***Sript DM_ITEMQTYVAL**END***launchpoint="+launchPoint)