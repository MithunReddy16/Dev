from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants



AppName=mbo.getThisMboSet().getParentApp()
#service.error("","AppName:"+AppName)
if itemnum and AppName in ('DM_CREATEDR','DM_VIEWIDR') :
    # below Code added by Mithun to Update avgcost from invcost to unitcost in MRLINE.  
    if  mbo.isNew()!=0 or mbo.isNew()==0 :
        invCostSet=mbo.getMboSet("INVENTORY.INVCOST")
        invCost=invCostSet.getMbo(0)
        avgcost=invCost.getDouble("AVGCOST")
        mbo.setValue("UNITCOST",avgcost)