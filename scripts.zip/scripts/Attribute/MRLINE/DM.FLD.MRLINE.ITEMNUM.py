from psdi.server import MXServer
from psdi.mbo import SqlFormat
application = mbo.getThisMboSet().getParentApp()
if application== "DM_CREATEDR" or application == "DM_VIEWIDR" or application=="DM_PLUSGWO_SRWN":
    userInfo =MXServer.getMXServer().getSystemUserInfo()
    if launchPoint =="FLD.ITEM.VAL":
        if not mbovalue.isNull():
            MR = mbo.getOwner()
            
            StoreLoc = MR.getString('DM_GRPORG')
            ItemSet = MXServer.getMXServer().getMboSet('ITEM',userInfo)
            whereclause= "ITEMNUM=:1 AND DM_INTERNALENABLED=1 and exists (select 1 from inventory where itemnum=ITEM.itemnum and siteid=:2 and location =:3) " 
            sqlFormat = SqlFormat(userInfo, whereclause)    
            sqlFormat.setObject(1, "ITEM", "ITEMNUM", mbo.getString('ITEMNUM'))
            sqlFormat.setObject(2, "INVENTORY", "siteid", mbo.getString('SITEID'))
            sqlFormat.setObject(3, "INVENTORY", "LOCATION", StoreLoc)
            ItemSet.setWhere(sqlFormat.format())
            Item = ItemSet.moveFirst()
            if not Item:
                service.error('scriptval','scriptvalidationerror',['Invalid Item'])
            else:
                mbo.setValue('STORELOCSITE',mbo.getString('SITEID'))
                mbo.setValue('STORELOC',StoreLoc)
            
            ItemSet.cleanup()
            ItemSet.close()