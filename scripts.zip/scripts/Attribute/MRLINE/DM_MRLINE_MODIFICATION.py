from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
myLogger = MXLoggerFactory.getLogger("maximo.custom")

owner = mbo.getOwner()
if(owner is not None and owner.getName()=='MR'):
    status = owner.getString("STATUS")
    if(status in ('CCRETURNMM','PENDINGMM','MURETURNMM')):
        mrnum = mbo.getString('MRNUM') 
        itemnum = mbo.getString("ITEMNUM")
        requestedBy = owner.getString("REQUESTEDBY")
        itemSet = mbo.getMboSet("ITEM")
        if (not itemSet.isEmpty()):
            itemMbo = itemSet.getMbo(0)
            mainUser = itemMbo.getString("DM_MAINUSER")
            myLogger.info('Processing MR: {}'.format(mrnum))
            mbo.setValue("DM_APPR",False,2L)
            mbo.setValue("DM_DDAPPR",False,2L)
            mbo.setValue("DM_SMAPPR",False,2L)
            #If the requestedby is same as main user, DM_MUAPPR flag is not changed
            if (mainUser != ''):
                personGroup = itemMbo.getMboSet("$PERSONGROUP","PERSONGROUPTEAM","persongroup = '" +mainUser+ "' and RESPPARTYGROUP = '" +requestedBy+ "' ")
                if (personGroup.isEmpty()):
                    mbo.setValue("DM_MUAPPR",False,2L)
                    #personGroupMbo = personGroup.getMbo(0)
                    #person = personGroupMbo.getString("RESPPARTYGROUP")
                personGroup.clear()
                personGroup.close()
            #If the requestedby is same as category controller approver, DM_CCAPPR flag is not changed      
            commodity = itemMbo.getString("COMMODITY")
            commodity_parts = commodity.split('-')
            if len(commodity_parts) > 1:
    			commodity_prefix = commodity_parts[0]
    			commodity_number = int(commodity_parts[1])
    			commodity_suffix = commodity_parts[1]
    			dm_mra_set = MXServer.getMXServer().getMboSet("DM_MRA", mbo.getUserInfo())
    			dm_mra_set.reset()
    			if(not dm_mra_set.isEmpty()):
        		    dm_mra_mbo = dm_mra_set.moveFirst()
        		    approveby=''
        		    while (dm_mra_mbo is not None):
        		        from_category = dm_mra_mbo.getString("FROMCATEGORY")
        		        to_category = dm_mra_mbo.getString("TOCATEGORY")
        		        from_category_parts = from_category.split('-')
        		        to_category_parts = to_category.split('-')
        		        if len(from_category_parts) > 1 and len(to_category_parts) > 1:
        		            from_category_prefix = from_category_parts[0]
        		            from_category_number = int(from_category_parts[1])
        		            from_category_suffix = from_category_parts[1]
        		            to_category_prefix = to_category_parts[0]
        		            to_category_number = int(to_category_parts[1])
        		            to_category_suffix = to_category_parts[1]
        		            if commodity_prefix == from_category_prefix == to_category_prefix:
        		                if from_category_number <= commodity_number <= to_category_number:
        		                    approveby = dm_mra_mbo.getString("APPROVEBY")
        		                    break;
        		        dm_mra_mbo = dm_mra_set.moveNext()
        		    personGroup = itemMbo.getMboSet("$PERSONGROUP","PERSONGROUPTEAM","persongroup = '" +approveby+ "' and RESPPARTYGROUP = '"+requestedBy+ "' " )
        		    if (personGroup.isEmpty()):
        		        mbo.setValue("DM_CCAPPR",False,2L)
        		    personGroup.clear()
        		    personGroup.close()