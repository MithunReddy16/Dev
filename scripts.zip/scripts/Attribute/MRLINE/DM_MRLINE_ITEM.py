# =============================================================
# SCRIPT   : DM_MRLINE_ITEM
# OBJECT   : MRLINE
# ATTRIBUTE: ITEMNUM
# EVENT    : RETRIEVELIST
# AUTHOR   : Mithun
# =============================================================
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants
mylogger = MXLoggerFactory.getLogger("maximo.custom.inventory")
mylogger.debug("*****DM_MRLINE_ITEM***7.25")
parent=mbo.getOwner()
superOwner=parent.getOwner()
# Below if is for Internal Requestion 
if superOwner  is None :
    mylogger.debug("*****DM_MRLINE_ITEM***7***:"+str(parent.getName()))
    mylogger.debug("*****DM_MRLINE_ITEM***7.0***:"+str(superOwner))
    if parent is not None and parent.getName() == 'MR': 
        AppName=mbo.getThisMboSet().getParentApp()
        mylogger.debug("*****DM_MRLINE_ITEM***8***:"+str(AppName))
        if  AppName in ('DM_CREATEDR','DM_VIEWIDR')   :
            if mbo.getOwner() :
                dmGrpOrg=mbo.getOwner().getString("DM_GRPORG")
                #itemSet1 = MXServer.getMXServer().getMboSet("ITEM", mbo.getUserInfo())
                relationObject = "ITEM"
                listWhere = (" DM_INTERNALENABLED = 1 AND STATUS = 'ACTIVE'  "
                    "    AND EXISTS (SELECT 1 FROM INVENTORY WHERE ITEMNUM = ITEM.ITEMNUM AND LOCATION = '" + dmGrpOrg + "'  ) " )
                mylogger.debug("*****DM_MRLINE_ITEM***8.0")
                relationWhere= (" DM_INTERNALENABLED = 1 AND STATUS = 'ACTIVE'  "
                    "    AND EXISTS (SELECT 1 FROM INVENTORY WHERE ITEMNUM = ITEM.ITEMNUM AND LOCATION = '" + dmGrpOrg + "'  ) " )
                srcKeys = ['ITEMNUM']
                targetKeys = ['ITEMNUM']
                mylogger.debug("*****DM_MRLINE_ITEM***8")
# Below if is for Work Order(STP) and Work order (TR)
elif superOwner  is not None :
    AppName=mbo.getThisMboSet().getParentApp()
    mylogger.debug("*****DM_MRLINE_ITEM***8.1"+str(AppName))
    if  AppName in ('DM_PLUSGWO_STP','DM_PLUSTWO')   :
        relationObject = "ITEM"
        store=mbo.getString("STORELOC")
        listWhere = (" STATUS = 'ACTIVE'  AND EXISTS (SELECT 1 FROM INVENTORY WHERE ITEMNUM = ITEM.ITEMNUM AND LOCATION = '" + store + "'  ) " )
        relationWhere = (" STATUS = 'ACTIVE'  AND EXISTS (SELECT 1 FROM INVENTORY WHERE ITEMNUM = ITEM.ITEMNUM AND LOCATION = '" + store + "'  ) " )        
        srcKeys = ['ITEMNUM']
        targetKeys = ['ITEMNUM']
    elif AppName in ('DM_PLUSGWO_SRWN'):
        relationObject = "ITEM"
        store=mbo.getString("STORELOC")
        listWhere = (" STATUS = 'ACTIVE' AND DM_INTERNALENABLED=1  AND EXISTS (SELECT 1 FROM INVENTORY WHERE ITEMNUM = ITEM.ITEMNUM AND LOCATION = '" + store + "'  ) " )
        relationWhere = (" STATUS = 'ACTIVE' AND DM_INTERNALENABLED=1  AND EXISTS (SELECT 1 FROM INVENTORY WHERE ITEMNUM = ITEM.ITEMNUM AND LOCATION = '" + store + "'  ) " )        
        srcKeys = ['ITEMNUM']
        targetKeys = ['ITEMNUM']    

else :
    mylogger.debug("*****DM_MRLINE_ITEM***9**"+str(AppName))
    relationObject = "ITEM"
    listWhere = (" STATUS = 'ACTIVE' AND EXISTS (SELECT 1 FROM INVENTORY WHERE ITEMNUM = ITEM.ITEMNUM ) " )
    relationWhere = (" STATUS = 'ACTIVE' AND EXISTS (SELECT 1 FROM INVENTORY WHERE ITEMNUM = ITEM.ITEMNUM ) " )
    srcKeys = ['ITEMNUM']
    targetKeys = ['ITEMNUM']