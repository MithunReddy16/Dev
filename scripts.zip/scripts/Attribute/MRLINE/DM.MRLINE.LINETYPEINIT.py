MrMbo = mbo.getOwner()

if mbo.toBeAdded() and mbo.getString('LINETYPE') == 'ITEM':
    if MrMbo and MrMbo.getString('DM_TYPE') =='OSP':
        mbo.setValue('LINETYPE','SERVICE')
    else:
        mbo.setValue('LINETYPE','ITEM')