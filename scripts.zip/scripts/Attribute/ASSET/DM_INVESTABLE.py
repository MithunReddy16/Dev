if (not mbo.getMboSet("DM_ACTIVEINVESTOR").isEmpty() or not mbo.getMboSet("DM_INACTIVEINVESTOR").isEmpty()) and mbo.getInt("DM_INVESTABLE") == 0 : 
    service.error("dm_investable","invest")