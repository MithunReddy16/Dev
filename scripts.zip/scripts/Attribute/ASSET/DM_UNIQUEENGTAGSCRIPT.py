if launchPoint=="DM_UNIQUEENGTAG":
    assetset = mbo.getMboSet("$DM_ENGTAG","Asset","assetnum!='"+mbo.getString("Assetnum")+"' and siteid='"+mbo.getString("siteid")+"' and DM_ASSETDEP_NUM='"+mbo.getString("DM_ASSETDEP_NUM")+"'")
    if not assetset.isEmpty():
        service.error("dm", "genericerror",["unique Engineering tag is allowed"])
    

if launchPoint=="DM_UNIQUEOLDETAG":
    assetset = mbo.getMboSet("$DM_ENGOLDTAG","Asset","assetnum!='"+mbo.getString("Assetnum")+"' and siteid='"+mbo.getString("siteid")+"' and DM_ASSETLEGACYDEPTNUM='"+mbo.getString("DM_ASSETLEGACYDEPTNUM")+"'")
    if not assetset.isEmpty():
        service.error("dm", "genericerror",["unique Old tag is allowed"])