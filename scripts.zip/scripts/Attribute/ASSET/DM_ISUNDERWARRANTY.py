#script:DM_ISUNDERWARRANTY
#Createdby:Ram
#Creation Date:15-Dec-24
#scope:based on the warranty required option ,warrranty expiry date wil be updated
#if warranty is not required then warranty expiry date will be updated to none
#Modified: 01/10/2025, NK
#if warranty is not required then update warranty start date and end date to null
isWarrnty = mbo.getInt("DM_ISUNDERWARRANTY")
    
if(isWarrnty == 0):
    mbo.setValueNull("WARRANTYEXPDATE")
    mbo.setValueNull("DM_WARRANTYSTDATE")