load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.java.lang)


logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_LOCSEARCH**START***")

if(mbo.isZombie())
{
	logger.error("***ASH***Sript DM_LOCSEARCH**its zombie mbo***")
	logger.error("***ASH***Sript DM_LOCSEARCH**mbo.getThisMboSet().count()="+mbo.getThisMboSet().count())
	logger.error("***ASH***Sript DM_LOCSEARCH**mbo.getThisMboSet().getCompleteWhere="+mbo.getThisMboSet().getCompleteWhere())
	whereClause1=" 1=1 "
	whereClause1=mbo.getThisMboSet().getCompleteWhere()
	//wclause = service.webclientsession().getCurrentApp().getResultsBean().getMboSet().getUserAndQbeWhere() ;
	ResultSet = service.webclientsession().getCurrentApp().getResultsBean();
	//prevResultSet= service.webclientsession().getPreviousApp().getResultsBean();
	logger.error("***ASH***Sript DM_LOCSEARCH**whereClause1="+whereClause1)
	/*logger.error("***ASH***Sript has records for action="+(ResultSet.hasRecordsForAction()))*/
	/*if(wclause.length()>0)*/
	if (!ResultSet.isEmpty())
	//if (whereClause1.length()>0)
	{
		logger.error("***ASH***Sript DM_LOCSEARCH**ResultSet.getMboSet().getUserAndQbeWhere() ="+ResultSet.getMboSet().getUserAndQbeWhere())
		logger.error("***ASH***Sript DM_LOCSEARCH**app="+app)
		logger.error("***ASH***Sript DM_LOCSEARCH** mboname="+ mboname)
		logger.error("***ASH***Sript DM_LOCSEARCH**mbo.getThisMboSet().getParentApp()="+mbo.getThisMboSet().getParentApp())
		if(launchPoint=="DM_LOCSEARCH")
		{
			if(app=="DM_PLUSTASSET")
			{
				if(whereClause1.length()<=0)
				{
					whereClause1=" 1=1 "
				}
    			listWhere=" ASSETLOCATION in (select DM_LOCATION from asset where "+whereClause1+")"
    			logger.error("***ASH***Sript DM_LOCSEARCH* dm_plustasset *listWhere="+listWhere)
			}
			if(app==null && mbo.getThisMboSet().getParentApp()=="DM_PLUSTWO")
			{
				whereClause1=ResultSet.getMboSet().getUserAndQbeWhere()
				if(whereClause1.length()<=0)
				{
					whereClause1=" 1=1 "
				}
			    logger.error("***ASH***Sript DM_LOCSEARCH* dm_plustwo*whereClause1="+whereClause1)
			    listWhere=" ASSETLOCATION in (select DM_LOCATION from asset where assetnum in (select assetnum from workorder where "+whereClause1+"))"
    			logger.error("***ASH***Sript DM_LOCSEARCH* dm_plustwo*listWhere="+listWhere)
			    
			}
			if(app==null && mbo.getThisMboSet().getParentApp()=="DM_PLUSGSR")
			{
				whereClause1=ResultSet.getMboSet().getUserAndQbeWhere()
				if(whereClause1.length()<=0)
				{
					whereClause1=" 1=1 "
				}
			    logger.error("***ASH***Sript DM_LOCSEARCH* dm_plustwo*whereClause1="+whereClause1)
			    listWhere=" ASSETLOCATION in (select DM_LOCATION from asset where assetnum in (select assetnum from SR where "+whereClause1+"))"
				
    			logger.error("***ASH***Sript DM_LOCSEARCH* dm_plustwo*listWhere="+listWhere)
			    
			}
		}
		else if (launchPoint=="DM_LOCATION")
		{
			domainid="DM_LOCATIONS"
			//wclause = service.webclientsession().getCurrentApp().getResultsBean().getMboSet().getUserAndQbeWhere() 
			//logger.error("***ASH***Sript DM_LOCSEARCH**wclause="+wclause)
			if(app=="DM_PLUSTASSET")
			{
				
				if(whereClause1.length()<=0)
				{
					whereClause1=" 1=1 "
				}
    			listWhere=" location in (select location from asset where "+whereClause1+")"
    			//listWhere=" 1=1"
    			logger.error("***ASH***Sript DM_LOCSEARCH**listWhere="+listWhere)
			}
			if(app==null && mbo.getThisMboSet().getParentApp()=="DM_PLUSTWO")
			{
				
				whereClause1=ResultSet.getMboSet().getUserAndQbeWhere()
				if(whereClause1.length()<=0)
				{
					whereClause1=" 1=1 "
				}
			    logger.error("***ASH***Sript DM_LOCSEARCH* dm_plustwo*whereClause1="+whereClause1)
			    listWhere=" location in (select location from asset where assetnum in (select assetnum from workorder where "+whereClause1+"))"
    			logger.error("***ASH***Sript DM_LOCSEARCH* dm_plustwo*listWhere="+listWhere)
			    
			}
			if(app==null && mbo.getThisMboSet().getParentApp()=="DM_PLUSGSR")
			{
				whereClause1=ResultSet.getMboSet().getUserAndQbeWhere()
				if(whereClause1.length()<=0)
				{
					whereClause1=" 1=1 "
				}
			    logger.error("***ASH***Sript DM_LOCSEARCH* dm_plustwo*whereClause1="+whereClause1)
			    listWhere=" location in (select location from asset where assetnum in (select assetnum from SR where "+whereClause1+"))"
    			logger.error("***ASH***Sript DM_LOCSEARCH* dm_plustwo*listWhere="+listWhere)
			    
			}
		}
		else 
		{
			if(app=="DM_PLUSTASSET")
			{
				if(whereClause1.length()<=0)
				{
					whereClause1=" 1=1 "
				}
				listWhere="classificationid IN (select dm_CLASSIFICATIONID from asset where "+whereClause1+")"
				logger.error("***ASH***Sript DM_LOCSEARCH**listWhere="+listWhere)
			}
			if(app==null && mbo.getThisMboSet().getParentApp()=="DM_PLUSTWO")
			{
				whereClause1=ResultSet.getMboSet().getUserAndQbeWhere()
				if(whereClause1.length()<=0)
				{
					whereClause1=" 1=1 "
				}
			    logger.error("***ASH***Sript DM_LOCSEARCH* dm_plustwo*whereClause1="+whereClause1)
			    listWhere="classificationid IN (select dm_CLASSIFICATIONID from asset where assetnum in (select assetnum from WORKORDER where "+whereClause1+"))"
				
    			logger.error("***ASH***Sript DM_LOCSEARCH* dm_plustwo*listWhere="+listWhere)
			    
			}
			if(app==null && mbo.getThisMboSet().getParentApp()=="DM_PLUSGSR")
			{
				whereClause1=ResultSet.getMboSet().getUserAndQbeWhere()
				if(whereClause1.length()<=0)
				{
					whereClause1=" 1=1 "
				}
			    logger.error("***ASH***Sript DM_LOCSEARCH* dm_plustwo*whereClause1="+whereClause1)
			    listWhere="classificationid IN (select dm_CLASSIFICATIONID from asset where assetnum in (select assetnum from SR where ASSETNUM IS NOT NULL AND "+whereClause1+"))"
    			logger.error("***ASH***Sript DM_LOCSEARCH* dm_plustwo*listWhere="+listWhere)
			    
			}
			
		}
		
	}
	else
	{
		logger.error("***ASH***Sript DM_LOCSEARCH** else of listwhere")
		if(launchPoint=="DM_LOCSEARCH")
		{
			domainid ='DM_ASSETLOCATIONS';
		}
		else if (launchPoint=="DM_LOCATION")
		{
			domainid="DM_LOCATIONS";
			listWhere="1=1"
		}
		else
		{
			listWhere=" CLASSIFICATIONID IN (SELECT CLASSIFICATIONID FROM CLASSSTRUCTURE WHERE CLASSSTRUCTUREID IN (SELECT CLASSSTRUCTUREID FROM CLASSSPECUSEWITH c WHERE OBJECTNAME ='ASSET') AND length(CLASSIFICATIONID)=8) "
		}
	}

}
else
{
	logger.error("***ASH***Sript DM_LOCSEARCH**its not zombie mbo***")
	if(launchPoint=="DM_LOCSEARCH")
	{
		domainid ='DM_ASSETLOCATIONS';
	}
	else if (launchPoint=="DM_LOCATION")
	{
		logger.error("***ASH***Sript DM_LOCSEARCH** else of launchPoint="+launchPoint)
		
		
		//listWhere="1=1"
		status = mbo.getTranslator().toExternalList("LOCASSETSTATUS", "DECOMMISSIONED", mbo);
		criteriaName = "(siteid =:1) and status not in (" + status + ")";
		sqfSite = new SqlFormat(mbo.getUserInfo(), criteriaName);
        sqfSite.setObject(1, "SITE", "SITEID", mbo.getString("siteid"));
        criteriaName = sqfSite.format();
        sqf = null;
        sql = "";
		if (!mbo.isNull("itemnum")) 
		{
			logger.error("***ASH***Sript DM_LOCSEARCH** itemnum not null")
			statusList = ["ACTIVE", "PLANNING", "PENDOBS"];
			validStatus = mbo.getTranslator().toExternalList("ITEMSTATUS", statusList);
			sql = "  and ( ( not exists ( select 1 from inventory where itemnum=:1 and location=locations.location and siteid=:2 and itemsetid = :3 ))";
			sql = sql + " or ( exists ( select 1 from inventory where itemnum = :1 and location = locations.location and siteid=:2 and itemsetid = :3 and status in (" + validStatus + "))) )";
			sqf = new SqlFormat(mbo.getUserInfo(), sql);
			sqf.setObject(1, "INVENTORY", "ITEMNUM", mbo.getString("itemnum"));
			sqf.setObject(2, "INVENTORY", "SITEID", mbo.getString("siteid"));
			sqf.setObject(3, "INVENTORY", "ITEMSETID", mbo.getString("itemsetid"));
			criteriaName = criteriaName.concat(sqf.format());
		}
		logger.error("***ASH***Sript DM_LOCSEARCH**mbo.getThisMboSet().getCompleteWhere="+mbo.getThisMboSet().getCompleteWhere())
		logger.error("***ASH***Sript DM_LOCSEARCH** else of criteriaName="+criteriaName)

		logger.error("***ASH***Sript DM_LOCSEARCH** else of mbo.getThisMboSet().getWhere()="+mbo.getThisMboSet().getWhere())
		logger.error("***ASH***Sript DM_LOCSEARCH** else of mbo.getThisMboSet().getAppWhere()="+mbo.getThisMboSet().getAppWhere())
		logger.error("***ASH***Sript DM_LOCSEARCH** else of mbo.getThisMboSet().getQbeWhere()="+mbo.getThisMboSet().getQbeWhere())
		logger.error("***ASH***Sript DM_LOCSEARCH** else of mbo.getThisMboSet().getUserWhere()="+mbo.getThisMboSet().getUserWhere())
		logger.error("***ASH***Sript DM_LOCSEARCH** else of mbo.getThisMboSet().getQbeWhere()="+mbo.getThisMboSet().getQbeWhere())
		logger.error("***ASH***Sript DM_LOCSEARCH** else of mbo.getThisMboSet().getUserAndQbeWhere()="+mbo.getThisMboSet().getUserAndQbeWhere())
		logger.error("***ASH***Sript DM_LOCSEARCH** else of mbo.getThisMboSet().getQbe()="+mbo.getThisMboSet().getQbe())	
		
		domainid ='DM_LOCATIONS';
		//listWhere="location in (select location from locations where "+criteriaName+"";
		listWhere=criteriaName+" and (exists ((select siteid from siteauth a1,groupuser b1,maxgroup m1,applicationauth  t1  where  b1.userid =  :&username&    and b1.groupname=a1.groupname  and b1.groupname=m1.groupname and m1.independent = 1  and a1.groupname = t1.groupname and  a1.siteid = locations.siteid )  union all (select siteid from siteauth a,groupuser b,maxgroup m  where  b.userid =  :&username&    and b.groupname=a.groupname  and b.groupname=m.groupname and m.independent = 0  and  a.siteid = locations.siteid and ( exists (select 1 from  maxgroup m2,applicationauth c,groupuser d where  d.userid =  :&username&  and d.groupname = m2.groupname and d.groupname = c.groupname and  m2.independent = 0  ))) ))";
	}
	else
	{
		domainid ='DM_CLASSIFICATIONI';
		//listWhere=" CLASSSTRUCTUREID IN (SELECT CLASSSTRUCTUREID FROM CLASSSPECUSEWITH c WHERE OBJECTNAME ='ASSET') AND length(CLASSIFICATIONID)=8 "
	}
}