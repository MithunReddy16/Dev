from psdi.mbo import MboConstants

if not mbovalue.isNull():
    if mbo.getInt("CLASSANCESTOR.HIERARCHYLEVELS") < 3:
    	service.error("DM","genericerror",["Entered classification is not valid"])