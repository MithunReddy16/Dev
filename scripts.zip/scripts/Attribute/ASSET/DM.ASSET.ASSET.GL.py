############################################
# Script: Used for component / children lookup in Assets DM app
# Author AA
# Version 1 - 24-12-2024
###########################################
ThisSet = mbo.getThisMboSet()
ParentApp = ThisSet.getParentApp()
Owner= mbo.getOwner()
if Owner:
	#service.error(ParentApp,ThisSet.getRelationName())
	if ParentApp.lower() == 'dm_plustasset' and ThisSet.getRelationName().upper() == 'DM_SUBASSEMBLIES':
		Owner= mbo.getOwner()
		Asset=''
		
		if not Owner:
			Owner = ThisSet.getOwner()
		if Owner:
			Asset = Owner.getString('Assetnum')
			
			
		domainid='DM_ASSETCHILDRENT'
		listWhere = " siteid=:siteid  and assetnum!='"+Asset+"' and dm_component = 1"
	elif ParentApp.lower() == 'dm_plustasset' and ThisSet.getRelationName().upper() == 'DM_ASSETCHILDREN':
		Owner= mbo.getOwner()
		Asset=''
		
		if not Owner:
			Owner = ThisSet.getOwner()
		if Owner:
			Asset = Owner.getString('Assetnum')
		domainid='DM_ASSETCHILDRENT'
		listWhere =" siteid=:siteid  and assetnum!='"+Asset+"' and dm_component = 0"
		
else:
	domainid='DM_ASSETCHILDRENT'