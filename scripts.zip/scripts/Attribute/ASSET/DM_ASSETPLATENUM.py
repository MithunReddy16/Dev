from psdi.server import MXServer

asset = mbo.getString("ASSETNUM")
plateNum = mbo.getString("DM_PLATE_NUM")
maintSec = mbo.getString("DM_MAINTSEC")
site = mbo.getString("SITEID")

if(asset != '' and plateNum != '' and maintSec != '' and site != ''):
    assetSet = MXServer.getMXServer().getMboSet("ASSET", mbo.getUserInfo())
    assetSet.setWhere("ASSETNUM != '" + asset + "' and DM_PLATE_NUM = '" + plateNum + "' and  DM_MAINTSEC = '" + maintSec + "' and SITEID = '" + site + "' and STATUS NOT IN (SELECT VALUE FROM SYNONYMDOMAIN WHERE MAXVALUE = 'DECOMMISSIONED')" )
    assetSet.reset()
    if(assetSet.count() > 0):
        service.error("dm_assetplate","Duplicateplate")
    assetSet.close()