assetset = mbo.getMboSet("DM_UNIQUEASSETTAGNUM")
if not assetset.isEmpty():
    service.error("DM_UNIQUE", "dupassetsn")