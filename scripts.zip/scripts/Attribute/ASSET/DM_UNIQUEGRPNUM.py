assetset = mbo.getMboSet("DM_UNIQUEGRPNUM")
if not assetset.isEmpty():
    service.error("DM_UNIQUE", "dupassetsn")