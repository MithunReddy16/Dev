##DM_ASSET_SERIALIZATION

from psdi.mbo import MboConstants
from psdi.server import MXServer

#DM_SERIALCLASS = First Rotating item select in case asset item changed later
#DM_SERIALNUM = Tracking serial number per class



def serialNumber(serialValue,paramLen):
	length = len(serialValue)
	while length<paramLen and length>0:
		serialValue = '0' + serialValue
		length = len(serialValue)
	return serialValue

if mbo.isNew():
    if mbo.isNull('itemnum'):
        mbo.setValueNull('DM_SERIALCLASS',11L)
        mbo.setValueNull('DM_SERIALNUM',11L)
        if not mbo.isNull('ASSETNUM'):
            mbo.setValueNull('ASSETNUM',11L)
    else:
        
        
        mbo.setValue('DM_SERIALCLASS',mbo.getString('itemnum'))
        
        
        
        assetSet = mbo.getMboSet("$SERIALCLASS_ASSET","ASSET"," DM_SERIALNUM in (select max(DM_SERIALNUM) from asset where DM_SERIALCLASS=:DM_SERIALCLASS ) and DM_SERIALCLASS=:DM_SERIALCLASS  ")
        
        maxSerial = 0
        NewAssetSerial = ''
        if assetSet is not None and not assetSet.isEmpty():
            maxSerial = assetSet.getMbo(0).getInt('DM_SERIALNUM')
        if maxSerial==0:
            NewAssetSerial ='00001'
        else:
            if maxSerial >= 99999:
                NewAssetSerial = str(maxSerial + 1)
            else:
                NewAssetSerial = serialNumber(str(maxSerial + 1),5) 
    
        if NewAssetSerial !='':
            SerialClass= mbo.getString('DM_SERIALCLASS')

            NewAssetNum=SerialClass+ '-' +NewAssetSerial
            mbo.setValue('DM_SERIALNUM',maxSerial + 1 ,11L);
            mbo.setValue('ASSETNUM',NewAssetNum,MboConstants.NOVALIDATION)
else:
	if mbo.getMboValue('ITEMNUM').getInitialValue().asString()!= mbo.getString('ITEMNUM'):
		print ('Class has changed Script Asset_Classification')
		## DO CHANGE CC_ASSETCATS