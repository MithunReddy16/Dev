from psdi.server import MXServer
from psdi.util import MXApplicationException


def setError(Msg):
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)


def validateGLAccountError(glcode,lineNum):
	'''
    coaSet = mbo.getMboSet("$coa", "CHARTOFACCOUNTS", "glaccount='" + glcode + "' AND active=1")
	if coaSet.isEmpty():
		coaSet.close()
		setError('GL Account is not valid')
    '''
    
    
	if glcode == None or glcode ==""  or  '?' in glcode:
		setError('GL Account is not valid in line#' + lineNum)
        


newStatus = mbo.getString("STATUS").upper()
oldStatus = mbo.getMboValue("STATUS").getPreviousValue().asString().upper()

if newStatus in ['COMPLETE', 'STAGED', 'SHIPPED'] and newStatus != oldStatus:
	invuseLineSet = mbo.getMboSet("INVUSELINE")

	if invuseLineSet is not None:
		for i in range(invuseLineSet.count()):
			invuseLine = invuseLineSet.getMbo(i)
			lineNum = str(invuseLine.getInt("INVUSELINENUM"))

			debitGL = invuseLine.getString("GLDEBITACCT")
			if debitGL:
				validateGLAccountError(debitGL,lineNum)

			creditGL = invuseLine.getString("GLCREDITACCT")
			if creditGL:
				validateGLAccountError(creditGL,lineNum)