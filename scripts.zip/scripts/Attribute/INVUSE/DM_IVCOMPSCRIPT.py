from java.lang import System
from com.ibm.tivoli.maximo.report.birt.queue import ReportQueueService
from com.ibm.tivoli.maximo.report.birt.runtime import ReportParameterData
from psdi.mbo import SqlFormat

#-----------------------------------------------------------------------------------------------------------
# Initialize logger
try:
    logger = service.getLogger("maximo.dm")
    logger.debug(">>> Entering script DM_IVCOMP")
except Exception as e:
    System.out.println("Failed to initialize logger: " + str(e))
    raise
#-----------------------------------------------------------------------------------------------------------

try:
    if mbo.getString("status") == 'COMPLETE':
        userInfo = mbo.getUserInfo()
        locale = userInfo.getLocale()

       
        logger.debug("UserInfo: " + str(userInfo))
        logger.debug("Locale: " + str(locale))

        if not mbo.isNull("locations.dm_persongroup.ALLPEOPLEINPERSONGROUP.primaryemail"):
            emailTo = mbo.getString("locations.dm_persongroup.ALLPEOPLEINPERSONGROUP.primaryemail")
            emailSubject = "Inventory Usage"
            emailComments = "Please acknowledge the Inventory usage."

            
            commTemplateID = "DM_IVGP"

            # Get the communication template
            commTemplateClause = SqlFormat(mbo, "templateid = :1")
            commTemplateClause.setObject(1, "COMMTEMPLATE", "TEMPLATEID", commTemplateID)
            commTemplateSet = mbo.getMboSet("$dm_ivgp", "COMMTEMPLATE", commTemplateClause.format())
            commTemplateMbo = commTemplateSet.getMbo(0)

            if commTemplateMbo is None:
                logger.error("Communication template with ID {} not found.".format(commTemplateID))
                System.out.println("Communication template with ID {} not found.".format(commTemplateID))
            else:
              
                sql = SqlFormat(mbo, commTemplateMbo.getString("SUBJECT"))
                sql.setIgnoreUnresolved(True)
                emailSubject = sql.resolveContent()

                sql = SqlFormat(mbo, commTemplateMbo.getString("MESSAGE"))
                sql.setIgnoreUnresolved(True)
                emailComments = sql.resolveContent()

           
            parameterData = ReportParameterData()
            parameterData.addParameter("appname", "DM_PLUSTINVUS")
            parameterData.addParameter("paramdelimiter", "")
            parameterData.addParameter("paramstring", "")
            whereClause = "(invuse.invuseid = {})".format(mbo.getLong("invuseid"))
            parameterData.addParameter("where", whereClause)

           
            logger.debug("Attempting to queue report with the following parameters:")
            logger.debug("Report Name: DM_IVGatepass.rptdesign")
            logger.debug("Report Parameters: " + str(parameterData.getParameters()))

            
            queueManager = ReportQueueService.getQueueService()
            if queueManager is None:
                logger.error("Failed to obtain ReportQueueService instance.")
                System.out.println("Failed to obtain ReportQueueService instance.")
            else:
                logger.debug("ReportQueueService initialized successfully.")
                System.out.println("ReportQueueService initialized successfully.")

            # Queue the Report
            try:
                reportFileName = queueManager.queueReport(
                    "DM_IVGatepass.rptdesign",  
                    "DM_PLUSTINVUS",                   
                    userInfo.getUserName(),    
                    emailTo,                    
                    emailSubject,               
                    emailComments,              
                    parameterData,             
                    locale.getCountry(),       
                    locale.getLanguage(),      
                    locale.getVariant(),        
                    userInfo.getTimeZone().getID(), 
                    userInfo.getLangCode(),    
                    long(0),                    
                    userInfo                    
                )

                if reportFileName is None:
                    logger.error("Failed to queue report: Report file name is null.")
                    System.out.println("Failed to queue report: Report file name is null.")
                else:
                    logger.debug("Report successfully queued. Report file name: " + reportFileName)
                    System.out.println("Report successfully queued. Report file name: " + reportFileName)

            except Exception as e:
                logger.error("Failed to queue the report: " + str(e))
                System.out.println("Failed to queue the report: " + str(e))

except Exception as e:
    logger.error("An error occurred in the script: " + str(e))
    System.out.println("An error occurred in the script: " + str(e))