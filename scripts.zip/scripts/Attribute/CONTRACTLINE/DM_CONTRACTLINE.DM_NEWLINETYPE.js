/*
Script: DM_CONTRACTLINE.DM_NEWLINETYPE
Created By: Ashok
Date: 15-Aug-2024
Req: Check if the Line Type is a PROVISION SUM then Make the Item and below fields readonly and enter the values automatically
DM_NEWLINETYPE
DM_CATEGORY
DM_BTYPE
DM_MAXVALUE
DM_MinVALUE
DM_TYPE
ORDERQTY
ORDERUNIT 
LINETYPE=STDSERVICE
ITEMNUM: PS

*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_CONTRACTLINE.DM_NEWLINETYPE**START***")

mboValue = mbo.getMboValue("DM_NEWLINETYPE") 
//initValue = mboValue.getInitialValue().asString() 
currValue = mboValue.getCurrentValue().asString(); 
prevValue = mboValue.getPreviousValue().asString(); 


if(currValue=="PS")
{
	mbo.setValue("LINETYPE","STDSERVICE")
	mbo.setValue("ITEMNUM","SOTHER")
	mbo.setValue("DM_CATEGORY","CO")
	mbo.setValue("DM_BTYPE","PS")
	mbo.setValue("DM_TYPE","S")
	mbo.setValue("ORDERQTY","1")
	mbo.setValue("ORDERUNIT","JOB")
	mbo.setValue("DM_MAXVALUE","")
	mbo.setValue("DM_MinVALUE","")

	logger.error("***ASH***Sript DM_CONTRACTLINE.DM_NEWLINETYPE**Values added and set readonly")
}
else if(prevValue=="PS")
{
	
	mbo.setValue("LINETYPE","")
	mbo.setValue("ITEMNUM","")
	mbo.setValue("DM_CATEGORY","")
	mbo.setValue("DM_BTYPE","")
	mbo.setValue("DM_TYPE","")
	mbo.setValue("ORDERQTY","0")
	mbo.setValue("ORDERUNIT","")
	mbo.setValue("DM_MAXVALUE","")
	mbo.setValue("DM_MinVALUE","")

	logger.error("***ASH***Sript DM_CONTRACTLINE.DM_NEWLINETYPE**Values added and set readonly")
	
}
logger.error("***ASH***Sript DM_CONTRACTLINE.DM_NEWLINETYPE**END***")