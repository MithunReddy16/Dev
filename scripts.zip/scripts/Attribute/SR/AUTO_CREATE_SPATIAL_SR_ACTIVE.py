'''Sample script
Automatically run Auto Create Spatial when Service Request status changes to Active. '''

from psdi.server import MXServer

if  MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("SRSTATUS",srStatus, mbo) == 'ACTIVE' :

    ticketid = mbo.getString("TICKETID")
    print "Auto Creating Spatial SR"
    print "TICKETID:"+ticketid
    print "SITEID: "+mbo.getString("SITEID")
    success = mbo.autoCreateSpatial(True)
    if (success):
         print "SR Spatial successfully created"
    else:
         print "SR Spatial creation failed"
         mbo.getThisMboSet().save()
         warngroup = "plussgis";
         warnkey = "autocreate_nofeats_placed_ticketuid";
         warnparams = [ticketid]