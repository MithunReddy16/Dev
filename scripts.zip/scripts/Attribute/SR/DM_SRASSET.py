from psdi.mbo import MboConstants
from psdi.server import MXServer

assetnum = mbo.getString("ASSETNUM")
if app == 'DM_CREATESR' and assetnum:
    workorder_set = MXServer.getMXServer().getMboSet("WORKORDER", mbo.getUserInfo())
    
    workorder_set.setWhere("ASSETNUM = '" + assetnum + "' AND STATUS NOT IN ('CLOSE', 'CAN', 'HISTEDIT')")
    
    workorder_set.reset()
# Added the Error message 18-09-2025
    if workorder_set.count() > 0:
       # warngroup = "dm_sr_validation"
       # warnkey = "asset_in_use"
        # warnparams = [assetnum]
        service.error("dm_dclassetnum","activeasset")