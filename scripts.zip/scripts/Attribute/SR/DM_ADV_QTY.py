##############################################
#script:DM_ADV_QTY
#Createdby:NK
#Creation Date:20-11-2025
#scope: Create SR - Validation
###############################################

from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

LP_MAP = {
    "DM_ADV_QTY2":   ("DM_ADV_3D",   "DM_ADV_3D_Q"),
    "DM_ADV_Q1":     ("DM_ADV_ST",   "DM_ADV_ST_Q"),
    "DM_ADV_Q2":     ("DM_ADV_BANNER",   "DM_ADV_BAN_Q"),
    "DM_ADV_Q3":     ("DM_ADV_PO",  "DM_ADV_PO_Q"),
    "DM_ADV_Q4":     ("DM_ADV_SSIGN", "DM_ADV_SSIGN_Q"),
    "DM_ADV_Q5":     ("DM_ADV_MIDSIGN", "DM_ADV_MSIGN_Q"),
    "DM_ADV_Q6":     ("DM_ADV_BIGSIGN", "DM_ADV_BSIGN_Q"),
    "DM_ADV_Q7":     ("DM_ADV_DBAR", "DM_ADV_DBAR_Q"),
    "DM_ADV_Q8":     ("DM_ADV_ROLLUP", "DM_ADV_ROLLUP_Q"),
    "DM_ADV_Q9":     ("DM_ADV_FRAMES", "DM_ADV_FRAME_Q"),
    "DM_ADV_Q10":    ("DM_ADV_REMOVAL", "DM_ADV_REM_Q"),
    "DM_ADV_Q11":    ("DM_ADV_MAINT", "DM_ADV_MAINT_Q"),
}

# Identify which pair to use
pair = LP_MAP.get(launchPoint)
if pair:
    chk_attr, qty_attr = pair
    checked = mbo.getBoolean(chk_attr)
    if checked:
        mbo.setFieldFlag(qty_attr, MboConstants.READONLY, False)
        mbo.setFieldFlag(qty_attr, MboConstants.REQUIRED, True)
    else:
        mbo.setFieldFlag(qty_attr, MboConstants.REQUIRED, False)
        mbo.setFieldFlag(qty_attr, MboConstants.READONLY, True)
        mbo.setValueNull(qty_attr, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION)