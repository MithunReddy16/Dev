######################################
#script:DM_ADV_REQTYPE
#created by :NK
#purpose: Clear reference number 
#Date:24/12/25
#####################################

from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory

reqType = mbo.getString("DM_ADV_REQTYPE")
if reqType:
        mbo.setValueNull("DM_ADV_REF", MboConstants.NOACCESSCHECK)
        
OTHER_CHECKBOXES = [
    "DM_ADV_BANNER",
    "DM_ADV_ST",
    "DM_ADV_PO",
    "DM_ADV_3D",
    "DM_ADV_DBAR",
    "DM_ADV_ROLLUP",
    "DM_ADV_SSIGN",
    "DM_ADV_MIDSIGN",
    "DM_ADV_FRAMES",
    "DM_ADV_BIGSIGN" ]

if reqType == "Removal":
    mbo.setValue("DM_ADV_REMOVAL", 1,MboConstants.NOACCESSCHECK )
    mbo.setFieldFlag("DM_ADV_REMOVAL", MboConstants.READONLY, True)
    mbo.setFieldFlag("LOCATION", MboConstants.REQUIRED, True)
    mbo.setFieldFlag("DM_ADV_REM_Q", MboConstants.READONLY, False)
    mbo.setFieldFlag("DM_ADV_REM_Q", MboConstants.REQUIRED, True)
    mbo.setValue("DM_ADV_MAINT", 0,MboConstants.NOACCESSCHECK )
    mbo.setFieldFlag("DM_ADV_MAINT", MboConstants.READONLY, True)

    
    for f in OTHER_CHECKBOXES:
        mbo.setValue(f,0,MboConstants.NOACCESSCHECK)
        mbo.setFieldFlag(f, MboConstants.READONLY, True)
        
elif reqType == "Softcopy":
    mbo.setFieldFlag("LOCATION", MboConstants.REQUIRED, False)
    mbo.setValue("DM_ADV_REMOVAL", 0,MboConstants.NOACCESSCHECK)
    mbo.setFieldFlag("DM_ADV_REMOVAL", MboConstants.READONLY, True)
    mbo.setFieldFlag("DM_ADV_REM_Q", MboConstants.READONLY, True)
    mbo.setFieldFlag("DM_ADV_REM_Q", MboConstants.REQUIRED, False)
    mbo.setFieldFlag("DM_ADV_MAINT", MboConstants.READONLY, True)
    mbo.setFieldFlag("DM_ADV_MAINT", MboConstants.REQUIRED, False)
    mbo.setValueNull("DM_ADV_MAINT_Q",MboConstants.NOACCESSCHECK);
    mbo.setValue("DM_ADV_MAINT", 0,MboConstants.NOACCESSCHECK )
    for f in OTHER_CHECKBOXES:
        #mbo.setValue(f,0, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
        mbo.setValue(f,0,MboConstants.NOACCESSCHECK)
        mbo.setFieldFlag(f, MboConstants.READONLY, True)
        
elif reqType == "Maintenance":
    mbo.setValue("DM_ADV_MAINT", 1,MboConstants.NOACCESSCHECK )
    mbo.setValue("DM_ADV_REMOVAL", 0, MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
    mbo.setFieldFlag("DM_ADV_REMOVAL", MboConstants.READONLY, True)
    mbo.setFieldFlag("LOCATION", MboConstants.REQUIRED, False)
    mbo.setFieldFlag("DM_ADV_REM_Q", MboConstants.READONLY, True)
    mbo.setFieldFlag("DM_ADV_REM_Q", MboConstants.REQUIRED, False)
    mbo.setValueNull("DM_ADV_REM_Q",MboConstants.NOACCESSCHECK);
    mbo.setFieldFlag("DM_ADV_MAINT", MboConstants.REQUIRED, True)
    for f in OTHER_CHECKBOXES:
        mbo.setValue(f,0, MboConstants.NOACCESSCHECK)
        mbo.setFieldFlag(f, MboConstants.READONLY, True)
        
else:
    mbo.setValue("DM_ADV_REMOVAL", 0, MboConstants.NOACCESSCHECK)
    mbo.setFieldFlag("DM_ADV_REMOVAL", MboConstants.READONLY, True)
    mbo.setFieldFlag("LOCATION", MboConstants.REQUIRED, True)
    mbo.setFieldFlag("DM_ADV_REM_Q", MboConstants.READONLY, True)
    mbo.setFieldFlag("DM_ADV_REM_Q", MboConstants.REQUIRED, False)
    mbo.setValue("DM_ADV_MAINT", 0, MboConstants.NOACCESSCHECK)
    mbo.setFieldFlag("DM_ADV_MAINT", MboConstants.READONLY, True)
    mbo.setFieldFlag("DM_ADV_MAINT", MboConstants.REQUIRED, False)
    mbo.setValueNull("DM_ADV_MAINT_Q",MboConstants.NOACCESSCHECK);
    for f in OTHER_CHECKBOXES:
        mbo.setFieldFlag(f, MboConstants.READONLY, False)
        mbo.setValue(f,0, MboConstants.NOACCESSCHECK)