#------------------------------------------------------------------------
#STPSCRIPT
#Script Name :DM_WOASSET_LIST
#Description :script to get the asset list which related to the selected location.
#Comment     :Used in GM Work Order / Service RequestApplication
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          20-Dec-2025         Initiate version.
#----------------------------------------------------------------------------------------------


service.log_debug("######################################## Start:" + scriptName+" ######################")

if (app == 'DM_PLUSGWO_GM' or app == 'DM_PLUSGSR_GM' ) and not mbo.isNull("location"):
    relationObject = "ASSET"
    listWhere = "SITEID=:SITEID  and  location IN (SELECT location FROM LOCANCESTOR WHERE ancestor IN (SELECT ancestor FROM LOCANCESTOR WHERE location='" + mbo.getString("location") + "' AND ancestor !=systemid ))"
    relationWhere  = listWhere + " AND ASSETNUM=:ASSETNUM"

elif app =='DM_CREATSR_STP' and mbo.getString("DM_MAINTDEPT") =='60181':
    relationObject = "ASSET"
    section = mbo.getString("dm_section")
    listWhere = "SITEID=:SITEID and DM_MAINTDEPT=:DM_MAINTDEPT"
    # Jabal Ali
    if section in ("60533","16492"):
        listWhere = "SITEID=:SITEID and DM_MAINTDEPT=:DM_MAINTDEPT and dm_location in ('2112112','2112111','2112113')"
    # Warsan    
    elif section in ("60531","60528"):
        listWhere = "SITEID=:SITEID and DM_MAINTDEPT=:DM_MAINTDEPT and dm_location in ('2112100','2112102','2112101')"
   
    relationWhere  = listWhere + " AND ASSETNUM=:ASSETNUM"
    
else:
    relationObject = "ASSET"
    listWhere =  "1=1"
    relationWhere  = listWhere + " AND ASSETNUM=:ASSETNUM"
    
service.log_debug("######################################## Finish:" + scriptName+" ######################")