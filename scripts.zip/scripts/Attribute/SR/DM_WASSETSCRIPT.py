#script:DM_WASSETSCRIPT
#Createdby:Ram
#Creation Date:17-FEB-25
#scope: based on the asset selected in workorder,warranty contract from asset will pass to the workorder
assetMbo=mbo.getMboSet("asset").getMbo(0)
if assetMbo is not None:
    wMbo=assetMbo.getMboSet("DM_WSWARRANTY").getMbo(0)
    if wMbo is not None:
         wcontract=wMbo.getString("contractnum")
         mbo.setValue("dm_wcontract",wcontract,2L)

if launchPoint =='DM_SRASSET' and app in ('DM_CREATSR_STP','DM_PLUSGSR_STP'):
    section = mbo.getString("DM_SECTION")
    #Jabal Ali
    if section in ("60533","16492"):
        mbo.setValue("DM_BUNIT","JABALALI")
    # Warsan    
    elif section in ("60531","60528"): 
        mbo.setValue("DM_BUNIT","WARSAN")

    if not assetMbo.isNull("DM_CONTRACTNUM"):
        mbo.setValue("VENDOR",assetMbo.getString("DM_CONTRACT.VENDOR"),2L)
        mbo.setValue("DM_VENDCONTRACT",assetMbo.getString("DM_CONTRACTNUM"),2L)
        mbo.setValue("DM_INHOUSE",False,2L)
    else:
        mbo.setValue("DM_INHOUSE",True,2L)
        
    
if assetMbo is None:
            mbo.setValueNull('dm_wcontract',2L)