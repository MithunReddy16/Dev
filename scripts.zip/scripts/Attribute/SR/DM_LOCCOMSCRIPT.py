# Created by: Ram
# Remarks: Validate Location Community and Responsibility Matrix during SR creation.
# Date: 31-Jul-2026

location = mbo.getString("LOCATION")
wotype = mbo.getString("DM_WOTYPE")
maintdept = mbo.getString("DM_MAINTDEPT")
bunit=mbo.getString("DM_BUNIT")
if app == "DM_CREATSR_SRWN" and location and bunit != "WSHUNIT":
 

    # Check if Maintenance Department belongs to SRN
    orgSet = mbo.getMboSet(
        "$ORG",
        "DM_ORGHIERARCHY",
        "unitid='" + maintdept + "' and abbriviation='SRN'"
    )

    if not orgSet.isEmpty():

        # Get Location record
        locSet = mbo.getMboSet(
            "$LOC",
            "LOCATIONS",
            "location='" + location + "'"
        )

        locMbo = locSet.getMbo(0)

        if locMbo:

            community = locMbo.getString("DM_COMMUNITY")

            # Validate Community
            if not community:
                service.error(
                    "dm",
                    "genericerror",
                    ["Location Community is missing. Please contact administrator."]
                )
            
            # Validate Responsibility Matrix
            respSet = mbo.getMboSet(
                "$RESP",
                "DM_RESPMANAGER",
                "worktype='" + wotype +
                "' and dm_maintdept='" + maintdept +
                "' and dm_bunit='" + bunit +
                "' and community='" + community + "'"
            )
           

           
            if respSet.isEmpty(): 
                service.error(
                    "dm",
                    "genericerror",
                    ["No matching Responsibility Matrix found. Please contact administrator."]
                )

            respSet.close()

        locSet.close()

    orgSet.close()