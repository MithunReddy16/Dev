#------------------------------------------------------------------------
#STPSCRIPT
#Script Name :DM_SR_MAINDEPT
#Description :SR Maintenance Department Get List Script
#Comment     :Used in STP create SR
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          05-May-2026         Initiate version.
#--------------------------------------------------------------------------------------------


# Elif added by mithun 
if mbo.isNew()  :
    if app =="DM_CREATSR_STP":    
        
        mbo.setValue("DM_MAINTDEPT","60181")
        #listWhere = "unittype='DEPARTMENT' and unitid in ('60181')"
        #relationWhere  = listWhere + "unitid =:dm_maintdept"
    elif app =="DM_CREATSR_SRWN":    
        mbo.setValue("DM_MAINTDEPT","15763")
        #listWhere = "unittype='DEPARTMENT' and unitid in ('15763')"
        #relationWhere  = listWhere + "unitid =:dm_maintdept"   
    
    #else:
     #   listWhere =  "unittype='DEPARTMENT' "
      #  relationWhere  = listWhere +  "unitid =:dm_maintdept"