#---------------------------------------------------------------------------------------------
# Script Name : DM_GM_CLEARAFF
# Description : Clear and require Affected Person when:
#               1. The SR is Ad-Hoc (DM_SERVICEID = 999), or
#               2. The current user's Employee Type is CONTRACTOR.
#
# Author/Modified By     Email                Version      Date               Comment
#---------------------------------------------------------------------------------------------
# Muhammad Darwish       MDARWISH.V@dm.ae     1.0          2026-09-15         Initial version.
# Muhammad Darwish       MDARWISH.V@dm.ae     1.1          2026-09-18         Added contractor condition.
#---------------------------------------------------------------------------------------------

from psdi.mbo import MboConstants
from psdi.server import MXServer
from psdi.mbo import SqlFormat

personSet = None

try:
    # Get the current user's Person ID
    userInfo = mbo.getUserInfo()
    currentPersonId = userInfo.getPersonId()

    isContractor = False

    # Check the current user's Employee Type
    if currentPersonId:
        personSet = MXServer.getMXServer().getMboSet("PERSON", userInfo)

        sqlFormat = SqlFormat("PERSONID = :1")
        sqlFormat.setObject(1, "PERSON", "PERSONID", currentPersonId)

        personSet.setWhere(sqlFormat.format())
        personSet.reset()

        personMbo = personSet.getMbo(0)

        if personMbo is not None:
            employeeType = personMbo.getString("EMPLOYEETYPE").strip().upper()

            if employeeType == "CONTRACTOR":
                isContractor = True

    isAdHoc = mbo.getString("DM_SERVICEID") == "999"

    # Affected Person is required for:
    # 1. Ad-Hoc SRs, or
    # 2. SRs created by contractor users
    affectedPersonRequired = isAdHoc or isContractor

    if affectedPersonRequired:
        # Clear the automatically populated value for a new SR
        # so that the user must select the affected person
        if mbo.isNew():
            if not mbo.isNull("AFFECTEDPERSONID"):
                mbo.setValueNull("AFFECTEDPERSONID", MboConstants.NOVALIDATION_AND_NOACTION)

        mbo.setFieldFlag("AFFECTEDPERSONID", MboConstants.REQUIRED, True)

    else:
        mbo.setFieldFlag("AFFECTEDPERSONID", MboConstants.REQUIRED, False)

        # If the service was changed from 999 to another service,
        # restore the normal auto-populated affected person
        previousServiceId = mbo.getMboValue("DM_SERVICEID").getPreviousValue().asString()

        if previousServiceId == "999":
            if not mbo.isNull("REPORTEDBYID"):
                mbo.setValue("AFFECTEDPERSONID", mbo.getString("REPORTEDBYID"))

finally:
    if personSet is not None:
        personSet.close()