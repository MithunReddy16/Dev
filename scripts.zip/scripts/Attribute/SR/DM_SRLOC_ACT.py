#---------------------------------------------------------------------------------------------
#Script Name :DM_SRLOC_ACT
#Description :Assign vendor and contract based on the location zone.
#             Use zone E2 for location 814-07373 and its code descendants.
#
#Author/Modifiedby       Email                Version      Date               Comment
#---------------------------------------------------------------------------------------------
#Muhammad Darwish        MDARWISH.V@dm.ae     1.0          2026-10-22         Initiate version.
#---------------------------------------------------------------------------------------------

if mbo.getString("DM_MAINTDEPT") == "1996":

    # Clear vendor and contract when location is empty.
    if mbo.isNull("LOCATION"):
        mbo.setValueNull("VENDOR")
        mbo.setValueNull("DM_VENDCONTRACT")

    elif not mbo.getBoolean("DM_INHOUSE"):

        location = mbo.getString("LOCATION")

        # Determine the location zone.
        if location == "814-07373" or location.startswith("814-07373-"):
            zone = "E2"
        else:
            zone = mbo.getString("DM_LOCATION.DM_ZONES")

        # Retrieve the contract mapped to the zone.
        zoneWhere = (
            "DOMAINID = 'DM_ZONEMAPPING' AND VALUE = '%s'"
            % zone.replace("'", "''")
        )

        zoneMappingSet = mbo.getMboSet("DM_GM_DOMAINZZ", "ALNDOMAIN", zoneWhere)
        zoneMappingSet.reset()

        zoneMappingMbo = zoneMappingSet.getMbo(0)

        if zoneMappingMbo is not None:
            contractNum = zoneMappingMbo.getString("DESCRIPTION")

            # Retrieve the approved contract.
            contractWhere = ("CONTRACTNUM = '%s' AND STATUS = 'APPR'"% contractNum.replace("'", "''"))

            contractSet = mbo.getMboSet("DM_GM_CONTARCTZZ","PURCHVIEW",contractWhere)
            contractSet.reset()

            contractMbo = contractSet.getMbo(0)

            if contractMbo is not None:
                mbo.setValue("VENDOR", contractMbo.getString("VENDOR"))
                mbo.setValue("DM_VENDCONTRACT", contractNum)