#--------------------------------------------------------
#Modified by:ram
#modified date:24-Dec-25
#scope: make the wo type is mandatory if the service type is Ad-Hoc
#--------------------------------------------------------

from psdi.mbo import MboConstants


if not mbo.isNull("DM_SERVICEID"):

    serviceId = mbo.getString("DM_SERVICEID")

    serviceCatalogSet = mbo.getMboSet("DM_SERVICECATALOG")
    serviceCatalog = serviceCatalogSet.getMbo(0)

    if serviceCatalog:

        serviceType = serviceCatalog.getString("TYPE")
        catalogServiceId = serviceCatalog.getString("SERVICEID")

        if serviceType == "AD-HOC":
            mbo.setValue("DM_WOTYPE","CP",MboConstants.NOACCESSCHECK)

        elif catalogServiceId.startswith("AS"):
            mbo.setValue("DM_WOTYPE","AS",MboConstants.NOACCESSCHECK)

        else:
            mbo.setValue("DM_WOTYPE","CM",MboConstants.NOACCESSCHECK)

else:
    mbo.setValueNull(
        "DM_MAINTDEPT",
        MboConstants.NOACCESSCHECK
    )