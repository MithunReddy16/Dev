###############################################
#script:DM_ADV_REF1
#Createdby:nk
#Creation Date:09-01-2026
#scope:Referenc number
###############################################

from psdi.mbo import MboConstants

FIELDS = [
    "DM_ADV_ST",
    "DM_ADV_PO",
    "DM_ADV_BANNER",
    "DM_ADV_SSIGN",
    "DM_ADV_MIDSIGN",
    "DM_ADV_BIGSIGN",
    "DM_ADV_DBAR",
    "DM_ADV_ROLLUP",
    "DM_ADV_3D",
    "DM_ADV_FRAMES",
    "DM_ADV_REMOVAL",
    "DM_ADV_MAINT",
]

srRef = mbo.getString("DM_ADV_REF")
if srRef:
    # Get matching WOs via relationship (SR -> WORKORDER)
    woSet = mbo.getMboSet("DM_ADV_WOBYREF")
    if woSet:
        woMbo = woSet.moveFirst()
        if woMbo:
            for f in FIELDS:
                mbo.setValue(f, woMbo.getBoolean(f), MboConstants.NOACCESSCHECK)
                
            for f in FIELDS:
                if mbo.getBoolean(f):
                    mbo.setFieldFlag(f, MboConstants.READONLY, False)
                else:
                    mbo.setFieldFlag(f, MboConstants.READONLY, True)