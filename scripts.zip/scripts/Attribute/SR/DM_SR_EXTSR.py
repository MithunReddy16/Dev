if mbo.getBoolean("dm_extsr") and not mbo.isNull("location"):
    mbo.setValue("assetnum","EXTASSET",11)
    mbo.setFieldFlag("assetnum",7l,True)
else:
    mbo.setValueNull("assetnum",11)
    mbo.setFieldFlag("assetnum",7l,False)