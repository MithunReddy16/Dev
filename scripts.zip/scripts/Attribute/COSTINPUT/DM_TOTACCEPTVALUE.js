/*
Script: DM_TOTACCEPTVALUE
Desc: Contract, View Release Costs Dialog(COSTINPUT.DM_TOTACCEPTVALUE), Total Accept Value Calculation
Created By: Ashok
Date: 24-Sep-2024
Req: 

Calculate The Total Accepted Costs 
Inspected and Accepted Works by the Zone Engineer.  (Committed)
(Total Accepted lines will reflect all the actual workorders’ lines referencing a specific contract. In MATUSETRANS / SERVRECTRANS)

String[] statuses = new String[]{"WAPPR"};
sum(receivedtotalcost) OR SUM(LINECOST) OR SUM(LOADEDCOST
select sum(receivedtotalcost) from poline where exists (select 1 from po where   po.ponum=poline.ponum and po.siteid=poline.siteid and po.revisionnum=poline.revisionnum and po.status in (" + this.getTranslator().toExternalList("postatus", statuses, this) + ") and potype in (" + this.getTranslator().toExternalList("POTYPE", "REL", this) + ") and po.currencycode=:2 and po.contractrefnum=:1 and (orgid in (select authorgid from contractauth where contractnum=:1 and orgid=:3))) 

*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)



//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_TOTACCEPTVALUE**START***")
 logger.error("***ASH***Sript DM_TOTACCEPTVALUE**owner mbo="+mbo.getOwner())
 dbShortcut=null;
 resultSet1=null;
try
{
	purchviewMbo=mbo.getOwner();
	totacceptvalue=0;
	if(purchviewMbo!=null && purchviewMbo.getName()=="PURCHVIEW")
	{
		logger.error("***ASH***Sript DM_TOTACCEPTVALUE**mbo.getOwner().getName()="+mbo.getOwner().getName())
		dbShortcut= new DBShortcut();
		dbShortcut.connect(mbo.getThisMboSet().getUserInfo().getConnectionKey());
		sqfQuery=new SqlFormat("select sum(receivedtotalcost) TOTACCEPTVALUE from poline where "
								+" exists (select 1 from po where   po.ponum=poline.ponum and po.siteid=poline.siteid and po.revisionnum=poline.revisionnum "
								+" and po.status in (select value from synonymdomain where domainid='POSTATUS'  and maxvalue in ('APPR','CLOSE','INPRG','WAPPR')) "
								+" and potype in (select value from synonymdomain where domainid='POTYPE'  and maxvalue in ('REL'))"
								//--and po.currencycode=:2 
								+" and po.contractrefnum='"+purchviewMbo.getString("CONTRACTNUM")+"' and (orgid in (select authorgid from contractauth where contractnum='"+purchviewMbo.getString("CONTRACTNUM")+"' and orgid='"+purchviewMbo.getString("ORGID")+"'))"
								+" and  ( "
								+" (poline.contreflineid is not null and (select DM_BTYPE from contractline cl where cl.contractlineid=poline.contreflineid)!='PS')"
								//+" or (poline.contreflineid is null) 
								+" )"
								+" )");
		
		logger.error("***ASH***Sript DM_TOTACCEPTVALUE**sqfQuery="+sqfQuery)
		
		resultSet1=dbShortcut.executeQuery(sqfQuery.format())
		if( resultSet1.next())
		{
			totacceptvalue=resultSet1.getDouble("TOTACCEPTVALUE")
		}
		mbo.setValue("DM_TOTACCEPTVALUE",totacceptvalue,2)
	}
}
catch(e)
{
	logger.error("***ASH***Sript DM_TOTACCEPTVALUE**EXCEPTION="+e);

}
finally
{
	if(resultSet1!=null)
	{
		resultSet1.close();
	}
	if(dbShortcut!=null)
	{
		dbShortcut.close();
	}
}