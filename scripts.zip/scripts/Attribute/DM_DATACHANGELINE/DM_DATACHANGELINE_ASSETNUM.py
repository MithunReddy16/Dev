#------------------------------------------------------------------------
#Script Name :DM_DATACHANGELINE_ASSETNUM
#Description :Data Change Line Asset Number Script
#Comment     :Used in Asset Data Change Request Application. 
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-Aug-2025         Initiate version.
#
#
#------------------------------------------------------------------------

# copy fields values from the asset to the line.
if not mbo.isNull("assetnum"):
    assetMbo = mbo.getMboSet("asset").getMbo(0)
    mbo.setValue("FROMCLASSSTRUCTUREID",assetMbo.getString("CLASSSTRUCTUREID"))
    mbo.setValue("FROMCOSTCENTER",assetMbo.getString("DM_SECTION"))
    mbo.setValue("FROMFLOC",assetMbo.getString("DM_LOCATION"))
    mbo.setValue("FROMLOCATION",assetMbo.getString("LOCATION"))
    mbo.setValue("FROMMAINTSEC",assetMbo.getString("DM_MAINTSEC"))