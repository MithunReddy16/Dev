#------------------------------------------------------------------------
#Script Name :DM_DATACHANGEATTRVALID
#Description :Data Change Request Line Attribute Validation Script
#Comment     :Used in Asset Data Change Request Application. 
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-Aug-2025         Initiate version.

#------------------------------------------------------------------------

service.log_debug("######################################## Start:" + scriptName+" ######################")

ownerMbo = mbo.getOwner()
if ownerMbo is not None:
    
    if launchPoint =="DATACHANGECC":
        if not mbo.isNull("TOCOSTCENTER") and mbo.getString("TOCOSTCENTER") != ownerMbo.getString("TOCOSTCENTER"):
            service.error("dmdtatchange","invalidvalue")
            

    if launchPoint =="DATACHANGEMAINTSEC":
        if not mbo.isNull("TOMAINTSEC") and mbo.getString("TOMAINTSEC") != ownerMbo.getString("TOMAINTSEC"):
            service.error("dmdtatchange","invalidvalue")
            
service.log_debug("######################################## End:" + scriptName+" ######################")