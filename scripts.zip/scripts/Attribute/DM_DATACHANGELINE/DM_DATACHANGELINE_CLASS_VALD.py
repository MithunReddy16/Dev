#------------------------------------------------------------------------
#Script Name :DM_DATACHANGELINE_CLASS_VALD.
#Description :Asset Data Change Line Request Classification Validation Script.
#Comment     :Used in Asset Data Change Request Application. 
#
#Author/Modifiedby     Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          01-Aug-2025         Initiate version.

#------------------------------------------------------------------------

service.log_debug("######################################## Start:" + scriptName+" ######################")

fromClassMboSet = mbo.getMboSet("FROMCLASSHIER_$$","DM_CLASSHIER","CHILDID=:FROMCLASSSTRUCTUREID and PARENTID is null")
fromClassMboSet.reset()
fromClassMbo = fromClassMboSet.getMbo(0)
if fromClassMbo:
    fromAncestorClass = fromClassMbo.getString("ANCESTORID")
    toClassMboSet = mbo.getMboSet("TOCLASSHIER_$$","DM_CLASSHIER","CHILDID=:CLASSSTRUCTUREID and PARENTID is null")
    toClassMboSet.reset()
    toClassMbo = toClassMboSet.getMbo(0)
    if toClassMbo:
        toAncestorClass = toClassMbo.getString("ANCESTORID")
        if toAncestorClass != fromAncestorClass:
            classMboSet = mbo.getMboSet("LEVELONECLASS_$$","CLASSSTRUCTURE","CLASSSTRUCTUREID='"+fromAncestorClass+"'" )
            classMboSet.reset()
            classMbo = classMboSet.getMbo(0)
            if classMbo:
                service.error("dmdatachange","wrongclass",[classMbo.getString("DESCRIPTION")])
                
service.log_debug("######################################## End:" + scriptName+" ######################")