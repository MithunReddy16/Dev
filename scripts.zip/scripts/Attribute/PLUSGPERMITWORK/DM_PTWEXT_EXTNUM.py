#------------------------------------------------------------------------
#STPSCRIPT
#Script Name :DM_PTWEXT_EXTNUM
#Description :script to calculate the number of the extension for the permit
#Comment     :Used in STP Work Order /
#
#Author/Modifiedby   Email                   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#Ammar Younes        SWORD_AYOUNES@dm.ae     1.0          20-MAY-2026         Initiate version.
#--------------------------------------------------------------------------------------------

from psdi.server import MXServer


if  "PENDINGEXT" == mbo.getString("status") and mbo.getInt("EXTNUM") >0:
    mbo.changeStatus("ISSUED",MXServer.getMXServer().getDate(),None,11l)
    
    # get the workflow service
    wfSrv = MXServer.getMXServer().lookup('WORKFLOW')
    # get active instances for the current mbo
    wfSet = wfSrv.getActiveInstances(mbo)
    # stop the first workflow instance
    if  wfSet.getMbo(0):
        wfSet.getMbo(0).stopWorkflow("Stopped")
    
    service.invokeScript("DM_EMAILPTW_ACTION", "generatePTWReport", [mbo.getString("PERMITWORKNUM"), mbo.getBoolean("THIRDPARTY"),mbo.getUserInfo()])