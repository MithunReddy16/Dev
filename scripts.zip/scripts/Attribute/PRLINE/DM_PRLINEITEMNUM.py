owner = mbo.getOwner()
if owner.getString('DM_PRPROCESSTYPE') == 'P2P':
    listWhere = " rotating =0 and STATUS='ACTIVE' "
elif owner.getString('DM_PRPROCESSTYPE') == 'AFP':
    listWhere = " rotating =1 and STATUS='ACTIVE' "
else:
    listWhere = " 1=2 "