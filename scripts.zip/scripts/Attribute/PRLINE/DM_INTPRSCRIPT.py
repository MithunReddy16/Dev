##############################################
# When user selects an item,  system checks for category controller , if item requires category controller approvals
# and requested users is same as cc approval, it sets the flag to true (CC Approved) otherwise to false
#
############################################

from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

myLogger = MXLoggerFactory.getLogger("maximo.custom")

itemnum = mbo.getString("ITEMNUM")
prnum = mbo.getString("prnum")
prlinenum = mbo.getInt("prlinenum")
requestedby = mbo.getOwner().getString("REQUESTEDBY")

approved_lines_count = 0

if itemnum:
    
    if mbo.isNew()!=0:
        
            mbo.setValue("dm_ccappr", False, MboConstants.NOACCESSCHECK)
           
            mbo.setValue("dm_appr", False, MboConstants.NOACCESSCHECK)
    ItemSet = MXServer.getMXServer().getMboSet("ITEM", mbo.getUserInfo())
    ItemSet.setWhere("itemnum = '{}'".format(itemnum))
    ItemSet.reset()

    if not ItemSet.isEmpty():
        item = ItemSet.getMbo(0)
        commodity = item.getString("COMMODITY")
      
        commodity_parts = commodity.split('-') 

        if len(commodity_parts) > 1:
            commodity_prefix = commodity_parts[0]
            commodity_number = int(commodity_parts[1])

            DM_MRA_Set = MXServer.getMXServer().getMboSet("DM_MRA", mbo.getUserInfo())
            DM_MRA_Set.reset()

            if DM_MRA_Set.count() > 0:
                for j in range(DM_MRA_Set.count()):
                    DM_MRA = DM_MRA_Set.getMbo(j)
                    from_category = DM_MRA.getString("fromcategory")
                    to_category = DM_MRA.getString("tocategory")
                    approver_assigned = DM_MRA.getString("approveby")

                    from_category_parts = from_category.split('-')
                    to_category_parts = to_category.split('-')

                    if len(from_category_parts) > 1 and len(to_category_parts) > 1:
                        from_category_prefix = from_category_parts[0]
                        from_category_number = int(from_category_parts[1])
                        to_category_prefix = to_category_parts[0]
                        to_category_number = int(to_category_parts[1])

                        if commodity_prefix == from_category_prefix == to_category_prefix:
                            myLogger.info('Prefix match: {} == {} == {}'.format(
                                commodity_prefix, from_category_prefix, to_category_prefix))
                            myLogger.info('Commodity {} is within range {}-{}'.format(
                                    commodity, from_category_number, to_category_number))
                            if from_category_number <= commodity_number <= to_category_number:
                                myLogger.info('Commodity {} is within range {}-{}'.format(
                                    commodity, from_category_number, to_category_number))

                                if approver_assigned:
                                    personSet = mbo.getMboSet(
                                        "$EMXPERSONGROUP", 
                                        "PERSONGROUPTEAM", 
                                        "persongroup = '{}' AND respparty = '{}'".format(approver_assigned, requestedby)
                                    )
                                    personMbo = personSet.getMbo(0)

                                    if personMbo:
                                      
                                            mbo.setValue("dm_ccappr", True, MboConstants.NOACCESSCHECK)
                                            myLogger.info('PR Line {} approved by approver {}.'.format(prlinenum, requestedby))
                                            approved_lines_count += 1
                                            break
                                       
                                            myLogger.info(
                                                'Approver {} is not assigned to PR Line {} via DM_MRA.'.format(requestedby, prlinenum)
                                            )
                                else:
                                    myLogger.info('No approver found for item {}.'.format(itemnum))

        
            
else:
    if not itemnum:
        mbo.setValue("dm_ccappr", False, MboConstants.NOACCESSCHECK)
        
        mbo.setValue("dm_appr", False, MboConstants.NOACCESSCHECK)
        myLogger.info("Item-related fields cleared as ITEMNUM is removed.")

myLogger.info("Processed ITEMNUM={} on PRLINE {}. Total approved PR lines: {}".format(itemnum, prlinenum, approved_lines_count))