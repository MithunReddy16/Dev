#-----------------------------------------------------------------------------------------
# Name:        DM_PRLINE_ITEM
# Description: Copy GRP Item description to Description
# Author: Mithun Reddy
# Version: 1.0 - 23-Jun-2025
#-----------------------------------------------------------------------------------------
from psdi.util.logging import MXLoggerFactory
logger = MXLoggerFactory.getLogger("maximo.custom")
appl = mbo.getThisMboSet().getParentApp()
if appl=="DM_PLUSGPR":
    itemnum=mbo.getString("ITEMNUM")
    if itemnum is not None and itemnum != "" :
        itemSet=mbo.getMboSet("ITEM")
        itemMbo = itemSet.moveFirst()
        if itemMbo:
            if not itemMbo.isNull('DM_GRPDESC'):
                mbo.setValue("DESCRIPTION",itemMbo.getString("DM_GRPDESC"))
                mbo.setValue("DESCRIPTION_LONGDESCRIPTION",itemMbo.getString("DM_GRPLONGDESC"))