# script made inactive by Mithun to work count type is perodic and selection item is Item
from psdi.mbo import MboConstants

#service.error('A','B')
if app == "DM_COUNTBOOK":
    '''
    selectionType = mbo.getString("SELECTIONTYPE")
    
    if selectionType == "ITEM":
        countBookSelSet = mbo.getMboSet("COUNTBOOKSELTYPE")
        
        if countBookSelSet.isEmpty():
            mbo.setValue("SELECTIONTYPE", "ITEM", MboConstants.NOACCESSCHECK)
        else:
            for i in range(countBookSelSet.count()):
                countBookSelMbo = countBookSelSet.getMbo(i)
                if countBookSelMbo.toBeAdded():
                    countBookSelSet.remove(countBookSelMbo)
        mbo.setValue("SELECTIONTYPE", "ITEM", MboConstants.NOACCESSCHECK)
    '''
    
    CountBookSelTable = service.webclientsession().getDataBean("main_cbsel_table")
    CountBookSelTable.refreshTable()