#-----------------------------------------------------------------------------------------
# Name:        DM_COUNTTYPE
# Description: script on DM_COUNTTYPE filed 
# Author: Mithun Reddy
# Version: 1.0 - 30-Nov-2025
#-----------------------------------------------------------------------------------------
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants
logger = MXLoggerFactory.getLogger("maximo.custom.inventory")

logger.info("****Script execution started for Count Book.****")
logger.debug("***** Mithun Debug*****")
if app == "DM_COUNTBOOK":
    countbookType = mbo.getString("DM_COUNTTYPE")
    if countbookType == "Annual":
        mbo.setValueNull("MONTH")
    if countbookType == "Periodic":
        mbo.setValue("SELECTIONTYPE", "ITEM", 2L)