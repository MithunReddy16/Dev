from psdi.server import MXServer

if mbo.getString('STATUS') not in ["ROUND1","ROUND2","WAPPR","FICO"]:
    mbo.setValue('statusdate', MXServer.getMXServer().getDate(),11L)