#-----------------------------------------------------------------------------------------
# Name:        DM_CBSTORE
# Description: script on DM_CBSTORE  
# Author: Mithun Reddy
# Version: 1.0 - 30-Nov-2025
#-----------------------------------------------------------------------------------------
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants
from psdi.server import MXServer
logger = MXLoggerFactory.getLogger("maximo.custom.inventory")

logger.debug("***** Mithun Debug on DM_CBSTORE*****")
if app == "DM_COUNTBOOK":
    glcreditacc = MXServer.getMXServer().getProperty('dm.adjustment.glcreditaccount')
    storerroom = mbo.getString("STOREROOM")
    logger.debug("***** Mithun **if storeroom is *****"+storerroom)
    if storerroom != None and storeroom !="":
        storeMbo=mbo.getMboSet("LOCATIONS").getMbo(0)
        storecontacc=storeMbo.getString("CONTROLACC")
        mbo.setValue("GLDEBITACCOUNT", storecontacc, MboConstants.NOACCESSCHECK)
        mbo.setValue("GLCREDITACCOUNT", glcreditacc, MboConstants.NOACCESSCHECK)
        mbo.setValue('SELECTIONTYPE','ITEM')
    elif  storerroom == None or storeroom =="":
        logger.debug("***** Mithun **if storeroom is empty *****")
        mbo.setValueNull("GLDEBITACCOUNT")
        mbo.setValueNull("GLCREDITACCOUNT")