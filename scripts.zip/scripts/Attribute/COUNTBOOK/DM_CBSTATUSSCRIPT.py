from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory
from psdi.server import MXServer

logger = MXLoggerFactory.getLogger("maximo.script.dm_countbook")

countBookLineSet = mbo.getMboSet("COUNTBOOKALLITM")

logger.debug("Script execution started for Count Book.")

if app == "DM_COUNTBOOK":
    logger.debug("Application context verified as DM_COUNTBOOK.")
    currentuser = mbo.getUserInfo().getUserName()
    today = MXServer.getMXServer().getDate()
    if countBookLineSet:
        countBookLineSet.setWhere("match=1")
        logger.debug("COUNTBOOKALLITM MboSet reset successfully.")
    
        if mbo.getString("status") == 'FICO':
            logger.debug("Conditions met: dm_isfinal is True and status is PCE.")
    #line.getBoolean("rotating")==True and
            line = countBookLineSet.moveFirst()
            while line:
                logger.debug("Processing lines")
                initialCount = line.getDouble("DM_INITIALPHYSCNT")
                itemnum=line.getString("itemnum")
                if  initialCount is not None:
                    initialCount = line.getDouble("DM_INITIALPHYSCNT")
                    itemnum=line.getString("itemnum")
                    
                    logger.debug('Rotating item {} found. Setting PHYSCNT '.format(itemnum))
                    
                    line.setValue("PHYSCNT", initialCount,2L)
                    line.setValue("PHYSCNTBY", currentuser)
                    line.setValue("PHYSCNTDATE", today)
                
                line = countBookLineSet.moveNext()
        else:
            logger.debug("Conditions not met. Either dm_isfinal is False or status is not PCE.")

logger.debug("Script execution completed for Count Book.")