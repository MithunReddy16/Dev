/*
Created By: Ashok
Date: 9-MAY-2024
Req: Validate the Storeroom has only 3 characters

*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")


logger.error("***ASH***Sript DM_VALSTOREBIN**START***")
logger.error("***ASH***Sript DM_VALSTOREBIN**app="+app)
logger.error("***ASH***Sript DM_VALSTOREBIN**user="+user)
if(app=="DM_STOREROOM")
{
	
	location1=mbo.getString("LOCATION")
	numCharacters = 0;
	
    for (i = 0; i < location1.length(); i++) {
		charCode = location1.charCodeAt(i);
        //if (Java.type("java.lang.Character").isLetter(location1.charAt(i))) {
		if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122)) {
            numCharacters++;
        }
    }
	logger.error("***ASH***Sript DM_VALSTOREBIN**numCharacters="+numCharacters)
	isAdminUser=mbo.getMboSet("$adminuser","groupuser","groupname IN ('MAXADMIN') and userid='"+user+"'").count();
	logger.error("***ASH***Sript DM_VALSTOREBIN**isAdminUser="+isAdminUser)
	//if(numCharacters>3 && isAdminUser==0)
	if(location1.length()!=3 && isAdminUser==0)
	{
		service.error("dm_locid","storecharlenval")
	}
}