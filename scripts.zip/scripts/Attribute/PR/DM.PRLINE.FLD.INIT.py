from psdi.mbo import MboConstants
from psdi.server import MXServer


#PR = mbo.getOwner()

mbovalue.setFlag(MboConstants.READONLY,False)
'''

if PR :
    PRStatus = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("PRSTATUS", PR.getString("STATUS"), PR)
    if PRStatus == 'APPR':
        mbovalue.setFlag(MboConstants.READONLY,False)
else:
    mbovalue.setFlag(MboConstants.READONLY,False)
    
'''
#if not interactive :
#if mbo.getName()=="PR":
#    mbo.setFieldFlag(["DM_GRPPRHEADERID","DM_GRPPRNUM"],MboConstants.READONLY,False)
#else:
#    mbo.setFieldFlag(["DESCRIPTION","DM_POSTATUS","DM_ITEMID","DM_GRPPONUM","DM_CREATIONDATE","DM_GRPPOHEADERID","DM_GRPPOLINENUM"],MboConstants.READONLY,False)