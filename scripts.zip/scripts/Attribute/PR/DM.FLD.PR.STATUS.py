#############################################
# Push Record to WF incase Status = GRP RETURN
# AA @14/11/25
###########################################
from psdi.server import MXServer 
from psdi.util.logging import MXLoggerFactory
from psdi.util import MXException

myLogger = MXLoggerFactory.getLogger("maximo.custom")

if mbo.getString('STATUS') == 'GRPRETURN':
    mxServer=MXServer.getMXServer()
    WFService = MXServer.getMXServer().lookup("WORKFLOW")
    PRWFInstanceSet = WFService.getActiveInstances(mbo)
    PRWFInstance =PRWFInstanceSet.moveFirst()
    if PRWFInstance:
        PRWFInstance.stopWorkflow("Stopped via script")
        
    WFService.initiateWorkflow('DM_INVPR', mbo)