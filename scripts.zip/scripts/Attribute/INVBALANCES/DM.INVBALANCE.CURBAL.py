if launchPoint == "FLD.INVBALANCE.NEWBAL":
    if not mbovalue.isNull():
        mbo.setFieldFlag('SHRINKAGEACC',128L,True)
        mbo.setFieldFlag('CONTROLACC',128L,True)
    #credit
    #mbo.setValueNull('SHRINKAGEACC')
    #debit
    #mbo.setValueNull('CONTROLACC')