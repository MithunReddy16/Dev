/*
Script: DM_SETINVBALANCEDATE
Created By: Ashok
Date: 21-Aug-2024
Req: Set the INVBALANCE.DM_BALANCEDATE to the last received Date,  

The Below Script only works for the Receiving, But not for Current Balance Adjustments 

*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)



//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.debug("***ASH***Sript DM_SETINVBALANCEDATE**START***")
logger.debug("***ASH***Sript DM_SETINVBALANCEDATE**mbo.getOwner()="+mbo.getOwner())
if(mbo.getOwner()!=null)
{
	logger.debug("***ASH***Sript DM_SETINVBALANCEDATE**mbo.getOwner().getName()="+mbo.getOwner().getName())
	curBalmboValue = mbo.getMboValue("CURBAL")
	oldbal=curBalmboValue.getPreviousValue().asDouble();
	logger.debug("***ASH***Sript DM_SETINVBALANCEDATE**oldbal="+oldbal)
	newbal=curBalmboValue.getDouble();
	logger.debug("***ASH***Sript DM_SETINVBALANCEDATE**newbal="+newbal)
	logger.debug("***ASH***Sript DM_SETINVBALANCEDATE**MXServer.getMXServer().getDate()="+MXServer.getMXServer().getDate())
	owner2=mbo.getOwner().getOwner();
	logger.debug("***ASH***Sript DM_SETINVBALANCEDATE**mbo.getOwner().getOwner()="+owner2)
	if(mbo.getOwner().getOwner()!=null)
	{
		
		logger.debug("***ASH***Sript DM_SETINVBALANCEDATE**mbo.getOwner().getOwner().getName()="+owner2.getName())
		if(owner2.getName()=="MATRECTRANS" )
		{
			logger.debug("***ASH***Sript DM_SETINVBALANCEDATE**ISSUETYPE="+owner2.getString("ISSUETYPE"))
			logger.debug("***ASH***Sript DM_SETINVBALANCEDATE**ISSUE="+owner2.getInt("ISSUE"))
			if( oldbal<newbal && owner2.getInt("ISSUE")==0)
			{
				mbo.setValue("DM_BALANCEDATE",MXServer.getMXServer().getDate(),2)
				logger.debug("***ASH***Sript DM_SETINVBALANCEDATE** after setvalue")
			}
		}
	}
}
logger.debug("***ASH***Sript DM_SETINVBALANCEDATE**END***")