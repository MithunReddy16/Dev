#------------------------------------------------------------------------

#Script Name :DM_DM_ACCIDENTCOST
#Description :Update amount field in accident app

#Author/Modifiedby   Version       Date               Comment
#-----------------------------------------------------------------------------------------
#NK                   1.0          27-Oct-2025         Initial version.

#----------------------------------------------------------------------------------------

from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory

myLogger = MXLoggerFactory.getLogger("maximo.custom")
myLogger.debug("****This is DM_ACCIDENTCOST****")

qty=mbo.getDouble("QUANTITY")
unitcost = mbo.getDouble("UNITPRICE")
total = qty * unitcost
mbo.setValue("AMOUNT", total,MboConstants.NOACCESSCHECK)
#mbo.setFieldFlag("AMOUNT", MboConstants.READONLY, True)
mbo.getMboValue("AMOUNT").setFlag(MboConstants.READONLY, True)