# Author Mithun
from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

mylogger = MXLoggerFactory.getLogger("maximo.custom.inventory")
mylogger.debug("*****DM_MATREC_TOBIN***1")
App= mbo.getThisMboSet().getParentApp()
if App =='DM_SHIPREC':
    if mbo.isNew() and mbo.toBeAdded() :
        tostore=mbo.getString("TOSTORELOC")
        if tostore!="HOLDING" :
            mylogger.debug("*****DM_MATREC_NEW***5.1"+str(tostore))
            mbo.setFieldFlag('TOBIN', MboConstants.REQUIRED, True)