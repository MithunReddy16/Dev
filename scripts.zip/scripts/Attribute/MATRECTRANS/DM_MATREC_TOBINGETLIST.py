# Author : Mithun 
from psdi.server import MXServer
tostore = mbo.getString('TOSTORELOC')
relationObject = "DM_STOREBINS"
listWhere = " binnum is not null   and ACTIVE=1  and   storeroomname ='"+tostore+"' "
relationWhere = " binnum is not null   and ACTIVE=1  and   storeroomname ='"+tostore+"' "
srcKeys = ['BINNUM']
targetKeys = ['TOBIN']