# Author : Mithun
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants
logger = MXLoggerFactory.getLogger("maximo.custom.inventory")
logger.debug("**** DM_OH_BALANCESUPDATE debug Started ***1")

grpbal = mbo.getString("GRPBAL")
maximobal = mbo.getString("MAXIMOBAL")

if grpbal is not None and grpbal.strip() != "" and maximobal is not None and maximobal.strip() != "":            
    grpbal_val = float(grpbal)
    maximobal_val = float(maximobal)        
    if grpbal_val == maximobal_val:            
        mbo.setValue("RESULT", "MATCH")
    else:
        mbo.setValue("RESULT", "NOT MATCH")