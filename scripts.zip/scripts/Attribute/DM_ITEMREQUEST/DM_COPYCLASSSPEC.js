load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")

//logger.error("Entering SR_INIT script for ticket " + mbo.getString("TICKETID"))
logger.error("***ASH***Sript DM_COPYCLASSSPEC**START***")
if(launchPoint=="DM_COPYCLASSPECCLASS")
{
    if(mbo.getString("CLASSIFICATIONID").length()>0)
    {
        //classSpecSet=mbo.getMboSet("CLASSIFICATION.CLASSSTRUCTURE.CLASSSPEC");
        classSpecSet=mbo.getMboSet("CLASSSPECUSEWITH");

		classSpecSet.setUserWhere("objectname='DM_ITEMREQUEST'");
        classSpecSet.setOrderBy("SEQUENCE");
        classSpecSet.reset();

        //classSpecSet=mbo.getMboSet("CLASSSPEC");
        logger.error("***ASH***Sript DM_COPYCLASSSPEC**classSpecSet.count="+classSpecSet.count())
        classItemSpecSet=mbo.getMboSet("DM_ITEMSPEC");
        logger.error("***ASH***Sript DM_COPYCLASSSPEC**classItemSpecSet.count="+classItemSpecSet.count())
        //fields=["ASSETATTRID"]
        
        classItemSpecSet.deleteAndRemoveAll();
        
        //classItemSpecSet.deleteAll(11);
        
        //classItemSpecSet.clear();
        logger.error("***ASH***Sript DM_COPYCLASSSPEC**After delete classItemSpecSet.count="+classItemSpecSet.count())
// First insert mandatory = 1
//var displaySeq = 10;
for (var i = 0; i < classSpecSet.count(); i++) {
    var classSpecMbo = classSpecSet.getMbo(i);
    
    
    if ((mbo.getBoolean("dm_isoem") == 1 && classSpecMbo.getInt("dm_isoem") == 1) ||
                (mbo.getBoolean("dm_isoem") == 0 && classSpecMbo.getInt("mandatory") == 1)) {
        
        var classItemSpecMbo = classItemSpecSet.addAtEnd();
        classItemSpecMbo.setValue("REQUESTNUM", mbo.getString("REQUESTNUM"));
        classItemSpecMbo.setValue("SITEID", mbo.getString("SITEID"));
        classItemSpecMbo.setValue("ASSETATTRID", classSpecMbo.getString("ASSETATTRID"));
        classItemSpecMbo.setValue("MEASUREUNITID", classSpecMbo.getString("CLASSSPEC.MEASUREUNITID"));
        //classItemSpecMbo.setValue("SECTION", classSpecMbo.getString("SECTION"));
        classItemSpecMbo.setValue("CLASSSTRUCTUREID", mbo.getString("CLASSSTRUCTUREID"));
        classItemSpecMbo.setValue("REFOBJECTNAME", "DM_ITEMREQUEST");
        classItemSpecMbo.setValue("REFOBJECTID", mbo.getLong("DM_ITEMREQUESTID"));
        classItemSpecMbo.setValue("MANDATORY", 1); // Set mandatory to 1
        var isOEM = mbo.getBoolean("dm_isoem")
        var SecondaryFlag = isOEM ? classSpecMbo.getInt("mandatory") : classSpecMbo.getInt("dm_isoem");
        classItemSpecMbo.setValue("dm_secmandatory", SecondaryFlag);

        classItemSpecMbo.setValue("DISPLAYSEQUENCE", classSpecMbo.getInt("SEQUENCE")); 
		//classItemSpecMbo.setValue("DISPLAYSEQUENCE", displaySeq)
		//displaySeq = displaySeq + 10;
    }
}

// Then insert mandatory = 0
for (var i = 0; i < classSpecSet.count(); i++) {
    var classSpecMbo = classSpecSet.getMbo(i);
    
    
     if ((mbo.getBoolean("dm_isoem") == 1 && classSpecMbo.getInt("dm_isoem") == 0) ||
                (mbo.getBoolean("dm_isoem") == 0 && classSpecMbo.getInt("mandatory") == 0)) {
        
        var classItemSpecMbo = classItemSpecSet.addAtEnd();
        classItemSpecMbo.setValue("REQUESTNUM", mbo.getString("REQUESTNUM"));
        classItemSpecMbo.setValue("SITEID", mbo.getString("SITEID"));
        classItemSpecMbo.setValue("ASSETATTRID", classSpecMbo.getString("ASSETATTRID"));
        classItemSpecMbo.setValue("MEASUREUNITID", classSpecMbo.getString("CLASSSPEC.MEASUREUNITID"));
        //classItemSpecMbo.setValue("SECTION", classSpecMbo.getString("SECTION"));
        classItemSpecMbo.setValue("CLASSSTRUCTUREID", mbo.getString("CLASSSTRUCTUREID"));
        classItemSpecMbo.setValue("REFOBJECTNAME", "DM_ITEMREQUEST");
        classItemSpecMbo.setValue("REFOBJECTID", mbo.getLong("DM_ITEMREQUESTID"));
        classItemSpecMbo.setValue("MANDATORY", 0); // Set mandatory to 0
        
        var isOEM = mbo.getBoolean("dm_isoem");
        var SecondaryFlag = isOEM ? classSpecMbo.getInt("mandatory") : classSpecMbo.getInt("dm_isoem");
        classItemSpecMbo.setValue("dm_secmandatory", SecondaryFlag);

        classItemSpecMbo.setValue("DISPLAYSEQUENCE", classSpecMbo.getInt("SEQUENCE"));
		//classItemSpecMbo.setValue("DISPLAYSEQUENCE", displaySeq)
		//displaySeq = displaySeq + 10;
    }
	
}
 classItemSpecSet.moveFirst();
 //classItemSpecSet.setOrderBy("DISPLAYSEQUENCE ASC");
 //classItemSpecSet.reset();   

    }
    /*
    else
    {
        
            logger.error("***ASH***Sript DM_COPYCLASSSPEC** launchPoint="+launchPoint)
            logger.error("***ASH***Sript DM_COPYCLASSSPEC** classificationid is empty")
            mbo.setValueNull("CLASSSTRUCTUREID",11);
             
            classItemSpecSet=mbo.getMboSet("DM_ITEMSPEC")
            logger.error("***ASH***Sript DM_COPYCLASSSPEC**classItemSpecSet.count="+classItemSpecSet.count())
            classItemSpecSet.deleteAll(11);
            classItemSpecSet.clear();
            logger.error("***ASH***Sript DM_COPYCLASSSPEC** aft del classItemSpecSet.count="+classItemSpecSet.count())
            
        
    }*/
}
else if (launchPoint=="DM_COPYCLASSSPEC") //classificationid
{
    
    if(mbo.getString("CLASSIFICATIONID").length()<=0)
    {
        logger.error("***ASH***Sript DM_COPYCLASSSPEC** launchPoint="+launchPoint)
        logger.error("***ASH***Sript DM_COPYCLASSSPEC** classificationid is empty")
        mbo.setValueNull("CLASSSTRUCTUREID",11);
         mbo.setFieldFlag("dm_isoem", MboConstants.READONLY, false)
        classItemSpecSet=mbo.getMboSet("DM_ITEMSPEC")
        logger.error("***ASH***Sript DM_COPYCLASSSPEC**classItemSpecSet.count="+classItemSpecSet.count())
        classItemSpecSet.deleteAll(11);
        //classItemSpecSet.deleteAndRemoveAll(11);
        //classItemSpecSet.clear();
        logger.error("***ASH***Sript DM_COPYCLASSSPEC** aft del classItemSpecSet.count="+classItemSpecSet.count())
        
    }
   else
   {
       var classification = mbo.getString("classificationid");

if (classification) {
    mbo.setFieldFlag("dm_isoem", MboConstants.READONLY, true);

    mbo.setValueNull("DM_SHORTDESCRIPTION_LONGDESCRIPTION", MboConstants.NOACCESSCHECK);
    mbo.setValueNull("DM_LONGDESC_LONGDESCRIPTION", MboConstants.NOACCESSCHECK);

   }

    }
    
}

else if (launchPoint == "DM_COPYITEMSPEC") { // item.CLASSSTRUCTUREID
load("nashorn:mozilla_compat.js");
importPackage(Packages.psdi.mbo);
importPackage(Packages.psdi.util.logging);

logger = MXLoggerFactory.getLogger("maximo.script");

if (mbo.getBoolean("dm_isoem")) {
    var current_classification = mbo.getString("CLASSSTRUCTUREID");
    var previous_classification = mbo.getMboValue("CLASSSTRUCTUREID").getPreviousValue().asString();

    if (current_classification.length > 0) {
        var classItemSpecSet = mbo.getMboSet("ITEMSPECCLASS");
        var classItemSpec = classItemSpecSet.moveFirst();

        while (classItemSpec !== null) {
            var classSpecUseWithSet = classItemSpec.getMboSet("DM_CLASSSEQUENCE");
            var classSpecUseWithMbo = classSpecUseWithSet.moveFirst();

            if (classSpecUseWithMbo !== null) {
                var isOem = classSpecUseWithMbo.getBoolean("DM_ISOEM");
                var isMandatory = classSpecUseWithMbo.getBoolean("MANDATORY");
				
				classItemSpec.setValue("MANDATORY", isOem, MboConstants.NOACCESSCHECK);
                classItemSpec.setValue("dm_secmandatory", isMandatory, MboConstants.NOACCESSCHECK);
				/*
                if (isOem && isMandatory) {
                    classItemSpec.setValue("MANDATORY", 1, MboConstants.NOACCESSCHECK);
                    classItemSpec.setValue("dm_secmandatory", 0, MboConstants.NOACCESSCHECK);
                } else if (!isOem && isMandatory) {
                    classItemSpec.setValue("MANDATORY", 0, MboConstants.NOACCESSCHECK);
                    classItemSpec.setValue("dm_secmandatory", 1, MboConstants.NOACCESSCHECK);
                } else {
                    classItemSpec.setValue("MANDATORY", 0, MboConstants.NOACCESSCHECK);
                    classItemSpec.setValue("dm_secmandatory", 0, MboConstants.NOACCESSCHECK);
                }*/
            }

            classItemSpec = classItemSpecSet.moveNext();
        }
    }

} else {
    var classItemSpecSet = mbo.getMboSet("ITEMSPECCLASS");
    var classItemSpec = classItemSpecSet.moveFirst();

    while (classItemSpec !== null) {
        var classSpecUseWithSet = classItemSpec.getMboSet("DM_CLASSSEQUENCE");
        var classSpecUseWithMbo = classSpecUseWithSet.moveFirst();

        if (classSpecUseWithMbo !== null) {
            var isOem = classSpecUseWithMbo.getBoolean("DM_ISOEM");
            var isMandatory = classSpecUseWithMbo.getBoolean("MANDATORY");
			
			classItemSpec.setValue("MANDATORY", isMandatory, MboConstants.NOACCESSCHECK);
            classItemSpec.setValue("dm_secmandatory",  isOem, MboConstants.NOACCESSCHECK);
			/*
            if (!isOem && isMandatory) {
                classItemSpec.setValue("MANDATORY", 1, MboConstants.NOACCESSCHECK);
                classItemSpec.setValue("dm_secmandatory", 0, MboConstants.NOACCESSCHECK);
            } else if (isOem && isMandatory) {
                classItemSpec.setValue("MANDATORY", 0, MboConstants.NOACCESSCHECK);
                classItemSpec.setValue("dm_secmandatory", 1, MboConstants.NOACCESSCHECK);
            } else {
                classItemSpec.setValue("MANDATORY", 0, MboConstants.NOACCESSCHECK);
                classItemSpec.setValue("dm_secmandatory", 0, MboConstants.NOACCESSCHECK);
            }*/
        }

        classItemSpec = classItemSpecSet.moveNext();
    }
}

// Refresh UI
if (interactive)
{
classItemSpecSet.moveFirst();
var session = service.webclientsession();
var App = session.getCurrentApp();
App.getAppBean().fireDataChangedEvent();
}
}
else if (launchPoint == "DM_UPDITEMSPEC") { // classificationid
    if (mbo.isNew()) {
        var owner = mbo.getOwner();
        if (owner != null && owner.getName() == "ITEM") {
            if (owner.getBoolean("dm_isoem")) {
                var classStructureId = owner.getString("CLASSSTRUCTUREID");
                if (classStructureId != null && classStructureId.trim() !== "") {
                    var classSpecUseWithSet = mbo.getMboSet("DM_CLASSSEQUENCE");
                    var classSpecUseWithMbo = classSpecUseWithSet.moveFirst();
                    var classSpecIsoem = classSpecUseWithMbo.getBoolean("DM_ISOEM");
                    mbo.setValue("MANDATORY", classSpecIsoem, MboConstants.NOACCESSCHECK);
                }
            }
        }
    }
}


logger.error("***ASH***Sript DM_COPYCLASSSPEC**END***")