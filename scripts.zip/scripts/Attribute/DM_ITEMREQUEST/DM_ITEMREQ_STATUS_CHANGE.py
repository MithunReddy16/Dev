#DM_ITEMREQ_STATUS_CHANGE



from psdi.server import MXServer
from  psdi.common.context import UIContext
#from psdi.webclient.system.controller import SessionContext, Utility, WebClientEvent

mxServer = MXServer.getMXServer()
from psdi.util.logging import MXLoggerFactory
myLogger = MXLoggerFactory.getLogger("maximo.custom")


#app = service.webclientsession().getCurrentApp()
#ItemRequestSet = app.getResultsBean().getMboSet()
#isTableSelect = app.getResultsBean().getTableStateFlags().isFlagSet(ResultsBean.TABLE_SUBSELECT_ON)


def setError(Msg):
		#global errorkey,errorgroup,params
		#errorkey='scriptvalidationerror'
		#errorgroup='scriptval'
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)



# ItemRequest (HEADER) Status Field
if launchPoint == 'DM_ITEMREQUEST.STATUS':
    
	
		
		ItemRequestMbo = mbo
		
		StatusHistorySet = ItemRequestMbo.getMboSet(HeaderStatusSet)
		StatusHistoryMbo = StatusHistorySet.addAtEnd(2)
		
		StatusHistoryMbo.setValue('ORGID',ItemRequestMbo.getString('ORGID'))	
		StatusHistoryMbo.setValue('SITEID',ItemRequestMbo.getString('SITEID'))
		StatusHistoryMbo.setValue('REQUESTNUM',ItemRequestMbo.getString('REQUESTNUM'))	
		#StatusHistoryMbo.setValue('STATUSDATE',ItemRequestMbo.getDate('STATUSDATE'))
		StatusHistoryMbo.setValue('STATUSDATE',MXServer.getMXServer().getDate())
		StatusHistoryMbo.setValue('STATUS',ItemRequestMbo.getString('STATUS'))