if app=='DM_ITEMREQ':
    itemSet = mbo.getMboSet("ITEM")
    itemSet.reset()
    
    if not itemSet.isEmpty():
        service.error("dm", "genericerror", ["GRPITEMCODE does exist in the ITEM table"])