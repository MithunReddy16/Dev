# DM_IRUPDITEMCOPYDTLS  - Modified by Mithun
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")

logger.error("***ASH***Sript DM_IRUPDITEMCOPYDTLS**START***")

# Mbo of current record: mbo
itemSet = mbo.getMboSet("DM_UPDITEMDESC")
itemMbo = itemSet.getMbo(0)

fieldsString = [
	"ITEMNUM", "ITEMSETID", "CLASSSTRUCTUREID", "COMMODITYGROUP",
	"COMMODITY", "GROUPNAME", "METERNAME", "LOTTYPE", "MAXISSUE",
	"ORDERUNIT", "ISSUEUNIT", "MSDSNUM", "DM_PLANNING", "DM_SOURCING",
	"DM_MAINUSER", "DM_AVAILABILITY","DM_CONDITION", "DESCRIPTION", "DM_GRP_USERITEMTYPE","DESCRIPTION_LONGDESCRIPTION"
]

fieldsInt = [
	"CONDITIONENABLED", "ISKIT", "CAPITALIZED", "INSPECTIONREQUIRED",
	"SPAREPARTAUTOADD", "ATTACHONISSUE", "TAXEXEMPT", "ROTATING","DM_ISOEM"
]

# If UPDITEMNUM is empty: clear all copied fields
updItemNum = mbo.getString("UPDITEMNUM")
if updItemNum is None or len(updItemNum) == 0:
	for field in fieldsInt:
		# 11 is kept from original script (same behaviour)
		mbo.setValueNull(field, 11)

	for field in fieldsString:
		mbo.setValueNull(field, 11)

	mbo.setValueNull("RECEIPTTOLERANCE", 2)
	mbo.setValueNull("CLASSIFICATIONID", 2)

	#irClassAttribuitesSet = mbo.getMboSet("DM_ITEMSPEC")
	#if irClassAttribuitesSet is not None and irClassAttribuitesSet.count() > 0:
	#	irClassAttribuitesSet.deleteAll(2)

# If an ITEM is selected: copy data from ITEM to request
if itemMbo is not None:

	# Copy string fields from ITEM
	for i in range(len(fieldsString)):
		fieldName = fieldsString[i]
		
		if fieldName in ["DESCRIPTION_LONGDESCRIPTION","DESCRIPTION"]:
			if fieldName == "DESCRIPTION" :
				
				mbo.setValue("DM_SHORTDESCRIPTION_LONGDESCRIPTION",itemMbo.getString(fieldName),MboConstants.NOACCESSCHECK | MboConstants.NOACTION)
				#service.error(itemMbo.getString(fieldName),mbo.getString("DM_SHORTDESCRIPTION_LONGDESCRIPTION"))
			if fieldName == "DESCRIPTION_LONGDESCRIPTION" :
				mbo.setValue("DM_LONGDESC_LONGDESCRIPTION",itemMbo.getString(fieldName),MboConstants.NOACCESSCHECK | MboConstants.NOACTION)
				
		elif i == 2 or i == 3:
			# CLASSSTRUCTUREID, COMMODITYGROUP (special flags in original script)
			mbo.setValue(fieldName,itemMbo.getString(fieldName),MboConstants.NOACCESSCHECK | MboConstants.NOACTION)
		else:
			mbo.setValue(fieldName, itemMbo.getString(fieldName), 2)

	# Other fields
	mbo.setValue("RECEIPTTOLERANCE", itemMbo.getDouble("RECEIPTTOLERANCE"), 2)
	mbo.setValue("CLASSIFICATIONID", itemMbo.getString("CLASSSTRUCTURE.CLASSIFICATIONID"), 2)

	# Copy integer/boolean-style fields
	for field in fieldsInt:
		mbo.setValue(field, itemMbo.getInt(field), 2)

	# Copy classification attributes
	irClassAttribuitesSet = mbo.getMboSet("DM_ITEMSPEC")
	itemClassAttrSet = itemMbo.getMboSet("ITEMSPECCLASS")
	itemClassAttrSet.setOrderBy("DISPLAYSEQUENCE ASC")

	if irClassAttribuitesSet:
		irClassAttribuitesSet.deleteAndRemoveAll(2)

	for i in range(itemClassAttrSet.count()):
		itemClassAttrMbo = itemClassAttrSet.getMbo(i)
		if itemClassAttrMbo is None:
			break

		irClassAttribuitesMbo = irClassAttribuitesSet.addAtEnd(2)

		irClassAttribuitesMbo.setValue(
			"ASSETATTRID", itemClassAttrMbo.getString("ASSETATTRID")
		)
		irClassAttribuitesMbo.setValue(
			"CLASSSTRUCTUREID", itemClassAttrMbo.getString("CLASSSTRUCTUREID")
		)
		irClassAttribuitesMbo.setValue(
			"DISPLAYSEQUENCE", itemClassAttrMbo.getInt("DISPLAYSEQUENCE")
		)
		irClassAttribuitesMbo.setValue(
			"REQUESTNUM", mbo.getString("REQUESTNUM")
		)
		irClassAttribuitesMbo.setValue(
			"SITEID", mbo.getString("SITEID")
		)
		
		
		irClassAttribuitesMbo.setValue("REFOBJECTNAME", "DM_ITEMREQUEST")
		irClassAttribuitesMbo.setValue(
			"REFOBJECTID", mbo.getLong("DM_ITEMREQUESTID")
		)
		irClassAttribuitesMbo.setValue(
			"MANDATORY",
			itemClassAttrMbo.getInt("MANDATORY")
		)
		irClassAttribuitesMbo.setValue(
			"DM_SECMANDATORY",
			itemClassAttrMbo.getInt("DM_SECMANDATORY")
		)
		# irClassAttribuitesMbo.setValue(
		#	 "DM_SHORTDESCREQ",
		#	 irClassAttribuitesMbo.getInt("CLASSSPEC.DM_SHORTDESCREQ")
		# )

		# Copy values (DATEVALUE / NUMVALUE / ALNVALUE / TABLEVALUE)
		if itemClassAttrMbo.getDate("DATEVALUE") is not None:
			irClassAttribuitesMbo.setValue("DATEVALUE", itemClassAttrMbo.getDate("DATEVALUE"))
			logger.error("***ASH***Sript DM_IRUPDITEMCOPYDTLS**ITEM**Attribute="+ itemClassAttrMbo.getString("ASSETATTRID")+ ", Date value=" + str(itemClassAttrMbo.getDate("DATEVALUE"))			)

		elif len(itemClassAttrMbo.getString("NUMVALUE")) > 0:
			irClassAttribuitesMbo.setValue("NUMVALUE", itemClassAttrMbo.getDouble("NUMVALUE"))
			logger.error(
				"***ASH***Sript DM_IRUPDITEMCOPYDTLS**ITEM**Attribute="
				+ itemClassAttrMbo.getString("ASSETATTRID")
				+ ", NUMVALUE value="
				+ str(itemClassAttrMbo.getDouble("NUMVALUE"))
			)

		elif len(itemClassAttrMbo.getString("ALNVALUE")) > 0:
			irClassAttribuitesMbo.setValue(
				"ALNVALUE", itemClassAttrMbo.getString("ALNVALUE")
			)
			logger.error(
				"***ASH***Sript DM_IRUPDITEMCOPYDTLS**ITEM**Attribute="
				+ itemClassAttrMbo.getString("ASSETATTRID")
				+ ", ALNVALUE value="
				+ itemClassAttrMbo.getString("ALNVALUE")
			)

		elif len(itemClassAttrMbo.getString("TABLEVALUE")) > 0:
			irClassAttribuitesMbo.setValue(
				"TABLEVALUE", itemClassAttrMbo.getString("TABLEVALUE")
			)
			logger.error(
				"***ASH***Sript DM_IRUPDITEMCOPYDTLS**ITEM**Attribute="
				+ itemClassAttrMbo.getString("ASSETATTRID")
				+ ", TABLEVALUE value="
				+ itemClassAttrMbo.getString("TABLEVALUE")
			)

		# Extra fields if present
		muid = itemClassAttrMbo.getString("MEASUREUNITID")
		if muid is not None and len(muid) > 0:
			irClassAttribuitesMbo.setValue("MEASUREUNITID", muid)

		section = itemClassAttrMbo.getString("SECTION")
		if section is not None and len(section) > 0:
			irClassAttribuitesMbo.setValue("SECTION", section)