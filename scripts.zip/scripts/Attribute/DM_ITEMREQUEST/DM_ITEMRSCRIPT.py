from psdi.mbo import MboConstants
status=mbo.getString("Status")
if status not in ("D-APPR","CLOSED","CAN"):
       if  mbo.isNull("ITRDESCRIPTION"):
                            mbo.setFieldFlag("ITRDescription", MboConstants.READONLY,False )
                            mbo.setFieldFlag("ITRDescription", MboConstants.REQUIRED, True)
elif status  in ("D-APPR","CLOSED","CAN"):
                            mbo.setFieldFlag("ITRDescription", MboConstants.READONLY,True )
                            mbo.setFieldFlag("ITRDescription", MboConstants.REQUIRED, False)