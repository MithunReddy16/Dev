/*
Script: DM_MINVALUE.VAL
Created By: Ashok
Date: 16-Sep-2024
Req: 
1. Make Above


*/

load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Script DM_MINVALUE.VALL**START***")
//mboset1=mboset;
mboset1=mbo.getThisMboSet();
logger.error("***ASH***Script DM_MINVALUE.VAL**mboset1 count="+mboset1.count())
mboset1.setOrderBy("DM_MINVALUE ASC")
minvalue=null;
maxvalue=null;
for(i=0;(subcontMbo=mboset1.getMbo(i))!=null;i++)
{
	
	prevminvalue=minvalue;
	prevmaxvalue=maxvalue;
	logger.error("***ASH***Script DM_MINVALUE.VAL**mboset1 prevminvalue="+prevminvalue)
	logger.error("***ASH***Script DM_MINVALUE.VAL**mboset1 prevmaxvalue="+prevmaxvalue)
	minvalue=subcontMbo.getDouble("DM_MINVALUE")
	maxvalue=subcontMbo.getDouble("DM_MAXVALUE")
	logger.error("***ASH***Script DM_MINVALUE.VAL**mboset1 minvalue="+minvalue)
	logger.error("***ASH***Script DM_MINVALUE.VAL**mboset1 maxvalue="+maxvalue)
	errorMsg="Value "+minvalue+" is less than "+maxvalue;
	if(prevminvalue!=null && minvalue<=prevmaxvalue)
	{
		service.error("dm","minvaluelessmax",[errorMsg])
	}
}
logger.error("***ASH***Script DM_MINVALUE.VAL**END***")