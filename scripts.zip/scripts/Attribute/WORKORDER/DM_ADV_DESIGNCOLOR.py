##############################################
#script:DM_ADV_DESIGNCOLOR
#Createdby:NK
#Creation Date:18-08-2026
#scope: Adv -  Design Completion validation
###############################################

from psdi.server import MXServer
from java.util import Calendar
from psdi.mbo import MboConstants

status = mbo.getString("STATUS")
expStart = mbo.getDate("DM_ADV_DT3")
expFinish = mbo.getDate("DM_ADV_DT7")

# Design currently active
designInProgressStatuses = [
    "DES_ASSIGNED",
    "INPROGRESS"
]

# Design stage completed / moved forward
designCompletedStatuses = [
    "DES_QC_WAPPR",
    "REQWAPPR",
    "REQAPPR",
    "WPRINT",
    "PRINT-QC",
    "PRINTQCCOMP",
    "WWORKSHOP",
    "WORKSHOP-QA",
    "WS-QA-COMP"
]


def dateOnly(dt):
    if dt is None:
        return None

    cal = Calendar.getInstance()
    cal.setTime(dt)

    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)

    return cal.getTime()


color = ""
designStatus = ""

today = dateOnly(MXServer.getMXServer().getDate())
startDate = dateOnly(expStart)
finishDate = dateOnly(expFinish)


# ==========================================================
# DESIGN CURRENTLY IN PROGRESS
# ==========================================================
if status in designInProgressStatuses:

    if startDate is not None and finishDate is not None:
        # Before expected start
        if today.before(startDate):
            color = "ORANGE"
            designStatus = "INPROGRESS"

        # Between expected start and expected finish
        elif today.before(finishDate) or today.equals(finishDate):
            color = "ORANGE"
            designStatus = "INPROGRESS"

        # Expected finish already passed
        elif today.after(finishDate):
            color = "RED"
            designStatus = "DELAYED"

    else:
        color = "ORANGE"
        designStatus = "INPROGRESS"


# ==========================================================
# DESIGN COMPLETED
# ==========================================================
elif status in designCompletedStatuses:
    color = "GREEN"
    designStatus = "COMPLETED"
    
#if designStatus:
#    mbo.setValue("DM_ADV_STATUS",designStatus,MboConstants.NOACCESSCHECK)
#else:
#    mbo.setValueNull("DM_ADV_STATUS",MboConstants.NOACCESSCHECK)    


thisvalue = color