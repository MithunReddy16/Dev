if not mbo.isNull("ORIGRECORDCLASS") and mbo.getString("ORIGRECORDCLASS") == "WORKORDER":
    origWo = mbo.getMboSet("ORIGWO").getMbo(0)
    if origWo:
        mbo.setValue("VENDOR",origWo.getString("VENDOR"))
        mbo.setValue("DM_VENDCONTRACT",origWo.getString("DM_VENDCONTRACT"))