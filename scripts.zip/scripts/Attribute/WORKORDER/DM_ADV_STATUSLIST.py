##############################################
#script:DM_ADV_STATUSLIST
#Createdby:NK
#Creation Date:25-08-2026
#scope: Adv -  Retrieve the status list
###############################################

from psdi.server import MXServer

mxServer = MXServer.getMXServer()

app = mbo.getThisMboSet().getApp()

statusSet = mxServer.getMboSet(
    "SYNONYMDOMAIN",
    mbo.getUserInfo()
)

if app and app.upper() == "DM_PLUSGWO_ADV":

    statusSet.setWhere(
        "domainid='WOSTATUS' "
        "and value in ("
        "'WAPPR',"
        "'WASSIGN',"
        "'DES_ASSIGNED',"
        "'INPROGRESS',"
        "'DESIGNED',"
         "'HOLD',"
        "'DES_QC_WAPPR',"
        "'DES_QC_APPR',"
        "'DES_QC_REJ',"
        "'REQWAPPR',"
        "'REQAPPR',"
        "'REQ-RETURNED',"
        "'WPRINT',"
        "'PRINT-QC',"
        "'PRINTQCCOMP',"
        "'WWORKSHOP',"
        "'WORKSHOP-QA',"
        "'WS-QA-COMP',"
         "'RETURNED-WQA',"
         "'WORKCOMP',"
         "'RETURNED',"
         "'CLOSE',"
          "'CAN'"
        ")"
    )

else:

    statusSet.setWhere(
        "domainid='WOSTATUS'"
    )

statusSet.reset()

listMboSet = statusSet

srcKeys = ["VALUE"]
targetKeys = ["STATUS"]