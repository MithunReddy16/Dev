if app == 'DM_PLUSGWO_STP' or mbo.getString("dm_maintdept") =='60181':
    relationObject = "WORKTYPE"
    listWhere = "WORKTYPE in ('CM','PM','MD','IN','OTHER') and orgid='DMORG'"
    relationWhere  = listWhere + " AND WORKTYPE=:WORKTYPE"
else:
    relationObject = "WORKTYPE"
    listWhere = "orgid='DMORG'"
    relationWhere  = listWhere + " AND WORKTYPE=:WORKTYPE"