###############################################
#script:DM_ADV_DESIGNERQA
#Createdby:nk
#Creation Date:29-09-26
#scope: Designer QA Checker cannot be the same person as the Designer
###############################################

from psdi.server import MXServer
from psdi.mbo import MboConstants

designer = mbo.getString("OWNER")
designQA = mbo.getString("DM_ADV_DQAC")

if designer and designQA:
    if designer.strip().upper() == designQA.strip().upper():
        service.error(
            "scriptval",
            "scriptvalidationerror",
            ["Designer QA cannot be the same person as the Designer. Please select a different person."]
            )