##############################################
#script:DM_ADV_WO
#Createdby:NK
#Creation Date:22-12-2025
#scope: Parent and related SR closure
###############################################

from psdi.server import MXServer
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants

myLogger = MXLoggerFactory.getLogger("maximo.custom")
myLogger.debug("****This is DM_ADV_WO****")

mxServer = MXServer.getMXServer()
userInfo = mbo.getUserInfo()
app = mbo.getThisMboSet().getParentApp()

woStatus = mbo.getString("STATUS")
closedWOStatuses = ["CLOSE", "CAN"]

if woStatus in closedWOStatuses and mbo.getString("WORKTYPE") =="ADV":
    myLogger.debug("****DM_ADV_WO - COND 1****")
    srnum = mbo.getString("DM_ADV_REQ")
    if srnum:
        myLogger.debug("****DM_ADV_WO - COND 2****")
        currentWonum = mbo.getString("WONUM")
        rrset = mbo.getMboSet("$rr", "RELATEDRECORD", "recordkey='"+srnum+"'")
        rrset.reset()
        if not rrset.isEmpty():
            myLogger.debug("****DM_ADV_WO - COND 3****")
            wonums = []
            rr = rrset.moveFirst()
            while rr:
                myLogger.debug("****DM_ADV_WO - COND 4****")
                wonum = rr.getString("RELATEDRECKEY")
                if wonum:
                    wonums.append(wonum)
                rr = rrset.moveNext()

            rrset.close()
            if wonums:
                myLogger.debug("****DM_ADV_WO - COND 5****")
                # 2) Check if ALL those workorders are closed
                in_list = ",".join(["'%s'" % w.replace("'", "''") for w in wonums])
                woSet = mbo.getMboSet("$WO_REL", "WORKORDER", "wonum in (%s)" % in_list)
                woSet.reset()
                allClosed = True
                w = woSet.moveFirst()
                while w:
                    myLogger.debug("****DM_ADV_WO - COND 6****")
                    wonum = w.getString("WONUM")
                    if wonum == currentWonum:
                        st = woStatus
                    else:
                        st = w.getString("STATUS")
                
                    if st not in closedWOStatuses:
                        allClosed = False
                        break
                
                    w = woSet.moveNext()
                
                woSet.close()
                    
                if allClosed:
                    # 3) Close the SR (only if not already closed)
                    myLogger.debug("****DM_ADV_WO - COND 7****")
                    srSet = mbo.getMboSet("$SR_TO_CLOSE", "SR", "ticketid='"+srnum+"'")
                    srSet.reset()
                    if not srSet.isEmpty():
                        myLogger.debug("****DM_ADV_WO - COND 8****")
                        sr = srSet.getMbo(0)
                        srStatus = sr.getString("STATUS")
                        closedSRStatuses = ["CLOSED", "CANCELLED"]
                        if srStatus not in closedSRStatuses:
                            sr.changeStatus("CLOSED", mxServer.getDate(), "Auto-closed: all related work orders are closed")
                    
                    #srSet.close()