#script:DM_WOASSET
#Createdby:Ram
#Creation Date:02-MAR-23
#scope: in workorder tr application ,based on the asset selected script will set the platenum
if (app == 'DM_PLUSTWO'):
    assetnum = mbo.getString("ASSETNUM")
    if (assetnum == "" or assetnum == None):
        mbo.setValueNull("DM_PLATENUM")
    else:
        asset = mbo.getMboSet("ASSET").getMbo(0)
        platenum = asset.getString("DM_PLATE_NUM")
        mbo.setValue("DM_PLATENUM", platenum)