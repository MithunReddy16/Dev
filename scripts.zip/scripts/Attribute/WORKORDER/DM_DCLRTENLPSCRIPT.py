#script:DM_DCLRTENLPSCRIPT
#created by :ram
#purpose: restricting the lookup for dcl on engineer 
#Date:10-Jul-25

from psdi.util.logging import MXLoggerFactory
from psdi.server import MXServer
#logger = MXLoggerFactory.getLogger("custom.dm")
userInfo = MXServer.getMXServer().getSystemUserInfo()
#logger.debug("****DM_DCLRTENLPSCRIPT started *****")
#logger.debug("****DM_DCLRTENLPSCRIPT started1 *****"+mbo.getString("PERSONGROUP"))

if app == "DM_PLUSGWO_DCL":
    personGroup = "DM_DCLSP"
    #service.error("dm","genericerror",["testing dcl sup"+personGroup+""])

    relationObject = "PERSON"
    relationWhere = (
        "personid IN ("
        "  SELECT respparty FROM persongroupteam "
        "  WHERE persongroup = '{}' "
        ")"
    ).format(personGroup)

    listWhere = relationWhere
elif app == "DM_PLUSGWO_SRWN":


        personGroup = mbo.getString("PERSONGROUP")
        #raise TypeError("*** persongroups  is "+str(WONUM))
        relationObject = "PERSON"
       # relationWhere="personid=:supervisor"
        relationWhere = (
            "personid IN ("
            "SELECT respparty "
            "FROM persongroupteam "
            "WHERE persongroup = '{}' "
            ")"
        ).format(personGroup)
        listWhere = relationWhere
       # service.error("dm","genericerror",["personGroup=[" + str(personGroup) + "] listWhere=[" + str(listWhere) + "]"])
else:
   domainid="DM_WOSUP"