###############################################
#script:DM_ADV_DUR
#Createdby:nk
#Creation Date:09-09-26
#scope: Calculate Duration
##############################################

from psdi.mbo import MboConstants
from java.util import Calendar

DAY_MILLIS = 24 * 60 * 60 * 1000


def getDateOnly(dateValue):
    if dateValue is None:
        return None

    cal = Calendar.getInstance()
    cal.setTime(dateValue)

    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)

    return cal.getTime()


# ==========================================================
# EXPECTED DURATION
# ==========================================================

expStart = mbo.getDate("DM_ADV_DT3")
expFinish = mbo.getDate("DM_ADV_DT7")

if expStart is not None and expFinish is not None:
    if expStart.after(expFinish):
            service.error("dm","genericerror",["Expected start date cannot be greater than expected finish date"])
            
    startDate = getDateOnly(expStart)
    finishDate = getDateOnly(expFinish)

    diffMillis = finishDate.getTime() - startDate.getTime()

    diffDays = int(diffMillis / DAY_MILLIS)

    mbo.setValue(
        "DM_ADV_DUR",
        diffDays,
        MboConstants.NOACCESSCHECK
    )

else:
    mbo.setValueNull(
        "DM_ADV_DUR",
        MboConstants.NOACCESSCHECK
    )


# ==========================================================
# ACTUAL DURATION
# ==========================================================

actStart = mbo.getDate("DM_ADV_DT4")
actFinish = mbo.getDate("DM_ADV_DT2")

if actStart is not None and actFinish is not None:
    if actStart.after(actFinish):
            service.error("dm","genericerror",["Actual start date cannot be greater than Actual finish date"])
            
    startDate = getDateOnly(actStart)
    finishDate = getDateOnly(actFinish)

    diffMillis = finishDate.getTime() - startDate.getTime()

    diffDays = int(diffMillis / DAY_MILLIS)

    mbo.setValue(
        "DM_ADV_ACTDUR",
        diffDays,
        MboConstants.NOACCESSCHECK
    )

else:
    mbo.setValueNull(
        "DM_ADV_ACTDUR",
        MboConstants.NOACCESSCHECK
    )