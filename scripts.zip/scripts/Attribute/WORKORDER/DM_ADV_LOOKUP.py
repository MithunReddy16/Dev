#script:DM_ADV_LOOKUP
#created by :NK
#purpose: restricting the lookup 
#Date:16-Jan-26

if app == "DM_PLUSGWO_ADV": 
    if launchPoint in ("DM_ADV_LOOKUP1","DM_ADV_LOOKUP2","DM_ADV_LOOKUP6","DM_ADV_LOOKUP7","DM_ADV_LOOKUP8"):
        personGroup = "DM_ADV04"
        relationObject = "PERSON"
        relationWhere = (
            "personid IN ("
            "  SELECT respparty FROM persongroupteam "
            "  WHERE persongroup = '{}' "
            ")"
        ).format(personGroup)
        listWhere = relationWhere
    elif launchPoint in ("DM_ADV_LOOKUP3","DM_ADV_LOOKUP9"):
        personGroup = "DM_ADV03"
        relationObject = "PERSON"
        relationWhere = (
            "personid IN ("
            "  SELECT respparty FROM persongroupteam "
            "  WHERE persongroup = '{}' "
            ")"
        ).format(personGroup)
        listWhere = relationWhere
    elif launchPoint in ("DM_ADV_LOOKUP4","DM_ADV_LOOKUP5"):
        personGroup = "DM_ADV05"
        relationObject = "PERSON"
        relationWhere = (
            "personid IN ("
            "  SELECT respparty FROM persongroupteam "
            "  WHERE persongroup = '{}' "
            ")"
        ).format(personGroup)
        listWhere = relationWhere   
'''
elif launchPoint in ('DM_ADV_LOOKUP10'):
    personGroup = "DM_ADV03"
    relationObject = "PERSON"
    relationWhere = (
        "personid IN ("
        "  SELECT respparty FROM persongroupteam "
        "  WHERE persongroup = '{}' "
        ")"
    ).format(personGroup)
    listWhere = relationWhere
'''    
#else:
#    domainid="DM_WOSUP"