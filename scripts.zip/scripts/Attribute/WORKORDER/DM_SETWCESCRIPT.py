from psdi.mbo import MboConstants

cmbo=mbo.getMboSet("DM_WCONTRACT").getMbo(0)
if cmbo is not None:
        
        mbo.setValue("supervisor",cmbo.getString("dm_engineer"),2L)
        #mbo.setFieldFlag("supervisor", MboConstants.READONLY, True)
else:
    mbo.setFieldFlag("supervisor", MboConstants.READONLY, False)
    #mbo.setValueNull("supervisor")