#script:DM_WORKTYPE(DCL)
#Createdby:Ram
#Creation Date:20-SEP-23
#scope: restricting the work type based on application for DCL and transport workorders

worktype = mbo.getString("WORKTYPE")
appl = mbo.getThisMboSet().getParentApp()

if not mbo.isNull('WORKTYPE'):
    if appl and appl =='DM_PLUSGWO_DCL':
        if (worktype not in ('PM','CM','CAL')):
            service.error("dm_worktype","notValid")
    elif  appl and appl =='DM_PLUSTWO':
        if (worktype not in ('PM','CM','ACC','PDM','REG','MISC','VM')):
            service.error("dm_worktype","notValid")