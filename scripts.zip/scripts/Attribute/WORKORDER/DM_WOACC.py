#script:DM_WOACC
#Createdby:Ram
#Creation Date:02-JUN-25
#scope: script will make the work type field to read only if the workk type is ACC
from psdi.server import MXServer
from psdi.mbo import MboConstants

if not mbo.isNew():
    if mbo.getString("WORKTYPE") == 'ACC':
        mbo.setFieldFlag("WORKTYPE", MboConstants.READONLY, True)