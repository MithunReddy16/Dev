'''Sample script
Automatically run Auto Create Spatial when Work Order Status changes to Approved.'''

from psdi.server import MXServer

if  MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("WOSTATUS",woStatus, mbo) == 'APPR' :

    woNum = mbo.getString("WONUM")
    print "Auto Creating Spatial WO"
    print "WONUM:"+woNum
    print "SITEID: "+mbo.getString("SITEID")
    success = mbo.autoCreateSpatial(True)
    if (success):
        print "WO Spatial successfully created"
    else:
        print "WO Spatial creation failed"
        mbo.getThisMboSet().save();
        warngroup = "plussgis";
        warnkey = "autocreate_nofeats_placed_workorderid";
        warnparams = [woNum]