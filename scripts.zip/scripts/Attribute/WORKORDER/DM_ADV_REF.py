###############################################
#script:DM_ADV_REF
#Createdby:nk
#Creation Date:23-Dec-25
#scope: Update reference number
###############################################
from psdi.mbo import MboConstants
from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.autoscript.autwfs")
logger.debug("*******DM_ADV_REF -START**********")

wonum = mbo.getString("WONUM")
siteid = mbo.getString("SITEID")
orgid = mbo.getString("ORGID")
refNum = mbo.getString("DM_ADV_REF")
woDesign= mbo.getString("OWNER")
woDesc= mbo.getString("DESCRIPTION")


logger.debug("**********DM_ADV_REF-Ref Num:"+str(refNum))
if refNum:
# --- update RELATEDRECORD rows linked to this WO ---
    logger.debug("*******DM_ADV_REF -Condition 1****************")
    try:
        rrMboSet = mbo.getMboSet("RR", "RELATEDRECORD", 
        "ORGID='{}' AND SITEID= '{}' AND RELATEDRECKEY='{}'".format(orgid,siteid,wonum))
        if not rrMboSet.isEmpty():
            rrMbo = rrMboSet.moveFirst()
            while rrMbo:
                rrMbo.setValue("DM_ADV_REF", refNum, MboConstants.NOACCESSCHECK)
                rrMbo.setValue("DM_ADV_DESIGNER", woDesign, MboConstants.NOACCESSCHECK)
                rrMbo.setValue("DM_ADV_DESC", woDesc, MboConstants.NOACCESSCHECK)
                rrMbo = rrMboSet.moveNext()
            rrMboSet.save()

    finally:
        if rrMboSet is not None:
            rrMboSet.close()