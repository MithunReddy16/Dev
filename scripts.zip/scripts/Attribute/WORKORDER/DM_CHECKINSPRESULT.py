#script:DM_CHECKINSPRESULT
#Createdby:Ram
#Creation Date:22-JUN-22
#scope: if the inspection entered for the workorder,script for the inspection result if not entered it throws the message to complete it before closing the wo
#and if the workorder is in inprogress status and work type is insepction then script will make the workorder to be independent irrespetive of parenwo status changes
from psdi.mbo import MboConstants

wo_status = mbo.getString("STATUS")

wo_type = mbo.getString("worktype")

activitySet = mbo.getMboSet("WOACTIVITY")
activitySetNum = activitySet.count()

inspecForm = mbo.getString("INSPFORMNUM")

if launchPoint=='DM_INSPSTATUS':

    if  wo_status in ('COMP', 'WCOMP'):
        if not mbo.isNull("INSPFORMNUM"):
           if mbo.getMboSet("DM_INSPECTIONRESULT").isEmpty():
               service.error("DM", "genericerror", ["Inspection form must be filled-in before completing work order."])
     
        for i in range(0, activitySetNum):
              activity = activitySet.getMbo(i)
              if not activity.isNull("INSPFORMNUM"):
                  if activity.getMboSet("DM_INSPECTIONRESULT").isEmpty():
                        service.error("DM", "genericerror", ['Work Order cannot be completed if there are inspection forms still not completed.'])
                

if launchPoint=='DM_INSPSTATUS':
    if  wo_status in ('INPRG') and wo_type=='IN' :
        for i in range(0, activitySetNum):
              activity = activitySet.getMbo(i)
              activity.setValue("PARENTCHGSSTATUS",0, MboConstants.NOACCESSCHECK | MboConstants.NOACTION)