if app == 'DM_WOTRACK_INSP' or mbo.getString("dm_maintdept") =='60181':
    relationObject = "PERSON"
    listWhere = "status='ACTIVE' and PERSONID in (SELECT RESPPARTYGROUP from PERSONGROUPTEAM where persongroup ='DM_INSPT')"
    relationWhere  = listWhere + " status='ACTIVE' AND PERSONID=:PERSONID"
else:
    relationObject = "PERSON"
    listWhere = "status='ACTIVE'"
    relationWhere  = listWhere + "personid=:lead"