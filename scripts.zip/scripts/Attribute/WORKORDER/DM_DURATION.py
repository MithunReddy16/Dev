###################################################
# Script = DM.duration
# Description = Auto calculate duration
# Author : NK
# Version 1 - 29 Sep 2025 - Intial Version
#################################################

from psdi.server import MXServer 
from psdi.util.logging import MXLoggerFactory
from psdi.mbo import MboConstants
from java.util import Date
from java.lang import Long

myLogger = MXLoggerFactory.getLogger("maximo.custom")
myLogger.debug("****This is DM_Duration****")

def getDur(mbo, field_name):
    myLogger.debug("****DM_Duration ; In getDur method*******")    
    try:
        if mbo is not None and not mbo.isNull(field_name):
            return mbo.getDouble(field_name)
    except:
        pass
    return 0.0

try:
    actstart = mbo.getDate("ACTSTART")
    actfinish = mbo.getDate("ACTFINISH")
    labset = mbo.getMboSet("LABTRANS")
    total_hours = 0.0

    if actstart and actfinish:
        #myLogger.debug("****DM_Duration- Dates are entered************")
        if labset is not None:
            i = 0
            while True:
                lab = labset.getMbo(i)
                if lab is None:
                    break
                total_hours += getDur(lab, "REGULARHRS")
                i += 1
        mbo.setValue("ESTDUR", total_hours, MboConstants.NOACCESSCHECK)        
        #myLogger.debug("****DM_Duration - Duration is :****"+str(durationHours))
finally:
    try:
        if labset is not None:
            labset.close()
    except:
        pass