##############################################
#script:DM_ADV_DASHBOARD
#Createdby:NK
#Creation Date:01-08-2026
#scope: Adv -  Update status description
###############################################

from psdi.mbo import MboConstants

if mbo.getString("WORKTYPE") == "ADV":
    status = mbo.getString("STATUS")
    pendingWith = ""

    if status in ("DES_ASSIGNED", "DES_QC_APPR", "REQAPPR","INPROGRESS"):
        pendingWith = "Designer"

    elif status == "DES_QC_WAPPR":
        pendingWith = "Design QC"

    elif status == "REQWAPPR":
        pendingWith = "Requester"

    elif status in ("WPRINT", "PRINTQCCOMP"):
        pendingWith = "Printer"

    elif status == "PRINT-QC":
        pendingWith = "Print QC"

    elif status in ("WWORKSHOP", "WS-QA-COMP"):
        pendingWith = "Workshop"

    elif status == "WORKSHOP-QA":
        pendingWith = "WorkshopQC"
        
    elif status == "WASSIGN":
        pendingWith = "NotAssignd"

    elif status in ("CLOSE"):
        pendingWith = "CLOSED"
        
    elif status in ("CAN"):
        pendingWith = "Cancelled"

    if pendingWith:
        mbo.setValue("WOLO9", pendingWith, MboConstants.NOACCESSCHECK)
    else:
        mbo.setValueNull("WOLO9", MboConstants.NOACCESSCHECK)