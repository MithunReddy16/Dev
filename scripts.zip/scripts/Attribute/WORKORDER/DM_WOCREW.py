#script:DM_WOCREW
#Createdby:Ram
#Modifiedby : Mithun
#Creation Date:05-MAY-23
#scope: restricting the crew in workorder applications  based on application and the user he belongs to
from psdi.server import MXServer
from psdi.mbo import MboConstants
from psdi.security import UserInfo

ThisSet = mbo.getThisMboSet()
appl = ThisSet.getParentApp()

currentUser = user
groupUserSet = mbo.getMboServer().getMboSet("GROUPUSER", mbo.getUserInfo())
groupUserSet.setWhere("userid = '{}' AND groupname = 'MAXADMIN'".format(currentUser))
groupUserSet.reset()
    
maximo = MXServer.getMXServer()
currentUser = maximo.getUserInfo(user)
persond = currentUser.getPersonId() 
personMbo = mbo.getMboSet('$person', 'person', "personid = '" + persond + "'").getMbo(0)
persondept = personMbo.getString("DM_Department")
personSec = personMbo.getString("DM_SECTION")
    
orgHirMbo = mbo.getMboSet('$DM_ORGHIERARCHY', 'DM_ORGHIERARCHY', "UNITID = '" + persondept + "'").getMbo(0)
abbriviation = orgHirMbo.getString("ABBRIVIATION")

if appl and appl =='DM_PLUSTWO':

    if mbo.getString('PARENT') == '' or mbo.getString('PARENT') is None:
        relationObject = "AMCREW"
        relationWhere =" AMCREW = :AMCREW"
        listWhere = " AMCREW = 'RECPT' "
    else:
        relationObject = "AMCREW"
        relationWhere ="AMCREW = :AMCREW"
        listWhere = " AMCREW != 'RECPT' "

elif (appl and appl =='DM_PLUSGWO_STP'):
    if abbriviation == 'STP' and groupUserSet.count() == 0:
        domainid="DM_PMCREW"
        listWhere = " DM_SECTION = '" + personSec + "'"
    elif groupUserSet.count() > 0:
        domainid="DM_PMCREW"
        listWhere="1=1"
elif appl and appl == 'DM_PLUSGWO_SRWN':
   # service.error("dm","genericerror")
    relationObject = "AMCREW"
    relationWhere = "AMCREW = :AMCREW"
    if  mbo.getString('dm_bunit') == 'FIUNIT'  :
        listWhere = (
        "(:vendor IS NOT NULL AND vendor = :vendor AND dm_bunit = :dm_bunit AND dm_department = :dm_maintdept and AMCREWTYPE=:DM_CREWTYPE ) "
        "OR "
        "(:vendor IS NULL AND dm_bunit = :dm_bunit AND dm_department = :dm_maintdept  and AMCREWTYPE=:DM_CREWTYPE  )"
    )
    else :
        listWhere = (
            "(:vendor IS NOT NULL AND vendor = :vendor "
            "AND dm_bunit = :dm_bunit "
            "AND dm_department = :dm_maintdept) "
            "OR "
            "(:vendor IS NULL AND dm_bunit = :dm_bunit AND dm_department = :dm_maintdept    )"
        )
    service.log("listWhere: " + listWhere)
else:
    domainid = 'DM_AMCREW'