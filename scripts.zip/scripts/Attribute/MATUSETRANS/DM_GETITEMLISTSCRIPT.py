from psdi.mbo import Mbo
from psdi.mbo import MboConstants
from psdi.mbo import MboSet
from psdi.util import MXApplicationException


def setError(Msg):
		#global errorkey,errorgroup,params
		#errorkey='scriptvalidationerror'
		#errorgroup='scriptval'
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)



app = mbo.getThisMboSet().getParentApp()



if launchPoint == "DM_GETITEMLIST" and  app != "DM_PLUSGWO_DCL":
        domainid = "DM_ITEMLIST"

if launchPoint == "DM_GETITEMLIST" and  app == "DM_PLUSGWO_DCL":
       domainid = "DM_DCLITEMLIST" 
   
    
if launchPoint == "DM_MATUSERLIST":
    
   # matset =mbo.getMboSet("MATUSETRANS")
    matset =mbo.getThisMboSet()
    mcount =matset.count()
    if mcount is not None: 
        mrecord = matset.moveFirst()
        while(mrecord):
            mitem= mrecord.getString("itemnum")
            #sitem=" (select itemnum from item where  rotating=0 and status in ('ACTIVE', 'PENDOBS'))"
            conKey = ""
            con = ""
            s = ""
        
            try:
                conKey = mbo.getThisMboSet().getUserInfo().getConnectionKey();
                con = mbo.getThisMboSet().getMboServer().getDBConnection(conKey)
                s = con.createStatement()
                val ="select itemnum from item where  rotating=0 and itemnum='"+mitem+"' and status in ('ACTIVE', 'PENDOBS')";
                rs = s.executeQuery(val)
                if rs.next() is not None:
                                            
                                      break;
                else:
                    setError("Please specify an item number in a valid status") 
            finally:
                    if s != "":
                        s.close()
                    if conKey != "" and con != "":
                        mbo.getThisMboSet().getMboServer().freeDBConnection(conKey)
        mrecord = matset.moveNext()