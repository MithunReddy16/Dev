#Author        : ram
#Created Date  : 30-Jul-2026
#Remarks       : Default LINETYPE to Material and make it read-only for new rows in the Actuals > Materials table. Applies only in the Work Order application.

from psdi.mbo import MboConstants

owner = mbo.getOwner()

if owner is not None and interactive:
    app = mbo.getThisMboSet().getParentApp()

    if app=='DM_PLUSGWO_SRWN':
        mbo.setValue("LINETYPE", "MATERIAL",2L)
        mbo.setFieldFlag("LINETYPE", MboConstants.READONLY, True)