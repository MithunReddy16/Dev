/*
Script: DM_MATUSETRANS.MATRECTRANSID
Created By: Ashok
Date: 16-Aug-2024
Req: 1. Copy the values from matrectrans to matusetrans DM_WPITEMID,DM_CONTREFLINEID
*/
load("nashorn:mozilla_compat.js");
importPackage(java.util)
importPackage(Packages.psdi.server)
importPackage(Packages.psdi.mbo)
importPackage(Packages.psdi.util.logging)
importPackage(Packages.psdi.app.contract.purch)
importPackage(Packages.psdi.app.contract.software)
importPackage(Packages.psdi.security)

//from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.dm")
logger.error("***ASH***Sript DM_MATUSETRANS.MATRECTRANSID**START***launchpoint="+launchPoint)
logger.error("***ASH***Sript DM_MATUSETRANS.MATRECTRANSID**matrectransid="+mbo.getString("MATRECTRANSID"))
logger.error("***ASH***Sript DM_MATUSETRANS.MATRECTRANSID**owner="+mbo.getOwner())
if(mbo.getOwner()!=null)
{
	logger.error("***ASH***Sript DM_MATUSETRANS.MATRECTRANSID**owner Name="+mbo.getOwner().getName())
	if(mbo.getOwner().getName()=="MATRECTRANS")
	{
		logger.error("***ASH***Sript DM_MATUSETRANS.MATRECTRANSID**Before SetValue")
		mbo.setValue("DM_WPITEMID",mbo.getOwner().getLong("DM_WPITEMID"),2)
		mbo.setValue("DM_CONTREFLINEID",mbo.getOwner().getLong("DM_CONTREFLINEID"),2)
		logger.error("***ASH***Sript DM_MATUSETRANS.MATRECTRANSID**After SetValue")
	}
}
/*
matrectransMbo=mbo.getMboSet("$MATRECTRANS","MATRECTRANS","MATRECTRANSID=:MATRECTRANSID").getMbo(0);
logger.error("***ASH***Sript DM_MATUSETRANS.MATRECTRANSID**START***matrectransMbo="+matrectransMbo)
if(matrectransMbo!=null)
{
	mbo.setValue("DM_WPITEMID",matrectransMbo.getLong("DM_WPITEMID"),2)
	mbo.setValue("DM_CONTREFLINEID",matrectransMbo.getLong("DM_CONTREFLINEID"),2)
}
*/
logger.error("***ASH***Sript DM_MATUSETRANS.MATRECTRANSID**END***launchpoint="+launchPoint)