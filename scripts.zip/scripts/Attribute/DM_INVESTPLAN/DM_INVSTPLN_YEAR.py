# script to validate the value of investment plan year. 
# user can create one plan only per year

from java.util import Calendar
from psdi.util import MXApplicationException


if mbo.getString("TYPE")== "MAIN":
    year = mbo.getString("year")
    opportMboSet = mbo.getMboSet("DM_INVSTPLAN_YEAR","DM_INVESTPLAN","year=:year and TYPE='MAIN' and status !='CAN' ")
    if opportMboSet.count() != 0 :
        service.error("dm_invst","dm_duplicatedyear",[year])


# Get current year
currentYear = Calendar.getInstance().get(Calendar.YEAR)

# Get value entered in field
yearValue = mbo.getInt("YEAR")
# Validation
if yearValue < currentYear:
    service.error("dm_invst","dm_invalidyear")