#DM_BUDGETLINE_FLD

def setError(Msg):
		#global errorkey,errorgroup,params
		#errorkey='scriptvalidationerror'
		#errorgroup='scriptval'
		params=[Msg]
		service.error('scriptval','scriptvalidationerror',params)
        
if launchPoint == 'BUDGETLINE_NEED':
	if not mbo.isNull('Need'):
		if mbo.getString('Need') !='New Asset':
			mbo.setValue('Quantity',1.00)
			mbo.setValueNull('Itemnum',2L)
			mbo.setValueNull('REASON')
			mbo.setValueNull('REQUIREDQ')
			mbo.setValueNull('PRIORITY')
			mbo.setValueNull('ROI')
			mbo.setValueNull('ROIUNIT')
			mbo.setValueNull('INITIATIVENAME')
			mbo.setValueNull('EXPECTEDCOST')
			mbo.setValueNull('ANNUALDEMAND')
			mbo.setValueNull('SSLINK')
			mbo.setValueNull('MGMTREF')
			mbo.setValueNull('REMARKS')
		else:
			mbo.setValueNull('assetnum',2L)
			
elif launchPoint == 'BUDGETLINE_ITEMNUM' or launchPoint == 'BUDGETLINE_ASSETNUM':
	if FLD == '' or FLD == None:
		mbo.setValue('DM_CENTRAL',False)
		mbo.setValueNull('DM_CENTRALDEPARTMENT')
		mbo.setValueNull('ROI')
		mbo.setValueNull('ROIUNIT')
	elif launchPoint == 'BUDGETLINE_ASSETNUM':
		AssetMboSet = mbo.getMboSet('ASSET')
		if not AssetMboSet.isEmpty():
			if AssetMboSet.getMbo(0).getString('STATUS') == 'DECOMMISSIONED':
				setError('Invalid Asset Status')