#DM_GENERATE_BUDGETLINENUM

if mbo.isNew() and mbo.isNull('BUDGETLINENUM'):
	thisSet = mbo.getThisMboSet()
	newLineNum = thisSet.max('BUDGETLINENUM') + 1
	mbo.setValue('BUDGETLINENUM',newLineNum)